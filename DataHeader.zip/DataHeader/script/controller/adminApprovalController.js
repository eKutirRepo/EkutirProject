'use strict';
var reuseArrayHeader;
MyApp.controller('AdminApprovalController', ['$scope', 'ApproveAdminService', function($scope, ApproveAdminService) {
	
	$scope.showListOfApproval = function () {
		
		ApproveAdminService.showListOfApproval()
		.then(function(data){
		showReuseTable(data.object)
		},function(data){
			console.log(data)
		});
	};
	

	$scope.myfunction = function (data) {
        ApproveAdminService.getAdminDetails(data)
		.then(function(data){
		showReuseTable(data.object)
		},function(data){
			console.log(data)
		});
        
        
        
    };
	
	
    
    
    
    
          
}]);

reuseArrayHeader = [
	
	{ "sTitle": "SL. NO#", "mData": "id" },
	{ "sTitle": "Email", "mData": "email" },
	{ "sTitle": "Phone", "mData": "phone" },
	{ "sTitle": "Status", "mData": "activeStatus" },
	{ "sTitle": "Enabled", "mData": "isenabled" },
	{ "sTitle": "Action", "sDefaultContent": '<a href="#" class="btn btn-primary btn-xs"  onclick="viewDetails(this)" ><i class="fa fa-folder"></i> View </a><a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Approve </a><a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Reject </a>' }
	 

	]
function showReuseTable(jsonData){

	$('#datatableId').addClass('nowrap').dataTable({
		"aaData": jsonData,
		dom: 'lBfrtip',
		"bFilter" : true, 
		"bPaginate": true,
		"lengthMenu": [5,10,15,20],
		buttons: ['excel' , 'print','copyHtml5'],
		// "scrollY": 200,
		fixedHeader: true,

		"scrollX": true,
		"aoColumns":reuseArrayHeader

	}); 
	
}
var table;
var emailForcheck;
function viewDetails(el) {
	table= $('#datatableId').DataTable();
	$('#datatableId tbody').on( 'click', 'tr', function () {
		
		emailForcheck=table.row($(this)).data().email;
		//angular.element(document.getElementById('AdminApprovalController')).scope().makeAlert('This is for Test');
		
		
		 angular.element(document.getElementById('approvalId')).scope().myfunction(emailForcheck);
		
		 table.reload();
	
	});
}








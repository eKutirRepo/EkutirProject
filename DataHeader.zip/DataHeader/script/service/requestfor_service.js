'use strict';
MyApp.factory('AdminService', ['$http', '$q', function($http, $q){

var AdminService={
			requestForAdmin:requestForAdmin	
	}
	return AdminService;
	
	function requestForAdmin(admin){
	
		var defer = $q.defer(admin);

		$http.post("http://localhost:8082/api/register",JSON.stringify(admin))
			.success(function(response) {
				defer.resolve(response);
			})
			.error(function(err) {
				defer.reject(err);
			});
		
	/*	var config={
				headers:{
				"Accept" : "application/json",
				"Content-Type" : "application/json"
				}
		}
		var data=admin;
		$http.post('http://localhost:8082/register',data,config)
		.success(function(response) {
			defer.resolve(response);
		})
		.error(function(err) {
			defer.reject(err);
		}); */
			
		/*
		$http({
		       method: 'POST',
		       url: 'http://localhost:8082/api/register',
		       data: JSON.stringify(admin),
		 
		}).success(function(response) {
			defer.resolve(response);
		})
		.error(function(err) {
			defer.reject(err);
		}); 
		
		
		return defer.promise;
	}*/
		return defer.promise;
	}

}]);

'use strict';
MyApp.factory('ApproveAdminService', ['$http', '$q', function($http, $q){

var ApproveAdminService={
		showListOfApproval:showListOfApproval,
		getAdminDetails:getAdminDetails,
		approveUser:approveUser
	}
return ApproveAdminService;
	
	function showListOfApproval(){
	
		var defer = $q.defer();
		
		$http.get("http://localhost:8082/api/pendingApproval")
			.success(function(response) {
				console.log(response);
				defer.resolve(response);
			})
			.error(function(err) {
				console.log(err);
				defer.reject(err);
			});
			
		return defer.promise;
	}
	
	function approveUser(user, token){
		
		var defer = $q.defer();
		var config={
				headers:{
				"Authorization":"Bearer "+ token.access_token,
				"Accept" : "application/json",
				"Content-Type" : "application/json"
				}
		}
		$http.get("http://localhost:8082/api/approveuser?email="+user,config)
			.success(function(response) {
				console.log(response);
				defer.resolve(response);
			})
			.error(function(err) {
				console.log(err);
				defer.reject(err);
			});
			
		return defer.promise;
	}
	
	
	
/*  function getAdminDetails(data) {
        var url = "http://localhost:8082/api/admindetails?email="+data;
        var defer = $q.defer();
        $http.get(url)
            .success(function (response) {
                defer.resolve(response);
            })
            .error(function (err) {
                defer.reject(err);
            })

        return defer.promise;
    }
	*/
	
	function getAdminDetails(emailval){
		
		var defer = $q.defer();
		
		$http({
		    url: 'http://localhost:8082/api/admindetails?email='+emailval, 
		    method: "GET",
		    headers: {
	            'Content-Type': 'application/json'
		    }
		 }).success(function(response) {
				console.log(response);
				defer.resolve(response);
		})
		.error(function(err) {
				console.log(err);
				defer.reject(err);
		});
		
	
	}
	
		

}]);

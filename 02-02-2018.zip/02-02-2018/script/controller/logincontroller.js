'use strict';

MyApp.controller('LoginController', ['$scope', 'LoginService','AuthService', function($scope, LoginService, AuthService) {
	
		$scope.login=function(){
		console.log($scope.user);
		$('#progress').show();
		AuthService.generateBasicAuth()
		
		.then(function(data){
			console.log(data);
				if(data.object==""){
					console.log(data);
				}else{
					console.log(data);
					AuthService.getAuthToken($scope.user, data.object)
					.then(function(data){
						console.log(data)
						
						$.jStorage.set("user", data.object);
						$.jStorage.set("token", data.object.loginToken);
						if(data.object.loginToken.access_token==null){
							console.log(data.object.loginToken.error_description);
						}else{
							$('#progress').hide();
							if(data.object.role.toUpperCase()=="ROLE_ADMIN" && data.object.profilecompletedstatus==0){
						
							  window.location.href="http://localhost:8080/sanimarkWeb/admin-home.html";
							  
							}else if(data.object.role.toUpperCase()=="ROLE_ADMIN" && data.object.profilecompletedstatus==1){
								
								 window.location.href="http://localhost:8080/sanimarkWeb/admindashboard.html";
							}
							
							else if(data.object.role.toUpperCase()=="ROLE_SUPER_ADMIN" && data.object.profilecompletedstatus==3){
								console.log("success coming");
							  window.location.href="http://localhost:8080/sanimarkWeb/home.html";
							}
						}
					},function(data){
						$('#progress').hide();
						console.log(data)
					});
				
			}
		},function(data){
			$('#progress').hide();
			console.log(data)
		});
		
		}
		
		/*LoginService.login($scope.user)
		.then(function(data){
		console.log(data)
		},function(data){
			console.log(data)
		});*/
          
}]);
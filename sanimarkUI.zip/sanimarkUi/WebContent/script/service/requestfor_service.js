'use strict';
MyApp.factory('AdminService', ['$http', '$q', function($http, $q){

	var UserService={
			requestForAdmin:requestForAdmin	
	}
	return AdminService;
	
	function requestForAdmin(user){
		var defer = $q.defer(user);
		
		$http.post("https://db79817c-cb65-447d-8ac0-86a5c1d2ff7d.predix-uaa.run.aws-usw02-pr.ice.predix.io")
			.success(function(response) {
				defer.resolve(response);
			})
			.error(function(err) {
				defer.reject(err);
			});
			
		return defer.promise;
	}
	
		

}]);

'use strict';
MyApp.factory('ApproveAdminService', ['$http', '$q', function($http, $q){

var ApproveAdminService={
		showListOfApproval:showListOfApproval	
	}
return ApproveAdminService;
	
	function showListOfApproval(){
	
		var defer = $q.defer();
		
		$http.get("http://localhost:8082/api/pendingApproval")
			.success(function(response) {
				console.log(response);
				defer.resolve(response);
			})
			.error(function(err) {
				console.log(err);
				defer.reject(err);
			});
			
		return defer.promise;
	}
	
		

}]);

'use strict';
MyApp.factory('RegisterService', ['$http', '$q', function($http, $q){

var RegisterService={
		registerforAdmin:registerforAdmin	
	}
	return RegisterService;
	
	function registerforAdmin(admin){
	
		var defer = $q.defer(admin);
		$http({
		       method: 'POST',
		       url: 'http://localhost:8082/api/registeradmin',
		       data: JSON.stringify(admin),
		        headers: {
		            'Content-Type': 'application/json'
		   }
		}).success(function(response) {
			defer.resolve(response);
		})
		.error(function(err) {
			defer.reject(err);
		}); 
		
		
	/*	
		
		
		
		
		$http.post("http://localhost:8082/api/registeradmin",JSON.stringify(admin))
			.success(function(response) {
				defer.resolve(response);
			})
			.error(function(err) {
				defer.reject(err);
			});*/
			
		return defer.promise;
	}
	
		

}]);

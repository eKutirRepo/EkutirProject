'use strict';
var reuseArrayHeader;
MyApp.controller('AdminApprovalController', ['$scope', 'ApproveAdminService', function($scope, ApproveAdminService) {
	
	$scope.showListOfApproval = function () {
		
		ApproveAdminService.showListOfApproval()
		.then(function(data){
		showReuseTable(data)
		},function(data){
			console.log(data)
		});
	};
          
}]);

reuseArrayHeader = [
	{ "sTitle": "Email", "mData": "email" },
	{ "sTitle": "Phone", "mData": "phone" },
	{ "sTitle": "Status", "mData": "activeStatus" },
	{ "sTitle": "Enabled", "mData": "isenable" }

	]
function showReuseTable(jsonData){
	$('#datatableId').addClass( 'nowrap' ).dataTable({
		"aaData": jsonData,
		dom: 'lBfrtip',
		"bFilter" : true, 
		"bPaginate": true,
		"lengthMenu": [5,10,15,20],
		buttons: ['excel' , 'print','copyHtml5'],
		// "scrollY": 200,
		fixedHeader: true,

		"scrollX": true,
		"aoColumns":reuseArrayHeader

	}); 
	
}
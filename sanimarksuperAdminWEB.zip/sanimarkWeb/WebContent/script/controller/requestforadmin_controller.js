'use strict';

MyApp.controller('RequestAdminController', ['$scope', 'AdminService', function($scope, AdminService) {
	
	$scope.requestForAdmin=function(){
		console.log($scope.admin);
		AdminService.requestForAdmin($scope.admin)
		.then(function(data){
			if(data.status==200){
				
				
			}
		},function(data){
			console.log(data)
		});
	}
          
}]);

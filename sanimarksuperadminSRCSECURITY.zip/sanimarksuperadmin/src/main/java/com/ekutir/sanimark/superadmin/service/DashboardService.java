package com.ekutir.sanimark.superadmin.service;

import java.util.List;

import com.ekutir.sanimark.superadmin.entity.SaniProduct;
import com.ekutir.sanimark.superadmin.entity.SupplierDetails;

public interface DashboardService {

	Long getToatlSupplier();

	Long getTotalMictoEnreprenure();

	Long getTotalProduct();

	Long getTotalTotalItem();

	Long getTotalOrder();

	Double getTotalTransaction();

	List<SupplierDetails> totalSupplier();

	List<SaniProduct> totalproduct();

	List<Object[]> topfiveproduct();



}

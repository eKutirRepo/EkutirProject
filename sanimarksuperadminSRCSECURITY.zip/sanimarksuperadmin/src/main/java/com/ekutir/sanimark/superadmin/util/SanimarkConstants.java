package com.ekutir.sanimark.superadmin.util;

/**
 * Classname : SRDHConstants.java <br>
 *
 * @Create Date : 22 Feb 2012
 *
 * @author : Mahindra Satyam
 * @Version information : 1.0
 * @Class Description : Class
 *         which holds the constants of SRDH.
 *
 */
public final class SanimarkConstants {

	
	public static final String DATABASE_TYPE = "databaseType";
	public static final String COMMON_SCHEMA_NAME = "hibernate.defaultSchema.common";
	public static final String SEEDING_SCHEMA_NAME = "hibernate.defaultSchema.seeding";
	public static final String TEMP_SCHEMA_NAME = "hibernate.defaultSchema.querybuilder";

	public static final String CRITICAL_EXCEPTION = "::CRITICAL EXCEPTION::";
	public static final String LDAP_ACTION = "/srdhportal/LdapConfig.action";
	public static final String SRDHLOGIN_ACTION = "/srdhportal/login.action";
	public static final String STATELOGIN_ACTION = "/srdhportal/LoginStateLdap.action";
	public static final String FRISTLOGIN_ACTION = "/srdhportal/firstlogin.action";
	public static final String FORGOT_PASSWORD_ACTION = "/srdhportal/forgotPassword.action";
	public static final String VIEW_FORGOT_PASSWORD_PAGE="/srdhportal/viewForgotPasswordAction.action";
	public static final String SELF_SERVICE_ACTION = "/srdhportal/selfregister.action";
	public static final String SELF_SERVICE_REGISTER_ACTION = "/srdhportal/registerselfservice.action";
	public static final String SELF_SERVICE_REGISTER_BACK_ACTION = "/srdhportal/selfserviceback.action";
	public static final String SELF_SERVICE_OTP_REGISTER_ACTION = "/srdhportal/otpregisterselfservice.action";
	public static final String SELF_SERVICE_OTP_REGISTER_BACK_ACTION = "/srdhportal/otpregisterselfserviceback.action";
	public static final String SELF_SERVICE_UID_ACTION = "/srdhportal/selfserviceuid.action";
	public static final String SELF_SERVICE_OTP_ACTION = "/srdhportal/otpselfservice.action";
	public static final String SELF_SERVICE_INSERT_RECORD = "/srdhportal/selfServiceInsertAction.action";
	public static final String SELF_SERVICE_MODIFY_RECORD = "/srdhportal/selfServiceModifyAction.action";
	public static final String SELF_SERVICE_INSERT_TRANSLIT_ACTION = "/srdhportal/insertSelfServiceTransLitAction.action";
	public static final String SELF_SERVICE_MODIFY_TRANSLIT_ACTION = "/srdhportal/modifySelfServiceTransLitAction.action";
	
	public static final String MANAGE_KYR = "/srdhportal/modifytransLitAction";
	public static final String INSERT_RECORD = "/srdhportal/menuInsertRecord";
	public static final String INSERT_RECORD1 = "/srdhportal/insertRecordAction";
	public static final String MODIFY_RECORD = "/srdhportal/menuAdvancedSearch";
	public static final String MODIFY_RECORD1 = "/srdhportal/modifyRecordAction";
	public static final String MODIFY_RECORD2 = "/srdhportal/organicModify";
	public static final String XML_UPLOAD = "/srdhportal/menuUploadEIDUIDXml";
	public static final String XML_UPLOAD1 = "/srdhportal/userFileUpload";
	public static final String XML_UPLOAD2 = "/srdhportal/userFileView";
	public static final String XML_INBOX = "/srdhportal/menuUploadEIDUIDXmlInbox";
	
	public static final String SEEDING_MANUAL = "/srdhportal/menuManualSeeding";
	public static final String SEEDING_MANUAL1 = "/srdhportal/manualSeeding";
	public static final String SEEDING_MANUAL2 = "/srdhportal/manualSeedingExport";
	public static final String SEEDING_BATCH = "/srdhportal/menuBatchSeeding";
	public static final String SEEDING_BATCH1 = "/srdhportal/csvFileUpload";
	public static final String SEEDING_BATCH2 = "/srdhportal/templateDownload";
	public static final String SEEDING_INBOX = "/srdhportal/gotoInbox";
	public static final String SEEDING_INBOX1 = "/srdhportal/paginatedCsvListAction";
	public static final String SEEDING_INBOX2 = "/srdhportal/deleteFile";
	
	public static final String VAULT = "/srdhportal/vaultdownload";
	public static final String VAULT1 = "/srdhportal/menuVaultDownloadInbox";
	public static final String VAULT2 = "/srdhportal/vaultdownloadFileView";
	public static final String VAULT3 = "/srdhportal/vaultdownloadoverwrite";
	public static final String VAULT4 = "/srdhportal/vaultdownloadoverwritecancel";
	public static final String VAULT_UPLOAD = "/srdhportal/menuVaultUpload";
	public static final String VAULT_UPLOAD1 = "/srdhportal/vaultuserFileUpload";
	public static final String VAULT_UPLOAD2 = "/srdhportal/vaultuploadoverwrite";
	public static final String VAULT_UPLOAD3 = "/srdhportal/vaultuploadoverwritecancel";
	public static final String VAULT_UPLOAD4 = "/srdhportal/vault";
	public static final String VAULT_CATALOGUE = "/srdhportal/menuVaultInbox";
	public static final String VAULT_CATALOGUE1 = "/srdhportal/vaultuserFileView";
	
	public static final String QUERY_BUILDER = "/srdhportal/menuQueryBuilderConnect";
	public static final String QUERY_BUILDER1 = "/srdhportal/goToConnect";
	public static final String QUERY_BUILDER2 = "/srdhportal/Radio";
	public static final String QUERY_BUILDER3 = "/srdhportal/cancelToConnect";
	public static final String QUERY_BUILDER4 = "/srdhportal/viewQueryBuilder";
	public static final String QUERY_BUILDER5 = "/srdhportal/exportQueryResults";
	public static final String QUERY_BUILDER6 = "/srdhportal/FinishQueryBuilder";
	public static final String QUERY_BUILDER7 = "/srdhportal/queryBuilderPageNumberAction";
	public static final String QUERY_BUILDER8 = "/srdhportal/queryBuilderExport";
	public static final String QUERY_BUILDER9 = "/srdhportal/cancel";
	public static final String QUERY_BUILDER10 = "/srdhportal/delete";
	public static final String QUERY_BUILDER11 = "/srdhportal/go";
	public static final String QUERY_BUILDER12 = "/srdhportal/savdqry";
	public static final String QUERY_BUILDER13 = "/srdhportal/pageActionSavedQueries";
	public static final String QUERY_BUILDER14 = "/srdhportal/menuQueryBuilderQueries";
	public static final String QUERY_BUILDER15 = "/srdhportal/selectQuery";
	public static final String QUERY_BUILDER16 = "/srdhportal/saveQueryResults";
	
	public static final String ADMIN = "/srdhportal/pageActionRole";
	public static final String REPORTS = "/srdhportal/reportsAction";
	
	public static final String USER_ADD = "/srdhportal/menuAddUser";
	public static final String USER_ADD1 = "/srdhportal/viewAddUser";
	public static final String USER_MODIFY = "/srdhportal/menuModifyUser";
	public static final String USER_MODIFY1 = "/srdhportal/viewModifyUser";
	public static final String USER_DELETE = "/srdhportal/menuDeleteUser";
	public static final String USER_DELETE1 = "/srdhportal/viewDeleteUser";
	
	public static final String USER_ACCESS_PERMISSION = "/srdhportal/menuAddUser";  // Add by Prasanta
	public static final String USER_ACC_PER_ADD = "/srdhportal/menuAddUserAccPer";
	//public static final String USER_ACC_PER_MODIFY = "/srdhportal/menuModifyUser";
	//public static final String USER_ACC_PER_DELETE = "/srdhportal/viewModifyUser";
	//public static final String USER_DELETE = "/srdhportal/menuDeleteUser";
	//public static final String USER_DELETE1 = "/srdhportal/viewDeleteUser";
	
	
	
	public static final String ROLE_ADD = "/srdhportal/menuAddRole";
	public static final String ROLE_ADD1 = "/srdhportal/addRole";
	public static final String ROLE_MODIFY = "/srdhportal/menuModifyRole";
	public static final String ROLE_MODIFY1 = "/srdhportal/modifyRole";
	public static final String ROLE_DELETE = "/srdhportal/menuDeleteRole";
	public static final String ROLE_DELETE1 = "/srdhportal/deleteRole";
	
	public static final String EXT_DB = "/srdhportal/pageActionExternalDB";
	public static final String EXT_DB_ADD = "/srdhportal/menuAddExternaldb";
	public static final String EXT_DB_ADD1 = "/srdhportal/viewAddExternalDB";
	public static final String EXT_DB_MODIFY = "/srdhportal/menuModifyExternaldb";
	public static final String EXT_DB_MODIFY1 = "/srdhportal/viewModifyExternalDB";
	public static final String EXT_DB_DELETE = "/srdhportal/menuDeleteExternaldb";
	public static final String EXT_DB_DELETE1 = "/srdhportal/viewDeleteExternalDB";
	

	public static final String SELF_SERVICE = "/srdhportal/selfservice.action";
	public static final String SELF_SERVICE_LOGOUT = "/srdhportal/selfservicelogout.action";
	
	public static final String SESSION_TIME_OUT_PAGE = "sessiontimeout";
	public static final String RELOGIN_PAGE = "relogin";
	
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String FIRSTLOGIN = "FIRSTLOGIN";
	public static final String ERROR = "ERROR";
	public static final String RET_INPUT = "input";
	public static final String WRONG_INPUT = "wronginput";
	public static final String FIRST_TIME_LOGIN="firsttimelogin";
	
	public static final String TRUE = "True";
	public static final String FALSE = "False";
	
	public static final String YES = "Y";
	public static final String NO = "N";
	
	public static final String ASH = "#";
	
	public static final String GENDER_M = "M";
	public static final String GENDER_F = "F";
	public static final String GENDER_T = "T";
	
	public static final String GENDER_MALE = "Male";
	public static final String GENDER_FEMALE = "Female";
	public static final String GENDER_TRANS = "Transgender";
	
	public static final String EMPTY = "EMPTY";
	public static final String OVERRITE = "overrite";
	
	public static final String DATE_FORMAT_DDMMYYYY = "dd-MM-yyyy";
	public static final String DATE_FORMAT_DDMMMYYYY = "dd-MMM-yyyy";
	public static final String DATE_FORMAT_DDMMYYYYHHMMA = "dd-MM-yyyy hh:mm a";
	public static final String DATE_FORMAT_DDMMMYYYYHHMMA = "dd-MMM-yyyy hh:mm a";	
	public static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";
	public static final String DATE_FORMAT_DDMMYYYYHHMM="dd-MM-yy_hh-mm_a";
	public static final String DATE_FORMAT_YYYYMMDDHHMMSS = "yyyy-MM-dd hh:mm:ss";
	public static final String IMAGE_CONTENT_TYPE = "image/jpeg";
	
	public static final String SRDH_RESOURCES_BUNDLE="SRDHResources";
	public static final String DATABASE_RESOURCES_BUNDLE="databaseResources";
	public static final String AUA_RESOURCES_BUNDLE="authclient";
	public static final String AUA_AUTHENTICATION_REQUIRED="isAUAAuthenticationRequired";
	public static final String AUA_AUTHENTICATION_RESPONSE_PASS="PASS";
	public static final String AUA_AUTHENTICATION_RESPONSE_FAIL="FAIL";
	
	
	/*********************** ACTIVATE DEACTIVATE ******************************/
	public static final String ACTIVE = "Active";
	public static final String DEACTIVE = "De-Active";
	
	/**************************WRONG ATTEMPT **********************/
	public static final String ACTIVATETIME = "ActivateTime";
	public static final String USERMAXATTEMPTS = "UserMaxAttempts";
	
	
	/************ Login Starts ******************/
	public static final String LDAP_AUTH_REQ = "LdapAuthReqired";
	public static final String LDAP_AUTH_TYPE = "LdapAuthType";
	public static final String LDAP_TYPE="SRDHLDAP";
	public static final String LDAP_TYPE_STATE="STATELDAP";
	public static final String FIRST_LOGIN_YES = "FIRST_LOGIN_YES";
	public static final String FIRST_LOGIN_NO = "FIRST_LOGIN_NO";
	public static final String FIRST_LOGIN_FAIL = "FIRST_LOGIN_FAIL";
	public static final String DISPLAY_FLAG = "displayFlag";
	public static final String ROLE_NAME="roleName";
	public static final String EMAIL_ADMIN="Admin";
	
	public static final String EMAIL_FROM="email.from";
	public static final String EMAIL_PASSWORD="email.password";
	public static final String EMAIL_SMTPHOST="email.smtphost";
	public static final String EMAIL_IP="email.ip";
	public static final String EMAIL_SMTPAUTH="email.smtpauth";
	public static final String EMAIL_SMTPSTARTTLSENABLE="email.smtpstarttlsenable";
	public static final String EMAIL_SMTPPORT="email.smtpport";
	public static final String EMAIL_PORT="email.port";
	public static final String EMAIL_SUBJECT="email.subject";
	public static final String EMAIL_SUBJECT1="email.subject1";
	
	public static final String EMAIL_MESSAGETEXT="email.messageText";
	public static final String EMAIL_MESSAGETEXT1="email.messageText1";
	public static final String EMAIL_MESSAGETEXT2="email.messageText2";
	
	public static final String EMAIL_MESSAGETEXT5="email.messageText5";
	public static final String EMAIL_MESSAGETEXT6="email.messageText6";
	
	public static final String EMAIL_SUBJECT_DELETE_USER="email.subjectDeleteUser";
	public static final String EMAIL_MESSAGETEXT_DELETE_USER="email.messageTextDeleteUser";
	public static final String EMAIL_SUBJECT_GIVE_USER_ACCESS="email.subjectGiveUserAccess";
	public static final String EMAIL_MESSAGETEXT_GIVE_USER_ACCESS="email.messageTextGiveUserAccess";
	
	public static final String INVALID_USERNAME_PASSWORD="INVALID";
	public static final String INVALID_PASSWORD="FAILURE";
	public static final String INVALID_ATTEMPTS_USERNAME_PASSWORD="INVALIDATTEMPTS";
	
	public static final String DEACTIVATE_LIST = "DeactivateReasonList";
	
	public static final String VER_HIS_SIZE = "VersionHistorySize";
	
	public static final String SRDH_KEY = "SRDH_KEY";
	
	/************ Login Ends ******************/
	
	/************ Role Starts ******************/

	/*public static final String ROLENAME_REQUIRED ="The Role Name is mandatory.";
	public static final String PERMISSIONS_REQUIRED ="Screen Should not be Blank.Minimum one Screen Should be selected.";
	public static final String ROLENAME_EXISTS ="Role Name already exists.";
	public static final String ROLEWITHSAMEPERMISSIONS_EXISTS ="Role Name with the same set of access rights exists.";
	*/
	
	/************ Role Ends ******************/

}

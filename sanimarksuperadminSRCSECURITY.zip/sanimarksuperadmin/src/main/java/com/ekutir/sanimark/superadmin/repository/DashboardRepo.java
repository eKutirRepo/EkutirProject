package com.ekutir.sanimark.superadmin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekutir.sanimark.superadmin.entity.SaniProduct;
import com.ekutir.sanimark.superadmin.entity.SupplierDetails;


public interface DashboardRepo extends JpaRepository<SupplierDetails, Long> {
	
	
	String TOTALSUPPLIER="select count(*) from SupplierDetails where status=1";
	
	String TOTALProduct="select count(*) from SaniProduct where activeStatus=1";
	
	String TOTALITEM="select count(*) from SaniItem where status=1";
	
	String TOTALORDER="select count(*) from OrderEntity where status=1";
	
	String TOTALTRANSACTION="SELECT SUM(orderAmount) FROM OrderEntity where status=1";
	
	String TOTALSUPPLIERLIST="from SupplierDetails where status=1";
	
	String PRODUCTLIST="select productName,productDescription,createdDate,activeStatus from SaniProduct where activeStatus=1";
	
	//String TOPFIVEPRODUCT="select distinct(pd.product_name),sum(od.OrderQuantity)  as totalcount from tbl_order_details_master od,sani_product pd where pd.productid=od.ProductId group by od.ProductId  order by totalcount desc LIMIT 5";
		
	
	
	String TOPFIVEPRODUCT="SELECT sum(OrderQuantity) OQ,(SELECT itemname FROM dbsanimarkdlink.tbl_items where itemid=ProductId) itemName FROM dbsanimarkdlink.tbl_order_details_master group by ProductId order by OQ DESC LIMIT 5";
	@Query(TOTALSUPPLIER)
	Long countTotalSupplier();


	@Query(TOTALProduct)
	Long countTotalProduct();

	@Query(TOTALITEM)
	Long countTotalTotalItem();

	@Query(TOTALORDER)
	Long countTotalTotalOrder();

	@Query(TOTALTRANSACTION)
	Double countTotalTotalTransaction();

	@Query(TOTALSUPPLIERLIST)
	List<SupplierDetails> findTotalSupplier();

	@Query(PRODUCTLIST)
	List<SaniProduct> totalProductList();

	@Query(value =TOPFIVEPRODUCT,nativeQuery = true)
	List<Object[]> totalfiveproduct();
	

	
}

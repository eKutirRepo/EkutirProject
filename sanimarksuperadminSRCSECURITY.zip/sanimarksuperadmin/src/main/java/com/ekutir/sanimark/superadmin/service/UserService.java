
package com.ekutir.sanimark.superadmin.service;

import com.ekutir.sanimark.superadmin.dto.User;

public interface UserService {

	public User findByEmail(String email);


}

package com.ekutir.sanimark.superadmin.entity;

import java.io.Serializable;
import java.sql.Blob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_items")
public class SaniItem implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -5757178966250321050L;

	@Id
	@Column(name="itemid")
	private Long itemId;
	
	@Column(name="itemname")
	private String itemName;
	
	@Column(name="itembrand")    
	private String itemBrand;
	
	@Column(name="product_cat_id")
	private int productCatId;
	
	@Column(name="mrp")
	private Double mrp;
	
	@Column(name="selling_price")
	private Double sellingPrice;
	
	@Column(name="warranty")
	private String warrnty;
	
	@Column(name="dimension")
	private String dimension;
	
	@Column(name="item_description")
	private String itemDescripton;
	
	@Column(name="itemImage")
	private Blob itemImage;
	
	@Column(name="manufactureDate")
	private Date manufactureDate;
	
	@Column(name="expiryDate")
	private Date expiryDate;
	
	@Column(name="color")
	private String color;
	
	@Column(name="CreatedBy")
	private String createdBy;
	
	@Column(name="CreatedDateTime")
	private Date createdDate;
	
	@Column(name="UpdatedBy")
	private String updatedBy;
	
	@Column(name="UpdatedDateTime")
	private Date updatedDate;
	
	@Column(name="approvalStatus")
	private int status;

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemBrand() {
		return itemBrand;
	}

	public void setItemBrand(String itemBrand) {
		this.itemBrand = itemBrand;
	}

	public int getProductCatId() {
		return productCatId;
	}

	public void setProductCatId(int productCatId) {
		this.productCatId = productCatId;
	}

	public Double getMrp() {
		return mrp;
	}

	public void setMrp(Double mrp) {
		this.mrp = mrp;
	}

	public Double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(Double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getWarrnty() {
		return warrnty;
	}

	public void setWarrnty(String warrnty) {
		this.warrnty = warrnty;
	}

	public String getDimension() {
		return dimension;
	}

	public void setDimension(String dimension) {
		this.dimension = dimension;
	}

	public String getItemDescripton() {
		return itemDescripton;
	}

	public void setItemDescripton(String itemDescripton) {
		this.itemDescripton = itemDescripton;
	}

	public Blob getItemImage() {
		return itemImage;
	}

	public void setItemImage(Blob itemImage) {
		this.itemImage = itemImage;
	}

	public Date getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	
	
	
	

}

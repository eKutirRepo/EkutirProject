package com.ekutir.sanimark.superadmin.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.sanimark.superadmin.dto.User;
import com.ekutir.sanimark.superadmin.dto.UserProfileDTO;
import com.ekutir.sanimark.superadmin.service.RegistrationService;
import com.ekutir.sanimark.superadmin.service.SuperAdminService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@PropertySource(ignoreResourceNotFound = true, value = "classpath:application.properties")
@RestController
public class AdminController {
	
	@Autowired
	private RegistrationService registrationService;
	
	@Autowired
	private SuperAdminService superAdminService;
	
	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtil registerUser(@RequestBody User user){
		ResponseUtil response = new ResponseUtil();
		try {	
			response = registrationService.registerUser(user);
			if(response.getStatus()==200){
				response.setMessage("Request for Admin sent successfully.");
			}
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}

	@RequestMapping(value = "/registeradmin", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtil registerForAdmin(@RequestParam(value="loginuser") String loginuser, 
			@RequestBody UserProfileDTO userProfile){
		ResponseUtil response = new ResponseUtil();
		try {	
			System.out.println("userProfile : " + userProfile);
			response = registrationService.registerAdmin(userProfile, loginuser);
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}	
	
	
	
	
	

	@RequestMapping(value = "/pendingApproval", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil approvalPending(){
		ResponseUtil response = new ResponseUtil();
		List<com.ekutir.sanimark.superadmin.entity.User> userpendingList=null;
		List<User> userpending=null;
		int i=0;
		try {	
			userpendingList=registrationService.pendingApprovalList();
			userpending=new ArrayList<>();
			for(com.ekutir.sanimark.superadmin.entity.User useree:userpendingList){
				User user2=new User();
				
			
					user2.setId(useree.getId());
					user2.setEmail(useree.getEmail());
					user2.setPhone(useree.getPhone());
					user2.setFirstName("".equalsIgnoreCase(useree.getFirstName())?"":useree.getFirstName());
					user2.setLastName("".equalsIgnoreCase(useree.getLastName())?"":useree.getLastName());
					if(useree.getStatus()==0){
						user2.setActiveStatus("Not Active");
					}else{
						user2.setActiveStatus("Active");
					}
					if(useree.getEnabled()==0){
						user2.setIsenabled("Disable");
					}else{
						user2.setIsenabled("Enable");
					}
					userpending.add(user2);
				}
		
			if(!userpending.isEmpty()){
				response.setStatus(200);
				response.setObject(userpending);
			}else{
				response.setStatus(400);
				response.setObject(null);
			}
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}
	
	@RequestMapping(value = "/admindetails/{email}", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil getAdminDetails(@RequestParam(value="email") String email){
		ResponseUtil response = new ResponseUtil();

		 com.ekutir.sanimark.superadmin.entity.User userByemail;
		try {	
		   
			userByemail=registrationService.getAdminDetails(email);
			if(userByemail!=null){
				response.setStatus(200);
				response.setObject(userByemail);
			}else{
				response.setStatus(400);
				response.setObject(null);
			}
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}
	
	
	@RequestMapping(value = "/approveuser", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil approveUser(@RequestParam(value="email") String email){
		ResponseUtil response = new ResponseUtil();
		try {	
			response=superAdminService.approveUser(email);
			if(response.getStatus()==200){
				response.setMessage("User \""+ email +"\" approved successfully.");
			}
		}catch (Exception ex) {
			ex.printStackTrace();
			
			return response;
		}
		return response;
	}

	
	
}

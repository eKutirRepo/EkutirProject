package com.ekutir.sanimark.superadmin.logging;

public class SanimarkLogging {

}

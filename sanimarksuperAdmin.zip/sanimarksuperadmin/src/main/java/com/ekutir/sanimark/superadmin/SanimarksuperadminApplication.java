package com.ekutir.sanimark.superadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SanimarksuperadminApplication{

	public static void main(String[] args) {
		SpringApplication.run(SanimarksuperadminApplication.class, args);
	}
	

}

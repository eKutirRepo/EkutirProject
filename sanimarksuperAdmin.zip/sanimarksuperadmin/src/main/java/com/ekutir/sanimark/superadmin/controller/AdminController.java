package com.ekutir.sanimark.superadmin.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.sanimark.superadmin.dto.User;
import com.ekutir.sanimark.superadmin.service.RegistrationService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@RestController
public class AdminController {
	
	@Autowired
	private RegistrationService registrationService;
	
	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtil registerUser(@RequestBody @Valid final User user){
		ResponseUtil response = new ResponseUtil();
		try {	
			registrationService.registerUser(user);
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}
}

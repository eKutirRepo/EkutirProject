package com.ekutir.sanimark.superadmin.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.sanimark.superadmin.dto.AdminDetails;
import com.ekutir.sanimark.superadmin.dto.User;

import com.ekutir.sanimark.superadmin.service.RegistrationService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@RestController
public class AdminController {
	
	@Autowired
	private RegistrationService registrationService;
	
	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtil registerUser(@RequestBody @Valid final User user){
		ResponseUtil response = new ResponseUtil();
		try {	
			registrationService.registerUser(user);
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}

	@RequestMapping(value = "/registeradmin", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtil registerForAdmin(@RequestBody @Valid final AdminDetails admin){
		ResponseUtil response = new ResponseUtil();
		try {	
			
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}
	
	
	@RequestMapping(value = "/pendingApproval", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil approvalPending(){
		ResponseUtil response = new ResponseUtil();
		
		List<com.ekutir.sanimark.superadmin.entity.User> userpendingList=null;
		
		List<User> userpending=null;
		
		try {	
			userpendingList=registrationService.pendingApprovalList();
			userpending=new ArrayList<>();
			for(com.ekutir.sanimark.superadmin.entity.User useree:userpendingList){
				
				User user2=new User();
				
				user2.setEmail(useree.getEmail());
				
				user2.setPhone(useree.getPhone());
				
				user2.setFirstName("".equalsIgnoreCase(useree.getFirstName())?"":useree.getFirstName());
				user2.setLastName("".equalsIgnoreCase(useree.getLastName())?"":useree.getLastName());
				
				if(useree.getStatus()==0){
					user2.setActiveStatus("Not Active");
				}else{
					user2.setActiveStatus("Active");
				}
				
				
				if(useree.getEnabled()==0){
					user2.setIsenable("Disable");
				}else{
					user2.setIsenable("Enable");
				}
				
				
				userpending.add(user2);
				
			}
			
			
			
			
			if(!userpending.isEmpty()){
				
				response.setStatus(200);
				response.setObject(userpending);
				
			}else{
				response.setStatus(400);
				response.setObject(null);
			}
			
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}
	
	
	
}

package com.ekutir.sanimark.superadmin.controller;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@PropertySource(ignoreResourceNotFound = true, value = "classpath:application.properties")
@RestController
public class BaseController {

	@Value("${authentication.oauth.clientid}")
	private  String clientId;
	
	@Value("${authentication.oauth.secret}")
	private  String clientSecret;
	
	@RequestMapping(value="/auth/header", produces="application/json", method=RequestMethod.GET)
	public ResponseEntity<ResponseUtil> getBasicAuthToken(){
		String authStringEnc="";
		ResponseUtil response = new ResponseUtil();
		if(StringUtils.isNotEmpty(clientId) && StringUtils.isNotBlank(clientSecret)){
		String authString=clientId+":"+clientSecret;
		byte[] authEncBytes = Base64.encodeBase64(authString.getBytes());
		 authStringEnc = new String(authEncBytes);
		 response.setObject(authStringEnc);
		}else{
			response.setObject(authStringEnc);
		}
		return new ResponseEntity<ResponseUtil>(response, HttpStatus.OK);
	}
}

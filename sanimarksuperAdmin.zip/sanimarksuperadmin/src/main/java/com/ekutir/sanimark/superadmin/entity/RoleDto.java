package com.ekutir.sanimark.superadmin.entity;

public class RoleDto {

}

package com.ekutir.sanimark.superadmin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekutir.sanimark.superadmin.entity.User;

public interface UserRepo extends JpaRepository<User, Long> {

	String SERACHPENDINGLIST="select email,firstName,lastName,phone,status,enabled from User";
	
	
	public User findByEmail(String email);

	@Query(SERACHPENDINGLIST)
	List<com.ekutir.sanimark.superadmin.entity.User> findpendingApprovals();
}

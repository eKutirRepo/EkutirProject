package com.ekutir.sanimark.superadmin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.ekutir.sanimark.superadmin.entity.SupplierDetails;


public interface DashboardRepo extends JpaRepository<SupplierDetails, Long> {
	
	
	String TOTALSUPPLIER="select count(*) from SupplierDetails where status=1";
	
	String TOTALProduct="select count(*) from SaniProduct where activeStatus=1";
	
	String TOTALITEM="select count(*) from SaniItem where status=1";
	
	String TOTALORDER="select count(*) from OrderEntity where status=1";
	
	String TOTALTRANSACTION="SELECT SUM(orderAmount) FROM OrderEntity where status=1";

	
	
	@Query(TOTALSUPPLIER)
	Long countTotalSupplier();


	@Query(TOTALProduct)
	Long countTotalProduct();

	@Query(TOTALITEM)
	Long countTotalTotalItem();

	@Query(TOTALORDER)
	Long countTotalTotalOrder();

	@Query(TOTALTRANSACTION)
	Double countTotalTotalTransaction();
	

	
}

package com.ekutir.sanimark.superadmin.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekutir.sanimark.superadmin.repository.DashboardRepo;
import com.ekutir.sanimark.superadmin.repository.DashboardTotalMe;
import com.ekutir.sanimark.superadmin.service.DashboardService;

@Service("DashboardService")
public class DashboardServiceImpl implements DashboardService {
  
	@Autowired
	DashboardRepo dashboardRepo;
	
	@Autowired
	DashboardTotalMe dashboardTotalMe;
	
	@Override
	public Long getToatlSupplier() {
		Long l=0L;
		try {
			
			l=dashboardRepo.countTotalSupplier();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return l;
	}

	@Override
	public Long getTotalMictoEnreprenure() {
		Long totalME=0L;
		try {
			
			totalME=dashboardTotalMe.countTotalME();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return totalME;
		
	}

	@Override
	public Long getTotalProduct() {
		Long totalProduct=0L;
		try {
			
			totalProduct=dashboardRepo.countTotalProduct();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return totalProduct;
	}
	
	
	public 	Long getTotalTotalItem(){
		Long totalItem=0L;
		try {
			
			totalItem=dashboardRepo.countTotalTotalItem();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return totalItem;
		
	}

	@Override
	public Long getTotalOrder() {
		Long totalOrder=0L;
		try {
			
			totalOrder=dashboardRepo.countTotalTotalOrder();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return totalOrder;
	}

	@Override
	public Double getTotalTransaction() {
		Double totalTransaction=0.0;
		try {
			
			totalTransaction=dashboardRepo.countTotalTotalTransaction();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return totalTransaction;
	}

}

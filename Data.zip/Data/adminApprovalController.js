'use strict';

MyApp.controller('AdminApprovalController', ['$scope', function($scope) {
	
	$scope.onloadFun = function() {
      
      }
          
}]);

package ekutir.sanimark.dao.Impl;

public class SanimarkSqlUtility {

	public static final String FETCH_SUPPLIER_QUERY = "SELECT SUPPLIER.address,SUPPLIER.business_name, SUPPLIER.login_id, SUPPLIER.supplier_id, "
			+ "SUPPLIER.primary_contact_first_name, SUPPLIER.primary_contact_number, SUPPLIER.secondary_contact_name, SUPPLIER.secondary_contact_number, SUPPLIER.service_description,SUPPLIER.status FROM dbsanimarkdlink.sani_supplier SUPPLIER order by created_date_time desc ";
	
	public static final String FETCH_SUPPLIER_ADDRESS_QUERY = "SELECT ADDRESS.AddressLine1,ADDRESS.AddressLine2,ADDRESS.AddressLine3,ADDRESS.block,ADDRESS.city,ADDRESS.district,ADDRESS.state,ADDRESS.country,ADDRESS.pincode  "
			+ " FROM dbsanimarkdlink.sani_address ADDRESS WHERE address_id=? ";
	
	public static final String SUPPLIER_REJECT = "DELETE FROM dbsanimarkdlink.sani_supplier WHERE supplier_id = ? ";
	
	public static final String SUPPLIER_ADDRESS = "DELETE FROM dbsanimarkdlink.sani_address "
			+ "WHERE address_id IN (select address from dbsanimarkdlink.sani_supplier where supplier_id= ? )";
	
	public static final String SUPPLIER_Approve = "UPDATE dbsanimarkdlink.sani_supplier SET status = 1 WHERE supplier_id =? ";
	
	public static final String FETCH_BUSINESS_CATEGORY_QUERY = "SELECT BCATEGORY.business_category_id, BCATEGORY.code, BCATEGORY.name FROM ekutir_gateway.gtwy_business_category BCATEGORY ";
	
	public static final String FETCH_ORDER_PRODUCT_DETAILS_QUERY = "SELECT distinct NPRODUCT.productid, NSUPPLR.supplier_id,NPRODUCT.product_brand_name, NPRODUCT.company_name, NPRODUCT.product_cat_id, NPRODUCTCAT.category_name, "
			+ "NPRODUCT.warranty, NPRODUCT.date_of_manufacturing, NPRODUCT.expiry_date, NPRODUCT.product_features, NPRODUCT.mrp, NPRODUCT.discountInpercent, NPRODUCT.sellingprice, NPRODUCT.productImg ,NSUPPLR.business_name "
			+ "from dbsanimarkdlink.sani_supplier NSUPPLR, dbsanimarkdlink.sani_supplier_x_product SUPLRXPRODCT, dbsanimarkdlink.sani_product NPRODUCT, dbsanimarkdlink.sani_product_category NPRODUCTCAT "
			+ "where NSUPPLR.supplier_id = SUPLRXPRODCT.supplier_id and NPRODUCT.product_cat_id = NPRODUCTCAT.product_cat_id and NPRODUCT.Product_Approved_Status = 0 ";
	
	public static final String FETCH_PRODUCT_UNITS_QUERY = "SELECT   A.UnitId, A.Unit, A.Price, A.advance, A.mrp FROM dbsanimarkdlink.sani_product_unit A Inner Join dbsanimarkdlink.sani_product_x_unit B on A.UnitId=B.UnitId and B.ProductId=? ";
	
	public static final String INSERT_NEWPRODUCT_QUERY = "INSERT INTO dbsanimarkdlink.sani_product (`product_brand_name`,`company_name`,`product_cat_id`,`warranty`,`date_of_manufacturing`,`expiry_date`,`product_features`,`productImg`,`mrp`,`discountInpercent`,`sellingprice`,`Product_Approved_Status` "
			+ ",`created_date`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ";
	
	public static final String INSERT_UNIT_DETAILS_QUERY = "INSERT INTO dbsanimarkdlink.sani_product_unit (Unit,Price,advance,mrp) VALUES (?,?,?,?)";
	
	public static final String INSERT_XUNIT_QUERY = "INSERT INTO dbsanimarkdlink.sani_product_x_unit (`ProductId`,`UnitId`) VALUES (?,?) ";
	
	public static final String INSERT_XSUPPLIER_QUERY = "INSERT INTO dbsanimarkdlink.sani_supplier_x_product (`product_id`,`supplier_id`) VALUES (?,?) ";
	
	public static final String FETCH_SUPPLIER_ORDER_QUERY = "select distinct C.address, A.OrderID, D.itemid, D.itemname, D.itembrand, A.OrderQuantity, D.mrp, D.selling_price, DATE_FORMAT(B.OrderDate,'%Y-%m-%d') as OrderDate, "
			+ " DATE_FORMAT(B.DeliveryRequestedFromDate,'%Y-%m-%d') as DeliveryRequestedFromDate, DATE_FORMAT(B.DeliveryRequestedToDate,'%Y-%m-%d') as DeliveryRequestedToDate, "
			+ " DATE_FORMAT(A.actual_delivery_date,'%Y-%m-%d') as actual_delivery_date, A.supplier_ack_status, B.UserID, C.first_name, C.middle_name, C.last_name, G.phone_number, B.OrderPaymentMode "
			+ " from dbsanimarkdlink.tbl_order_details_master A,  dbsanimarkdlink.tbl_order_header_master B, ekutir_gateway.gtwy_user_master C, "
			+ " dbsanimarkdlink.tbl_items D, ekutir_gateway.gtwy_registration G, dbsanimarkdlink.sani_supplier_x_item Y "
			+ " WHERE A.OrderID = B.OrderID and B.UserID = C.user_id and A.ProductId=D.itemid "
			+ " and C.registration = G.registration_id and D.itemid = Y.itemId and Y.supplier_id=? order by 2 desc ";
	
	public static final String FETCH_SUPPLIER_ORDER_ADDRESS_QUERY = "SELECT ADDRESS.address_line_1,ADDRESS.address_line_2,address_line_3,ADDRESS.block,ADDRESS.city,ADDRESS.district,ADDRESS.state,ADDRESS.country,ADDRESS.postal_code  "
			+ " FROM ekutir_gateway.gtwy_address ADDRESS WHERE address_id=? ";
	
	public static final String ACKNOWLEDGE_ORDER_QUERY = " UPDATE dbsanimarkdlink.tbl_order_details_master SET supplier_ack_status = 1, updated_at=? WHERE OrderID =? and ProductId = ? ";

	public static final String FETCH_PRODUCT_CATEGORY_QUERY = "SELECT PCATEGORY.product_cat_id, PCATEGORY.category_name FROM dbsanimarkdlink.sani_product_category PCATEGORY ";

	public static final String FETCH_SERVICE_CATEGORY_QUERY = "SELECT idservice_category, category_name FROM dbsanimarkdlink.service_category ";

	public static final String DELETE_PRODUCT = "update dbsanimarkdlink.sani_product set active_status =0 where productid = ? ";
	
	//public static final String DELETE_PRODUCT_X_SUPPLIER = "DELETE FROM dbsanimarkdlink.sani_supplier_x_product WHERE product_id = ? ";

	//public static final String DELETE_PRODUCT_X_UNIT = "DELETE FROM dbsanimarkdlink.sani_product_x_unit WHERE ProductId =? ";

	//public static final String DELETE_PRODUCT_UNIT = "DELETE FROM dbsanimarkdlink.sani_product_unit "
			//+ "WHERE UnitId IN (select UnitId from dbsanimarkdlink.sani_product_x_unit where ProductId= ? ) ";

	public static final String EDIT_NEWPRODUCT_QUERY = "UPDATE dbsanimarkdlink.sani_product SET `product_brand_name`=?,`company_name`= ?,`product_cat_id`= ?,`product_features`= ?,`warranty`= ?,`mrp`= ?,`discountInpercent`= ?,`sellingprice`= ?,`date_of_manufacturing`= ?,`expiry_date`= ?,`productImg`= ?, `updated_date`= ? where productid=?";

	public static final String EDIT_UNIT_DETAILS_QUERY = "UPDATE dbsanimarkdlink.sani_product_unit SET Unit= ?, Price=?, advance=?, mrp=? where UnitId= ? ";

	public static final String INSERT_SERVICES_DETAILS = "INSERT into dbsanimarkdlink.service (`brand_name`,`contact_details`,`service_description`,`when_to_use`,`how_to_use`,`consumer_benefit`,`service_cat_id`,`business_name`,`address`,`block`,`district`,`state_service`,`country`,`pincode`,`created_date`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";

	public static final String INSERT_SERVICEXSUPPLIER_QUERY = "INSERT INTO dbsanimarkdlink.sani_supplier_x_service (`service_Id`,`supplier_Id`) VALUES (?,?) ";
	
	public static final String SELECT_SERVICES_ADDRESS_DETAILS = "SELECT A.business_name, concat(B.addressLine1,',',B.addressLine2,',',B.addressLine3) as address, B.block,B.district,B.state,B.country,B.pincode "
			+ "FROM dbsanimarkdlink.sani_supplier A, dbsanimarkdlink.sani_address B where A.address = B.address_id and supplier_id= ? ";

	public static final String PRODUCT_APPROVE = "UPDATE dbsanimarkdlink.sani_product SET Product_Approved_Status = 1 WHERE productid = ? ";

	public static final String FETCH_SERVICE_DETAILS_QUERY = "select X.* from(SELECT A.serviceid,A.business_name,A.brand_name, A.contact_details,A.service_description,A.when_to_use,A.how_to_use,A.consumer_benefit , "
			+ " A.service_cat_id, D.category_name from dbsanimarkdlink.service A ,dbsanimarkdlink.sani_supplier B, dbsanimarkdlink.sani_supplier_x_service C, dbsanimarkdlink.service_category D "
			+ " where B.supplier_id = C.supplier_Id and C.service_Id = A.serviceid and A.service_approved_status = 1 and A.service_cat_id = D.idservice_category and A.service_active_status = 1 order by A.serviceid desc ) X "
			+ " where X.serviceid in (select service_Id from dbsanimarkdlink.sani_supplier_x_service where supplier_Id = ? ) ";

	public static final String FETCH_UNITS_QUERY = "SELECT A.UnitId, A.Unit, A.Price, A.advance, A.mrp FROM dbsanimarkdlink.sani_product_unit A Inner Join dbsanimarkdlink.sani_product_x_unit B on A.UnitId=B.UnitId and B.ProductId=? ";

	public static final String FETCH_PRODUCT_DETAILS_QUERY = "SELECT NPRODUCT.productid, NPRODUCT.product_brand_name, NPRODUCT.company_name, NPRODUCT.product_cat_id, NPRODUCTCAT.category_name, "
			+ "NPRODUCT.warranty, DATE_FORMAT(NPRODUCT.date_of_manufacturing,'%d-%m-%Y') as date_of_manufacturing , NPRODUCT.expiry_date, NPRODUCT.product_features, NPRODUCT.mrp, NPRODUCT.discountInpercent, NPRODUCT.sellingprice, NPRODUCT.productImg "
			+ "from dbsanimarkdlink.sani_product NPRODUCT, dbsanimarkdlink.sani_product_category NPRODUCTCAT	where NPRODUCT.product_cat_id = NPRODUCTCAT.product_cat_id and  NPRODUCT.Product_Approved_Status = 1 ";

	public static final String FETCH_SERVICE_APPROVAL_QUERY = "SELECT B.supplier_id, B.business_name, A.serviceid,A.brand_name, A.contact_details, A.service_description,A.when_to_use,A.how_to_use, "
			+ " A.consumer_benefit, A.service_cat_id, CATG.category_name "
			+ " from dbsanimarkdlink.service A, dbsanimarkdlink.sani_supplier B,dbsanimarkdlink.sani_supplier_x_service D, dbsanimarkdlink.service_category CATG "
			+ " where A.serviceid=D.service_Id and D.supplier_Id=B.supplier_id and A.service_cat_id = CATG.idservice_category "
			+ " and A.service_approved_status= 0 and A.service_active_status= 1 order by A.serviceid desc ";

	public static final String SELECT_UNIT_ID_OF_PRODUCT_ID = "SELECT UnitId FROM dbsanimarkdlink.sani_product_x_unit WHERE ProductId=? and UnitId=? ";

	public static final String SERVICES_APPROVED = "UPDATE dbsanimarkdlink.service SET service_approved_status = 1 WHERE serviceid = ? ";

	public static final String DELETE_SERVICE = "update dbsanimarkdlink.service set service_active_status = 0 where serviceid = ? ";
	
	public static final String DELETE_X_SERVICE = "DELETE FROM dbsanimarkdlink.sani_supplier_x_service WHERE service_Id = ? ";

	//public static final String EDIT_XUNIT_QUERY = null;

	//public static final String EDIT_XSUPPLIER_QUERY = null;

	public static final String EDIT_SERVICES_DETAILS = "UPDATE dbsanimarkdlink.service SET brand_name= ?, contact_details= ?, service_description= ?, when_to_use= ?, how_to_use= ?, consumer_benefit= ?, service_cat_id= ?, updated_date= ? where serviceid= ? ";

	public static final String REJECT_PRODUCT = "DELETE FROM dbsanimarkdlink.sani_product WHERE productid = ? ";
	
	public static final String REJECT_PRODUCT_UNIT = "DELETE FROM dbsanimarkdlink.sani_product_unit "
			+ "WHERE UnitId IN (select UnitId from dbsanimarkdlink.sani_product_x_unit where ProductId= ? ) ";

	public static final String REJECT_PRODUCT_X_UNIT = "DELETE FROM dbsanimarkdlink.sani_product_x_unit WHERE ProductId =? ";

	public static final String REJECT_PRODUCT_X_SUPPLIER = "DELETE FROM dbsanimarkdlink.sani_supplier_x_product WHERE product_id = ? ";

	public static final String REJECT_SERVICE = "DELETE FROM dbsanimarkdlink.nukkad.service WHERE serviceid = ? ";
	
	public static final String REJECT_X_SERVICE = "DELETE FROM dbsanimarkdlink.sani_supplier_x_service WHERE service_Id = ? ";

	public static final String FETCH_ADMIN_DETAILS = "SELECT login_id FROM dbsanimarkdlink.sani_admin where status = 1 ";

	public static final String FETCH_ID_DETAILS = "select C.login_id from dbsanimarkdlink.tbl_items A, dbsanimarkdlink.sani_supplier_x_item B, "
			+ " dbsanimarkdlink.sani_supplier C where A.itemid = B.itemId and B.supplier_id= C.supplier_id and A.itemid = ? ";

	public static final String FETCH_SUPPLIER_ID_DETAILS = "SELECT login_id FROM dbsanimarkdlink.sani_supplier WHERE supplier_id = ? ";

	public static final String FETCH_SUPLLIER_PRODUCT_QUERY = " SELECT NPRODUCT.productid,NPRODUCT.product_brand_name,NPRODUCT.company_name,NPRODUCT.product_cat_id,NPRODUCTCAT.category_name,NPRODUCT.warranty,"
			+" NPRODUCT.date_of_manufacturing,NPRODUCT.expiry_date,NPRODUCT.product_features,NPRODUCT.mrp,NPRODUCT.discountInpercent,NPRODUCT.sellingprice,"
			+" NPRODUCT.productImg from dbsanimarkdlink.sani_product NPRODUCT,dbsanimarkdlink.sani_product_category NPRODUCTCAT ,dbsanimarkdlink.sani_supplier_x_product supxprod "
			+" where NPRODUCT.product_cat_id = NPRODUCTCAT.product_cat_id  and NPRODUCT.productid = supxprod.product_id and   NPRODUCT.Product_Approved_Status = 1  and  supxprod.supplier_id = ?";

	public static final String FETCH_PRODUCT_CATEGORY_DEATILS = "SELECT product_cat_id,category_name FROM dbsanimarkdlink.sani_product_category";

	public static final String FETCH_PRODUCT_DEATILS = "SELECT NPRODUCT.productid,NPRODUCT.product_brand_name,NPRODUCT.company_name,NPRODUCT.product_cat_id,NPRODUCT.warranty,NPRODUCT.date_of_manufacturing,NPRODUCT.expiry_date,NPRODUCT.product_features,NPRODUCT.productImg,NPRODUCT.mrp,NPRODUCT.discountInpercent,NPRODUCT.sellingprice"
			+" from dbsanimarkdlink.sani_product NPRODUCT,dbsanimarkdlink.sani_product_category NPRODUCTCAT ,dbsanimarkdlink.sani_supplier_x_product supxprod where NPRODUCT.product_cat_id = NPRODUCTCAT.product_cat_id  and NPRODUCT.productid = supxprod.product_id and NPRODUCT.Product_Approved_Status = 1 and  NPRODUCTCAT.product_cat_id = ?";

	public static final String CLOSED_ORDER_QUERY = "UPDATE dbsanimarkdlink.tbl_order_details_master SET supplier_ack_status = 2 WHERE OrderID =? and ProductId = ?";

	public static final String INSERT_PRODUCT_ITEMS = null;

	public static final String FETCH_SANI_PRODUCT_DETAILS_QUERY = "select X.* from(SELECT PROD.productid, PROD.product_name, CAT.product_cat_id, CAT.category_name, PROD.product_description, PROD.active_status, PROD.product_image "
			+ " FROM dbsanimarkdlink.sani_product PROD, dbsanimarkdlink.sani_product_category CAT "
			+ " where PROD.product_cat_id = CAT.product_cat_id and PROD.active_status=1 order by PROD.productid desc) X "
			+ " where X.productid in (select product_id from dbsanimarkdlink.sani_supplier_x_product where supplier_id = ? ) ";

	public static final String FETCH_SANI_PRODUCT_ITEMS_DETAILS_QUERY = "SELECT ITEMS.itemid, ITEMS.itemname, ITEMS.itembrand, PROD.product_cat_id, ITEMS.mrp, ITEMS.selling_price, "
			+ " ITEMS.item_description, ITEMS.itemImage, ITEMS.warranty, ITEMS.dimension,date(ITEMS.expiryDate) as expiryDate, date(ITEMS.manufactureDate) as manufactureDate, ITEMS.approvalStatus, ITEMS.color "
			+ " FROM dbsanimarkdlink.sani_product PROD, dbsanimarkdlink.product_x_item XITEM, dbsanimarkdlink.tbl_items ITEMS "
			+ " where PROD.productid = XITEM.productid and  ITEMS.itemid = XITEM.itemid and PROD.productid = ? and ITEMS.approvalStatus = 1 ";

	public static final String FETCH_ALL_ITEMS_DETAILS_QUERY = " SELECT ITEMS.itemid, ITEMS.itemname, ITEMS.itembrand, ITEMS.product_cat_id, ITEMS.mrp, "
			+ " ITEMS.selling_price, ITEMS.item_description, ITEMS.itemImage, ITEMS.warranty, ITEMS.dimension, "
			+ " ITEMS.expiryDate, ITEMS.manufactureDate, ITEMS.approvalStatus, ITEMS.color "
			+ " FROM dbsanimarkdlink.tbl_items ITEMS, dbsanimarkdlink.sani_supplier_x_item SXI "
			+ " where ITEMS.itemid = SXI.itemId and SXI.supplier_id = ? and ITEMS.approvalStatus = 1 ";

	public static final String INSERT_ITEMS_DETAILS = "INSERT into dbsanimarkdlink.tbl_items (`itemname`,`itembrand`,`product_cat_id`,`mrp`,`selling_price`,`item_description`,`itemImage`,`warranty`,`dimension`,`manufactureDate`,`expiryDate`,`color`,`CreatedBy`,`CreatedDateTime`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";

	public static final String CREATE_PRODUCT = "INSERT INTO  dbsanimarkdlink.sani_product(product_name, product_cat_id, product_description, "
			+ " created_by, created_date, product_image) VALUES (?,?,?,?,?,?)";

	public static final String CREATE_ITEM = "INSERT INTO  dbsanimarkdlink.product_x_item(productid,itemid) VALUES (?,?) " ;

	public static final String EDIT_PRODUCTS_QUERY = "UPDATE dbsanimarkdlink.sani_product SET `product_name`=?,`product_cat_id`= ?,`product_description`= ?, `product_image`=?, "
			+ " `updated_by`=?, `updated_date`= ? where `productid`=? ";

	public static final String SELECT_ITEM_ID = "SELECT itemid FROM dbsanimarkdlink.product_x_item WHERE ProductId=? ";

	public static final String INSERT_ITEMS_DETAILS_QUERY = "INSERT INTO  dbsanimarkdlink.product_x_item(productid,itemid) VALUES (?,?) " ;

	public static final String EDIT_ITEMS_DETAILS_QUERY = "UPDATE dbsanimarkdlink.tbl_items SET itemid= ? where productid= ? ";

	public static final String DELETE_ITEMS_DETAILS_QUERY = "delete from dbsanimarkdlink.product_x_item where itemid=? and productid= ? ";

	public static final String INSERT_PRODUCTXSUPPLIER_QUERY = "INSERT INTO dbsanimarkdlink.sani_supplier_x_product (product_id, supplier_id) VALUES (?,?) ";

	public static final String ITEM_APPROVE = "UPDATE dbsanimarkdlink.tbl_items SET approvalStatus = 1 WHERE itemid = ? ";

	public static final String FETCH_SERVICE_ID_DETAILS = "select C.login_id from dbsanimarkdlink.service A, dbsanimarkdlink.sani_supplier_x_service B, dbsanimarkdlink.sani_supplier C "
			+ "where A.serviceid = B.service_Id and B.supplier_Id = C.supplier_id and A.serviceid = ? ";

	public static final String EDIT_ITEM_DETAILS = "update dbsanimarkdlink.tbl_items set itemname=?, itembrand=?, product_cat_id=?, mrp=?, selling_price=?, warranty=?, dimension=?, "
			+ " item_description=?, itemImage=?, manufactureDate=?, expiryDate=?, color=?, UpdatedBy=?, UpdatedDateTime=?, approvalStatus =0 where itemid=? ";

	public static final String FETCH_ITEMS_APPROVAL_QUERY = "select SPXITEM.supplier_id, SUPPLIER.business_name, ITEMS.itemid, ITEMS.itemname, ITEMS.itembrand, ITEMS.product_cat_id, ITEMS.mrp, ITEMS.selling_price, "
			+ " ITEMS.item_description, ITEMS.itemImage, ITEMS.warranty, ITEMS.dimension,date(ITEMS.expiryDate) as expiryDate, date(ITEMS.manufactureDate) as manufactureDate, "
			+ " ITEMS.approvalStatus, PRODCAT.category_name, ITEMS.color FROM dbsanimarkdlink.tbl_items ITEMS, "
			+ " sani_supplier_x_item SPXITEM, dbsanimarkdlink.sani_supplier SUPPLIER , "
			+ " dbsanimarkdlink.sani_product_category PRODCAT where ITEMS.itemid = SPXITEM.itemId and SUPPLIER.supplier_id = SPXITEM.supplier_id "
			+ " and ITEMS.product_cat_id = PRODCAT.product_cat_id and ITEMS.approvalStatus = 0 order by ITEMS.itemid desc";

	public static final String FETCH_SUPPLIER_ITEMS_DETAILS_QUERY = "SELECT distinct ITEMS.itemid, ITEMS.itemname, ITEMS.itembrand, ITEMS.product_cat_id, ITEMS.mrp, ITEMS.selling_price, "
			+ " ITEMS.item_description, ITEMS.itemImage, ITEMS.warranty, ITEMS.dimension,date(ITEMS.expiryDate) as expiryDate, "
			+ " date(ITEMS.manufactureDate) as manufactureDate, ITEMS.approvalStatus, PRODCAT.category_name " 	
			+ " FROM dbsanimarkdlink.tbl_items ITEMS, dbsanimarkdlink.sani_product_category PRODCAT, "
			+ " sani_supplier_x_item SPXITEM, dbsanimarkdlink.sani_supplier SUPPLIER "
			+ " where ITEMS.itemid = SPXITEM.itemId and SPXITEM.supplier_id = SUPPLIER.supplier_id "
			+ " and ITEMS.product_cat_id = PRODCAT.product_cat_id and ITEMS.approvalStatus = 1 and SUPPLIER.supplier_id = ? ";

	public static final String INSERT_SUPPLIERXITEMS_DETAILS = "INSERT INTO dbsanimarkdlink.sani_supplier_x_item(itemId,supplier_id) VALUES (?,?) ";

	public static final String DELETE_ITEM = "delete from dbsanimarkdlink.tbl_items where itemid=? ";

	public static final String DELETE_ITEM_X_SUPPLIER = "DELETE FROM dbsanimarkdlink.sani_supplier_x_item WHERE itemId = ? ";

	public static final String FETCH_SUPPLIER_SERVICE_DETAILS_QUERY = "SELECT SERVICE.serviceid, SERVICE.brand_name, SERVICE.contact_details, SERVICE.service_description, SERVICE.when_to_use, "
			+ " SERVICE.how_to_use, SERVICE.consumer_benefit from dbsanimarkdlink.service SERVICE, "
			+ " dbsanimarkdlink.sani_supplier_x_service SXS, dbsanimarkdlink.sani_supplier SUPPLIER where SERVICE.serviceid = SXS.service_Id "
			+ " and SXS.supplier_Id = SUPPLIER.supplier_id and SERVICE.service_approved_status = 1 and service_active_status = 1 and SUPPLIER.supplier_id = ? ";

	public static final String UPDATE_ACK_STATUS_CLOSE = "UPDATE dbsanimarkdlink.tbl_order_details_master SET supplier_ack_status = 2, updated_at=? WHERE OrderID =? and productId= ? ";

	public static final String FETCH_BUYCODE_DETAILS = "SELECT buycode FROM dbsanimarkdlink.buy_code where order_id = ? and buycode=? ";

	public static final String INSERT_MESSAGE_DETAILS = "INSERT INTO dbsanimarkdlink.sani_me_message (messagedescription,created_date,created_by,message_type) VALUES (?,?,?,?) ";

	public static final String INSERT_MSG_INTO_MEMSG = "INSERT INTO dbsanimarkdlink.sani_me_message (messagedescription,created_date,created_by,message_type) VALUES (?,?,?,?) ";

	public static final String FIND_PHONE_NUMBER = "SELECT SUPPLIER.primary_contact_number, PROD.itembrand "
			+ " FROM dbsanimarkdlink.tbl_order_details_master ORDERMASTER, dbsanimarkdlink.sani_supplier_x_item X, "
			+ " dbsanimarkdlink.sani_supplier SUPPLIER, dbsanimarkdlink.tbl_items PROD "
			+ " where ORDERMASTER.ProductId = X.itemId and X.supplier_id = SUPPLIER.supplier_id "
			+ " and ORDERMASTER.ProductId = PROD.itemid and ORDERMASTER.OrderID =? and ORDERMASTER.ProductId=? ";

}

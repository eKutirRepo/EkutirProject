package ekutir.sanimark.dao;

import java.util.List;

import ekutir.sanimark.android.dto.EditProductDataBean;
import ekutir.sanimark.android.dto.FetchBusinessCategoryBean;
import ekutir.sanimark.android.dto.FetchPCategoryBean;
import ekutir.sanimark.android.dto.FetchProductsBean;
import ekutir.sanimark.android.dto.FetchServiceForApprovalBean;
import ekutir.sanimark.android.dto.FetchServicesDataBean;
import ekutir.sanimark.android.dto.FetchSupplierOrderDataBean;
import ekutir.sanimark.android.dto.ProductDataBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ServicesDataBean;
import ekutir.sanimark.android.dto.ServicesEditDataBean;
import ekutir.sanimark.dto.FetchProductServiceCategoryDto;
import ekutir.sanimark.view.beans.CreateProductBean;
import ekutir.sanimark.view.beans.EditItemBean;
import ekutir.sanimark.view.beans.FetchItemsApprovalBean;
import ekutir.sanimark.view.beans.FetchItemsForProductBean;
import ekutir.sanimark.view.beans.FetchProductsForSani;
import ekutir.sanimark.view.beans.FetchServiceCategoryBean;
import ekutir.sanimark.view.beans.FetchSupplierItemsBean;
import ekutir.sanimark.view.beans.FetchSupplierServicesBean;
import ekutir.sanimark.view.beans.ItemBean;
import ekutir.sanimark.view.beans.ItemIdDetailsBean;
import ekutir.sanimark.view.beans.MicroEntrepreneurMsgBean;
import ekutir.sanimark.view.beans.ServiceCategoryBean;

public interface SanimarkDao{
	
	List<RegisterDataBean> fetchSuppliersDetails();

	int rejectSupplier(int supplierId);

	int approveSupplier(int supplierId);

	List<FetchBusinessCategoryBean> fetchBusinessCategory();

	List<FetchProductsBean> fetchProductsDetails();

	int addProduct(ProductDataBean productBean);

	List<FetchSupplierOrderDataBean> fetchSuppliersOrderDetails();

	int acknowledgeOrder(int orderId, int productId);

	List<FetchProductServiceCategoryDto> fetchProductCategory();

	List<FetchProductServiceCategoryDto> fetchServiceCategory();

	int deleteProduct(int productId);

	int editProducts(EditProductDataBean editProducts);

	int createServices(ServicesDataBean createServicesData);

	int approveProduct(int productId);

	List<FetchServicesDataBean> fetchServicesDetails();

	//List<FetchProductsBean> fetchProducts();

	List<FetchServiceForApprovalBean> fetchServicesApprovalDetails();

	int approveService(int serviceId);

	int deleteService(int serviceId);

	int editService(ServicesEditDataBean editService);

	int rejectProduct(int productId);

	int rejectService(int serviceId);

	List<String> fetchAdminDetails();

	List<String> fetchApprovalLogin(int itemId);

	List<String> fetchSupplierApproval(int supplierId);

	List<ProductDataBean> fetchSupplierProducts(int suplierid);

	List<FetchPCategoryBean> fetchProdCategory();

	int closeOrder(int orderId, int productId);

	List<FetchProductsForSani> fetchSaniProducts();

	List<FetchItemsForProductBean> fetchSaniProductItems(int productId);

	List<FetchItemsForProductBean> fetchAllItems();

	int createItem(ItemBean createItemData);

	int createProduct(CreateProductBean createProduct, List<ItemIdDetailsBean> itemLists);

	int approveItems(int itemId);

	List<String> fetchServicesApprovalLogin(int serviceId);

	int editItem(EditItemBean editItem);

	List<FetchItemsApprovalBean> fetchItemsforApproval();

	List<FetchSupplierItemsBean> fetchSupplierItems(int supplierId);

	int deleteItem(int itemId);

	List<FetchSupplierServicesBean> fetchSupplierServices(int supplierId);

	boolean updateAckStatus(int orderId, int productId);

	boolean fetchBuycode(int orderId, int buyCode);

	int sendMicroEntrepreneurMsg(MicroEntrepreneurMsgBean microEntrepreneurMsgData);

	List<ServiceCategoryBean> fetchServiceCategories();

//	boolean sendProductAddedMail(String email);

}

package ekutir.sanimark.dao.Impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ekutir.sanimark.android.model.Address;
import ekutir.sanimark.android.model.Application;
import ekutir.sanimark.android.model.Auth;
import ekutir.sanimark.android.model.Customer;
import ekutir.sanimark.android.model.CustomerType;
import ekutir.sanimark.android.model.MeAndMyLand;
import ekutir.sanimark.android.model.User;
import ekutir.sanimark.constant.GatewayConstants;
import ekutir.sanimark.controller.GatewayController;
import ekutir.sanimark.dao.HomeDao;



@Repository("HomeDao")
public class HomeDaoImpl implements HomeDao {

	private static final Logger LOGGER = Logger.getLogger(GatewayController.class);

	// private SessionFactory sessionFactory;
	@Autowired
	@Qualifier(value = "hibernate4AnnotatedSessionFactoryForSanimark")
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	Session session = null;
	Transaction tx = null;

	/*@Override
	@Transactional(readOnly = true)
	public List<Advertisement> getAdvertisements(String appCode, String masterKey, Date currentDate) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Advertisement.class).createAlias("application", "a")
				.add(Restrictions.eq("a.applicationCode", appCode));
		Conjunction and = Restrictions.conjunction();
		and.add(Restrictions.le("start_date_time", currentDate));
		and.add(Restrictions.ge("end_date_time", currentDate));
		List<Advertisement> advertisementList = criteria.list();
		return advertisementList;
	}

	@Override
	@Transactional(readOnly = true)
	public List<BusinessTip> getBusinessTips(String appCode, String masterKey, Date currentDate) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(BusinessTip.class).createAlias("application", "a")
				.add(Restrictions.eq("a.applicationCode", appCode));
		Conjunction and = Restrictions.conjunction();
		and.add(Restrictions.le("start_date_time", currentDate));
		and.add(Restrictions.ge("end_date_time", currentDate));
		List<BusinessTip> businessTipList = criteria.list();
		return businessTipList;
	}

	@Override
	@Transactional(readOnly = true)
	public List<SaleAndOffer> getSalesAndOffers(String appCode, String masterKey, Date currentDate) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(SaleAndOffer.class).createAlias("application", "a")
				.add(Restrictions.eq("a.applicationCode", appCode));
		Conjunction and = Restrictions.conjunction();
		and.add(Restrictions.le("start_date_time", currentDate));
		and.add(Restrictions.ge("end_date_time", currentDate));
		List<SaleAndOffer> saleAndOfferList = criteria.list();
		return saleAndOfferList;
	}*/

	@Override
	@Transactional(readOnly = true)
	public boolean isMasterKeyExists(String masterKey) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Auth.class);
		criteria.add(Restrictions.eq("authToken", masterKey));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count != 0);
	}

	@Override
	@Transactional(readOnly = true)
	public boolean isAppCodeExists(String appCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Application.class);
		criteria.add(Restrictions.eq("applicationCode", appCode));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count != 0);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Customer> fetchCustomers(int userId, int page) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.createCriteria("user", "u");
		criteria.add(Restrictions.eq("u.userId", userId));
		criteria.setFirstResult(page * 10);
		criteria.setMaxResults(10);
		criteria.setMaxResults(GatewayConstants.MAX_SIZE_OF_CUSTOMERS);
		return (List<Customer>) criteria.list();
	}

	@Override
	@Transactional(readOnly = true)
	public boolean isAuthKeyExists(String authKey) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Auth.class).add(Restrictions.eq("authToken", authKey))
				.add(Restrictions.eq("authType", GatewayConstants.AUTH_KEY_TAG));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@Override
	@Transactional(readOnly = true)
	public long getCustomerCount(int userId) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.createCriteria("user", "u");
		criteria.add(Restrictions.eq("u.userId", userId));
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}

	@Override
	public Customer getCustomer(int customerId) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.add(Restrictions.idEq(customerId));
		return (Customer) criteria.uniqueResult();
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(customer);
		return customer;
	}

	@Override
	public User fetchUser(int userId) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.idEq(userId));
		return (User) criteria.uniqueResult();
	}

	@Override
	public List<CustomerType> fetchListOfCustomerType(String appCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(CustomerType.class);
		criteria.createCriteria("application", "a");
		criteria.add(Restrictions.eq("a.applicationCode", appCode));
		return (List<CustomerType>) criteria.list();
	}

	@Override
	public boolean checkAppRequestAndMasterKey(String masterKey, String appCode) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Auth.class);
		criteria.add(Restrictions.eq("authToken", masterKey));
		criteria.setProjection(Projections.rowCount());
		return ((Long) criteria.uniqueResult() > 0L);
	}

	@Override
	public User saveUser(User user) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(user);
		return user;
	}

	@Override
	public CustomerType fetchCustomerType(String customerType) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(CustomerType.class);
		criteria.add(Restrictions.eq("typeCode", customerType));
		return (CustomerType) criteria.uniqueResult();
	}

	@Override
	public List<MeAndMyLand> fetchLandDetailsForCustomer(int customerId) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(MeAndMyLand.class).createAlias("customer", "c")
				.add(Restrictions.eq("c.customerId", customerId));
		if (null != criteria.list()) {
			List<MeAndMyLand> lm = (List<MeAndMyLand>) criteria.list();
			if (null != lm && lm.size() > 0 && lm.get(0).getLandId() != 0) {
				return lm;
			}
		}
		criteria = session.createCriteria(Customer.class).add(Restrictions.idEq(customerId));
		List<MeAndMyLand> lm = new ArrayList<>();
		MeAndMyLand e = new MeAndMyLand();
		e.setCustomer((Customer) criteria.uniqueResult());
		lm.add(e);
		return lm;

	}

	@Override
	public List<MeAndMyLand> updateLandDetails(List<MeAndMyLand> landDetails) {
		Session session = this.sessionFactory.getCurrentSession();
		List<MeAndMyLand> savedLandDetails = new ArrayList<MeAndMyLand>();
		for (MeAndMyLand m : landDetails) {
			session.saveOrUpdate(m);
			savedLandDetails.add(m);
		}
		return savedLandDetails;
	}

	@Override
	public Address getCustomerAddress(int addressId) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Address.class);
		criteria.add(Restrictions.eq("addressId", addressId));
		return (Address) criteria.uniqueResult();
	}

	@Override
	public User getUser(int userId) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("userId", userId));
		return (User) criteria.uniqueResult();
	}

}
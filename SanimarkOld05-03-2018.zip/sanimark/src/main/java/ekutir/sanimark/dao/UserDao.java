package ekutir.sanimark.dao;

import java.util.List;

import ekutir.sanimark.android.dto.AddressBean;
import ekutir.sanimark.android.dto.AdminUserBean;
import ekutir.sanimark.android.dto.ForgetPasswordBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ResetPasswordBean;
import ekutir.sanimark.android.dto.UserViewBean;
import ekutir.sanimark.view.beans.UserResetPassword;
import ekutir.sanimark.web.model.AgrimarkUsers;

public interface UserDao {

	AgrimarkUsers findById(int id);

	String findByNameAndPassword(UserViewBean userviewBean);

	void logoutUser(AgrimarkUsers user);

	List<AgrimarkUsers> findAllUsers();

	List<Object[]> forgetPassword(String roleBean,String email);

	int registration(RegisterDataBean registerBean);

	boolean duplicateRegistration(RegisterDataBean registerBean);

	List<String> fetchAdminDetails();

	int adminBean(AdminUserBean adminBean);

	int changeadminpass(AdminUserBean changeadminpass);

	List<AdminUserBean> fetchAdminData();

	void updatedminpass(String loginId,String hashPassword);

	List<RegisterDataBean> fetchSupplierData();
	
	void updatesupplierpass(String login, String hashPassword);

	boolean resetPassword(ResetPasswordBean resetPwd, String roleBean);

	boolean insertToken(String nextToken);

	String fetchToken(String nextToken);

	boolean checkForExistToken(String chkToken);

	void clearToken(String clrtoken);

	String returnToken(String rtnToken);

	int resetUserPassword(UserResetPassword userResetPassword, String loginUserId);

	int resetAdminPassword(UserResetPassword adminResetPassword, String loginUserId);

}

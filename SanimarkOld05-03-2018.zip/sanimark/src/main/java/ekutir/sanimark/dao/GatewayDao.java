package ekutir.sanimark.dao;

import java.util.List;
import java.util.Map;

import ekutir.sanimark.android.model.AppMaster;
import ekutir.sanimark.android.model.Application;
import ekutir.sanimark.android.model.BusinessUser;
import ekutir.sanimark.android.model.Customer;
import ekutir.sanimark.android.model.CustomerType;
import ekutir.sanimark.android.model.MeAndMyLand;
import ekutir.sanimark.android.model.PhoneXOtp;
import ekutir.sanimark.android.model.Registration;
import ekutir.sanimark.android.model.SvadhaErpAddress;
import ekutir.sanimark.android.model.SvadhaErpMeCustomer;
import ekutir.sanimark.android.model.User;
import ekutir.sanimark.android.view.ResetPassword;

public interface GatewayDao {

	public int insertCustomerDetails(Customer customer);

	public Map<String, Boolean> isPhoneNumberAlreadyRegistered(long phoneNumber, String appCode);

	public void savePhoneNumberTempAuthKeyAndOtp(PhoneXOtp phoneXOtp);

	public void saveTempAuthKey(long phoneNumber, String authKey);

	public boolean verifyPassword(String password, long phoneNumber, String tempAuthKey, String appCode);

	public boolean verifyOtp(long phoneNumber, int otp, String tempAuthKey);

	public User insertNewUserRegistrationDetails(User user);

	public BusinessUser updateBusinessUser(BusinessUser businessUser);

	public BusinessUser fetchBusinessUser(long phoneNumber);

	public void writeToAudit(String string, String string2);

	public User getMicroentrepreneur(int microentrepreneurId);

	public Registration fetchRegistrationDetails(long phoneNumber, String applicationCode);

	public User updateRegistrationForReturningUser(User user);

	public void removeTempAuth(long phoneNumber);

	public Application fetchApplication(String applicationCode);

	public boolean isCustomerExistsForMicroentrepreneur(String custAadharNumber);

	public User fetchUser(long phoneNumber, String appCode);

	public boolean checkTempAuth(long phoneNumber, String tempAuthKey);

	public Customer fetchCustomer(int customerId);

	public List<MeAndMyLand> saveMeAndMyLandDetailsForCustomer(List<MeAndMyLand> listOfMeAndMyLands);

	public CustomerType fetchCustomerTypes(String customerTypeDesc);

	public User fetchUserById(int userId);

	//public int saveSvadhaCustomerInfo(SvadhaErpMeCustomer erpMeCustomer);

	public int saveSvadhaErpMeAddress(SvadhaErpAddress erpAddress);

	public void saveAppMapping(AppMaster appMaster);

	public int getConnectedAppCustomerId(long phoneNumber);

	public Customer saveCustomer(Customer customer);

	public boolean isCustomerPhoneNumberAndAadhaarNumberPresent(long custPhoneNumber, int userId, String aadhaarNumber);

	public boolean isCustomerExistsForMicroentrepreneur(long custPhoneNumber);

	public int resetAppUserPassword(ResetPassword resetPassword);
}

package ekutir.sanimark.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ekutir.sanimark.android.dto.FetchPCategoryBean;
import ekutir.sanimark.dao.CrmDao;
import ekutir.sanimark.erp.view.beans.crm.AdvertisementsBean;
import ekutir.sanimark.erp.view.beans.crm.CatalogBean;
import ekutir.sanimark.erp.view.beans.crm.CustomerCommDetailBean;
import ekutir.sanimark.erp.view.beans.crm.CustomerPlaceOrderBean;
import ekutir.sanimark.erp.view.beans.crm.FetchBusinessCategoryBean;
import ekutir.sanimark.erp.view.beans.crm.FetchClusterDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchCustomerDataBean;
import ekutir.sanimark.erp.view.beans.crm.FetchDispositionsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchItemDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchOrdersBean;
import ekutir.sanimark.erp.view.beans.crm.FetchPaymentModesBean;
import ekutir.sanimark.erp.view.beans.crm.FetchPriceChangeDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.LeadPlaceOrderItemBean;
import ekutir.sanimark.erp.view.beans.crm.OrderDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.OrderFollowUpDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.ProductdetailBean;
import ekutir.sanimark.service.CrmService;


@Service("CustomerService")
@Transactional
public class CrmServiceimpl implements CrmService {
	@Autowired
	private CrmDao dao;

	public List<FetchCustomerDataBean> fetchCustomerData() {

		return dao.fetchCustomerData();
	}

	@Override
	public List<FetchClusterDetailsBean> fetchClusterDetails() {
		return dao.fetchClusterDetails();
	}

	@Override
	public int deleteCustomer(int customerId) {
		return dao.deleteCustomer(customerId);
	}

	@Override
	public List<FetchCustomerDataBean> searchCustomer(String createdFromDate, String createdToDate) {
		return dao.searchCustomer(createdFromDate, createdToDate);
	}

	@Override
	public List<FetchBusinessCategoryBean> fetchBusinessCategory() {
		return dao.fetchBusinessCategory();
	}

	/*@Override
	public List<CommDetailsBean> fetchCustomerCommHistory(int customerId,int prevId) {
		return dao.fetchCustomerCommHistory(customerId,prevId);
	}*/

	@Override
	public List<FetchDispositionsBean> fetchDispositions() {
		return dao.fetchDispositions();
	}

	@Override
	public List<FetchItemDetailsBean> fetchItemDetails() {
		return dao.fetchItemDetails();
	}

	@Override
	public List<FetchPaymentModesBean> fetchPaymentModes() {
		return dao.fetchPaymentModes();
	}

	@Override
	public List<FetchOrdersBean> fetchOrders() {
		return dao.fetchOrders();
	}

	@Override
	public List<OrderDetailsBean> orderDetails() {
		return dao.orderDetails();
	}

	/*@Override
	public int addCustomer(FetchCustomerDataBean addCustomerData) {
		return dao.addCustomer(addCustomerData);
	}
*/
	@Override
	public int editCustomer(FetchCustomerDataBean editCustomer) {
		return dao.editCustomer(editCustomer);
	}

	@Override
	public int saveCustomerCommDetails(CustomerCommDetailBean saveCustomerComm) {
		return dao.saveCustomerCommDetails(saveCustomerComm);
	}

	@Override
	public int placeOrder(CustomerPlaceOrderBean placeorderbean, List<LeadPlaceOrderItemBean> placeorderitemBean) {
		return dao.placeOrder(placeorderbean, placeorderitemBean);
	}

	@Override
	public List<FetchOrdersBean> searchOrders(String createdFromDate, String createdToDate, String myOrders) {
		return dao.searchOrders(createdFromDate, createdToDate, myOrders);
	}

	@Override
	public List<FetchOrdersBean> closeOrders() {
		return dao.closeOrders();
	}

	@Override
	public List<FetchOrdersBean> dropOrders() {
		return dao.dropOrders();
	}

	@Override
	public List<FetchOrdersBean> searchClosedOrders(String createdFromDate, String createdToDate, String myOrders) {
		return dao.searchClosedOrders(createdFromDate, createdToDate, myOrders);
	}

	@Override
	public List<FetchOrdersBean> searchDropedOrders(String createdFromDate, String createdToDate, String myOrders) {
		return dao.searchDropedOrders(createdFromDate, createdToDate, myOrders);
	}

	@Override
	public int saveOrderFollowUpDetail(OrderFollowUpDetailsBean saveOrderFollowUpData) {
		return dao.saveOrderFollowUpDetail(saveOrderFollowUpData);
	}

	@Override
	public List<OrderFollowUpDetailsBean> fetchOrderFollowUpHistory(int orderId) {
		return dao.fetchOrderFollowUpHistory(orderId);
	}

	@Override
	public List<FetchOrdersBean> fetchCustomerOrderHistory(int customerId) {
		return dao.fetchCustomerOrderHistory(customerId);
	}

	@Override
	public List<CatalogBean> searchItemDetails(int itemid) {
		return dao.searchItemDetails(itemid);
	}

	@Override
	public List<FetchOrdersBean> ordersCustomerHistory(int customerId, int orderId) {

		return dao.ordersCustomerHistory(customerId,orderId);
	}

	@Override
	public List<CatalogBean> fetchcatalog(int catalogid) {
	
		return dao.fetchcatalog(catalogid);
	}

	@Override
	public List<AdvertisementsBean> getAdvertisements(int masterkey) {
		// TODO Auto-generated method stub
		return dao.getAdvertisements(masterkey);
	}

	@Override
	public List<FetchPCategoryBean> advClicable( int catalogid) {
		// TODO Auto-generated method stub
		return dao.advClicable(catalogid);
	}

	@Override
	public List<AdvertisementsBean> getSaleOffer() {
		// TODO Auto-generated method stub
		return dao.getSaleOffer();
	}

	@Override
	public List<AdvertisementsBean> getNewSaleOffer() {
		// TODO Auto-generated method stub
		return dao.getNewSaleOffer();
	}

	/*@Override
	public RoleActionBean getRoleAction() {
		// TODO Auto-generated method stub
		return dao.getRoleAction();
	}*/

	@Override
	public List<AdvertisementsBean> getbiztips(int masterkey) {
		// TODO Auto-generated method stub
		return dao.getbiztips(masterkey);
	}

	@Override
	public List<FetchOrdersBean> fetchPartialOrders() {
		// TODO Auto-generated method stub
		return dao.fetchPartialOrders();
	}

	@Override
	public List<FetchOrdersBean> searchPartialOrders(String createdFromDate, String createdToDate, String myOrders) {
		return dao.searchPartialOrders(createdFromDate, createdToDate, myOrders);
	}

	@Override
	public FetchPriceChangeDetailsBean checkForPriceChange(int customerId, List<OrderDetailsBean> orderDetails) {
		return dao.checkForPriceChange(customerId,orderDetails);
	}

}

package ekutir.sanimark.android.dto;

public class FetchSupplierOrderDataBean {
	
	private int orderId;
	private int itemId;
	private String itemName;
	private String brandName;
	//private String companyName;
	private double orderQuantity;
	private double mrp;
	private double sellingPrice;
	//private double advance;
	private String orderDate;
	private String orderRequestFromDate;
	private String orderRequestToDate;
	private String deliveryDate;
	private int supplier_ack_status;
	private int customerId;
	private String customerFName;
	private String customerMName;
	private String customerLName;
	private long customerMobileNumber;
	private int productId;
	private AddressBean address;
	private String orderPaymentMode;
	
	public FetchSupplierOrderDataBean() {
		super();
	}

	public FetchSupplierOrderDataBean(int orderId, int itemId, String itemName, String brandName, double orderQuantity, double mrp,
			double sellingPrice, String orderDate, String orderRequestFromDate, String orderRequestToDate,
			String deliveryDate, int supplier_ack_status, int customerId, String customerFName, String customerMName,
			String customerLName, long customerMobileNumber, int productId, AddressBean address, String orderPaymentMode) {
		super();
		this.orderId = orderId;
		this.itemId = itemId;
		this.itemName = itemName;
		this.brandName = brandName;
		this.orderQuantity = orderQuantity;
		this.mrp = mrp;
		this.sellingPrice = sellingPrice;
		this.orderDate = orderDate;
		this.orderRequestFromDate = orderRequestFromDate;
		this.orderRequestToDate = orderRequestToDate;
		this.deliveryDate = deliveryDate;
		this.supplier_ack_status = supplier_ack_status;
		this.customerId = customerId;
		this.customerFName = customerFName;
		this.customerMName = customerMName;
		this.customerLName = customerLName;
		this.customerMobileNumber = customerMobileNumber;
		this.address = address;
		this.productId = productId;
		this.orderPaymentMode = orderPaymentMode;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public double getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(double orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public double getMrp() {
		return mrp;
	}

	public void setMrp(double mrp) {
		this.mrp = mrp;
	}

	public double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderRequestFromDate() {
		return orderRequestFromDate;
	}

	public void setOrderRequestFromDate(String orderRequestFromDate) {
		this.orderRequestFromDate = orderRequestFromDate;
	}

	public String getOrderRequestToDate() {
		return orderRequestToDate;
	}

	public void setOrderRequestToDate(String orderRequestToDate) {
		this.orderRequestToDate = orderRequestToDate;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public int getSupplier_ack_status() {
		return supplier_ack_status;
	}

	public void setSupplier_ack_status(int supplier_ack_status) {
		this.supplier_ack_status = supplier_ack_status;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerFName() {
		return customerFName;
	}

	public void setCustomerFName(String customerFName) {
		this.customerFName = customerFName;
	}

	public String getCustomerMName() {
		return customerMName;
	}

	public void setCustomerMName(String customerMName) {
		this.customerMName = customerMName;
	}

	public String getCustomerLName() {
		return customerLName;
	}

	public void setCustomerLName(String customerLName) {
		this.customerLName = customerLName;
	}

	public long getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(long customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public AddressBean getAddress() {
		return address;
	}

	public void setAddress(AddressBean address) {
		this.address = address;
	}

	public String getOrderPaymentMode() {
		return orderPaymentMode;
	}

	public void setOrderPaymentMode(String orderPaymentMode) {
		this.orderPaymentMode = orderPaymentMode;
	}

}

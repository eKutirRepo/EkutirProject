package ekutir.sanimark.android.model;

import java.io.Serializable;
import java.sql.Blob;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ekutir_gateway.gtwy_sale_offer")
public class SaleAndOffer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "sale_offer_id")
	private int saleOfferId;

	@Column(name = "caption")
	private String caption;

	@Column(name = "alt_text")
	private String altText;

	@Column(name = "graphic")
	private Blob graphic;

	@Column(name = "start_date_time")
	private Timestamp startDateTime;

	@Column(name = "end_date_time")
	private Timestamp endDateTime;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "application")
	private Application application;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date_time")
	private Timestamp createdDateTime;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date_time")
	private Timestamp updatedDateTime;

	public int getSaleOfferId() {
		return saleOfferId;
	}

	public void setSaleOfferId(int saleOfferId) {
		this.saleOfferId = saleOfferId;
	}

	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public String getAltText() {
		return altText;
	}

	public void setAltText(String altText) {
		this.altText = altText;
	}

	public Blob getGraphic() {
		return graphic;
	}

	public void setGraphic(Blob graphic) {
		this.graphic = graphic;
	}

	public Timestamp getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Timestamp startDateTime) {
		this.startDateTime = startDateTime;
	}

	public Timestamp getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(Timestamp endDateTime) {
		this.endDateTime = endDateTime;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Timestamp updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

}

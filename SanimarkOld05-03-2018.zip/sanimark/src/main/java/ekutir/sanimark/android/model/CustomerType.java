package ekutir.sanimark.android.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ekutir_gateway.gtwy_customer_type")
public class CustomerType {

	@Id
	@GeneratedValue
	@Column(name = "type_id")
	private int typeId;

	@Column(name = "type_caption")
	private String typeCode;

	@Column(name = "type_description")
	private String typeDescription;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "application")
	private Application application;

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getTypeDescription() {
		return typeDescription;
	}

	public void setTypeDescription(String typeDescription) {
		this.typeDescription = typeDescription;
	}

}

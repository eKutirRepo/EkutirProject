package ekutir.sanimark.android.dto;

import java.util.List;

public class FetchPCategoryBean {
	
	private int prodCategoryId;
	private String categoryName;
	private List<ProductAndroidBean> products;
	
	public FetchPCategoryBean() {
		super();
	}
	
	public FetchPCategoryBean(int prodCategoryId, String categoryName, List<ProductAndroidBean> products) {
		super();
		this.prodCategoryId = prodCategoryId;
		this.categoryName = categoryName;
		this.products = products;
	}
	public int getProdCategoryId() {
		return prodCategoryId;
	}
	public void setProdCategoryId(int prodCategoryId) {
		this.prodCategoryId = prodCategoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public List<ProductAndroidBean> getProducts() {
		return products;
	}
	public void setProducts(List<ProductAndroidBean> products) {
		this.products = products;
	}
	
}

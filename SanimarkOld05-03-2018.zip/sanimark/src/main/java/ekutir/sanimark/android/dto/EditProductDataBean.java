package ekutir.sanimark.android.dto;

import java.util.List;

import ekutir.sanimark.view.beans.ItemIdDetailsBean;

public class EditProductDataBean {
	
	private int productId;
	private String productName;
	private int categoryId;
	private String productDescription;
	private byte[] productImage;
	private List<ItemIdDetailsBean> itemList;
	
	public EditProductDataBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EditProductDataBean(int productId, String productName, int categoryId, String productDescription, byte[] productImage,
			List<ItemIdDetailsBean> itemList) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.categoryId = categoryId;
		this.productDescription = productDescription;
		this.productImage = productImage;
		this.itemList = itemList;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public byte[] getProductImage() {
		return productImage;
	}

	public void setProductImage(byte[] productImage) {
		this.productImage = productImage;
	}

	public List<ItemIdDetailsBean> getItemList() {
		return itemList;
	}

	public void setItemList(List<ItemIdDetailsBean> itemList) {
		this.itemList = itemList;
	}

}

package ekutir.sanimark.android.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ekutir_gateway.gtwy_app_master")
public class AppMaster {

	@EmbeddedId
	private AppMasterKey appMasterKey;

	@Column(name = "app_code")
	private String applicationCode;

	public AppMasterKey getAppMasterKey() {
		return appMasterKey;
	}

	public void setAppMasterKey(AppMasterKey appMasterKey) {
		this.appMasterKey = appMasterKey;
	}

	public String getApplicationCode() {
		return applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

}

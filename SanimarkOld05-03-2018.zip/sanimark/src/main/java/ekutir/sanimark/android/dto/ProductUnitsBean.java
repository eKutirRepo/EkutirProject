package ekutir.sanimark.android.dto;

public class ProductUnitsBean {
	
	private int unitId;
	private String unit;
	private Double price;
	private Double advance;
	private Double mrp;
	
	public ProductUnitsBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductUnitsBean(int unitId, String unit, Double price, Double advance, Double mrp) {
		super();
		this.unitId = unitId;
		this.unit = unit;
		this.price = price;
		this.advance = advance;
		this.mrp = mrp;
	}
	
	public int getUnitId() {
		return unitId;
	}

	public void setUnitId(int unitId) {
		this.unitId = unitId;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getAdvance() {
		return advance;
	}

	public void setAdvance(Double advance) {
		this.advance = advance;
	}

	public Double getMrp() {
		return mrp;
	}

	public void setMrp(Double mrp) {
		this.mrp = mrp;
	}
	
}

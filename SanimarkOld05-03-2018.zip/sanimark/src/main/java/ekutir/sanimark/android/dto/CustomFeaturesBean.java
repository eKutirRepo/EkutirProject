package ekutir.sanimark.android.dto;

public class CustomFeaturesBean {
	
	private int featureId;
	private String featureName;
	private String featureDescription;
	
	public CustomFeaturesBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomFeaturesBean(int featureId, String featureName, String featureDescription) {
		super();
		this.featureId = featureId;
		this.featureName = featureName;
		this.featureDescription = featureDescription;
	}

	public int getFeatureId() {
		return featureId;
	}

	public void setFeatureId(int featureId) {
		this.featureId = featureId;
	}

	public String getFeatureName() {
		return featureName;
	}

	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}

	public String getFeatureDescription() {
		return featureDescription;
	}

	public void setFeatureDescription(String featureDescription) {
		this.featureDescription = featureDescription;
	}
	
}

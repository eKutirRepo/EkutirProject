package ekutir.sanimark.model.erp;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "`dbsvadha.erp`.tbl_suppliersxproductitems")
public class SupplierProductItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column
	private int ProductItemSKU;
	@Column
	private int SupplierID;
	@Column
	private Double MRP;
	@Column
	private int CreatedBy;
	@Column
	private Date CreatedDateTime;
	@Column
	private int UpdatedBy;
	@Column
	private Date UpdatedDateTime;
	@Column
	private String ItemName;
	@Column
	private String ItemDescription;
	@Column
	private double UnitPrice;
	@Column
	private String Dimensions;
	@Column
	private int ReOrderLevel;
	@Column
	private int BizCategoryID;
	public SupplierProductItem() {
		super();
	}
	public SupplierProductItem(int productItemSKU, int supplierID, Double procurementPrice, int createdBy,
			Date createdDateTime, int updatedBy, Date updatedDateTime, String itemName, String itemDescription,
			double unitPrice, String dimensions, int reOrderLevel, int bizCategoryID, Double mRP) {
		super();
		ProductItemSKU = productItemSKU;
		SupplierID = supplierID;
		MRP = mRP;
		CreatedBy = createdBy;
		CreatedDateTime = createdDateTime;
		UpdatedBy = updatedBy;
		UpdatedDateTime = updatedDateTime;
		ItemName = itemName;
		ItemDescription = itemDescription;
		UnitPrice = unitPrice;
		Dimensions = dimensions;
		ReOrderLevel = reOrderLevel;
		BizCategoryID = bizCategoryID;
	}
	public int getProductItemSKU() {
		return ProductItemSKU;
	}
	public void setProductItemSKU(int productItemSKU) {
		ProductItemSKU = productItemSKU;
	}
	public int getSupplierID() {
		return SupplierID;
	}
	public void setSupplierID(int supplierID) {
		SupplierID = supplierID;
	}
	
	public Double getMRP() {
		return MRP;
	}
	public void setMRP(Double mRP) {
		MRP = mRP;
	}
	public int getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(int createdBy) {
		CreatedBy = createdBy;
	}
	public Date getCreatedDateTime() {
		return CreatedDateTime;
	}
	public void setCreatedDateTime(Date createdDateTime) {
		CreatedDateTime = createdDateTime;
	}
	public int getUpdatedBy() {
		return UpdatedBy;
	}
	public void setUpdatedBy(int updatedBy) {
		UpdatedBy = updatedBy;
	}
	public Date getUpdatedDateTime() {
		return UpdatedDateTime;
	}
	public void setUpdatedDateTime(Date updatedDateTime) {
		UpdatedDateTime = updatedDateTime;
	}
	public String getItemName() {
		return ItemName;
	}
	public void setItemName(String itemName) {
		ItemName = itemName;
	}
	public String getItemDescription() {
		return ItemDescription;
	}
	public void setItemDescription(String itemDescription) {
		ItemDescription = itemDescription;
	}
	public double getUnitPrice() {
		return UnitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		UnitPrice = unitPrice;
	}
	public String getDimensions() {
		return Dimensions;
	}
	public void setDimensions(String dimensions) {
		Dimensions = dimensions;
	}
	public int getReOrderLevel() {
		return ReOrderLevel;
	}
	public void setReOrderLevel(int reOrderLevel) {
		ReOrderLevel = reOrderLevel;
	}
	public int getBizCategoryID() {
		return BizCategoryID;
	}
	public void setBizCategoryID(int bizCategoryID) {
		BizCategoryID = bizCategoryID;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "SupplierProductItem [ProductItemSKU=" + ProductItemSKU + ", SupplierID=" + SupplierID
				+ ", MRP=" + MRP + ", CreatedBy=" + CreatedBy + ", CreatedDateTime="
				+ CreatedDateTime + ", UpdatedBy=" + UpdatedBy + ", UpdatedDateTime=" + UpdatedDateTime + ", ItemName="
				+ ItemName + ", ItemDescription=" + ItemDescription + ", UnitPrice=" + UnitPrice + ", Dimensions="
				+ Dimensions + ", ReOrderLevel=" + ReOrderLevel + ", BizCategoryID=" + BizCategoryID + "]";
	}
	
	
	
	

}

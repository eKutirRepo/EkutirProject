package ekutir.sanimark.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_product_unit")
public class ProductUnit implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int UnitId;
	
	@Column
	private String Unit;
	
	@Column 
	private Double Price;
	
	@Column
	private Double advance;
	
	@Column
	private Double mrp;

	public ProductUnit() {
		super();
	}

	public ProductUnit(int unitId, String unit, Double price, Double advance, Double mrp) {
		super();
		UnitId = unitId;
		Unit = unit;
		Price = price;
		this.advance = advance;
		this.mrp = mrp;
	}

	public int getUnitId() {
		return UnitId;
	}

	public void setUnitId(int unitId) {
		UnitId = unitId;
	}

	public String getUnit() {
		return Unit;
	}

	public void setUnit(String unit) {
		Unit = unit;
	}

	public Double getPrice() {
		return Price;
	}

	public void setPrice(Double price) {
		Price = price;
	}
	
	public Double getAdvance() {
		return advance;
	}

	public void setAdvance(Double advance) {
		this.advance = advance;
	}

	public Double getMrp() {
		return mrp;
	}

	public void setMrp(Double mrp) {
		this.mrp = mrp;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

package ekutir.sanimark.view.beans;

import java.util.List;

public class CreateProductBean {
	
	private String productName;
	private int categoryId;
	private String productDescription;
	private byte[] productImage;
	
	public CreateProductBean() {
		super();
	}
	public CreateProductBean(String productName, int categoryId, String productDescription, byte[] productImage) {
		super();
		this.productName = productName;
		this.categoryId = categoryId;
		this.productDescription = productDescription;
		this.productImage = productImage;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public byte[] getProductImage() {
		return productImage;
	}
	public void setProductImage(byte[] productImage) {
		this.productImage = productImage;
	}
	
}

package ekutir.sanimark.view.beans;

import java.util.List;

public class FetchItemsforApprovalDto {
	
	private List<FetchItemsApprovalBean> items;

	public List<FetchItemsApprovalBean> getItems() {
		return items;
	}

	public void setItems(List<FetchItemsApprovalBean> items) {
		this.items = items;
	}
}

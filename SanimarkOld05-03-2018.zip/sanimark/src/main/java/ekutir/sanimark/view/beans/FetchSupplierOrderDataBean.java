package ekutir.sanimark.view.beans;

public class FetchSupplierOrderDataBean {
	
	private int orderId;
	private int productId;
	private String productBrandName;
	private String companyName;
	private double orderQuantity;
	private String unit;
	private double price;
	private String orderPaymentMode;
	private double advance;
	private String orderDate;
	private String deliveryDate;
	private int supplier_ack_status;
	private int customerId;
	private String customerFName;
	private String customerMName;
	private String customerLName;
	private long customerMobileNumber;
	private AddressBean address;
	
	public FetchSupplierOrderDataBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FetchSupplierOrderDataBean(int orderId, int productId, String productBrandName, String companyName,
			double orderQuantity, String unit, double price, String orderPaymentMode, double advance, String orderDate, String deliveryDate,
			int supplier_ack_status, int customerId, String customerFName, String customerMName, String customerLName,
			long customerMobileNumber, AddressBean address) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.productBrandName = productBrandName;
		this.companyName = companyName;
		this.orderQuantity = orderQuantity;
		this.unit = unit;
		this.price = price;
		this.orderPaymentMode = orderPaymentMode;
		this.advance = advance;
		this.orderDate = orderDate;
		this.deliveryDate = deliveryDate;
		this.supplier_ack_status = supplier_ack_status;
		this.customerId = customerId;
		this.customerFName = customerFName;
		this.customerMName = customerMName;
		this.customerLName = customerLName;
		this.customerMobileNumber = customerMobileNumber;
		this.address = address;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductBrandName() {
		return productBrandName;
	}

	public void setProductBrandName(String productBrandName) {
		this.productBrandName = productBrandName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public double getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(double orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getOrderPaymentMode() {
		return orderPaymentMode;
	}

	public void setOrderPaymentMode(String orderPaymentMode) {
		this.orderPaymentMode = orderPaymentMode;
	}

	public double getAdvance() {
		return advance;
	}

	public void setAdvance(double advance) {
		this.advance = advance;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public int getSupplier_ack_status() {
		return supplier_ack_status;
	}

	public void setSupplier_ack_status(int supplier_ack_status) {
		this.supplier_ack_status = supplier_ack_status;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerFName() {
		return customerFName;
	}

	public void setCustomerFName(String customerFName) {
		this.customerFName = customerFName;
	}

	public String getCustomerMName() {
		return customerMName;
	}

	public void setCustomerMName(String customerMName) {
		this.customerMName = customerMName;
	}

	public String getCustomerLName() {
		return customerLName;
	}

	public void setCustomerLName(String customerLName) {
		this.customerLName = customerLName;
	}

	public long getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(long customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}

	public AddressBean getAddress() {
		return address;
	}

	public void setAddress(AddressBean address) {
		this.address = address;
	}
	
}

package ekutir.sanimark.view.beans;

public class AdminViewBean {
	
	private int adminId;
	private String adminName;
	private String loginId;
	private String password;
	private int status;
	
	public AdminViewBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminViewBean(int adminId, String adminName, String loginId, String password, int status) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.loginId = loginId;
		this.password = password;
		this.status = status;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
}

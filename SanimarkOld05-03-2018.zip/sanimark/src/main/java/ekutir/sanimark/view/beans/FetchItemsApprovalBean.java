package ekutir.sanimark.view.beans;

public class FetchItemsApprovalBean {
	
	private int supplierId;
	private String supplierName;
	private int itemId;
	private String itemName;
	private String itemBrand;
	private int productCategoryId;
	private double mrp;
	private double sellingPrice;
	private String itemDescription;
	private String itemImage;
	private String warranty;
	private String dimension;
	private String expiryDate;
	private String manufactureDate;
	private int status;
	private String categoryName;
	private String color;
	
	public FetchItemsApprovalBean() {
		super();
	}

	public FetchItemsApprovalBean(int supplierId, String supplierName, int itemId, String itemName, String itemBrand,
			int productCategoryId, double mrp, double sellingPrice, String itemDescription, String itemImage,
			String warranty, String dimension, String expiryDate, String manufactureDate, int status,
			String categoryName, String color) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemBrand = itemBrand;
		this.productCategoryId = productCategoryId;
		this.mrp = mrp;
		this.sellingPrice = sellingPrice;
		this.itemDescription = itemDescription;
		this.itemImage = itemImage;
		this.warranty = warranty;
		this.dimension = dimension;
		this.expiryDate = expiryDate;
		this.manufactureDate = manufactureDate;
		this.status = status;
		this.categoryName = categoryName;
		this.color = color;
	}



	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemBrand() {
		return itemBrand;
	}
	public void setItemBrand(String itemBrand) {
		this.itemBrand = itemBrand;
	}
	public int getProductCategoryId() {
		return productCategoryId;
	}
	public void setProductCategoryId(int productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
	
	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public double getMrp() {
		return mrp;
	}
	public void setMrp(double mrp) {
		this.mrp = mrp;
	}
	public double getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getItemImage() {
		return itemImage;
	}
	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(String manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	
}

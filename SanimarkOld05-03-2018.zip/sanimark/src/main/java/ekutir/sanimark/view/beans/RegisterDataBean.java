package ekutir.sanimark.view.beans;

import java.util.Date;

public class RegisterDataBean {
	
	private int supplierId;
	private String loginId;
	private String password;
	private String businessName;
	private String primaryContactName;
	private String primaryContactNumber;
	private String secondaryContactName;
	private String secondaryContactNumber;
	private String businessDescription;
	private int status;
	private AddressBean address;
	
	
	public RegisterDataBean() {
		super();
	}


	public RegisterDataBean(int supplierId, String loginId, String password, String businessName,
			String primaryContactName, String primaryContactNumber, String secondaryContactName,
			String secondaryContactNumber, String businessDescription,int status,AddressBean address) {
		super();
		this.supplierId = supplierId;
		this.loginId = loginId;
		this.password = password;
		this.businessName = businessName;
		this.primaryContactName = primaryContactName;
		this.primaryContactNumber = primaryContactNumber;
		this.secondaryContactName = secondaryContactName;
		this.secondaryContactNumber = secondaryContactNumber;
		this.businessDescription = businessDescription;
		this.status=status;
		this.address = address;
	}


	public int getSupplierId() {
		return supplierId;
	}


	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}


	public String getLoginId() {
		return loginId;
	}


	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getBusinessName() {
		return businessName;
	}


	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}


	public String getPrimaryContactName() {
		return primaryContactName;
	}


	public void setPrimaryContactName(String primaryContactName) {
		this.primaryContactName = primaryContactName;
	}


	public String getPrimaryContactNumber() {
		return primaryContactNumber;
	}


	public void setPrimaryContactNumber(String primaryContactNumber) {
		this.primaryContactNumber = primaryContactNumber;
	}


	public String getSecondaryContactName() {
		return secondaryContactName;
	}


	public void setSecondaryContactName(String secondaryContactName) {
		this.secondaryContactName = secondaryContactName;
	}


	public String getSecondaryContactNumber() {
		return secondaryContactNumber;
	}


	public void setSecondaryContactNumber(String secondaryContactNumber) {
		this.secondaryContactNumber = secondaryContactNumber;
	}


	public String getBusinessDescription() {
		return businessDescription;
	}


	public void setStatus(int status) {
		this.status = status;
	}
	
	public int getStatus() {
		return status;
	}


	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}


	public AddressBean getAddress() {
		return address;
	}


	public void setAddress(AddressBean address) {
		this.address = address;
	}


	

}

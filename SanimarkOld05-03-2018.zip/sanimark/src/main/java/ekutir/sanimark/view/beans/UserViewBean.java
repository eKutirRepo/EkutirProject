package ekutir.sanimark.view.beans;

public class UserViewBean {

	private String userName;
	private String message;
	private int userId;
	private String loginId;
    private String password;
	//private String remPwd;
	private String role;
	private int status;
    
    public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
    public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/*public String getRemPwd() {
		return remPwd;
	}

	public void setRemPwd(String remPwd) {
		this.remPwd = remPwd;
	}*/
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public int getStatus() {
		return status;
	}

	public int setStatus(int status) {
		return this.status = status;
	}

	public UserViewBean() {}
	 public UserViewBean(int userId,String loginId,String userName,String password,String message, String role, int status) {
		  this.userId=userId;
	      this.loginId = loginId;
	      this.userName = userName;
	      this.password = password;
	      this.message=message;
	      this.role=role;
	      this.status=status;
	      
	   }
}

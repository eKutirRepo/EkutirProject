package ekutir.sanimark.view.beans;

public class FetchServicesDataBean {
	
	private int serviceId;
	private String business_name;
	private String serviceBrandName;
	private int servCategoryId;
	private String servCategoryName;;
	private String contactDetails;
	private String serviceDescription;
	private String whenToUse;
	private String howToUse;
	private String consumerBenifit;
	
	public FetchServicesDataBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FetchServicesDataBean(int serviceId, String business_name, String serviceBrandName, int servCategoryId,
			String servCategoryName, String contactDetails, String serviceDescription, String whenToUse,
			String howToUse, String consumerBenifit) {
		super();
		this.serviceId = serviceId;
		this.business_name = business_name;
		this.serviceBrandName = serviceBrandName;
		this.servCategoryId = servCategoryId;
		this.servCategoryName = servCategoryName;
		this.contactDetails = contactDetails;
		this.serviceDescription = serviceDescription;
		this.whenToUse = whenToUse;
		this.howToUse = howToUse;
		this.consumerBenifit = consumerBenifit;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getBusiness_name() {
		return business_name;
	}

	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}

	public String getServiceBrandName() {
		return serviceBrandName;
	}

	public void setServiceBrandName(String serviceBrandName) {
		this.serviceBrandName = serviceBrandName;
	}

	public int getServCategoryId() {
		return servCategoryId;
	}

	public void setServCategoryId(int servCategoryId) {
		this.servCategoryId = servCategoryId;
	}

	public String getServCategoryName() {
		return servCategoryName;
	}

	public void setServCategoryName(String servCategoryName) {
		this.servCategoryName = servCategoryName;
	}

	public String getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(String contactDetails) {
		this.contactDetails = contactDetails;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public String getWhenToUse() {
		return whenToUse;
	}

	public void setWhenToUse(String whenToUse) {
		this.whenToUse = whenToUse;
	}

	public String getHowToUse() {
		return howToUse;
	}

	public void setHowToUse(String howToUse) {
		this.howToUse = howToUse;
	}

	public String getConsumerBenifit() {
		return consumerBenifit;
	}

	public void setConsumerBenifit(String consumerBenifit) {
		this.consumerBenifit = consumerBenifit;
	}
	
}

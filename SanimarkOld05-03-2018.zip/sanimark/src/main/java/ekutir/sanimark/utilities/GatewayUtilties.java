package ekutir.sanimark.utilities;

import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;

import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;

import ekutir.sanimark.constant.GatewayConstants;
import ekutir.sanimark.dto.AddressDto;
import ekutir.sanimark.dto.Communication;
import ekutir.sanimark.dto.CustomerAndLandDetails;
import ekutir.sanimark.dto.CustomerDto;
import ekutir.sanimark.dto.LandDetailsDto;
import ekutir.sanimark.dto.RegistrationDto;
import ekutir.sanimark.dto.RequestValidationDto;
import ekutir.sanimark.dto.UserDto;
import ekutir.sanimark.dto.ValidationDto;
import ekutir.sanimark.service.RegistrationService;

public class GatewayUtilties {

	@Autowired
	private RegistrationService registrationService;

	public static RequestValidationDto validateRequestForMicroEntrepreneur(RegistrationDto registrationDto) {
		RequestValidationDto validationDto = new RequestValidationDto();
		boolean isSuccesfullyValidated = false;
		List<ValidationDto> missingOrInvalidFieldsAndMessages = new ArrayList<ValidationDto>();
		ValidationDto validation = null;
		if (null != registrationDto && null != registrationDto.getUser()) {
			if ((null != registrationDto.getUser().getAadharNumber())
					&& (!registrationDto.getUser().getAadharNumber().isEmpty())) {
				isSuccesfullyValidated = true;
			} else {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.AADHAAR_NUMBER_TAG);
				validation.setMessage(GatewayConstants.AADHAAR_NUMBER_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}
			if (!((registrationDto.getCommunication().getApplicationCode() != null)
					&& (!registrationDto.getCommunication().getApplicationCode().isEmpty()))) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.APPLICATION_INDENTIFIER_TAG);
				validation.setMessage(GatewayConstants.APPLICATION_INDENTIFIER_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}
			if (!((registrationDto.getUser().getFirstName() != null)
					&& (!registrationDto.getUser().getFirstName().isEmpty()))) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.FIRST_NAME_TAG);
				validation.setMessage(GatewayConstants.FIRST_NAME_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}
			if (!((registrationDto.getUser().getLastName() != null)
					&& (!registrationDto.getUser().getLastName().isEmpty()))) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.LAST_NAME_TAG);
				validation.setMessage(GatewayConstants.LAST_NAME_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}
			if (!((registrationDto.getCommunication().getImei()) != null)
					&& (!registrationDto.getCommunication().getImei().isEmpty())) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.IMEI_NUMBER_TAG);
				validation.setMessage(GatewayConstants.IMEI_NUMBER_MISSING_INVALID_STATUS_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}
			if (!((registrationDto.getCommunication().getPhoneNumber() != 0)
					&& String.valueOf(registrationDto.getCommunication().getPhoneNumber()).matches("\\d{10}"))) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.PHONE_NUMBER_TAG);
				validation.setMessage(GatewayConstants.PHONE_NUMBER_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}

			// NOT MANDATORY
			/*
			 * if (!((registrationDto.getUser().getShopLicenseNumber() != null)
			 * &&
			 * (!registrationDto.getUser().getShopLicenseNumber().isEmpty()))) {
			 * isSuccesfullyValidated = false; validation = new ValidationDto();
			 * validation.setCode(GatewayConstants.SHOP_LICENSE_NUMBER_TAG);
			 * validation.setMessage(GatewayConstants.
			 * SHOP_LICENSE_NUMBER_MISSING_INVALID_MESSAGE);
			 * missingOrInvalidFieldsAndMessages.add(validation); }
			 */
			/*
			 * if (!(null != registrationDto.getUser().getTypeOfUser() &&
			 * !registrationDto.getUser().getTypeOfUser().isEmpty() &&
			 * (registrationDto.getUser().getTypeOfUser()
			 * .equalsIgnoreCase(GatewayConstants.CUSTOMER_TYPE_RETURNING_USER)
			 * || registrationDto.getUser().getTypeOfUser()
			 * .equalsIgnoreCase(GatewayConstants.
			 * CUSTOMER_TYPE_BUSINESS_DELEGATE)))) { if
			 * (!((registrationDto.getUser().getShopLicenseExpiryDate() != null)
			 * && (checkDateFormat(registrationDto.getUser().
			 * getShopLicenseExpiryDate(), "dd-MM-yyyy")))) {
			 * isSuccesfullyValidated = false; validation = new ValidationDto();
			 * validation.setCode(GatewayConstants.SHOP_LICENSE_EXPIRY_DATE_TAG)
			 * ; validation.setMessage(GatewayConstants.
			 * SHOP_LICENSE_EXPIRY_DATE_MISSING_INVALID_MESSAGE);
			 * missingOrInvalidFieldsAndMessages.add(validation); } }
			 */
			if (!((registrationDto.getUser().getAddress() != null)
					&& (validateAddress(registrationDto.getUser().getAddress())))) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.ADDRESS_TAG);
				validation.setMessage(GatewayConstants.ADDRESS_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}

			if (registrationDto.getCommunication().getApplicationCode().equals(GatewayConstants.RUHAAT_APP_CODE)) {
				/*if (!validateBankDetails(registrationDto.getUser())) {
					isSuccesfullyValidated = false;
					validation = new ValidationDto();
					validation.setCode(GatewayConstants.BANK_TAG);
					validation.setMessage(GatewayConstants.BANK_DETAILS_MISSING_INVALID_MESSAGE);
					missingOrInvalidFieldsAndMessages.add(validation);
				}*/
			}
		} else {
			isSuccesfullyValidated = false;
			validation = new ValidationDto();
			validation.setCode(GatewayConstants.MISSING_USER_DETAILS_STATUS_CODE);
			validation.setMessage(GatewayConstants.MISSING_USER_DETAILS_STATUS_MESSAGE);
		}
		validationDto.setListOfValidationMessagesWithCodes(missingOrInvalidFieldsAndMessages);
		validationDto.setSuccesfullyValidated(isSuccesfullyValidated);
		return validationDto;
	}

	private static boolean validateBankDetails(UserDto userDto) {
		boolean isSuccesfullyValidated = false;
		if (null != userDto.getBankAccountName() && !userDto.getBankAccountName().isEmpty()) {
			isSuccesfullyValidated = true;
		}
		if (null != userDto.getBankAccountNumber() && !userDto.getBankAccountNumber().isEmpty()
				&& userDto.getBankAccountNumber().matches("[0-9]+")) {
			isSuccesfullyValidated = isSuccesfullyValidated && true;
		}

		if (null != userDto.getBankIfscCode() && !userDto.getBankIfscCode().isEmpty()) {
			isSuccesfullyValidated = isSuccesfullyValidated && true;
		}

		if (null != userDto.getBankName() && !userDto.getBankName().isEmpty()) {
			isSuccesfullyValidated = isSuccesfullyValidated && true;
		}
		return isSuccesfullyValidated;
	}

	private static boolean validateAddress(AddressDto addressDto) {
		boolean isSuccesfullyValidated = false;
		if ((addressDto.getAddressLine1() != null) && (!addressDto.getAddressLine1().isEmpty())) {
			isSuccesfullyValidated = true;
		} else {
			isSuccesfullyValidated = false;
		}
		if (!((addressDto.getBlock() != null) && (!addressDto.getBlock().isEmpty()))) {
			isSuccesfullyValidated = isSuccesfullyValidated && false;
		}
		if (!((addressDto.getCity() != null) && (!addressDto.getCity().isEmpty()))) {
			isSuccesfullyValidated = isSuccesfullyValidated && false;
		}
		if (!((addressDto.getState() != null) && (!addressDto.getState().isEmpty()))) {
			isSuccesfullyValidated = isSuccesfullyValidated && false;
		}
		if (!((addressDto.getCountry() != null) && (!addressDto.getCountry().isEmpty()))) {
			isSuccesfullyValidated = isSuccesfullyValidated && false;
		}
		if (!((addressDto.getPostalCode() != null) && (addressDto.getPostalCode() != 0L))) {
			isSuccesfullyValidated = isSuccesfullyValidated && false;
		}
		return isSuccesfullyValidated;
	}

	private static boolean checkDateFormat(Date meShopLicenseExpiryDate, String string) {
		return true;
	}

	public static RequestValidationDto validateRequestForOtp(Communication otp) {
		RequestValidationDto validationDto = new RequestValidationDto();
		boolean isSuccesfullyValidated = false;
		List<ValidationDto> missingOrInvalidFieldsAndMessages = new ArrayList<ValidationDto>();
		ValidationDto validation = null;
		if (null != otp) {
			if (otp.getOtp() != 0) {
				isSuccesfullyValidated = true;
			} else {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.OTP_TAG);
				validation.setMessage(GatewayConstants.OTP_TAG_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}
			if (!(otp.getPhoneNumber() != 0 && String.valueOf(otp.getPhoneNumber()).matches("\\d{10}"))) {
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.PHONE_NUMBER_TAG);
				validation.setMessage(GatewayConstants.PHONE_NUMBER_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}
			if (null == otp.getOtpGenerationDate()) {
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.OTP_RECEIVED_DATE_TIME);
				validation.setMessage(GatewayConstants.OTP_RECEIVED_DATE_TIME_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}
		}
		validationDto.setListOfValidationMessagesWithCodes(missingOrInvalidFieldsAndMessages);
		validationDto.setSuccesfullyValidated(isSuccesfullyValidated);
		return validationDto;
	}

	public static RequestValidationDto validateRequestForCustomer(RegistrationDto registration) {
		return validateRequestForCustomer(registration.getCustomer());
	}

	public static RequestValidationDto validateRequestForCustomer(CustomerDto customer) {
		RequestValidationDto validationDto = new RequestValidationDto();
		boolean isSuccesfullyValidated = false;
		List<ValidationDto> missingOrInvalidFieldsAndMessages = new ArrayList<ValidationDto>();
		ValidationDto validation = null;
		if (null != customer) {
			if (null != customer.getCustFirstName() && !customer.getCustFirstName().isEmpty()) {
				isSuccesfullyValidated = true;
			} else {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.FIRST_NAME_TAG);
				validation.setMessage(GatewayConstants.FIRST_NAME_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}

			/*
			 * if (!(null != customer.getCustMiddleName() &&
			 * !customer.getCustMiddleName().isEmpty())) {
			 * isSuccesfullyValidated = false; validation = new ValidationDto();
			 * validation.setCode(GatewayConstants.MIDDLE_NAME_TAG);
			 * validation.setMessage(GatewayConstants.
			 * MIDDLE_NAME_TAG_MISSING_INVALID_MESSAGE);
			 * missingOrInvalidFieldsAndMessages.add(validation); }
			 */

			if (!(null != customer.getCustLastName() && !customer.getCustLastName().isEmpty())) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.LAST_NAME_TAG);
				validation.setMessage(GatewayConstants.LAST_NAME_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}

			if (!(customer.getCustPhoneNumber() != 0L
					&& String.valueOf(customer.getCustPhoneNumber()).matches("\\d{10}"))) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.PHONE_NUMBER_TAG);
				validation.setMessage(GatewayConstants.PHONE_NUMBER_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}/* else {
				RequestValidationDto validateCustomerPhoneNumber = new Regis
						.verifyCustomerPhoneNumber(customer.getUserId(), customer.getCustPhoneNumber());
				if (!validateCustomerPhoneNumber.isSuccesfullyValidated()) {
					isSuccesfullyValidated = false;
					missingOrInvalidFieldsAndMessages
							.addAll(validateCustomerPhoneNumber.getListOfValidationMessagesWithCodes());
				}
			}*/
			/*if (!(null != customer.getCustAadharNumber() && !customer.getCustAadharNumber().isEmpty())) {
				isSuccesfullyValidated = false;
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.AADHAAR_NUMBER_TAG);
				validation.setMessage(GatewayConstants.AADHAAR_NUMBER_MISSING_INVALID_MESSAGE);
				missingOrInvalidFieldsAndMessages.add(validation);
			}*/
		}
		validationDto.setListOfValidationMessagesWithCodes(missingOrInvalidFieldsAndMessages);
		validationDto.setSuccesfullyValidated(isSuccesfullyValidated);
		return validationDto;
	}

	public static String generateAuthKey(String aadhaarId, long phoneNumber, String tempAuthKey) {
		Random rand = new Random();
		String rndm = Integer.toString(rand.nextInt()) + (System.currentTimeMillis() / 1000L);
		return hashCal("SHA-256", rndm).substring(0, 20);
	}

	public static String getMasterKey(String meApplicationCode) {
		if (meApplicationCode.equalsIgnoreCase(GatewayConstants.SANIMARK_APP_CODE)) {
			return GatewayConstants.SANIMARK_MASTER_KEY;
		} else if (meApplicationCode.equalsIgnoreCase(GatewayConstants.AGRIMARK_APP_CODE)) {
			return GatewayConstants.AGRIMARK_MASTER_KEY;
		} else {
			return GatewayConstants.RUHAAT_MASTER_KEY;
		}
	}

	public static String getCurrentDateAsString(String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(new Date());
	}

	public static Date getCurrentDate(String format) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.parse(formatter.format(new Date()));
	}

	public static String convertBlobToBase64(Blob graphic) throws SQLException {
		byte[] bytes = graphic.getBytes(1, (int) graphic.length());
		String encodedfile = null;
		encodedfile = new String(Base64.getEncoder().encodeToString(bytes));
		return encodedfile;
	}

	public static Blob convertByteArrayToBlob(byte[] byteArray) throws SerialException, SQLException {
		if (null != byteArray) {
			return new javax.sql.rowset.serial.SerialBlob(byteArray);
		}
		return null;
	}

	public static String getMasterKey(String meApplicationCode, long phoneNumber) {
		if (meApplicationCode.equalsIgnoreCase(GatewayConstants.SANIMARK_APP_CODE)) {
			return GatewayConstants.SANIMARK_MASTER_KEY;
		} else if (meApplicationCode.equalsIgnoreCase(GatewayConstants.AGRIMARK_APP_CODE)) {
			return GatewayConstants.AGRIMARK_MASTER_KEY;
		} else {
			return GatewayConstants.RUHAAT_MASTER_KEY;
		}
	}

	public static RequestValidationDto checkRequestForReturningAndBusinessDelegateUser(Communication communication) {
		RequestValidationDto requestValidation = new RequestValidationDto();
		boolean isSuccessfullyValidated = false;
		List<ValidationDto> listOfValidationMessagesWithCodes = new ArrayList<>();
		ValidationDto validation = null;
		if (null != communication.getImei() && !communication.getImei().isEmpty()) {
			isSuccessfullyValidated = true;
		} else {
			validation = new ValidationDto();
			validation.setCode(GatewayConstants.IMEI_NUMBER_MISSING_INVALID_STATUS_CODE);
			validation.setMessage(GatewayConstants.IMEI_NUMBER_MISSING_INVALID_STATUS_MESSAGE);
			listOfValidationMessagesWithCodes.add(validation);
		}
		if (0L != communication.getPhoneNumber()) {
			isSuccessfullyValidated = isSuccessfullyValidated && true;
		} else {
			validation = new ValidationDto();
			validation.setCode(GatewayConstants.PHONE_NUMBER_MISSING_INVALID_CODE);
			validation.setMessage(GatewayConstants.PHONE_NUMBER_MISSING_INVALID_MESSAGE);
			isSuccessfullyValidated = isSuccessfullyValidated && false;
		}
		requestValidation.setSuccesfullyValidated(isSuccessfullyValidated);
		requestValidation.setListOfValidationMessagesWithCodes(listOfValidationMessagesWithCodes);
		return requestValidation;
	}

	public static RequestValidationDto validateRequestForUser(UserDto customer) {
		RequestValidationDto requestValidation = new RequestValidationDto();
		boolean isSuccessfullyValidated = false;
		List<ValidationDto> listOfValidationMessagesWithCodes = new ArrayList<>();
		ValidationDto validation = null;
		if (null != customer.getFirstName() && !customer.getFirstName().isEmpty()) {
			isSuccessfullyValidated = true;
		} else {
			isSuccessfullyValidated = false;
			validation = new ValidationDto();
			validation.setCode(GatewayConstants.USER_FIRST_NAME_MISSING_CODE);
			validation.setMessage(GatewayConstants.USER_FNAME_INVALID_MESSAGE);
			listOfValidationMessagesWithCodes.add(validation);
		}

		if (null != customer.getLastName() && !customer.getLastName().isEmpty()) {
			isSuccessfullyValidated = isSuccessfullyValidated && true;
		} else {
			isSuccessfullyValidated = false;
			validation = new ValidationDto();
			validation.setCode(GatewayConstants.USER_LAST_NAME_MISSING_CODE);
			validation.setMessage(GatewayConstants.USER_LAST_INVALID_MESSAGE);
			listOfValidationMessagesWithCodes.add(validation);
		}
		if (validateAddress(customer.getAddress())) {
			isSuccessfullyValidated = isSuccessfullyValidated && true;
		} else {
			isSuccessfullyValidated = false;
			validation = new ValidationDto();
			validation.setCode(GatewayConstants.ADDRESS_TAG);
			validation.setMessage(GatewayConstants.ADDRESS_MISSING_INVALID_MESSAGE);
			listOfValidationMessagesWithCodes.add(validation);
		}
		requestValidation.setListOfValidationMessagesWithCodes(listOfValidationMessagesWithCodes);
		requestValidation.setSuccesfullyValidated(isSuccessfullyValidated);
		return requestValidation;
	}

	public static RequestValidationDto validateRequestForMeAndMyLand(CustomerAndLandDetails customerLandDetails,
			String typeOfValidation) {
		RequestValidationDto requestValidation = new RequestValidationDto();
		boolean isSuccesfullyValidated = false;
		List<ValidationDto> listOfValidationMessagesWithCodes = new ArrayList<>();
		ValidationDto validation = null;
		if (typeOfValidation.equalsIgnoreCase(GatewayConstants.CREATE_CUSTOMER_AND_LAND_DETAILS)
				|| typeOfValidation.equalsIgnoreCase(GatewayConstants.UPDATE_CUSTOMER_AND_LAND_DETAILS)) {
			RequestValidationDto validateRequestForCustomer = new RequestValidationDto();
			if (0 != customerLandDetails.getCustomer().getCustomerId()
					&& null != customerLandDetails.getCustomer().getCustAadharNumber()) {
				// validateRequestForCustomer =
				// validateCustomerPhoneNumber(customerLandDetails.getCustomer().getUserId(),
				// customerLandDetails.getCustomer().getCustPhoneNumber());
				// if (!validateRequestForCustomer.isSuccesfullyValidated()) {
				// isSuccesfullyValidated = false;
				// listOfValidationMessagesWithCodes
				// .addAll(validateRequestForCustomer.getListOfValidationMessagesWithCodes());
				// } else {
				// isSuccesfullyValidated = true;
				// }
				validateRequestForCustomer = validateRequestForCustomer(customerLandDetails.getCustomer());
				if (!validateRequestForCustomer.isSuccesfullyValidated()) {
					isSuccesfullyValidated = false;
					listOfValidationMessagesWithCodes
							.addAll(validateRequestForCustomer.getListOfValidationMessagesWithCodes());
				} else {
					isSuccesfullyValidated = true;
				}
			} else {
				isSuccesfullyValidated = true;
			}
			if (null != customerLandDetails.getCustomer().getAddress()) {
				isSuccesfullyValidated = isSuccesfullyValidated
						&& validateAddress(customerLandDetails.getCustomer().getAddress());
				if (!isSuccesfullyValidated) {
					validation = new ValidationDto();
					validation.setCode(GatewayConstants.ADDRESS_MISSING_INVALID_CODE);
					validation.setMessage(GatewayConstants.ADDRESS_MISSING_INVALID_MESSAGE);
					listOfValidationMessagesWithCodes.add(validation);
				}
			}
			if (null != customerLandDetails.getLandDetails()) {
				List<LandDetailsDto> landDetails = customerLandDetails.getLandDetails();
				for (LandDetailsDto details : landDetails) {
					if (null != details.getLandLocation() && !details.getLandLocation().isEmpty()) {
						isSuccesfullyValidated = isSuccesfullyValidated && true;
					} else {
						validation = new ValidationDto();
						validation.setCode(GatewayConstants.LAND_LOCATION_INVALID_STATUS_CODE);
						validation.setMessage(GatewayConstants.LAND_LOCATION_INVALID_STATUS_MESSAGE);
						listOfValidationMessagesWithCodes.add(validation);
					}

					if (null != details.getLandOwnership() && !details.getLandOwnership().isEmpty()) {
						isSuccesfullyValidated = isSuccesfullyValidated && true;
					} else {
						validation = new ValidationDto();
						validation.setCode(GatewayConstants.LAND_OWNERSHIP_INVALID_STATUS_CODE);
						validation.setMessage(GatewayConstants.LAND_OWNERSHIP_INVALID_STATUS_MESSAGE);
						listOfValidationMessagesWithCodes.add(validation);
					}

					/*if (null != details.getLandArea() && details.getLandArea() != new Double(0)) {
						isSuccesfullyValidated = isSuccesfullyValidated && true;
					} else {
						validation = new ValidationDto();
						validation.setCode(GatewayConstants.LAND_AREA_INVALID_STATUS_CODE);
						validation.setMessage(GatewayConstants.LAND_AREA_INVALID_STATUS_MESSAGE);
						listOfValidationMessagesWithCodes.add(validation);
					}*/

					if (null != details.getLandUnit() && !details.getLandUnit().isEmpty()) {
						isSuccesfullyValidated = isSuccesfullyValidated && true;
					} else {
						validation = new ValidationDto();
						validation.setCode(GatewayConstants.LAND_UOM_INVALID_STATUS_CODE);
						validation.setMessage(GatewayConstants.LAND_UOM_INVALID_STATUS_MESSAGE);
						listOfValidationMessagesWithCodes.add(validation);
					}

					if (typeOfValidation.equalsIgnoreCase(GatewayConstants.UPDATE_CUSTOMER_AND_LAND_DETAILS)) {
						if (details.getLandId() != 0) {
							isSuccesfullyValidated = isSuccesfullyValidated && true;
						} else {
							validation = new ValidationDto();
							validation.setCode(GatewayConstants.LAND_ID_INVALID_STATUS_CODE);
							validation.setMessage(GatewayConstants.LAND_ID_INVALID_STATUS_MESSAGE);
							listOfValidationMessagesWithCodes.add(validation);
						}
					}
				}
			}
		} else {
			// Fetch customer land details
			if (null != customerLandDetails.getCustomer() && customerLandDetails.getCustomer().getCustomerId() != 0) {
				isSuccesfullyValidated = true;
			} else {
				validation = new ValidationDto();
				validation.setCode(GatewayConstants.CUST_ID_INVALID_STATUS_CODE);
				validation.setMessage(GatewayConstants.CUST_ID_INVALID_STATUS_MESSAGE);
				listOfValidationMessagesWithCodes.add(validation);
			}
		}

		requestValidation.setListOfValidationMessagesWithCodes(listOfValidationMessagesWithCodes);
		requestValidation.setSuccesfullyValidated(isSuccesfullyValidated);
		return requestValidation;
	}

	public static String hashCal(String type, String str) {
		byte[] hashseq = str.getBytes();
		StringBuffer hexString = new StringBuffer();
		try {
			MessageDigest algorithm = MessageDigest.getInstance(type);
			algorithm.reset();
			algorithm.update(hashseq);
			byte messageDigest[] = algorithm.digest();
			for (int i = 0; i < messageDigest.length; i++) {
				String hex = Integer.toHexString(0xFF & messageDigest[i]);
				if (hex.length() == 1) {
					hexString.append("0");
				}
				hexString.append(hex);
			}
		} catch (NoSuchAlgorithmException nsae) {
		}
		return hexString.toString();
	}

	public static Date convertToLocalTimezone(Date shopLicExpiryDate) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(GatewayConstants.MYSQL_TIMESTAMP_FORMAT);
		formatter.setTimeZone(TimeZone.getTimeZone("IST"));
		 //formatter.setTimeZone(TimeZone.getTimeZone("NPT"));
		return formatter.parse(formatter.format(shopLicExpiryDate));
	}
}
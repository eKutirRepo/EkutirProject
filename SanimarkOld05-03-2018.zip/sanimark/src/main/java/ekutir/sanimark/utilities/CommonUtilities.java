package ekutir.sanimark.utilities;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.codec.binary.Base64;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class CommonUtilities {
	DateFormat formatter = null;

	
	public String currentDateTime() throws ParseException
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		dateFormat.setTimeZone(TimeZone.getTimeZone("IST")); 
		//dateFormat.setTimeZone(TimeZone.getTimeZone("NPT")); 
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	public String expiryDateTime() throws ParseException
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		dateFormat.setTimeZone(TimeZone.getTimeZone("IST")); 
		//dateFormat.setTimeZone(TimeZone.getTimeZone("NPT")); 
		Date date = new Date();
		return dateFormat.format(date);
		//Date expDt = addDays(date,1);
		//return dateFormat.format(expDt);
	}
	
	 public Date addDays(Date date, int days)
	    {
		 Calendar cal = Calendar.getInstance();
	        cal.setTime(date);
	        cal.add(Calendar.DATE, days); 
	        return cal.getTime();
	    }
	 public String nullValueCheck(Object value) {
			String result = "";
			if (value != null) {
				result = value.toString();
			} else {
				result = "";
			}
			return result;
		}
	 
	 public double emptyIntegerValueCheck(Object value) {
			double result = 0;
			if (value != null) {
				result = Double.parseDouble((value.toString()));
			} else {
				result = 0;
			}
			return result;
		}
	 public  int emptyIntegerValue(Object value) {
			int result = 0;
			if (value != null) {
				result = Integer.parseInt(value.toString());
			} else {
				result = 0;
			}
			return result;
		}
	 
	 public  String base64ToString(Object value) {
			String responseImage = "";
			if (value != null) {
				byte[] responseImg = Base64.encodeBase64((byte[]) value);
				try {
					responseImage = new String(responseImg, "UTF-8");
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			} else {
				responseImage = "";
			}
			return responseImage;
		}
	 
	 public static String generateHash(String input) {
			StringBuilder hash = new StringBuilder();

			try {
				MessageDigest sha = MessageDigest.getInstance("SHA-1");
				byte[] hashedBytes = sha.digest(input.getBytes());
				char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
				for (int idx = 0; idx < hashedBytes.length; ++idx) {
					byte b = hashedBytes[idx];
					hash.append(digits[(b & 0xf0) >> 4]);
					hash.append(digits[b & 0x0f]);
				}
			} catch (NoSuchAlgorithmException e) {
				// handle error here.
			}

			return hash.toString();
		}
}

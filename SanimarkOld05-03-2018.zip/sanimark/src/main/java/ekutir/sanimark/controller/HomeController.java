package ekutir.sanimark.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import ekutir.sanimark.constant.GatewayConstants;
import ekutir.sanimark.dto.CustomerAndLandDetails;
import ekutir.sanimark.dto.CustomerDto;
import ekutir.sanimark.dto.CustomerListDto;
import ekutir.sanimark.dto.CustomerTypes;
import ekutir.sanimark.dto.RequestValidationDto;
import ekutir.sanimark.dto.StatusDto;
import ekutir.sanimark.dto.UserDto;
import ekutir.sanimark.dto.UserIdDto;
import ekutir.sanimark.dto.ValidationDto;
import ekutir.sanimark.service.HomeService;
import ekutir.sanimark.service.RegistrationService;
import ekutir.sanimark.utilities.GatewayUtilties;

@Controller
public class HomeController {

	@Autowired
	HomeService homeService;

	@Autowired
	RegistrationService registrationService;

	@Autowired
	ServletContext servletContext;

	private static final Logger LOGGER = Logger.getLogger(HomeController.class);

/*	@RequestMapping(value = { "/getAdvertisements/{appCode}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.GET })
	public ResponseEntity<List<AdvertisementDto>> getAdvertisements(@RequestHeader("master_key") String masterKey,
			@PathVariable String appCode) throws ParseException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.MASTER_KEY_TAG, masterKey);
		AdvertisementDto advertisementDto = null;
		StatusDto status = new StatusDto();
		List<AdvertisementDto> advertisements = new ArrayList<>();
		if (null != masterKey && null != appCode) {
			advertisementDto = new AdvertisementDto();
			if (homeService.isMasterKeyExists(masterKey)) {
				if (homeService.isAppCodeExists(appCode)) {
					advertisements = homeService.fetchAdvertisements(appCode, masterKey);
					if (!(null != advertisements && advertisements.size() > 0)) {
						advertisements = new ArrayList<>();
						status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
						status.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
						advertisementDto.setStatus(status);
						advertisements.add(advertisementDto);
					}
					LOGGER.info("Advertisements fetched successfully.");
					return new ResponseEntity<List<AdvertisementDto>>(advertisements, headers, HttpStatus.OK);
				} else {
					status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.APP_CODE_INVALID_STATUS_MESSAGE);
					advertisementDto.setStatus(status);
					advertisements.add(advertisementDto);
				}
			} else {
				status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.MASTER_KEY_INVALID_STATUS_MESSAGE);
				advertisementDto.setStatus(status);
				advertisements.add(advertisementDto);
			}
		} else {
			advertisements = new ArrayList<>();
			advertisementDto = new AdvertisementDto();
			status = new StatusDto();
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.MASTER_KEY_OR_APPLICATION_CODE_INVALID_STATUS_MESSAGE);
			advertisementDto.setStatus(status);
			LOGGER.debug("Bad request");
		}
		return new ResponseEntity<List<AdvertisementDto>>(advertisements, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/getSalesAndOffers/{appCode}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.GET })
	public ResponseEntity<List<SalesAndOffersDto>> getSalesAndOffers(@RequestHeader("master_key") String masterKey,
			@PathVariable String appCode) throws ParseException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.MASTER_KEY_TAG, masterKey);
		SalesAndOffersDto salesAndOffersDto = null;
		StatusDto status = new StatusDto();
		List<SalesAndOffersDto> salesAndOffers = new ArrayList<>();
		if (null != masterKey && null != appCode) {
			salesAndOffersDto = new SalesAndOffersDto();
			if (homeService.isMasterKeyExists(masterKey)) {
				if (homeService.isAppCodeExists(appCode)) {
					salesAndOffers = homeService.fetchSalesAndOffers(appCode, masterKey);
					if (!(null != salesAndOffers && salesAndOffers.size() > 0)) {
						salesAndOffers = new ArrayList<>();
						status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
						status.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
						salesAndOffersDto.setStatus(status);
						salesAndOffers.add(salesAndOffersDto);
					}
					LOGGER.info("Sales and Offers fetched successfully.");
					return new ResponseEntity<List<SalesAndOffersDto>>(salesAndOffers, headers, HttpStatus.OK);
				} else {
					status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.APP_CODE_INVALID_STATUS_MESSAGE);
					salesAndOffersDto.setStatus(status);
					salesAndOffers.add(salesAndOffersDto);
				}
			} else {
				status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.MASTER_KEY_INVALID_STATUS_MESSAGE);
				salesAndOffersDto.setStatus(status);
				salesAndOffers.add(salesAndOffersDto);
			}
		} else {
			salesAndOffers = new ArrayList<>();
			salesAndOffersDto = new SalesAndOffersDto();
			status = new StatusDto();
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.MASTER_KEY_OR_APPLICATION_CODE_INVALID_STATUS_MESSAGE);
			salesAndOffersDto.setStatus(status);
		}
		return new ResponseEntity<List<SalesAndOffersDto>>(salesAndOffers, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/getBusinessTips/{appCode}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.GET })
	public ResponseEntity<List<BusinessTipsDto>> getBusinessTips(@RequestHeader("master_key") String masterKey,
			@PathVariable String appCode) throws ParseException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.MASTER_KEY_TAG, masterKey);
		BusinessTipsDto businessTipsDto = null;
		StatusDto status = new StatusDto();
		List<BusinessTipsDto> businessTips = new ArrayList<>();
		if (null != masterKey && null != appCode) {
			businessTipsDto = new BusinessTipsDto();
			if (homeService.isMasterKeyExists(masterKey)) {
				if (homeService.isAppCodeExists(appCode)) {
					businessTips = homeService.fetchBusinessTips(appCode, masterKey);
					if (!(null != businessTips && businessTips.size() > 0)) {
						businessTips = new ArrayList<>();
						status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
						status.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
						businessTipsDto.setStatus(status);
						businessTips.add(businessTipsDto);
					}
					LOGGER.info("Advertisements fetched successfully.");
					return new ResponseEntity<List<BusinessTipsDto>>(businessTips, headers, HttpStatus.OK);
				} else {
					status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.APP_CODE_INVALID_STATUS_MESSAGE);
					businessTipsDto.setStatus(status);
					businessTips.add(businessTipsDto);
				}
			} else {
				status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.MASTER_KEY_INVALID_STATUS_MESSAGE);
				businessTipsDto.setStatus(status);
				businessTips.add(businessTipsDto);
			}
		} else {
			businessTips = new ArrayList<>();
			businessTipsDto = new BusinessTipsDto();
			status = new StatusDto();
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.MASTER_KEY_OR_APPLICATION_CODE_INVALID_STATUS_MESSAGE);
			businessTipsDto.setStatus(status);
		}
		return new ResponseEntity<List<BusinessTipsDto>>(businessTips, headers, HttpStatus.BAD_REQUEST);
	}*/

	@RequestMapping(value = { "/getCustomers/{appCode}/{page}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST })
	public ResponseEntity<CustomerListDto> getCustomers(@RequestHeader("auth_key") String authKey,
			@PathVariable int page, @PathVariable String appCode, @RequestBody UserIdDto user) throws ParseException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authKey);
		StatusDto status = new StatusDto();
		CustomerListDto customers = new CustomerListDto();
		if (null != authKey && null != appCode) {
			if (homeService.isAuthKeyExists(authKey)) {
				if (homeService.isAppCodeExists(appCode)) {
					customers = homeService.fetchCustomers(user.getUserId(), page);
					if (!(null != customers && customers.getCustomers().size() > 0)) {
						customers = new CustomerListDto();
						status.setStatusCode(GatewayConstants.NO_CUSTOMER_FOUND_STATUS_CODE);
						status.setStatusMessage(GatewayConstants.NO_CUSTOMER_FOUND_STATUS_MESSAGE);
						customers.setStatus(status);
					}
					LOGGER.info("Customers fetched successfully.");
					return new ResponseEntity<CustomerListDto>(customers, headers, HttpStatus.OK);
				} else {
					status.setStatusCode(GatewayConstants.APP_CODE_INVALID_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.APP_CODE_INVALID_STATUS_MESSAGE);
					customers.setStatus(status);
				}
			} else {
				status.setStatusCode(GatewayConstants.AUTH_KEY_INVALID_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.AUTH_KEY_INVALID_STATUS_MESSAGE);
				customers.setStatus(status);
			}
		} else {
			status = new StatusDto();
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.MASTER_KEY_OR_APPLICATION_CODE_INVALID_STATUS_MESSAGE);
			customers.setStatus(status);
		}
		return new ResponseEntity<CustomerListDto>(customers, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/editCustomer/{appCode}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST })
	public ResponseEntity<CustomerDto> editCustomers(@RequestHeader("auth_key") String authKey,
			@PathVariable String appCode, @RequestBody CustomerDto editedCustomer) throws ParseException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authKey);
		StatusDto status = new StatusDto();
		CustomerDto savedCustomer = new CustomerDto();
		if (null != authKey && null != appCode) {
			if (homeService.isAuthKeyExists(authKey)) {
				if (homeService.isAppCodeExists(appCode)) {
					RequestValidationDto validateRequestForCustomer = GatewayUtilties
							.validateRequestForCustomer(editedCustomer);

					RequestValidationDto verifyCustomerPhoneNumber = registrationService
							.verifyCustomerPhoneNumberAndAadhaarNumber(editedCustomer.getUserId(),
									editedCustomer.getCustPhoneNumber(), editedCustomer.getCustAadharNumber(),
									"EDIT_CUSTOMER");
					validateRequestForCustomer
							.setSuccesfullyValidated(verifyCustomerPhoneNumber.isSuccesfullyValidated());
					if (!verifyCustomerPhoneNumber.isSuccesfullyValidated()) {
						validateRequestForCustomer.getListOfValidationMessagesWithCodes()
								.addAll(verifyCustomerPhoneNumber.getListOfValidationMessagesWithCodes());
					}

					if (validateRequestForCustomer.isSuccesfullyValidated()) {
						savedCustomer = homeService.saveCustomer(editedCustomer);
						if (!(null != savedCustomer && savedCustomer.getStatus().getStatusCode()
								.equalsIgnoreCase(GatewayConstants.EDITED_CUSTOMER_SAVED_SUCCESSFULLY_STATUS_CODE))) {
							status.setStatusCode(GatewayConstants.NO_CUSTOMER_FOUND_STATUS_CODE);
							status.setStatusMessage(GatewayConstants.NO_CUSTOMER_FOUND_STATUS_MESSAGE);
							savedCustomer.setStatus(status);
						}
						LOGGER.info("Customers fetched successfully.");
						return new ResponseEntity<CustomerDto>(savedCustomer, headers, HttpStatus.OK);
					} else {
						status.setStatusCode(GatewayConstants.CUSTOMER_DATA_INVALID_STATUS_CODE);
						status.setStatusMessage(GatewayConstants.CUSTOMER_DATA_INVALID_STATUS_MESSAGE);
						savedCustomer.setStatus(status);
					}
				} else {
					status.setStatusCode(GatewayConstants.APP_CODE_INVALID_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.APP_CODE_INVALID_STATUS_MESSAGE);
					savedCustomer.setStatus(status);
				}
			} else {
				status.setStatusCode(GatewayConstants.AUTH_KEY_INVALID_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.AUTH_KEY_INVALID_STATUS_MESSAGE);
				savedCustomer.setStatus(status);
			}
		} else {
			status = new StatusDto();
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.MASTER_KEY_OR_APPLICATION_CODE_INVALID_STATUS_MESSAGE);
			savedCustomer.setStatus(status);
		}
		return new ResponseEntity<CustomerDto>(savedCustomer, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/editUser/{appCode}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST })
	public ResponseEntity<UserDto> editUser(@RequestHeader("auth_key") String authKey, @PathVariable String appCode,
			@RequestBody UserDto user) throws ParseException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authKey);
		StatusDto status = new StatusDto();
		UserDto saveduser = new UserDto();
		if (null != authKey && null != appCode) {
			if (homeService.isAuthKeyExists(authKey)) {
				if (homeService.isAppCodeExists(appCode)) {
					RequestValidationDto validateRequestForCustomer = GatewayUtilties.validateRequestForUser(user);
					if (validateRequestForCustomer.isSuccesfullyValidated()) {
						saveduser = homeService.saveUser(user);
						LOGGER.info("Customers fetched successfully.");
						return new ResponseEntity<UserDto>(saveduser, headers, HttpStatus.OK);
					} else {
						status.setStatusCode(GatewayConstants.CUSTOMER_DATA_INVALID_STATUS_CODE);
						status.setStatusMessage(GatewayConstants.CUSTOMER_DATA_INVALID_STATUS_MESSAGE);
					}
				} else {
					status.setStatusCode(GatewayConstants.APP_CODE_INVALID_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.APP_CODE_INVALID_STATUS_MESSAGE);
				}
			} else {
				status.setStatusCode(GatewayConstants.AUTH_KEY_INVALID_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.AUTH_KEY_INVALID_STATUS_MESSAGE);
			}
		} else {
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.MASTER_KEY_OR_APPLICATION_CODE_INVALID_STATUS_MESSAGE);
		}
		saveduser.setStatus(status);
		return new ResponseEntity<UserDto>(saveduser, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/fetchCustomerTypes/{appCode}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.GET })
	public ResponseEntity<CustomerTypes> fetchCustomerTypes(@RequestHeader("master_key") String masterKey,
			@PathVariable String appCode) throws ParseException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.MASTER_KEY_TAG, masterKey);
		StatusDto status = new StatusDto();
		CustomerTypes customerTypes = new CustomerTypes();
		if (null != masterKey && null != appCode) {
			if (homeService.isAppRequestAuthorized(masterKey, appCode)) {
				customerTypes = homeService.fetchCustomerTypes(appCode);
				LOGGER.info("Customer types fetched successfully");
				return new ResponseEntity<CustomerTypes>(customerTypes, headers, HttpStatus.OK);
			} else {
				status.setStatusCode(GatewayConstants.APP_REQUEST_NOT_AUTHORIZED_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.APP_REQUEST_NOT_AUTHORIZED_STATUS_MESSAGE);
			}
		} else {
			status = new StatusDto();
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.MASTER_KEY_OR_APPLICATION_CODE_INVALID_STATUS_MESSAGE);
		}
		customerTypes.setStatus(status);
		return new ResponseEntity<CustomerTypes>(customerTypes, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/customer/meandmyland/fetch" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<CustomerAndLandDetails> fetchLandDetailsForCustomer(@RequestHeader("auth_key") String authkey,
			@RequestBody CustomerAndLandDetails customerLandDetails) {
		RequestValidationDto validationDto = new RequestValidationDto();
		if (customerLandDetails.getCustomer().getCustomerId() == 0) {
			List<ValidationDto> listOfValidationMessagesWithCodes = new ArrayList<>();
			ValidationDto validation = new ValidationDto();
			validation.setCode(GatewayConstants.CUSTOMER_ID_MISSING_STATUS_CODE);
			validation.setMessage(GatewayConstants.CUST_ID_INVALID_STATUS_MESSAGE);
			listOfValidationMessagesWithCodes.add(validation);
			validationDto.setListOfValidationMessagesWithCodes(listOfValidationMessagesWithCodes);
			validationDto.setSuccesfullyValidated(false);
		} else {
			validationDto.setListOfValidationMessagesWithCodes(Collections.emptyList());
			validationDto.setSuccesfullyValidated(true);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authkey);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		if ((validationDto != null) && (validationDto.isSuccesfullyValidated())) {
			customerLandDetails = homeService.fetchCustomerAndLandDetails(customerLandDetails, authkey);
			isRequestProcessingSucessfull = true;
		} else {
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			customerLandDetails.setStatus(status);
		}
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<CustomerAndLandDetails>(customerLandDetails, headers, HttpStatus.OK);
		}
		return new ResponseEntity<CustomerAndLandDetails>(customerLandDetails, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/customer/meandmyland/update" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<CustomerAndLandDetails> updateLandDetailsForCustomer(
			@RequestHeader("auth_key") String authkey, @RequestBody CustomerAndLandDetails customerLandDetails) {
		RequestValidationDto validationDto = GatewayUtilties.validateRequestForMeAndMyLand(customerLandDetails,
				GatewayConstants.UPDATE_CUSTOMER_AND_LAND_DETAILS);

		RequestValidationDto verifyCustomerPhoneNumber = registrationService.verifyCustomerPhoneNumberAndAadhaarNumber(
				customerLandDetails.getCustomer().getUserId(), customerLandDetails.getCustomer().getCustPhoneNumber(),
				customerLandDetails.getCustomer().getCustAadharNumber(), "UPDATE_LAND_DETAILS");
		validationDto.setSuccesfullyValidated(verifyCustomerPhoneNumber.isSuccesfullyValidated());
		if (!verifyCustomerPhoneNumber.isSuccesfullyValidated()) {
			validationDto.getListOfValidationMessagesWithCodes()
					.addAll(verifyCustomerPhoneNumber.getListOfValidationMessagesWithCodes());
		}

		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authkey);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		if ((validationDto != null) && (validationDto.isSuccesfullyValidated())) {
			customerLandDetails = homeService.updateCustomerAndLandDetails(customerLandDetails, authkey);
			isRequestProcessingSucessfull = true;
		} else {
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			customerLandDetails.setStatus(status);
		}
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<CustomerAndLandDetails>(customerLandDetails, headers, HttpStatus.OK);
		}
		return new ResponseEntity<CustomerAndLandDetails>(customerLandDetails, headers, HttpStatus.BAD_REQUEST);
	}
}
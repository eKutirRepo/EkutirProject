package ekutir.sanimark.controller;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ekutir.sanimark.android.dto.CustomFeaturesBean;
import ekutir.sanimark.android.dto.DataManipulationBean;
import ekutir.sanimark.android.dto.EditProductDataBean;
import ekutir.sanimark.android.dto.ErrorResponseBean;
import ekutir.sanimark.android.dto.FetchBusinessCategoryBean;
import ekutir.sanimark.android.dto.FetchPCategoryBean;
import ekutir.sanimark.android.dto.FetchProductsBean;
import ekutir.sanimark.android.dto.FetchServiceForApprovalBean;
import ekutir.sanimark.android.dto.FetchServicesDataBean;
import ekutir.sanimark.android.dto.FetchSupplierOrderDataBean;
import ekutir.sanimark.android.dto.ProductDataBean;
import ekutir.sanimark.android.dto.ProductUnitsBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ServicesDataBean;
import ekutir.sanimark.android.dto.ServicesEditDataBean;
import ekutir.sanimark.android.dto.SupplierDataViewBean;
import ekutir.sanimark.dto.ErrorDto;
import ekutir.sanimark.dto.FetchBusinessCategoryDto;
import ekutir.sanimark.dto.FetchItemsForProductDto;
import ekutir.sanimark.dto.FetchProductDto;
import ekutir.sanimark.dto.FetchProductForSaniDto;
import ekutir.sanimark.dto.FetchProductServiceCategoryDto;
import ekutir.sanimark.dto.FetchServiceCategoryDto;
import ekutir.sanimark.dto.FetchServiceForApprovalBeanDto;
import ekutir.sanimark.dto.FetchServicesDataBeanDto;
import ekutir.sanimark.dto.FetchSupplerServicesDataBeanDto;
import ekutir.sanimark.dto.FetchSupplierItemsDto;
import ekutir.sanimark.dto.FetchSuppliersBeanDto;
import ekutir.sanimark.dto.FetchSuppliersOrderBeanDto;
import ekutir.sanimark.dto.ItemsDto;
import ekutir.sanimark.dto.ProductCategoryDto;
import ekutir.sanimark.dto.SupplierProductsDto;
import ekutir.sanimark.service.SanimarkService;
import ekutir.sanimark.utilities.CommonException;
import ekutir.sanimark.utilities.PasswordHasher;
import ekutir.sanimark.view.beans.CloseOrderDataBean;
import ekutir.sanimark.view.beans.CreateProductBean;
import ekutir.sanimark.view.beans.EditItemBean;
import ekutir.sanimark.view.beans.FetchItemsApprovalBean;
import ekutir.sanimark.view.beans.FetchItemsForProductBean;
import ekutir.sanimark.view.beans.FetchItemsforApprovalDto;
import ekutir.sanimark.view.beans.FetchProductsForSani;
import ekutir.sanimark.view.beans.FetchServiceCategoryBean;
import ekutir.sanimark.view.beans.FetchSupplierItemsBean;
import ekutir.sanimark.view.beans.FetchSupplierServicesBean;
import ekutir.sanimark.view.beans.ItemBean;
import ekutir.sanimark.view.beans.ItemIdDetailsBean;
import ekutir.sanimark.view.beans.MicroEntrepreneurMsgBean;
import ekutir.sanimark.view.beans.ServiceCategoryBean;

@Controller
@RequestMapping("/")
@CrossOrigin(origins = "*", maxAge = 3600)
public class SanimarkController {

	@Autowired
	SanimarkService sanimarkService;

	@Autowired
	MessageSource messageSource;

	@Autowired
	PasswordHasher passwordHasher;

	@Autowired
	HttpSession httpSession;

	private static final Logger logger = Logger.getLogger(SanimarkController.class);
	private ObjectMapper mapper = null;
	private Locale locale;
	private List<RegisterDataBean> fetchSuppliersDetails = null;
	private List<FetchBusinessCategoryBean> fetchBusinessCategoryDetails = null;
	private RegisterDataBean approveSupplier = null;
	private List<FetchProductsBean> fetchProductsDetails = null;
	private List<FetchProductsBean> fetchProductsData = null;
	private List<FetchProductsForSani> fetchProductsForSaniData = null;
	private DataManipulationBean datamanipulation = null;
	private ProductDataBean productBean = null;
	private List<CustomFeaturesBean> featureDetails = null;
	private List<FetchSupplierOrderDataBean> fetchSupplierOrdersDetails = null;
	private List<FetchProductServiceCategoryDto> fetchProductDetails = null;
	private List<FetchProductServiceCategoryDto> fetchServiceDetails = null;
	private List<ProductUnitsBean> unitDetails = null;
	private EditProductDataBean editProducts = null;
	private EditItemBean editItem = null;
	private ServicesEditDataBean editService = null;
	private List<ProductUnitsBean> editUnitDetails = null;
	private List<FetchServicesDataBean> fetchServicesDetails = null;
	private List<FetchServiceForApprovalBean> fetchServicesApprovalDetails = null;
	private List<ProductDataBean> fetchSupplierProducts = null;
	private List<FetchPCategoryBean> fetchProdCategoryData = null;
	private List<FetchItemsForProductBean> fetchItemsForProductData = null;
	private List<FetchItemsApprovalBean> fetchItemsForApprovalData = null;
	private List<FetchSupplierItemsBean> fetchSupplierItemsData = null;
	private CreateProductBean createProduct = null;
	private List<ItemIdDetailsBean> itemLists = null;
	private List<FetchSupplierServicesBean> fetchSupplierServicesDetails = null;
	private List<ServiceCategoryBean> fetchserviceDetails = null;

	@ExceptionHandler(CommonException.class)
	public ResponseEntity<ErrorDto> exceptionHandler(Exception ex) {
		ErrorResponseBean error = new ErrorResponseBean();
		error.setErrorCode(HttpStatus.PRECONDITION_FAILED.value());
		error.setMessage(ex.getMessage());
		ErrorDto errorDto = new ErrorDto();
		errorDto.setError(error);
		return new ResponseEntity<ErrorDto>(errorDto, HttpStatus.OK);
	}

	// Fetch Suppliers Details
	@RequestMapping(value = "/fetchSuppliers", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchSuppliersBeanDto> fetchSuppliers() throws CommonException {
		mapper = new ObjectMapper();
		fetchSuppliersDetails = sanimarkService.fetchSuppliersDetails();
		if (fetchSuppliersDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		logger.info(fetchSuppliersDetails);
		FetchSuppliersBeanDto fetchSupplierBeanDto = new FetchSuppliersBeanDto();
		fetchSupplierBeanDto.setSuppliers(fetchSuppliersDetails);
		return new ResponseEntity<FetchSuppliersBeanDto>(fetchSupplierBeanDto, HttpStatus.OK);

	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/rejectsupplier", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> rejectsupplier(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int supplierId = mapper.readValue(json, SupplierDataViewBean.class).getSupplierId();
			List<String> fetchSupplierApproval = sanimarkService.fetchSupplierApproval(supplierId);
			int rejectSid = sanimarkService.rejectSupplier(supplierId);

			// System.out.println("Admin Size : "+fetchSupplierApproval.size());

			for (String rejectSupplierMail : fetchSupplierApproval) {
				boolean mailSend = sanimarkService.sendSupplierRejectdMail(rejectSupplierMail);
			}

			if (supplierId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			// datamanipulation.setMessage(messageSource.getMessage("valid.reject",
			// null, locale));
			datamanipulation.setId(rejectSid);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/approveSupplier", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> approveSupplier(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int supplierId = mapper.readValue(json, RegisterDataBean.class).getSupplierId();
			int approveSid = sanimarkService.approveSupplier(supplierId);

			List<String> fetchSupplierApproval = sanimarkService.fetchSupplierApproval(supplierId);
			System.out.println("Admin Size : " + fetchSupplierApproval.size());
			for (String approveSupplierMail : fetchSupplierApproval) {
				boolean mailSend = sanimarkService.sendSupplierApproveddMail(approveSupplierMail);
			}
			if (supplierId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			// datamanipulation.setMessage(messageSource.getMessage("valid.approve",
			// null, locale));
			datamanipulation.setId(approveSid);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/fetchBusinessCategory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchBusinessCategoryDto> fetchBusinessCategory() throws CommonException {
		mapper = new ObjectMapper();
		fetchBusinessCategoryDetails = sanimarkService.fetchBusinessCategory();
		if (fetchBusinessCategoryDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		logger.info(fetchBusinessCategoryDetails);
		FetchBusinessCategoryDto fetchBusinessCategoryDto = new FetchBusinessCategoryDto();
		fetchBusinessCategoryDto.setCategory(fetchBusinessCategoryDetails);
		return new ResponseEntity<FetchBusinessCategoryDto>(fetchBusinessCategoryDto, HttpStatus.OK);

	}

	@RequestMapping(value = "/fetchProductsForApproval", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchProductDto> fetchProductsForApproval() throws CommonException {
		// throws CommonException, IOException, JsonProcessingException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		fetchProductsDetails = sanimarkService.fetchProductsDetails();

		if (fetchProductsDetails == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchProductDto fetchProductDto = new FetchProductDto();
		fetchProductDto.setProducts(fetchProductsDetails);
		return new ResponseEntity<FetchProductDto>(fetchProductDto, HttpStatus.OK);
	}

	/*@RequestMapping(value = "/fetchProducts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchProductDto> fetchProducts() throws CommonException {
		// throws CommonException, IOException, JsonProcessingException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		fetchProductsData = sanimarkService.fetchProducts();

		if (fetchProductsData == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchProductDto fetchProductDto = new FetchProductDto();
		fetchProductDto.setProducts(fetchProductsData);
		return new ResponseEntity<FetchProductDto>(fetchProductDto, HttpStatus.OK);
	}*/

	/* Fetch Products for sanimark */
	@RequestMapping(value = "/fetchAllProducts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchProductForSaniDto> fetchAllProducts() throws CommonException {
		// throws CommonException, IOException, JsonProcessingException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		fetchProductsForSaniData = sanimarkService.fetchSaniProducts();

		if (fetchProductsForSaniData == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchProductForSaniDto fetchProductForSaniDto = new FetchProductForSaniDto();
		fetchProductForSaniDto.setProducts(fetchProductsForSaniData);
		return new ResponseEntity<FetchProductForSaniDto>(fetchProductForSaniDto, HttpStatus.OK);
	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/createNewProduct", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> createNewProduct(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			productBean = mapper.readValue(json, ProductDataBean.class);
			int productData = sanimarkService.addProduct(productBean);
			List<String> fetchAdminDetails = sanimarkService.fetchAdminDetails();
			// System.out.println("Admin Size : "+fetchAdminDetails.size());
			if (productData > 0) {
				// String email =
				// httpSession.getAttribute("userName").toString();
				// boolean mailSend =
				// sanimarkService.sendProductAddedMail(email);
				for (String adminMail : fetchAdminDetails) {
					boolean adminmailSend = sanimarkService.sendProductAddedMailtoAdmin(adminMail);
				}
				System.out.println("after service Impl");
				/*
				 * if (mailSend == false) { throw new
				 * CommonException(messageSource.getMessage(
				 * "valid.invalidmailid", null, locale)); }
				 */
				// datamanipulation.setMessage(messageSource.getMessage("valid.save",
				// null, locale));
				datamanipulation.setId(productData);
			} else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}
			// datamanipulation.setMessage(messageSource.getMessage("valid.placed",
			// null, locale));
			// datamanipulation.setId(productData);

		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchSupplierOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchSuppliersOrderBeanDto> fetchSupplierOrders() throws CommonException {
		fetchSupplierOrdersDetails = sanimarkService.fetchSuppliersOrderDetails();
		if (fetchSupplierOrdersDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		//logger.info("After Calll ========== " + fetchSupplierOrdersDetails);
		FetchSuppliersOrderBeanDto fetchSuppliersOrderBeanDto = new FetchSuppliersOrderBeanDto();
		fetchSuppliersOrderBeanDto.setOrders(fetchSupplierOrdersDetails);

		return new ResponseEntity<FetchSuppliersOrderBeanDto>(fetchSuppliersOrderBeanDto, HttpStatus.OK);

	}

	@RequestMapping(value = "/acknowledgeOrder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> acknowledgeOrder(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int orderId = mapper.readValue(json, FetchSupplierOrderDataBean.class).getOrderId();
			int productId = mapper.readValue(json, FetchSupplierOrderDataBean.class).getItemId();
			int acknowledge = sanimarkService.acknowledgeOrder(orderId, productId);

			if (orderId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			if (acknowledge > 0) {
				datamanipulation.setMessage(messageSource.getMessage("valid.save",
				null, locale));
				datamanipulation.setId(acknowledge);
			} else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}

			// datamanipulation.setMessage(messageSource.getMessage("valid.save",
			// null, locale));
			datamanipulation.setId(acknowledge);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/fetchProductServiceCategories", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchProductServiceCategoryDto> fetchProductServiceCategories() throws CommonException {
		mapper = new ObjectMapper();
		fetchProductDetails = sanimarkService.fetchProductCategory();
		fetchServiceDetails = sanimarkService.fetchServiceCategory();
		if (fetchProductDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		logger.info(fetchProductDetails);
		FetchProductServiceCategoryDto fetchProductServiceCategoryDto = new FetchProductServiceCategoryDto();
		fetchProductServiceCategoryDto.setProductCategories(fetchProductDetails);
		// fetchProductServiceCategoryDto.setServiceCategories(fetchServiceDetails);
		return new ResponseEntity<FetchProductServiceCategoryDto>(fetchProductServiceCategoryDto, HttpStatus.OK);

	}

	/* Fetch Product Categories for SanimarkDlink */

	@RequestMapping(value = "/fetchCategories", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchProductServiceCategoryDto> fetchCategories() throws CommonException {
		mapper = new ObjectMapper();
		fetchProductDetails = sanimarkService.fetchProductCategory();
		if (fetchProductDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		logger.info(fetchProductDetails);
		FetchProductServiceCategoryDto fetchProductServiceCategoryDto = new FetchProductServiceCategoryDto();
		fetchProductServiceCategoryDto.setProductCategories(fetchProductDetails);
		return new ResponseEntity<FetchProductServiceCategoryDto>(fetchProductServiceCategoryDto, HttpStatus.OK);

	}

	@RequestMapping(value = "/deleteProduct", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> deleteProduct(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int productId = mapper.readValue(json, ProductDataBean.class).getProductId();
			int deletePid = sanimarkService.deleteProduct(productId);

			if (productId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			datamanipulation.setMessage(messageSource.getMessage("valid.delete.product",
			 null, locale));
			datamanipulation.setId(deletePid);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/rejectProduct", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> rejectProduct(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int productId = mapper.readValue(json, ProductDataBean.class).getProductId();
			int rejectPid = sanimarkService.rejectProduct(productId);

			if (productId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			// datamanipulation.setMessage(messageSource.getMessage("valid.delete.product",
			// null, locale));
			datamanipulation.setId(rejectPid);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/deleteService", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> deleteService(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int serviceId = mapper.readValue(json, ServicesDataBean.class).getServiceId();
			int deleteSid = sanimarkService.deleteService(serviceId);

			if (serviceId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			datamanipulation.setMessage(messageSource.getMessage("valid.delete.product", null, locale));
			datamanipulation.setId(deleteSid);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/rejectService", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> rejectService(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int serviceId = mapper.readValue(json, ServicesDataBean.class).getServiceId();
			int rejectSid = sanimarkService.rejectService(serviceId);

			if (rejectSid == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			datamanipulation.setMessage(messageSource.getMessage("valid.delete.product", null, locale));
			datamanipulation.setId(rejectSid);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/editProduct", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> editCustomer(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			editProducts = mapper.readValue(json, EditProductDataBean.class);
			int editProductData = sanimarkService.editProducts(editProducts);
			// datamanipulation.setMessage(messageSource.getMessage("valid.update",
			// null, locale));
			datamanipulation.setId(editProductData);

		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	@RequestMapping(value = "/editService", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> editService(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			editService = mapper.readValue(json, ServicesEditDataBean.class);
			int editServiceData = sanimarkService.editService(editService);
			datamanipulation.setMessage(messageSource.getMessage("valid.update", null, locale));
			datamanipulation.setId(editServiceData);

		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	@RequestMapping(value = "/createNewService", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> createNewService(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			ServicesDataBean createServicesData = mapper.readValue(json, ServicesDataBean.class);
			int createServices = sanimarkService.createServices(createServicesData);
			List<String> fetchAdminDetails = sanimarkService.fetchAdminDetails();
			if (createServices > 0) {
				//String email = httpSession.getAttribute("userName").toString();
				String email = "tapas@ekisticssolutions.com";
				boolean mailSend = sanimarkService.sendServiceAddedMail(email);
				for(String adminMail: fetchAdminDetails){
					boolean adminmailSend = sanimarkService.sendServiceAddedMailtoAdmin(adminMail);
					System.out.println("================adminmailSend================="+adminmailSend);
				}
				if (mailSend == false) {
					throw new CommonException(messageSource.getMessage("valid.invalidmailid", null, locale));
				}
				datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
				datamanipulation.setId(createServices);
			} else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}
		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/approveProduct", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> approveProduct(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int productId = mapper.readValue(json, ProductDataBean.class).getProductId();
			int approveProduct = sanimarkService.approveProduct(productId);
			List<String> fetchApprovalLogin = sanimarkService.fetchApprovalLogin(productId);
			// System.out.println("Admin Size : "+fetchApprovalLogin.size());
			for (String approveMail : fetchApprovalLogin) {
				boolean mailSend = sanimarkService.sendProductApproveddMail(approveMail);
			}
			if (productId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			// datamanipulation.setMessage(messageSource.getMessage("valid.approved.product",
			// null, locale));
			datamanipulation.setId(approveProduct);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/approveServices", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> approveServices(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int serviceId = mapper.readValue(json, ServicesDataBean.class).getServiceId();
			int approveService = sanimarkService.approveService(serviceId);
			
			List<String> fetchServicesApprovalLogin = sanimarkService.fetchServicesApprovalLogin(serviceId);
			for(String approveMail: fetchServicesApprovalLogin){
				boolean mailSend = sanimarkService.sendServiceApproveddMail(approveMail);
			}
			if (serviceId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			datamanipulation.setMessage(messageSource.getMessage("valid.approved.service", null, locale));
			datamanipulation.setId(approveService);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/fetchServices", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchServicesDataBeanDto> fetchServices() throws CommonException {
		fetchServicesDetails = sanimarkService.fetchServicesDetails();
		if (fetchServicesDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchServicesDataBeanDto fetchServicesDataBeanDto = new FetchServicesDataBeanDto();
		fetchServicesDataBeanDto.setServices(fetchServicesDetails);

		return new ResponseEntity<FetchServicesDataBeanDto>(fetchServicesDataBeanDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchServiceForApproval", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchServiceForApprovalBeanDto> fetchServiceForApproval() throws CommonException {
		fetchServicesApprovalDetails = sanimarkService.fetchServicesApprovalDetails();
		if (fetchServicesApprovalDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchServiceForApprovalBeanDto fetchServiceForApprovalBeanDto = new FetchServiceForApprovalBeanDto();
		fetchServiceForApprovalBeanDto.setServices(fetchServicesApprovalDetails);

		return new ResponseEntity<FetchServiceForApprovalBeanDto>(fetchServiceForApprovalBeanDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchSupplierProducts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SupplierProductsDto> fetchSupplierProducts(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		int suplierid = mapper.readValue(json, FetchProductsBean.class).getSupplierId();
		fetchSupplierProducts = sanimarkService.fetchSupplierProducts(suplierid);
		if (fetchSupplierProducts == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		SupplierProductsDto supplierProductsDto = new SupplierProductsDto();
		supplierProductsDto.setSuplierproduct(fetchSupplierProducts);

		return new ResponseEntity<SupplierProductsDto>(supplierProductsDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchProdCategory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ProductCategoryDto> fetchProdCategory() throws CommonException {
		// throws CommonException, IOException, JsonProcessingException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		fetchProdCategoryData = sanimarkService.fetchProdCategory();

		if (fetchProdCategoryData == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		ProductCategoryDto productCategoryDto = new ProductCategoryDto();
		productCategoryDto.setProducts(fetchProdCategoryData);
		return new ResponseEntity<ProductCategoryDto>(productCategoryDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/closeOrder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> closeOrder(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		DataManipulationBean datamanipulation = new DataManipulationBean();
		try {
			
			mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			int orderId = mapper.readValue(json, CloseOrderDataBean.class).getOrderId();
			int productId = mapper.readValue(json, CloseOrderDataBean.class).getItemId();
			int buyCode = mapper.readValue(json, CloseOrderDataBean.class).getBuycode();
			boolean fetchbuycode = sanimarkService.fetchBuycode(orderId,buyCode);
			boolean ackupdate=false;
			if (fetchbuycode) {
				ackupdate = sanimarkService.updateAckStatus(orderId,productId);
				datamanipulation.setMessage(messageSource.getMessage("valid.update", null, locale));
			}else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}
			

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	/* Fetch Products Items for sanimark */

	@RequestMapping(value = "/fetchItemsForProduct", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchItemsForProductDto> fetchItemsForProduct(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		int productId = mapper.readValue(json, FetchProductsForSani.class).getProductId();
		fetchItemsForProductData = sanimarkService.fetchSaniProductItems(productId);

		if (fetchItemsForProductData == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchItemsForProductDto fetchItemsForProductDto = new FetchItemsForProductDto();
		fetchItemsForProductDto.setProductItems(fetchItemsForProductData);
		return new ResponseEntity<FetchItemsForProductDto>(fetchItemsForProductDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchAllItems", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchItemsForProductDto> fetchAllItems() throws CommonException, IOException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		fetchItemsForProductData = sanimarkService.fetchAllItems();

		if (fetchItemsForProductData == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchItemsForProductDto fetchItemsForProductDto = new FetchItemsForProductDto();
		fetchItemsForProductDto.setProductItems(fetchItemsForProductData);
		return new ResponseEntity<FetchItemsForProductDto>(fetchItemsForProductDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/createItem", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> createItem(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			ItemBean createItemData = mapper.readValue(json, ItemBean.class);
			int createItem = sanimarkService.createItem(createItemData);
			if (createItem > 0) {
				datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
				datamanipulation.setId(createItem);
			} else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}
		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	@RequestMapping(value = "/createProduct", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> createProduct(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			createProduct = mapper.readValue(json, CreateProductBean.class);
			itemLists = (List<ItemIdDetailsBean>) mapper
					.readValue(json, ItemsDto.class).getItemList();
			int createProd = sanimarkService.createProduct(createProduct, itemLists);
			
			if (createProd > 0) {
				String email = httpSession.getAttribute("userName").toString();
				boolean mailSend = sanimarkService.sendProductAddedMail(email);
				
				System.out.println("after service Impl");
				if (mailSend == false) {
					throw new CommonException(messageSource.getMessage("valid.invalidmailid", null, locale));
				}
				datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
				datamanipulation.setId(createProd);
			} else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}
		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}
	
	// Controller for Approved Item by Admin

	@SuppressWarnings("unused")
	@RequestMapping(value = "/approveItem", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> approveItem(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();

			int itemId = mapper.readValue(json, ItemIdDetailsBean.class).getItemId();
			int approveItem = sanimarkService.approveItems(itemId);
			
			List<String> fetchApprovalLogin = sanimarkService.fetchApprovalLogin(itemId);

			for (String approveMail : fetchApprovalLogin) {
				boolean mailSend = sanimarkService.sendProductApproveddMail(approveMail);
			}
			if (itemId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			datamanipulation.setMessage(messageSource.getMessage("valid.approved.product", null, locale));
			datamanipulation.setId(approveItem);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}
	
	@RequestMapping(value = "/editItem", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE })
			public ResponseEntity<DataManipulationBean> editItem(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
			datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			editItem = mapper.readValue(json, EditItemBean.class);
			int editItemData = sanimarkService.editItem(editItem);
			//datamanipulation.setMessage(messageSource.getMessage("valid.update", null, locale));
			datamanipulation.setId(editItemData);

		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/fetchItemsforApproval", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchItemsforApprovalDto> fetchItemsforApproval()	throws CommonException, IOException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		fetchItemsForApprovalData = sanimarkService.fetchItemsforApproval();

		if (fetchItemsForApprovalData == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchItemsforApprovalDto fetchItemsforApprovalDto = new FetchItemsforApprovalDto();
		fetchItemsforApprovalDto.setItems(fetchItemsForApprovalData);
		return new ResponseEntity<FetchItemsforApprovalDto>(fetchItemsforApprovalDto, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/fetchSupplierItems", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchSupplierItemsDto> fetchSupplierItems(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		int supplierId = mapper.readValue(json, FetchItemsApprovalBean.class).getSupplierId();
		fetchSupplierItemsData = sanimarkService.fetchSupplierItems(supplierId);

		if (fetchSupplierItemsData == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchSupplierItemsDto fetchSupplierItemsDto = new FetchSupplierItemsDto();
		fetchSupplierItemsDto.setProductItems(fetchSupplierItemsData);
		return new ResponseEntity<FetchSupplierItemsDto>(fetchSupplierItemsDto, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/deleteItem", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> deleteItem(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int itemId = mapper.readValue(json, ItemIdDetailsBean.class).getItemId();
			int deleteItemId = sanimarkService.deleteItem(itemId);

			if (deleteItemId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			datamanipulation.setMessage(messageSource.getMessage("valid.delete.product",
			 null, locale));
			datamanipulation.setId(deleteItemId);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}
	
	@RequestMapping(value = "/fetchSupplierServices", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchSupplerServicesDataBeanDto> fetchSupplierServices(@RequestBody final String json) throws CommonException, IOException, JsonProcessingException{
		
		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		int supplierId = mapper.readValue(json, SupplierDataViewBean.class).getSupplierId();
		fetchSupplierServicesDetails = sanimarkService.fetchSupplierServices(supplierId);
		if (fetchSupplierServicesDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchSupplerServicesDataBeanDto fetchSupplerServicesDataBeanDto = new FetchSupplerServicesDataBeanDto();
		fetchSupplerServicesDataBeanDto.setServices(fetchSupplierServicesDetails);

		return new ResponseEntity<FetchSupplerServicesDataBeanDto>(fetchSupplerServicesDataBeanDto, HttpStatus.OK);
	}
	
	// Controller for message send to Micro Entrepreneur
	
			@RequestMapping(value = "/microEntrepreneurMsgs", method = RequestMethod.POST, produces = {
				MediaType.APPLICATION_JSON_VALUE })
				public ResponseEntity<DataManipulationBean> microEntrepreneurMsgs(@RequestBody final String json)
				throws CommonException, JsonParseException, JsonMappingException, IOException {
				datamanipulation = new DataManipulationBean();
			try {
				mapper = new ObjectMapper();
				MicroEntrepreneurMsgBean microEntrepreneurMsgData = mapper.readValue(json, MicroEntrepreneurMsgBean.class);
				int sendMeMsgs = sanimarkService.sendMicroEntrepreneurMsg(microEntrepreneurMsgData);
				if (sendMeMsgs > 0) {
					datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
					datamanipulation.setId(sendMeMsgs);
				} else {
					throw new CommonException(messageSource.getMessage("error.msg", null, locale));
				}
			} catch (JsonParseException jpe) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (JsonMappingException jme) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (IOException io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}

			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
		}
			
		/* Fetch Service Categories for SanimarkDlink */

		@RequestMapping(value = "/fetchServiceCategories", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<FetchServiceCategoryDto> fetchServiceCategories() throws CommonException {
			mapper = new ObjectMapper();
			fetchserviceDetails = sanimarkService.fetchServiceCategories();
			if (fetchserviceDetails == null) {

				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}
			logger.info(fetchserviceDetails);
			FetchServiceCategoryDto fetchServiceCategoryDto = new FetchServiceCategoryDto();
			fetchServiceCategoryDto.setServiceCategories(fetchserviceDetails);
			return new ResponseEntity<FetchServiceCategoryDto>(fetchServiceCategoryDto, HttpStatus.OK);

		}

}
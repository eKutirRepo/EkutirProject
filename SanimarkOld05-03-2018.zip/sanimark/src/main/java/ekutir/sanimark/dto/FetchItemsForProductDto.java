package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.view.beans.FetchItemsForProductBean;

public class FetchItemsForProductDto {
	
	private List<FetchItemsForProductBean> productItems;

	public List<FetchItemsForProductBean> getProductItems() {
		return productItems;
	}

	public void setProductItems(List<FetchItemsForProductBean> productItems) {
		this.productItems = productItems;
	}
	
}

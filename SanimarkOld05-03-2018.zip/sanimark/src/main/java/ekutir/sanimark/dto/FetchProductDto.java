package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.FetchProductsBean;

public class FetchProductDto {
	
	private List<FetchProductsBean> products;

	public List<FetchProductsBean> getProducts() {
		return products;
	}

	public void setProducts(List<FetchProductsBean> products) {
		this.products = products;
	}

}

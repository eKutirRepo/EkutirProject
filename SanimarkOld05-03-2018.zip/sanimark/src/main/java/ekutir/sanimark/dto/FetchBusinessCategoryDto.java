package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.FetchBusinessCategoryBean;

public class FetchBusinessCategoryDto {
	
	private List<FetchBusinessCategoryBean> category;

	public List<FetchBusinessCategoryBean> getCategory() {
		return category;
	}

	public void setCategory(List<FetchBusinessCategoryBean> category) {
		this.category = category;
	}

}

package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.FetchServiceForApprovalBean;

public class FetchServiceForApprovalBeanDto {
	
	private List<FetchServiceForApprovalBean> Services;

	public List<FetchServiceForApprovalBean> getServices() {
		return Services;
	}

	public void setServices(List<FetchServiceForApprovalBean> services) {
		Services = services;
	}
	
}

package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.FetchProductCategoryBean;
import ekutir.sanimark.android.dto.FetchServiceCategoryBean;

public class FetchProductServiceCategoryDto {
	
	private List<FetchProductServiceCategoryDto> productCategories;
//	private List<FetchProductServiceCategoryDto> serviceCategories;
	
	public List<FetchProductServiceCategoryDto> getProductCategories() {
		return productCategories;
	}
	public void setProductCategories(List<FetchProductServiceCategoryDto> productCategories) {
		this.productCategories = productCategories;
	}
	/*public List<FetchProductServiceCategoryDto> getServiceCategories() {
		return serviceCategories;
	}
	public void setServiceCategories(List<FetchProductServiceCategoryDto> serviceCategories) {
		this.serviceCategories = serviceCategories;
	}*/
	
	
}
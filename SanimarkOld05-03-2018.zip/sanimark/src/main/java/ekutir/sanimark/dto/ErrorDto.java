package ekutir.sanimark.dto;

import ekutir.sanimark.android.dto.ErrorResponseBean;

public class ErrorDto {

private ErrorResponseBean error;

public ErrorResponseBean getError() {
	return error;
}

public void setError(ErrorResponseBean error) {
	this.error = error;
}


}

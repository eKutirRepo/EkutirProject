package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.view.beans.ItemIdDetailsBean;


public class ItemsDto {
	
	private List<ItemIdDetailsBean> itemList;

	public List<ItemIdDetailsBean> getItemList() {
		return itemList;
	}

	public void setItemList(List<ItemIdDetailsBean> itemList) {
		this.itemList = itemList;
	}

}

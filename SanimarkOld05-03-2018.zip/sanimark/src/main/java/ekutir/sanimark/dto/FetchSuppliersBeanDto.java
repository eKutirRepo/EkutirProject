package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.RegisterDataBean;

public class FetchSuppliersBeanDto {

	private List<RegisterDataBean> suppliers;

	public List<RegisterDataBean> getSuppliers() {
		return suppliers;
	}

	public void setSuppliers(List<RegisterDataBean> suppliers) {
		this.suppliers = suppliers;
	}

}

package ekutir.sanimark.web.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_address")
public class WebAddress implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column
	private int address_id;
	@Column
	private String addressLine1;
	@Column
	private String addressLine2;
	@Column
	private String addressLine3;
	@Column
	private String block;
	@Column
	private String city;
	@Column
	private String district;
	@Column
	private String state;
	@Column
	private String country;
	@Column
	private String pincode;
	@Column
	private String created_date_time;
	@Column
	private String created_by;
	@Column
	private String updated_date_time;
	@Column
	private String updated_by;
	
	public WebAddress() {
		super();
	}

	public WebAddress(int address_id, String addressLine1, String addressLine2, String addressLine3, String block,
			String city, String district, String state, String country, String pincode, String created_date_time,
			String created_by, String updated_date_time, String updated_by) {
		super();
		this.address_id = address_id;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.block = block;
		this.city = city;
		this.district = district;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
		this.created_date_time = created_date_time;
		this.created_by = created_by;
		this.updated_date_time = updated_date_time;
		this.updated_by = updated_by;
	}

	public int getAddress_id() {
		return address_id;
	}

	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCreated_date_time() {
		return created_date_time;
	}

	public void setCreated_date_time(String created_date_time) {
		this.created_date_time = created_date_time;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_date_time() {
		return updated_date_time;
	}

	public void setUpdated_date_time(String updated_date_time) {
		this.updated_date_time = updated_date_time;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}

package ekutir.sanimark.web.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "agriscore.service")
public class Services implements Serializable{
	/*
	 * This is our model class and it corresponds to Service table in database.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int serviceid;
	@Column
	private String business_name;
	@Column
	private String service_description;
	@Column
	private String when_to_use;
	@Column
	private String how_to_use;
	@Column
	private String consumer_benefit;
	@Column
	private String contact_details;
	@Column
	private String address;
	@Column
	private String block;
	@Column
	private String district;
	@Column
	private String state_service;
	@Column
	private String country;
	@Column
	private String pincode;
	@Column
	private String created_by;
	@Column
	private Date created_date;
	@Column
	private String updated_by;
	@Column
	private Date updated_date;
	@Column
	private int service_cat_id;
	
	public Services() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Services(int serviceid, String business_name, String service_description,
			String when_to_use, String how_to_use, String consumer_benefit, String contact_details, String address,
			String block, String district, String state_service, String country, String pincode, String created_by,
			Date created_date, String updated_by, Date updated_date, int service_cat_id) {
		super();
		this.serviceid = serviceid;
		this.business_name = business_name;
		this.service_description = service_description;
		this.when_to_use = when_to_use;
		this.how_to_use = how_to_use;
		this.consumer_benefit = consumer_benefit;
		this.contact_details = contact_details;
		this.address = address;
		this.block = block;
		this.district = district;
		this.state_service = state_service;
		this.country = country;
		this.pincode = pincode;
		this.created_by = created_by;
		this.created_date = created_date;
		this.updated_by = updated_by;
		this.updated_date = updated_date;
		this.service_cat_id = service_cat_id;
	}

	public int getServiceid() {
		return serviceid;
	}

	public void setServiceid(int serviceid) {
		this.serviceid = serviceid;
	}

	public String getBusiness_name() {
		return business_name;
	}

	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}

	public String getService_description() {
		return service_description;
	}

	public void setService_description(String service_description) {
		this.service_description = service_description;
	}

	public String getWhen_to_use() {
		return when_to_use;
	}

	public void setWhen_to_use(String when_to_use) {
		this.when_to_use = when_to_use;
	}

	public String getHow_to_use() {
		return how_to_use;
	}

	public void setHow_to_use(String how_to_use) {
		this.how_to_use = how_to_use;
	}

	public String getConsumer_benefit() {
		return consumer_benefit;
	}

	public void setConsumer_benefit(String consumer_benefit) {
		this.consumer_benefit = consumer_benefit;
	}

	public String getContact_details() {
		return contact_details;
	}

	public void setContact_details(String contact_details) {
		this.contact_details = contact_details;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState_service() {
		return state_service;
	}

	public void setState_service(String state_service) {
		this.state_service = state_service;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public Date getUpdated_date() {
		return updated_date;
	}

	public void setUpdated_date(Date updated_date) {
		this.updated_date = updated_date;
	}

	public int getService_cat_id() {
		return service_cat_id;
	}

	public void setService_cat_id(int service_cat_id) {
		this.service_cat_id = service_cat_id;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

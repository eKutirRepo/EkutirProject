package ekutir.sanimark.erp.view.beans.crm;

import java.util.List;

public class ProductdetailBean {
	private int productId;
	private String productName;
	private String description;
	private List<FetchItemDetailsBean> itemDetails;
	public ProductdetailBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductdetailBean(int productId, String productName, String description,
			List<FetchItemDetailsBean> itemDetails) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.description = description;
		this.itemDetails = itemDetails;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<FetchItemDetailsBean> getItemDetails() {
		return itemDetails;
	}
	public void setItemDetails(List<FetchItemDetailsBean> itemDetails) {
		this.itemDetails = itemDetails;
	}
	

}

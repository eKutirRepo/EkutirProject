package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.AdvertisementsBean;

public class SalesOfferdto {
	private List<AdvertisementsBean> salesoffer;

	public List<AdvertisementsBean> getSalesoffer() {
		return salesoffer;
	}

	public void setSalesoffer(List<AdvertisementsBean> salesoffer) {
		this.salesoffer = salesoffer;
	}
}

package ekutir.sanimark.erp.view.beans.crm;

public class FetchDispositionsBean {
	private int dispositionId;
	private String dispositionDislayName;

	public FetchDispositionsBean(int dispositionId, String dispositionDislayName) {

		this.dispositionId = dispositionId;
		this.dispositionDislayName = dispositionDislayName;

	}

	public int getDispositionId() {
		return dispositionId;
	}

	public void setDispositionId(int dispositionId) {
		this.dispositionId = dispositionId;
	}

	public String getDispositionDislayName() {
		return dispositionDislayName;
	}

	public void setDispositionDislayName(String dispositionDislayName) {
		this.dispositionDislayName = dispositionDislayName;
	}

}

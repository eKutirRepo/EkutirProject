package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.CatalogBean;



public class CatalogItemDto {
	
	private List<CatalogBean> catalog;

	public List<CatalogBean> getCatalog() {
		return catalog;
	}

	public void setCatalog(List<CatalogBean> catalog) {
		this.catalog = catalog;
	}
	

}

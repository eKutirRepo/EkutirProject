package ekutir.sanimark.erp.view.beans.crm;

public class FetchPaymentModesBean {
	private int paymentMode;
	private String paymentModeDisplayName;

	public FetchPaymentModesBean(int paymentMode, String paymentModeDisplayName) {
		this.paymentMode = paymentMode;
		this.paymentModeDisplayName = paymentModeDisplayName;

	}

	public int getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(int paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPaymentModeDisplayName() {
		return paymentModeDisplayName;
	}

	public void setPaymentModeDisplayName(String paymentModeDisplayName) {
		this.paymentModeDisplayName = paymentModeDisplayName;
	}

}

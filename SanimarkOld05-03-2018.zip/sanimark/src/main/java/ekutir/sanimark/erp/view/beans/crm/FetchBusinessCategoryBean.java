package ekutir.sanimark.erp.view.beans.crm;

public class FetchBusinessCategoryBean {
	private int categoryId;
	private String categoryCode;
	private String categoryDisplayNames;

	public FetchBusinessCategoryBean(int categoryId, String categoryCode, String categoryDisplayNames) {

		this.categoryId = categoryId;
		this.categoryCode = categoryCode;
		this.categoryDisplayNames = categoryDisplayNames;

	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCategoryDisplayNames() {
		return categoryDisplayNames;
	}

	public void setCategoryDisplayNames(String categoryDisplayNames) {
		this.categoryDisplayNames = categoryDisplayNames;
	}

}

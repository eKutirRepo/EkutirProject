package ekutir.sanimark.erp.dto.crm;

import java.util.ArrayList;
import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.OrderFollowUpDetailsBean;

public class OrderFollowUpDto {

	List<OrderFollowUpDetailsBean> commDetails = new ArrayList<>();

	public List<OrderFollowUpDetailsBean> getCommDetails() {
		return commDetails;
	}

	public void setCommDetails(List<OrderFollowUpDetailsBean> commDetails) {
		this.commDetails = commDetails;
	}

}

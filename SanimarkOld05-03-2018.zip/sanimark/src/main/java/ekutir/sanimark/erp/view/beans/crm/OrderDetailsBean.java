package ekutir.sanimark.erp.view.beans.crm;

public class OrderDetailsBean {
	private int itemId;
	private String itemName;
	private double orderQuantity;
	private double unitPrice;
	private String stockQuantity;
	private String shipmentDate;
	private double shipmentQuantity;

	public OrderDetailsBean() {
	}

	

	public OrderDetailsBean(int itemId, String itemName, double orderQuantity, double unitPrice, String stockQuantity,
			String shipmentDate, double shipmentQuantity) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.orderQuantity = orderQuantity;
		this.unitPrice = unitPrice;
		this.stockQuantity = stockQuantity;
		this.shipmentDate = shipmentDate;
		this.shipmentQuantity = shipmentQuantity;
	}



	public double getShipmentQuantity() {
		return shipmentQuantity;
	}



	public void setShipmentQuantity(double shipmentQuantity) {
		this.shipmentQuantity = shipmentQuantity;
	}



	public String getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(String stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public String getShipmentDate() {
		return shipmentDate;
	}

	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}

	

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(double orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

}

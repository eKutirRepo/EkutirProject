package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.AdvertisementsBean;

public class BizTipsDto {
	private List<AdvertisementsBean> biztipsDetails;

	public List<AdvertisementsBean> getBiztipsDetails() {
		return biztipsDetails;
	}

	public void setBiztipsDetails(List<AdvertisementsBean> biztipsDetails) {
		this.biztipsDetails = biztipsDetails;
	}
}

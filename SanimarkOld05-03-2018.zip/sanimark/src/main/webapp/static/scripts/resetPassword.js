var _loginId;
var _role;
var _token;
$(document).ready(function(){
    var getUrlParameter = function getUrlParameter(sParam)
    {
        var sPageURL = decodeURIComponent(window.location.search.substring(1)),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : sParameterName[1];
            }
        }
    };
    
    _loginId = getUrlParameter('email');
    _role = getUrlParameter('role');
    _token = getUrlParameter('emailLoginToken');
    
    $('#formResetPassword').validator().on('submit', function (e) {
      if (e.isDefaultPrevented()) {
        alert("Enter all the mandatory fields and submit again.")
      } else {
            e.preventDefault();

            var reset = {};
            reset.loginId = _loginId;
            reset.password = $("#new_pwd").val();
            reset.role = _role;
            reset.token = _token;
            $(".loader").show();
            $("#btn_submit").prop("disabled", true);
            $.ajax({
                            url: "resetPassword",
                            data: JSON.stringify(reset),
                            error: function(e){
                                $(".loader").hide();
                                showErrorAlert();
                            },
                            success: function(data){
                                $(".loader").hide();
                               if(data.error)
                                    showErrorAlert();
                               else{
                                   showSuccessAlert("Password updated successfully.");
                               }   
                            },
                            dataType: "json",
                            contentType: 'application/json; charset=utf-8',
                            type: "POST",
                            cache: false,
                            crossDomain: true
                    });
      }
    });
});

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(2000, 0, function()
        {
           window.location.href = "logOut";
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           	$("#btn_submit").prop("disabled", false);
        }); 
}
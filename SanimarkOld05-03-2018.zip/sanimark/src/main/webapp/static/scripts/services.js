$(document).ready(function() {
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    
    fetchServices();
    $("#editServiceForm").validator().on('submit', function(e){
        if (e.isDefaultPrevented()) {
            alert("Please fill up all the mandatory fields and submit again.")
        } else {
            e.preventDefault();
            submitEditServiceData();
        }
    });
});

function fetchServices(){
    $(".loader").show();
    $.ajax({
                url: "fetchServices",
                error: function(e){
					showErrorAlert("Services data fetch failed. Please try again.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Services data fetch failed. Please try again.");
                   else{
                       $.each(data.services, function(index){
                           this.serialNo = index+1;
                       });
                       setServiceTableData(data.services);
                       fetchServCategories();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
}

function fetchServCategories(){
    $(".loader").show();
    $.ajax({
                url: "fetchServiceCategories",
                error: function(e){
                    $(".loader").hide();
					showErrorAlert("Data fetch failed. Please try again.");
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                        var options = '';
                        $.each(data.serviceCategories, function(index){
                            options += '<option value="'+this.categoryId+'">'+this.categoryName+'</option>';
                        });
                        $("#selServCategory").append(options);
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
}

function setServiceTableData(serviceData){
    
    if ($.fn.DataTable.isDataTable( '#tblServices' ) ) {
        $('#tblServices').DataTable().destroy();
        $('#tblServices tbody').off( 'click');
    }
        var table = $('#tblServices').DataTable( {
            data: serviceData,
            columns: [
                { "data": "serialNo" },
                { "data": "serviceBrandName" },
                { "data": "servCategoryName" },
                { "data": "contactDetails" },
                { "data": "serviceDescription" },
                { "data": "" }
            ],
            columnDefs: [ {
                "targets": -1,
                "data": null,
                "orderable": false,
                "defaultContent": "<button class='btn btn-primary btn-xs btn-edit-service' style='margin:2px'>Edit</button><button style='margin:2px' class='btn btn-danger btn-xs btn-delete-service'>Delete</button>"
                }
            ]
        } );

        $('#tblServices tbody tr').css("cursor", "pointer");
        
        $('#tblServices tbody').on( 'click', 'tr', function () {
            var data = table.row(this).data();
            $("#serviceName").text(data.serviceBrandName);
            $("#servCategory").text(data.servCategoryName);
            $("#servContact").text(data.contactDetails);
            $("#servDesc").text(data.serviceDescription);
            $("#servWhenToUse").text(data.whenToUse);
            $("#servHowToUse").text(data.howToUse);
            $("#consumerBen").text(data.consumerBenifit);
            
            $("#serviceModal").modal();
        });
        
        $('#tblServices tbody').on( 'click', '.btn-delete-service', function (e) {
            e.stopPropagation();
            var currRow = table.row( $(this).parents('tr'));
            var data = table.row( $(this).parents('tr') ).data();
            BootstrapDialog.show({
                                    title: 'Confirm',
                                    message: 'Are you sure you want to delete the service?',
                                    buttons: [{
                                    label: 'OK',
                                    action: function(dialog) {
                                    deleteService(data.serviceId);
                                    dialog.close();
                                        }
                                }, {
                                    label: 'Cancel',
                                    action: function(dialog) {
                                    dialog.close();
                                        }
                                }]
                        });
        } );
        
        $('#tblServices tbody').on( 'click', '.btn-edit-service', function (e) {
            e.stopPropagation();
            $(":input", "#editServiceForm").val("");
            var currRow = table.row( $(this).parents('tr'));
            var data = table.row( $(this).parents('tr') ).data();
            _currEditServiceData = data;
            $("#editServBrandName").val(data.serviceBrandName);
            $("#selServCategory").val(data.servCategoryId);
            $("#editServContact").val(data.contactDetails);
            $("#editServDescription").val(data.serviceDescription);
            $("#editServWhenToUse").val(data.whenToUse);
            $("#editServHowToUse").val(data.howToUse);
            $("#editServConsumerBen").val(data.consumerBenifit);

            $("#editServiceForm").validator('update');

            $("#serviceEditModal").modal();
        });
}

function deleteService(serviceId){
    var service = {"serviceId": serviceId};
    $(".loader").show();
    $.ajax({
                url: "deleteService",
                data: JSON.stringify(service),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       showSuccessAlert("Service deleted successfully.");
                       fetchServices();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function submitEditServiceData(){
    var editService = {};
    editService.serviceId = _currEditServiceData.serviceId;
    editService.serviceBrandName = $("#editServBrandName").val();
    editService.servCategoryId = $("#selServCategory").val();
    editService.contactDetails = $("#editServContact").val();
    editService.serviceDescription = $("#editServDescription").val();
    editService.whenToUse = $("#editServWhenToUse").val();
    editService.howToUse = $("#editServHowToUse").val();
    editService.consumerBenifit = $("#editServConsumerBen").val();
    
    $(".btnEditSubmitServ").prop("disabled", true);
    $(".loader").show();
    $.ajax({
                url: "editService",
                data: JSON.stringify(editService),
                error: function(e){
					showErrorAlert3("Update service failed.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error){
						showErrorAlert3("Update service failed.");
                   }
                   else{
                       $("#serviceEditModal").modal("hide");
                	   showSuccessAlert("Service updated successfully.");
                       fetchServices();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
        });
}

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(2000, 0, function()
        {
            $(".btnEditSubmitServ").prop("disabled", false);
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg);  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           	
        }); 
}

function showErrorAlert3(msg)
{
        if(msg){
            $('#error-alert3').html("<strong>Error:&nbsp;</strong>"+msg);  
        }
        $('#error-alert3').css("opacity", 1); 
        $('#error-alert3').css("visibility", "visible");
        $('#error-alert3').fadeTo(4000, 0, function()
        {
           	$(".btnEditSubmitServ").prop("disabled", false);
        }); 
}

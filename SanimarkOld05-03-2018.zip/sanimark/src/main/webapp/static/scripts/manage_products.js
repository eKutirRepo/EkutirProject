var _currEditProductData;
var _currEditServiceData;
 
$(document).ready(function() {
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    
    $( "#editManufactureDate" ).datepicker({
        dateFormat: "yy-mm-dd",
        changeYear: true
    });
    $( "#editExpiryDate" ).datepicker({
        dateFormat: "yy-mm-dd",
        changeYear: true
    });
    
    $("#editDiscount").on("input", function(e){
        var discount = Number($(this).val());
        var mrp = Number($("#editMRP").val());
        if(mrp){
            var sellingPrice = mrp - (mrp * (discount/100)); 
            $("#editPrice").val(sellingPrice.toFixed(2));
        }
    });
    
    $("#editPrice").on("input", function(e){
        var sellingPrice = Number($(this).val());
        var mrp = Number($("#editMRP").val());
        if(mrp){
            var discount = ((mrp-sellingPrice)/mrp)*100; 
            $("#editDiscount").val(discount.toFixed(2));
        }
    });
    
    fetchProducts();
    
    $("#editProductForm").validator().on('submit', function(e){
        if (e.isDefaultPrevented()) {
            alert("Please fill up all the mandatory fields and submit again.")
        } else {
            e.preventDefault();
            submitEditProductData();
        }
    });
    
    $(".fileImage").change(function(e){
            if (this.files && this.files[0]) {
                
                if(this.files[0].size > 30000){
                    alert("File Size limit exeeds!!");
                    return;
                } 
                var reader = new FileReader();
                var parent = this.parentNode.parentNode.parentNode;
                reader.onload = function (e) {
                    $('#editProdImg', parent).attr('src', e.target.result);
                }

                reader.readAsDataURL(this.files[0]);
            }
    });
} );

function fetchProducts(){
    $(".loader").show();
    $.ajax({
                url: "fetchAllProducts",
                error: function(e){
					showErrorAlert("Data fetch failed. Please try again.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                       $.each(data.products, function(index){
                           this.serialNo = index+1;
                       });
                       setTableData(data.products);
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
}

function setTableData(dataSet){
    if ( $.fn.DataTable.isDataTable( '#tblProducts' ) ) {
        $('#tblProducts').DataTable().destroy();
        $('#tblProducts tbody').off( 'click');
    }
        var table = $('#tblProducts').DataTable( {
            data: dataSet,
            columns: [
                { "data": "serialNo" },
                { "data": "productName" },
                { "data": "prodCategoryName" },
                { "data": "productDescription" },
                { "data": "" }
            ],
            columnDefs: [ {
                "targets": -1,
                "data": null,
                "orderable": false,
                "defaultContent": "<button class='btn btn-primary btn-xs btn-view-item' style='margin:2px'>View Items</button><button class='btn btn-warning btn-xs btn-edit' style='margin:2px'>Edit</button><button class='btn btn-danger btn-xs btn-delete' style='margin:2px'>Delete</button>"
                }
            ]
        } );
    
    //$('#tblProducts tbody tr').css("cursor", "pointer");
    
    $('#tblProducts tbody').on( 'click', '.btn-view-item', function (e) {
        var currRow = table.row( $(this).parents('tr'));
        var data = table.row( $(this).parents('tr') ).data();
        var product = {"productId": data.productId};
        $(".loader").show();
        $.ajax({
                    url: "fetchItemsForProduct",
                    data: JSON.stringify(product),
                    error: function(e){
                        showErrorAlert("Data fetch failed. Please try again.");
                        $(".loader").hide();
                    },
                    success: function(data){
                        $(".loader").hide();
                       if(data.error)
                            showErrorAlert("Data fetch failed. Please try again.");
                       else{
                           setItemsData(data.productItems);
                       }   
                    },
                    dataType: "json",
                    contentType: 'application/json; charset=utf-8',
                    type: "POST",
                    cache: false,
                    crossDomain: true
        });
        
    });
    
    $('#tblProducts tbody').on( 'click', '.btn-edit', function (e) {
        var currRow = table.row( $(this).parents('tr'));
        var data = table.row( $(this).parents('tr') ).data();
        window.sessionStorage.currEditProductData = encodeURIComponent(JSON.stringify(data));
        window.location.href = "editProduct";
    });
    
    $('#tblProducts tbody').on( 'click', '.btn-delete', function (e) {
        e.stopPropagation();
        var currRow = table.row( $(this).parents('tr'));
        var data = table.row( $(this).parents('tr') ).data();
        BootstrapDialog.show({
                                title: 'Confirm',
                                message: 'Are you sure you want to delete the product?',
                                buttons: [{
                                label: 'OK',
                                action: function(dialog) {
                                deleteProduct(data.productId);
                                dialog.close();
                                    }
                            }, {
                                label: 'Cancel',
                                action: function(dialog) {
                                dialog.close();
                                    }
                            }]
                    });
    } );
}

function setItemsData(itemsData){
        $("#viewItemsModal .modal-body").empty();
        $.each(itemsData, function(index){
            var item = '<div class="wrapper">'
                    +'<h3 class="text-center">'+this.itemName+'</h3>'
                    +'<div class="row">'
                        +'<div class="col-md-6">'
                            +'<h4><small>MRP: </small>'+this.mrp+'</h4>'
                            +'<h4><small>Selling Price: </small>'+this.sellingPrice+'</h4>'
                            +'<h4><small>Warranty: </small>'+this.warranty+'</h4>'
                            +'<h4><small>Dimension: </small>'+this.dimension+'</h4>'
                            +'<h4><small>Color: </small>'+this.color+'</h4>'
                            +'<button class="btn btn-warning btn-sm btn-edit-item">Edit Item</button>'
                        +'</div>'
                        +'<div class="col-md-6">'
                            +'<img src="data:image/jpeg;base64,'+this.itemImage+'" class="img-responsive img-thumbnail" style="max-height:200px">'
                        +'</div>'
                    +'</div>'
                +'</div>';
            $(item).appendTo("#viewItemsModal .modal-body").data(this);
        });
        $(".btn-edit-item").click(function(index){
            var data = $(this).closest(".wrapper").data();
            window.sessionStorage.currEditItemData = encodeURIComponent(JSON.stringify(data));
            window.location.href = "editItem";
        });
        
        $("#viewItemsModal").modal();
}

function deleteProduct(productId){
    var product = {"productId": productId};
    $(".loader").show();
    $.ajax({
                url: "deleteProduct",
                data: JSON.stringify(product),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       showSuccessAlert("Product deleted successfully.");
                       fetchProducts();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function showSuccessAlert(msg, redirect)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(2000, 0, function()
        {
            if(redirect == true)
                window.location.reload();
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg);  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           	
        }); 
}

function showErrorAlert2(msg)
{
        if(msg){
            $('#error-alert2').html("<strong>Error:&nbsp;</strong>"+msg);  
        }
        $('#error-alert2').css("opacity", 1); 
        $('#error-alert2').css("visibility", "visible");
        $('#error-alert2').fadeTo(4000, 0, function()
        {
           	$(".btnEditSubmit").prop("disabled", false);
        }); 
}
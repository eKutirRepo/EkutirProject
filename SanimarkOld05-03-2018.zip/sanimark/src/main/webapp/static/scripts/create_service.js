$(document).ready(function(){
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    
    $(".loader").show();
    $.ajax({
                url: "fetchServiceCategories",
                error: function(e){
                    $(".loader").hide();
					showErrorAlert("Data fetch failed. Please try again.");
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                        var options = '';
                        $.each(data.serviceCategories, function(index){
                            options += '<option value="'+this.categoryId+'">'+this.categoryName+'</option>';
                        });
                        $("#serviceCategory").append(options);
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
    $("#myForm").validator().on('submit', function(e){
        if (e.isDefaultPrevented()) {
            alert("Please fill up all the mandatory fields and submit again.")
        } else {
            e.preventDefault();
            submitData();
        }
    });
});

function submitData(){
      var serviceObj = {};
      serviceObj.serviceBrandName = $("#serviceName").val();
      serviceObj.servCategoryId = $("#serviceCategory").val();
      serviceObj.contactDetails = $("#contactDetails").val();
      serviceObj.serviceDescription = $("#servDescription").val();
      serviceObj.whenToUse = $("#whenToUse").val();
      serviceObj.howToUse = $("#howToUse").val();
      serviceObj.consumerBenifit = $("#consumerBenifit").val();
      
      $(".btnSubmit").prop("disabled", true);	
      $(".loader").show();
        $.ajax({
                url: "createNewService",
                data: JSON.stringify(serviceObj),
                error: function(e){
					showErrorAlert("Service creation failed.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Service creation failed.");
                   else{
                	   showSuccessAlert("Service Created Successfully. Please wait for admin approval.");
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
        });
}

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(3000, 0, function()
        {
            $(".btnSubmit").prop("disabled", false);
            window.location.href = "services";
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           $(".btnSubmit").prop("disabled", false);	 	
        }); 
}
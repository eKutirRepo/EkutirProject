$(document).ready(function() {
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    $(".loader").show();
    $.ajax({
                url: "fetchSuppliers",
                error: function(e){
					showErrorAlert("Data fetch failed. Please try again.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                       $.each(data.suppliers, function(index){
                           this.serialNo = index+1;
                           this.addressStr = '';
                           if(this.address.block)
                                this.addressStr += this.address.block+', ';
                           if(this.address.city)
                                this.addressStr += this.address.city+', ';
                           if(this.address.district)
                                this.addressStr += this.address.district;
                           if(this.status == 0)
                               this.statusStr = '<span class="bg-danger">Waiting Approval</span>';
                           else if(this.status == 1)
                               this.statusStr = '<span class="bg-success">Approved</span>';
                           else if(status == 2)
                               this.statusStr = '<span class="bg-warning">License Expired</span>';
                       });
                      setTableData(data.suppliers); 
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
    $("#messageForm").validator().on('submit', function(e){
        if (e.isDefaultPrevented()) {
            alert("Please enter message and submit again.")
        } else {
            e.preventDefault();
            sendMessage();
        }
    });
    
    $("#link_msg").click(function(e){
        e.preventDefault();
        $("#messageForm").validator('destroy');
        $("#msg").val("");
        $("#messageForm").validator();
        $("#messageModal").modal();
    });
} );

function sendMessage(){
    var message = {"messagedescription": $("#msg").val()};
    $(".loader").show();
    $("#btn_msg").prop("disabled", true);
    $.ajax({
                url: "microEntrepreneurMsgs",
                data: JSON.stringify(message),
                error: function(e){
                    $("#messageModal").modal("hide");
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $("#messageModal").modal("hide");
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       showSuccessAlert("Message sent successfully.");
                   }
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
}


function setTableData(dataSet){
    var table = $('#tblSupplier').DataTable( {
        data: dataSet,
        columns: [
            { "data": "serialNo" },
            { "data": "businessName" },
            { "data": "addressStr" },
            { "data": "primaryContactName" },
            { "data": "primaryContactNumber" },
            {"data": "statusStr"},
            { "data": "" }
        ],
        columnDefs: [ {
            "targets": -1,
            "data": null,
            "orderable": false,
            "defaultContent": "<button class='btn btn-primary btn-xs btn-approve' style='margin:2px'>Approve</button><button class='btn btn-danger btn-xs btn-reject' style='margin:2px'>Reject</button><a href='viewSupplierProducts' class='btn-view-products'>View Approved Items/Services</a>"
        } ]
    } );
    
    disableAction();
    
    $('#tblSupplier tbody').on( 'click', '.btn-view-products', function (e) {
        e.stopPropagation();
        var currRow = table.row( $(this).parents('tr'));
        var data = table.row( $(this).parents('tr') ).data();
        window.sessionStorage.currSupplier = data.businessName;
		window.sessionStorage.currSupplierId = data.supplierId;
    });
    
    $('#tblSupplier tbody').on( 'click', '.btn-reject', function (e) {
        e.stopPropagation();
        var currRow = table.row( $(this).parents('tr'));
        var data = table.row( $(this).parents('tr') ).data();
        BootstrapDialog.show({
                                title: 'Confirm',
                                message: 'Are you sure you want to reject the supplier?',
                                buttons: [{
                                label: 'OK',
                                action: function(dialog) {
                                rejectSupplier(data.supplierId, currRow);
                                dialog.close();
                                    }
                            }, {
                                label: 'Cancel',
                                action: function(dialog) {
                                dialog.close();
                                    }
                            }]
                    });
    } );
    
    $('#tblSupplier tbody').on( 'click', '.btn-approve', function (e) {
        e.stopPropagation();
        var currRow = table.row( $(this).parents('tr'));
        var data = table.row( $(this).parents('tr') ).data();
        BootstrapDialog.show({
                                title: 'Confirm',
                                message: 'Are you sure you want to approve the supplier?',
                                buttons: [{
                                label: 'OK',
                                action: function(dialog) {
                                approveSupplier(data, currRow.node());
                                dialog.close();
                                    }
                            }, {
                                label: 'Cancel',
                                action: function(dialog) {
                                dialog.close();
                                    }
                            }]
                    });
    } );
    
    $('#tblSupplier tbody tr').css("cursor", "pointer");
    $('#tblSupplier tbody').on( 'click', 'tr', function () {
        var data = table.row(this).data();
        $("#businessName").text(data.businessName);
        $("#businessEmail").text(data.loginId);
        $("#address").text(data.address.addressLine1+', '+data.address.addressLine2+', '+data.address.addressLine3+', '+data.address.block+', '+data.address.city+', '+data.address.district+', '+data.address.state+', '+data.address.country+', '+data.address.pincode);
        $("#primaryContactPerson").text(data.primaryContactName);
        $("#primaryContactNumber").text(data.primaryContactNumber);
        $("#secondaryContactPerson").text(data.secondaryContactName);
        $("#secondaryContactNumber").text(data.secondaryContactNumber);
        $("#businessDescription").text(data.businessDescription);
        $("#status").text(data.status == 0? 'Waiting Approval' : 'Approved');
        
        $("#myModal").modal();
    } );
}

function approveSupplier(rowData, currRow){
    var supplier = {"supplierId": rowData.supplierId};
    $(".loader").show();
    $.ajax({
                url: "approveSupplier",
                data: JSON.stringify(supplier),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       showSuccessAlert("Supplier approved successfully.");
                       rowData.status = 1;
                       rowData.statusStr = '<span class="bg-success">Approved</span>';
                       $(".btn-approve,.btn-reject", currRow).prop("disabled", true);
                      $($(currRow).children()[5]).html('<span class="bg-success">Approved</span>');
                   }
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function rejectSupplier(supplierId, currRow){
    var supplier = {"supplierId": supplierId};
    $(".loader").show();
    $.ajax({
                url: "rejectsupplier",
                data: JSON.stringify(supplier),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       currRow.remove().draw();
                       showSuccessAlert("Supplier rejected successfully.");
                       reorderSupplier();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function reorderSupplier(){
    if($("#tblSupplier tbody tr").length > 1){
       $("#tblSupplier tbody tr").each(function(index){
            $("td", this).first().text(index+1);
       }); 
    }
}

function disableAction(){
    var dataTable = $("#tblSupplier").DataTable();
    dataTable.rows().every(function(){
        var data = this.data();
        if(data.status == 1 || data.status == 2){
            $(".btn-approve,.btn-reject", this.node()).remove();
        }
        else if(data.status == 0){
            $(".btn-view-products", this.node()).remove();
        }
    });
}

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(4000, 0, function()
        {
            $("#btnSubmit").prop("disabled", false);	
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           $("#btnSubmit").prop("disabled", false);	 	
        }); 
}
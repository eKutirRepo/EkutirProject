$(document).ready(function(){
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    var itemData = JSON.parse(decodeURIComponent(window.sessionStorage.currEditItemData));
    if(itemData){
        $("#itemName").val(itemData.itemName);
        $("#itemId").val(itemData.itemId);
        $("#brand").val(itemData.itemBrand);
        $("#warranty").val(itemData.warranty);
        $("#mrp").val(itemData.mrp);
        $("#sell_price").val(itemData.sellingPrice);
        $("#manufactureDate").val(itemData.manufactureDate);
        $("#expiryDate").val(itemData.expiryDate);
        $("#item_description").val(itemData.itemDescription);
        $("#dimension").val(itemData.dimension);
        $("#color").val(itemData.color);
        $(".image_preview").attr("src", "data:image/jpeg;base64,"+itemData.itemImage);
    }
    
    $(".loader").show();
    $.ajax({
                url: "fetchCategories",
                error: function(e){
                    $(".loader").hide();
					showErrorAlert("Data fetch failed. Please try again.");
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                        var options = '';
                        $.each(data.productCategories, function(index){
                            options += '<option value="'+this.categoryId+'">'+this.categoryName+'</option>';
                        });
                        $("#category").append(options);
                        $("#category").val(itemData.productCategoryId);
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
    $(".fileImage").change(function(e){
            if (this.files && this.files[0]) {
                
                if(this.files[0].size > 30000){
                    alert("File Size limit exeeds!!");
                    return;
                } 
                var reader = new FileReader();
                var parent = this.parentNode.parentNode.parentNode;
                reader.onload = function (e) {
                    $('.image_preview', parent).attr('src', e.target.result);
                }

                reader.readAsDataURL(this.files[0]);
            }
    });
    
    $( "#manufactureDate" ).datepicker({
        dateFormat: "yy-mm-dd",
        changeYear: true
    });
    $( "#expiryDate" ).datepicker({
        dateFormat: "yy-mm-dd",
        changeYear: true
    });
    
    $("#myForm").validator().on('submit', function(e){
        if (e.isDefaultPrevented()) {
            alert("Please fill up all the mandatory fields and submit again.")
        } else {
            e.preventDefault();
            submitEditItemData();
        }
    });
});

function submitEditItemData(){
      var itemData = {};
      itemData.itemId = $("#itemId").val();
      itemData.categoryId = $("#category").val();
      itemData.itemName = $("#itemName").val();
      itemData.brandName = $("#brand").val();
      itemData.warranty = $("#warranty").val();
      itemData.manufactureDate = $("#manufactureDate").val();
      itemData.expiryDate = $("#expiryDate").val();
      itemData.mrp = $("#mrp").val();
      itemData.sellingPrice = $("#sell_price").val();
      itemData.itemDescription = $("#item_description").val();
      itemData.dimension = $("#dimension").val();
      itemData.color = $("#color").val();
      
      var base64ImageContent = $('.image_preview').attr('src').replace(/^data:image\/(png|jpg|jpeg);base64,/, "");
      if(base64ImageContent == "static/images/noimage.png")
          base64ImageContent = "";
      itemData.productImg = base64ImageContent;
      
      
      $(".btnSubmit").prop("disabled", true);
      $(".loader").show();
        $.ajax({
                url: "editItem",
                data: JSON.stringify(itemData),
                error: function(e){
					showErrorAlert("Item edit failed.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Item edit failed.");
                   else{
                	   showSuccessAlert("Item Saved Successfully. Please wait for admin approval.");
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
        });
}

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(4000, 0, function()
        {
            $(".btnSubmit").prop("disabled", false);
            window.location.href = "supplierHome";
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           $(".btnSubmit").prop("disabled", false);	 	
        }); 
}
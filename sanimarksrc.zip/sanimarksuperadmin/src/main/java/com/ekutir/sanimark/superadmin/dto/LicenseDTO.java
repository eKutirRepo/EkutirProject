package com.ekutir.sanimark.superadmin.dto;

import java.util.Date;


public class LicenseDTO{


	private Long id;
	
	private String licenseType;
	
	private String licenseNo;
	
	private int licensePeriod;
	
	private Date licenseDate;
	
	private Double licenseprice;
	
    private String createdBy;
    
    private String updatedBy;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLicenseType() {
		return licenseType;
	}

	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public Date getLicenseDate() {
		return licenseDate;
	}

	public void setLicenseDate(Date licenseDate) {
		this.licenseDate = licenseDate;
	}

	public Double getLicenseprice() {
		return licenseprice;
	}

	public void setLicenseprice(Double licenseprice) {
		this.licenseprice = licenseprice;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public int getLicensePeriod() {
		return licensePeriod;
	}

	public void setLicensePeriod(int licensePeriod) {
		this.licensePeriod = licensePeriod;
	}

	@Override
	public String toString() {
		return "LicenseDTO [id=" + id + ", licenseType=" + licenseType + ", licenseNo=" + licenseNo + ", licenseDate="
				+ licenseDate + ", licenseprice=" + licenseprice + ", createdBy=" + createdBy + ", updatedBy="
				+ updatedBy + "]";
	}

	
}

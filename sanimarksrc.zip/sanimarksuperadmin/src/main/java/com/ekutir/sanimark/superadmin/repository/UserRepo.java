package com.ekutir.sanimark.superadmin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ekutir.sanimark.superadmin.entity.User;

public interface UserRepo extends JpaRepository<User, Long> {

	public User findByEmail(String email);
}

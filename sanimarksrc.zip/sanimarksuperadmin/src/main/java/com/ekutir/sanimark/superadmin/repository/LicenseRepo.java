package com.ekutir.sanimark.superadmin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ekutir.sanimark.superadmin.entity.License;

public interface LicenseRepo extends JpaRepository<License, Long> {

}

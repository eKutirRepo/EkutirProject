package com.ekutir.sanimark.superadmin.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.ekutir.sanimark.superadmin.service.DashboardService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@RestController
public class DashboardController {
	@Autowired
	private DashboardService dashboardService;
	
	@RequestMapping(value = "/totalnofordashboard", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil registerUser(){
		ResponseUtil response = new ResponseUtil();
		
		Long count=0L;
		
		Long totalMicroEntrePrenure=0L;
		
		Long totalProduct=0L;
		try {	
			
			count=dashboardService.getToatlSupplier();
			
			//totalMicroEntrePrenure=dashboardService.getTotalMictoEnreprenure();
			
			
			totalProduct=dashboardService.getTotalProduct();
			
			System.out.println(count+""+totalMicroEntrePrenure);
			
			
			
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}
	

	
	
	
	@RequestMapping(value = "/hello", method = RequestMethod.GET, produces = "application/json")
	public String Hello() {
		
		
		return "JHHH";
		
		
	}
	

}

package com.ekutir.sanimark.superadmin.service;

public interface DashboardService {

	Long getToatlSupplier();

	Long getTotalMictoEnreprenure();

	Long getTotalProduct();

}

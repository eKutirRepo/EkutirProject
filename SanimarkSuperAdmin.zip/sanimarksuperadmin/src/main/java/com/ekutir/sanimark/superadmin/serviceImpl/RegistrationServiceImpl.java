package com.ekutir.sanimark.superadmin.serviceImpl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekutir.sanimark.superadmin.dto.User;
import com.ekutir.sanimark.superadmin.exception.LoginException;
import com.ekutir.sanimark.superadmin.repository.UserRepo;
import com.ekutir.sanimark.superadmin.service.RegistrationService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@Service("registerService")
public class RegistrationServiceImpl implements RegistrationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RegistrationServiceImpl.class);
	
	@Autowired
	private UserRepo userRepo;
	
	@Override
	public ResponseUtil registerUser(User user) throws LoginException {
		LOGGER.info("Inside RegistrationServiceImpl .. registerUser");
		ResponseUtil response = new ResponseUtil();
		
		if(StringUtils.isNotEmpty(user.getEmail())){
			com.ekutir.sanimark.superadmin.entity.User dbUser=new com.ekutir.sanimark.superadmin.entity.User();
			BeanUtils.copyProperties(user, dbUser);
			dbUser.setStatus(0);
			dbUser.setEnabled(0);
			dbUser = userRepo.save(dbUser);
			if(dbUser.getId()!=null){
				BeanUtils.copyProperties(dbUser, user);
				if(dbUser.getVersion() > 0){
					response.setStatus(200);
					response.setObject(user);
				}
			}
		}
		LOGGER.info("Exit RegistrationServiceImpl .. registerUser");
		return response;
	}


}

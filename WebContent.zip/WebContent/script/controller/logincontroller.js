'use strict';

MyApp.controller('LoginController', ['$scope', 'LoginService', function($scope, LoginService) {
	
		$scope.login=function(){
		console.log($scope.user)
		LoginService.login($scope.user)
		.then(function(data){
		console.log(data)
		},function(data){
			console.log(data)
		});
	}
          
}]);
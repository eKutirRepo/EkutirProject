'use strict';
MyApp.factory('LoginService', ['$http', '$q', function($http, $q){

	var LoginService={
			login:login	
	}
	return LoginService;
	
	function login(user){
		var defer = $q.defer(user);
		
		$http.post("http://localhost:8082/login",JSON.stringify(user))
			.success(function(response) {
				defer.resolve(response);
			})
			.error(function(err) {
				defer.reject(err);
			});
			
		return defer.promise;
	}
	
		

}]);

'use strict';
MyApp.factory('AdminService', ['$http', '$q', function($http, $q){

var AdminService={
			requestForAdmin:requestForAdmin	
	}
	return AdminService;
	
	function requestForAdmin(admin){
	
		var defer = $q.defer(admin);
		
		$http.post("http://localhost:8082/register",JSON.stringify(admin))
			.success(function(response) {
				defer.resolve(response);
			})
			.error(function(err) {
				defer.reject(err);
			});
			
		return defer.promise;
	}
	
		

}]);

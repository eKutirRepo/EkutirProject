'use strict';

var MyApp = angular.module('MyApp',[]);



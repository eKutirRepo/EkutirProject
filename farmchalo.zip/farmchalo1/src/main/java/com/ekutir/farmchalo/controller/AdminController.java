package com.ekutir.farmchalo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.farmchalo.model.ApplicationInfo;
import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.model.User;
import com.ekutir.farmchalo.service.AdminService;
import com.ekutir.farmchalo.utility.ResponseUtility;

@RestController
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	@RequestMapping(value = "/user_registration", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtility userRegistration(@RequestBody @Valid final User user){
		ResponseUtility response = new ResponseUtility();
		try {
			
			boolean flag  = adminService.addUser(user);
			if(flag) {
				response.setStatus(200);
				response.setMessage("Success");
			}else {
				response.setStatus(200);
				response.setMessage("failed");
			}
			
		} catch (Exception e) {
			response.setStatus(500);
			response.setMessage("failed");
			e.printStackTrace();
		}
		return response;  
	}
	
	
	@RequestMapping(value = "/allUsers", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtility allUsers(@RequestBody @Valid final Login login){
		ResponseUtility response = new ResponseUtility();
		try {
			System.out.println("Login/..... ");
			
			 List<User> listUser  = adminService.getAllUsers(login);
				
			if(null != listUser) {
				response.setObject(listUser);
				response.setStatus(200);
				response.setMessage("Success");
			}else {
				response.setStatus(200);
				response.setMessage("failed");
			}
			
		} catch (Exception e) {
			response.setStatus(500);
			response.setMessage("failed");
			e.printStackTrace();
		}
		return response;  
	}
	
	
	@RequestMapping(value = "/activeOrDeactiveUser", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtility activeOrDeactiveUser(@RequestBody @Valid final User user){
		ResponseUtility response = new ResponseUtility();
		try {
			ApplicationInfo applicationInfo  = adminService.updateUser(user);
				
			if(null != applicationInfo) {
				response.setObject(applicationInfo.getUrl());
				response.setStatus(200);
				response.setMessage("Success");
			}else {
				response.setStatus(200);
				response.setMessage("failed");
			}
			
		} catch (Exception e) {
			response.setStatus(500);
			response.setMessage("failed");
			e.printStackTrace();
		}
		return response;  
	}
	
}

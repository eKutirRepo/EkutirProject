package com.ekutir.farmchalo.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ekutir.farmchalo.dao.repository.ApplicationRepository;
import com.ekutir.farmchalo.dao.repository.DemoUserRepository;
import com.ekutir.farmchalo.dao.repository.LoginRepository;
import com.ekutir.farmchalo.dao.repository.UserApplicationMapingRepository;
import com.ekutir.farmchalo.dao.repository.UserRepository;
import com.ekutir.farmchalo.exception.LoginException;
import com.ekutir.farmchalo.exception.UserException;
import com.ekutir.farmchalo.model.Application;
import com.ekutir.farmchalo.model.ApplicationInfo;
import com.ekutir.farmchalo.model.DemoUser;
import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.model.User;
import com.ekutir.farmchalo.model.UserApplicationMaping;
import com.ekutir.farmchalo.service.UserService;
import com.ekutir.farmchalo.utility.Mail;
import com.ekutir.farmchalo.utility.PasswordGenerator;

@Component
public class UserServiceImpl implements UserService{

	@Autowired
	DemoUserRepository demoUserRepository;
	
	@Autowired
    UserRepository userRepository;
	
	@Autowired
	LoginRepository loginRepository;
	
	@Autowired
	ApplicationRepository applicationRepository;
	
	@Autowired
	UserApplicationMapingRepository userApplicationMapingRepository;
	
	@Override
	public ApplicationInfo addDemouserInfo(DemoUser user) throws UserException {
		
		ApplicationInfo applicationInfo = null;
		
		try {
			DemoUser demouser = 	demoUserRepository.save(user);
			
			if(null !=demouser && null !=user.getApplication()) {
				Application application = applicationRepository.getApplicatinByName(user.getApplication());
				if(null!=application)
				for(ApplicationInfo  ai : application.getApplicationInfoList())
					if(ai.getVersion().equalsIgnoreCase("demo")) applicationInfo = ai;
						    String sellerMailId = demouser.getEmailID();
							String sellerMailName = demouser.getName();
							Thread thread = new Thread();
							Mail mail = new Mail();
							mail.setParameters(sellerMailId,sellerMailName);
							thread = new Thread(mail);
							thread.start();    
				
			}
			 return applicationInfo;
		} catch (Exception e) {
			System.out.println(e);
			throw new UserException("Error while add demo user info", e);
			
		}
		
	}


	@Override
	@Transactional
	public List<ApplicationInfo> getProjects(Login login) {
		List<ApplicationInfo> listApplicationInfo = new ArrayList<ApplicationInfo>();
		
		try {   
			Login existUser = loginRepository.isUserExist(login.getLoginCode());
			if(null!=existUser) {
				User user = userRepository.getUserByLogin(existUser);  
			 List<UserApplicationMaping> applicationMapings  = userApplicationMapingRepository.getUserApplicationMapingRepositoryByUser(user);
		
		     for(UserApplicationMaping applicationMaping:applicationMapings) listApplicationInfo.add(applicationMaping.getApplicationInfo());
		
			}
		return listApplicationInfo;
		} catch (Exception e) {
			
			
		}
		return listApplicationInfo;
	}


	

}

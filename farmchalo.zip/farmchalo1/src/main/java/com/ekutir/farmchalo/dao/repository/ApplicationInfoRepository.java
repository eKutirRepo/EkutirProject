package com.ekutir.farmchalo.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ekutir.farmchalo.model.Application;
import com.ekutir.farmchalo.model.ApplicationInfo;

@Repository
public interface ApplicationInfoRepository extends JpaRepository<ApplicationInfo, Long> {

	@Query("fROM ApplicationInfo A where A.application = :application and A.country=:country")    
	List<ApplicationInfo> getApplicatinByName(@Param("application") Application application,@Param("country") String country);

	@Query("fROM ApplicationInfo A where  A.country=:country")  
	List<ApplicationInfo> getAppByCountryName(@Param("country") String country);  
}

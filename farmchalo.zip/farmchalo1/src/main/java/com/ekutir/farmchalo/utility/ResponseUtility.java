package com.ekutir.farmchalo.utility;

import java.io.Serializable;
import java.util.List;

import com.ekutir.farmchalo.model.ApplicationInfo;
import com.ekutir.farmchalo.model.UserApplicationMaping;

public class ResponseUtility implements Serializable {

	private int status;
	private Object object;
	private String message;
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Object getObject() {
		return object;
	}
	public void setObject(Object object) {
		this.object = object;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	

}

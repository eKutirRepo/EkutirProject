package com.ekutir.farmchalo.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ekutir.farmchalo.model.DemoUser;




	@Repository
	public interface DemoUserRepository  extends JpaRepository<DemoUser, Long> {
		
		
}

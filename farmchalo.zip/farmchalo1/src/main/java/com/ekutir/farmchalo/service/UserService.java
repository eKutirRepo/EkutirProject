package com.ekutir.farmchalo.service;

import java.util.List;

import com.ekutir.farmchalo.exception.UserException;
import com.ekutir.farmchalo.model.ApplicationInfo;
import com.ekutir.farmchalo.model.DemoUser;
import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.model.User;

public interface UserService {

	 ApplicationInfo addDemouserInfo(DemoUser user) throws UserException;
	 List<ApplicationInfo> getProjects(Login login);


}

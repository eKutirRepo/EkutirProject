package com.ekutir.farmchalo.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.model.User;
import com.ekutir.farmchalo.model.UserApplicationMaping;


@Repository
public interface UserRepository  extends JpaRepository<User, Long> {
	
	@Query("fROM User U where U.login = :login")    
	User getUserByLogin(@Param("login") Login login);
 
}

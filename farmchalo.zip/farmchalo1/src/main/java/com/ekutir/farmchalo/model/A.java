package com.ekutir.farmchalo.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.ekutir.farmchalo.utility.PasswordGenerator;

public class A {
	
	
	/*
	public static void main(String[] args) {
		PasswordGenerator p = new PasswordGenerator();
System.out.println(p.get());
	}*/
	

}

package com.ekutir.farmchalo.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "user_application_mapping")
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"}, allowGetters = true)
public class UserApplicationMaping implements Serializable {

	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long userApplicationMapingid;


	    @OneToOne(cascade = CascadeType.ALL)
	    private ApplicationInfo applicationInfo;
	    
	    @OneToOne(cascade = CascadeType.ALL)
	    private User user;
	    
	    
	    private Date createdAt;

	  
	    private Date updatedAt=new Date();

		public Long getUserApplicationMapingid() {
			return userApplicationMapingid;
		}

		public void setUserApplicationMapingid(Long userApplicationMapingid) {
			this.userApplicationMapingid = userApplicationMapingid;
		}

		

		public ApplicationInfo getApplicationInfo() {
			return applicationInfo;
		}

		public void setApplicationInfo(ApplicationInfo applicationInfo) {
			this.applicationInfo = applicationInfo;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		
		public Date getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(Date createdAt) {
			this.createdAt = createdAt;
		}

		public Date getUpdatedAt() {
			return updatedAt;
		}

		public void setUpdatedAt(Date updatedAt) {
			this.updatedAt = updatedAt;
		}
	    
	    
}

package com.ekutir.farmchalo.service;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.ekutir.farmchalo.exception.LoginException;
import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.utility.ResponseUtility;

@Component
public interface LoginService {

	public Map<String,String> login(Login user) throws LoginException;
		

}

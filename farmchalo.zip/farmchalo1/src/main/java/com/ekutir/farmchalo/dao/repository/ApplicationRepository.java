package com.ekutir.farmchalo.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ekutir.farmchalo.model.Application;


@Repository
public interface ApplicationRepository  extends JpaRepository<Application, Long> {

	@Query("fROM Application A where A.name = :name")    
	Application getApplicatinByName(@Param("name") String name);  
	
	
}

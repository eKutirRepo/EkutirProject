package com.ekutir.farmchalo.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "demo_user")
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"}, allowGetters = true)
public class DemoUser implements Serializable {

	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long demoUserId;
	    
	    private String name;
	    private long phone;
	    private String emailID;
	    private long landLine;
	    private String message;
	    private String application;
	    
	    @Column(nullable = false, updatable = false)
	    @Temporal(TemporalType.TIMESTAMP)
	    @CreatedDate
	    private Date createdAt=new Date();
	    
		public Long getDemoUserId() {
			return demoUserId;
		}
		public void setDemoUserId(Long demoUserId) {
			this.demoUserId = demoUserId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public long getPhone() {
			return phone;
		}
		public void setPhone(long phone) {
			this.phone = phone;
		}
		public String getEmailID() {
			return emailID;
		}
		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}
		public long getLandLine() {
			return landLine;
		}
		public void setLandLine(long landLine) {
			this.landLine = landLine;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public String getApplication() {
			return application;
		}
		public void setApplication(String application) {
			this.application = application;
		}
		public Date getCreatedAt() {
			return createdAt;
		}
		public void setCreatedAt(Date createdAt) {
			this.createdAt = createdAt;
		}
	  
	    
	    
	  
	   /* @JsonManagedReference
	    @OneToMany(mappedBy = "company", cascade = CascadeType.DETACH)
	    @OrderBy("name ASC")
	    private Set<Employee> employee;*/

	    
		
	 
}

package com.ekutir.farmchalo.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "application", uniqueConstraints = {@UniqueConstraint(columnNames = {"applicationId"})})
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"}, allowGetters = true)
public class Application implements Serializable {

	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long applicationId;
	    
	    private String name;
	    private String status;
	    
	   // @Column(nullable = false, updatable = false)
	    @Temporal(TemporalType.TIMESTAMP)
	    @CreatedDate
	    private Date createdAt=new Date();

	   // @Column(nullable = false)
	    @Temporal(TemporalType.TIMESTAMP)
	    @LastModifiedDate
	    private Date updatedAt=new Date();

	    @JsonIgnore
	    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true,mappedBy="application",fetch=FetchType.EAGER)
		private Set<ApplicationInfo> applicationInfoList;
	    
	    
		public Long getApplicationId() {
			return applicationId;
		}

		public void setApplicationId(Long applicationId) {
			this.applicationId = applicationId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}


		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public Date getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(Date createdAt) {
			this.createdAt = createdAt;
		}

		public Date getUpdatedAt() {
			return updatedAt;
		}

		public void setUpdatedAt(Date updatedAt) {
			this.updatedAt = updatedAt;
		}

		public Set<ApplicationInfo> getApplicationInfoList() {
			return applicationInfoList;
		}

		public void setApplicationInfoList(Set<ApplicationInfo> applicationInfoList) {
			this.applicationInfoList = applicationInfoList;
		}

	    
		 
	 
}

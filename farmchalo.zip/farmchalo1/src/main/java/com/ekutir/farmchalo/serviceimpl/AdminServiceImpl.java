package com.ekutir.farmchalo.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ekutir.farmchalo.dao.repository.ApplicationInfoRepository;
import com.ekutir.farmchalo.dao.repository.ApplicationRepository;
import com.ekutir.farmchalo.dao.repository.LoginRepository;
import com.ekutir.farmchalo.dao.repository.UserApplicationMapingRepository;
import com.ekutir.farmchalo.dao.repository.UserRepository;
import com.ekutir.farmchalo.model.Application;
import com.ekutir.farmchalo.model.ApplicationInfo;
import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.model.User;
import com.ekutir.farmchalo.model.UserApplicationMaping;
import com.ekutir.farmchalo.service.AdminService;
import com.ekutir.farmchalo.utility.Mail;
import com.ekutir.farmchalo.utility.PasswordGenerator;

@Component
public class AdminServiceImpl  implements AdminService{

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	LoginRepository loginRepository;
	@Autowired
	PasswordGenerator passwordGenerator;
	
	@Autowired
	ApplicationRepository  applicationRepository ;
	
	@Autowired
	ApplicationInfoRepository  applicationInfoRepository ;
	@Autowired
	UserApplicationMapingRepository userApplicationMaping;
	
	@Override
	public boolean addUser(User user) {
		
		boolean flag = false ;
		
		
		try {
			Login login = new Login();
			login.setUsername(user.getEmailID());
			login.setPassword(new String(passwordGenerator.get()));  
			login.setCreatedAt(new Date()); 
			login.setUpdatedAt(new Date()); 
			login = loginRepository.save(login);
			
			
			user.setLogin(login);
			User saveUser = userRepository.save(user);    
			
			List<UserApplicationMaping> list = new ArrayList<UserApplicationMaping>();
			for(int index=0;index<user.getProjectId().length;index++ ) {
				Application application = 	applicationRepository.findOne(saveUser.getProjectId()[index]);
				
				
				if(null!=application) {
				Set<ApplicationInfo> listApplicationInfo = application.getApplicationInfoList();
				
				for(ApplicationInfo applicationInfo:listApplicationInfo) {
					if(applicationInfo.getCountry().equalsIgnoreCase(saveUser.getCountry())) {
						UserApplicationMaping userApplicationMaping = new UserApplicationMaping();
						userApplicationMaping.setUser(saveUser);
						userApplicationMaping.setApplicationInfo(applicationInfo);
						userApplicationMaping.setCreatedAt(new Date());
					
						list.add(userApplicationMaping);
					}
						
				  }
				}
				
			}
			
			userApplicationMaping.save(list);
			
			 flag = true;
			
			 /*if(null!=saveUser) {
				 
				    String sellerMailId = saveUser.getEmailID();
					String sellerMailName = saveUser.getName();
					
					if(sellerMailId !=null)
					{
					Thread thread = new Thread();
					Mail mail = new Mail();
					mail.setParameters(sellerMailId,sellerMailName);
					thread = new Thread(mail);
					thread.start();
					}
				 
			 }*/
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return flag;
	}


	@Override
	public List<User> getAllUsers(Login login) {
		System.out.println("joiiioo..");  
		 List<User> listUser = new  ArrayList<User>();
		 try {
			listUser = userRepository.findAll();    
		} catch (Exception e) {
			System.out.println(e);
		}
		return listUser;
	}


	@Override
	public ApplicationInfo updateUser(User user) {
		
		User existUser = userRepository.findOne(user.getUserId());
		if(null!=existUser) {
			existUser.setStatus(user.getStatus());
			userRepository.save(existUser);
		}
		
		return null;
	}
}

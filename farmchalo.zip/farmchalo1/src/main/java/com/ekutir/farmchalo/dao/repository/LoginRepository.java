package com.ekutir.farmchalo.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ekutir.farmchalo.model.Login;


@Repository
public interface LoginRepository  extends JpaRepository<Login, Long> {

	
	 @Query("fROM Login r where r.username = :username")    
	    Login getLoginByUser(@Param("username") String id);   
	 /*@Query("SELECT r.id FROM RuleVo r where r.name = :name") 
	    List<Long> findIdByName(@Param("name") String name);
	 
	 @Query("SELECT r.name FROM RuleVo r where r.id = :id") 
	    String findNameById(@Param("id") Long id);*/
	
	
	 @Query("FROM Login l where l.username = :username and l.password = :password")  
	 Login isValidUser(@Param("username") String username,@Param("password") String password);

	 @Query("FROM Login l where l.loginCode = :loginCode")  
	 Login isUserExist(@Param("loginCode") String loginCode);
	
}

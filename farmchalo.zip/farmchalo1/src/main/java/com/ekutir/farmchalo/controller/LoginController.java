package com.ekutir.farmchalo.controller;


import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.service.LoginService;
import com.ekutir.farmchalo.utility.ResponseUtility;



@RestController
public class LoginController {
	
	@Autowired
	private LoginService loginService;
	
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtility sayHello(@RequestBody @Valid final Login login){
		
		ResponseUtility response = new ResponseUtility();
		try {
			Map<String,String> map= loginService.login(login);
			
			System.out.println();
			if(null!=map && map.get("loginType").equalsIgnoreCase(login.getLoginType())){
				System.out.println(map.get("loginCode")); 
					response.setObject(map.get("loginCode"));
					response.setStatus(200);
					response.setMessage("Success");
				
				} else {
					response.setMessage("Failure");
					response.setStatus(201);
				}
			
			
			
		}catch (Exception ex) {
			response.setMessage("Failure");
			response.setStatus(201);
			
			return response;

		}
		
		return response;
	
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/* @Autowired
	 UserRepository userRepository;
	 
	 @Autowired
	 LoginRepository loginRepository;
	
	@PostMapping("/createuser")
	public boolean createNote(@Valid @RequestBody User user) {
		System.out.println("Manas");  
		userRepository.save(user);
		Login login = new Login;
		login.setPassword(user.ge);
		loginRepository.save(login);
	    return true;
	}
	
	@PostMapping("/login")
	public Login createNote(@Valid @RequestBody Login login) {
	    return loginRepository.save(login);
	}
	
	@PostMapping("/validUser")
	public Login validUser(@Valid @RequestBody Login login) {
		
		System.out.println(login.getPassword());
		System.out.println(login.getUsername());
		
		Login l = loginRepository.isValidUser(login.getUsername().trim(), login.getPassword().trim());  
		
	    return l;
	}
	
	@RequestMapping("/api")  
	public String hello(){
		//loginRepository.rr("manas");
		return "MANAS :";
	}
	
	
	@PostMapping("/getLoin/{id}")
	public ResponseEntity<Login> getNoteById(@PathVariable(value = "id") Long noteId) {
		Login login = loginRepository.findOne(noteId);
	    if(login == null) {
	        return ResponseEntity.notFound().build();
	    }
	    return ResponseEntity.ok().body(login);
	}*/
	
	/* @Autowired
	    NoteRepository noteRepository;
	 @Autowired
	    CompanyRepoSitory companyRepository;
	
	@RequestMapping("/api")  
	public String hello(){
		return "Welcome Manas World";
	}
		
	@GetMapping("/notes")
	public List<Note> getAllNotes() {
	    return noteRepository.findAll();
	}
	
	@GetMapping("/companys")
	public List<Company> getCompanys() {
	    return companyRepository.findAll();
	}
	
	@PostMapping("/createnotes")
	public Note createNote(@Valid @RequestBody Note note) {
	    return noteRepository.save(note);
	}

	@GetMapping("/getnotes/{id}")
	public ResponseEntity<Note> getNoteById(@PathVariable(value = "id") Long noteId) {
	    Note note = noteRepository.findOne(noteId);
	    if(note == null) {
	        return ResponseEntity.notFound().build();
	    }
	    return ResponseEntity.ok().body(note);
	}
	
	@PutMapping("/updatenotes/{id}")
	public ResponseEntity<Note> updateNote(@PathVariable(value = "id") Long noteId, 
	                                       @Valid @RequestBody Note noteDetails) {
		
		System.out.println("manas");
	    Note note = noteRepository.findOne(noteId);
	    if(note == null) {
	        return ResponseEntity.notFound().build();
	    }
	    note.setTitle(noteDetails.getTitle());
	    note.setContent(noteDetails.getContent());

	    Note updatedNote = noteRepository.save(note);
	    return ResponseEntity.ok(updatedNote);
	}
	
	
	@DeleteMapping("/notes/{id}")
	public ResponseEntity<Note> deleteNote(@PathVariable(value = "id") Long noteId) {
	    Note note = noteRepository.findOne(noteId);
	    if(note == null) {
	        return ResponseEntity.notFound().build();
	    }

	    noteRepository.delete(note);
	    return ResponseEntity.ok().build();
	}
	*/
	
}
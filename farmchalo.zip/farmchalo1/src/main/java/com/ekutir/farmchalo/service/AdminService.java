package com.ekutir.farmchalo.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.ekutir.farmchalo.model.ApplicationInfo;
import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.model.User;

@Component
public interface AdminService {

	List<User> getAllUsers(Login login);

	boolean addUser(User user);

	ApplicationInfo updateUser(User user);

}

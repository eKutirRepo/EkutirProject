package com.ekutir.farmchalo.serviceimpl;


import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ekutir.farmchalo.dao.repository.LoginRepository;
import com.ekutir.farmchalo.exception.LoginException;
import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.service.LoginService;
import com.ekutir.farmchalo.utility.PasswordHasher;

@Component
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginRepository loginRepo;
	@Autowired
	PasswordHasher passwordHasher;
	
	@Override
	public Map<String,String> login(Login user) throws LoginException {
		 Map<String,String> map =null;
		Login isValidLogin=null;
		
		try {
			isValidLogin = loginRepo.isValidUser(user.getUsername(),user.getPassword());
			
			if(null!=isValidLogin) {
				map = new HashMap<String,String>();
				String loginCode = passwordHasher.generateLonginCode(isValidLogin.getUsername(),isValidLogin.getPassword(), isValidLogin.getLoginid());
				isValidLogin.setLastLogin(new Timestamp((new Date()).getTime()));
				isValidLogin.setLoginCode(loginCode);  
				loginRepo.save(isValidLogin);
				map.put("loginCode", loginCode);
				map.put("loginType", isValidLogin.getLoginType());
			}
			
		} catch (Exception e) {
			throw new LoginException("Error while login to  superAdmin", e);
		}
		return map;
	}

}

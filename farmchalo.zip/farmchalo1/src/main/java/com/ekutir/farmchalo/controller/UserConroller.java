package com.ekutir.farmchalo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.farmchalo.model.ApplicationInfo;
import com.ekutir.farmchalo.model.DemoUser;
import com.ekutir.farmchalo.model.Login;
import com.ekutir.farmchalo.model.User;
import com.ekutir.farmchalo.model.UserApplicationMaping;
import com.ekutir.farmchalo.service.UserService;
import com.ekutir.farmchalo.utility.ResponseUtility;

@RestController
public class UserConroller {
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/saveDemoUser", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtility saveDemoUser(@RequestBody @Valid final DemoUser user){
		ResponseUtility response = new ResponseUtility();
		
		try {
			ApplicationInfo applicationInfo  = userService.addDemouserInfo(user);
				
			if(null != applicationInfo) {
				response.setObject(applicationInfo.getUrl());
				response.setStatus(200);
				response.setMessage("Success");
			}else {
				response.setStatus(200);
				response.setMessage("failed");
			}
			
		} catch (Exception e) {
			response.setStatus(500);
			response.setMessage("failed");
			e.printStackTrace();
		}
		return response;  
	}
	
	
	
	@RequestMapping(value = "/getProjects", method = RequestMethod.POST, produces = "application/json")  
	public ResponseUtility getProjects(@RequestBody @Valid final Login login){   
		ResponseUtility response = new ResponseUtility();  
		try {
			
			List<ApplicationInfo> list = userService.getProjects(login);
			
		
			if(null != list) {
				response.setObject(list);
				response.setStatus(200);
				response.setMessage("Success");
			}else {
				response.setStatus(201);
				response.setMessage("failed");
			}
			
		} catch (Exception e) {
			System.out.println("ERoorr"+e);  
			response.setStatus(500);
			response.setMessage("failed");
		}
		List<ApplicationInfo>  a= (List<ApplicationInfo> )response.getObject();
		return response;  
	}
	
	
}

package com.ekutir.farmchalo.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "user")
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"}, allowGetters = true)
public class User implements Serializable {

	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long userId;
	    
	    private String organizationName;
	    private String name;
	    private String country;
	    private String compEmailID;
	    private long phone;
	    private String emailID;
	    private long landLine;
	    private String webUrl;
	    private String office;
	    private String location;
	    private int pin;
	    private String state;
	    private String district;
	    private String city;
	    
	   
	    @Transient
	    private long  projectId[];
 	    
	    @Column(name = "licensesFrom")
	    @DateTimeFormat(pattern = "dd/MM/YYYY") 
		private Date licensesFrom;
	   
	    @Column(name = "licensesTo")
	    @DateTimeFormat(pattern = "dd/MM/YYYY")    
		private Date licensesTo;
	    
	    private int status;
	    
	    @OneToOne(cascade = CascadeType.ALL)
	    private Login login;
	   // @Column(nullable = false, updatable = false)
	    @Temporal(TemporalType.TIMESTAMP)
	    @CreatedDate
	    private Date createdAt=new Date();

	   // @Column(nullable = false)
	    @Temporal(TemporalType.TIMESTAMP)
	    @LastModifiedDate
	    private Date updatedAt=new Date();

		public Long getUserId() {
			return userId;
		}

		public void setUserId(Long userId) {
			this.userId = userId;
		}

		public String getOrganizationName() {
			return organizationName;
		}

		public void setOrganizationName(String organizationName) {
			this.organizationName = organizationName;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}

		public String getCompEmailID() {
			return compEmailID;
		}

		public void setCompEmailID(String compEmailID) {
			this.compEmailID = compEmailID;
		}

		public long getPhone() {
			return phone;
		}

		public void setPhone(long phone) {
			this.phone = phone;
		}

		public String getEmailID() {
			return emailID;
		}

		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}

		public long getLandLine() {
			return landLine;
		}

		public void setLandLine(long landLine) {
			this.landLine = landLine;
		}

		public String getWebUrl() {
			return webUrl;
		}

		public void setWebUrl(String webUrl) {
			this.webUrl = webUrl;
		}

		public String getOffice() {
			return office;
		}

		public void setOffice(String office) {
			this.office = office;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public int getPin() {
			return pin;
		}

		public void setPin(int pin) {
			this.pin = pin;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getDistrict() {
			return district;
		}

		public void setDistrict(String district) {
			this.district = district;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}

		public Login getLogin() {
			return login;
		}

		public void setLogin(Login login) {
			this.login = login;
		}

		public Date getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(Date createdAt) {
			this.createdAt = createdAt;
		}

		public Date getUpdatedAt() {
			return updatedAt;
		}

		public void setUpdatedAt(Date updatedAt) {
			this.updatedAt = updatedAt;
		}

		
		

		public Date getLicensesFrom() {
			return licensesFrom;
		}

		public void setLicensesFrom(Date licensesFrom) {
			this.licensesFrom = licensesFrom;
		}

		

		public Date getLicensesTo() {
			return licensesTo;
		}

		public void setLicensesTo(Date licensesTo) {
			this.licensesTo = licensesTo;
		}

		public long[] getProjectId() {
			return projectId;
		}

		public void setProjectId(long[] projectId) {
			this.projectId = projectId;
		}

		
		
	  
	   /* @JsonManagedReference
	    @OneToMany(mappedBy = "company", cascade = CascadeType.DETACH)
	    @OrderBy("name ASC")
	    private Set<Employee> employee;*/

	    
		
	 
}

package com.ekutir.farmchalo.exception;

public class LoginException extends Exception {
	private static final long serialVersionUID = -3014523168024582443L;
	private String errorCode;
	
	/**
	 * LoginException default constructor.
	 * 
	 */
	public LoginException(){
		super();
	}
	/**
	 * Constructs LoginException with the specified detail message.
	 * @param message - detail message.
	 */
	public LoginException(String message){
		super(message);
	}
	/**
	 * Constructs LoginException with the specified cause .	
	 * @param cause - the cause (which is saved for later retrieval by the Throwable.getCause() method).
	 * 				  A null value is permitted, and indicates that the cause is nonexistent or unknown.
	 */
	public LoginException(Throwable cause){
		super(cause);
	}
	/**
	 * Constructs LoginException with the specified detail message and cause .
	 * @param message - detail message.
	 * @param cause - the cause (which is saved for later retrieval by the Throwable.getCause() method).
	 * 				  A null value is permitted, and indicates that the cause is nonexistent or unknown.
	 */
	public LoginException(String message, Throwable cause) {
		super(message,cause);
	}
	/**
	 * Constructs LoginException with the specified detail message, cause and SQL State
	 * @param message - detail message.
	 * @param cause - the cause (which is saved for later retrieval by the Throwable.getCause() method).
	 * 				  A null value is permitted, and indicates that the cause is nonexistent or unknown.
	 * @param errorCode - 
	 */
	public LoginException(String message, Throwable cause, String errorCode){
		super(message,cause);
	}
	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}

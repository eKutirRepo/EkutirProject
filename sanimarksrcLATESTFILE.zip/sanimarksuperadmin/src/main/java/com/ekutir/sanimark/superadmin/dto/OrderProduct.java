package com.ekutir.sanimark.superadmin.dto;

public class OrderProduct {
	
	
	private String productName;
	
	private String totalOrder;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getTotalOrder() {
		return totalOrder;
	}

	public void setTotalOrder(String totalOrder) {
		this.totalOrder = totalOrder;
	}
	
	
	
	

}

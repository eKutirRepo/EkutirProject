'use strict';

MyApp.controller('AdminRegisterController', ['$scope', 'RegisterService', function($scope, RegisterService) {
	
	$scope.registerforAdmin=function(){
		console.log($scope.admin);
		RegisterService.registerforAdmin($scope.admin)
		.then(function(data){
			if(data.status==200){
				
				
			}
		},function(data){
			console.log(data)
		});
	}
          
}]);

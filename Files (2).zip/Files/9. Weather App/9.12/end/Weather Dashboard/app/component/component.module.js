﻿(function () {
    var name = "app.component",
        requires = [];

    angular.module(name, requires);
}());
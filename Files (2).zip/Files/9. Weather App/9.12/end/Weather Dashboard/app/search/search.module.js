﻿(function () {
    var name = "app.search",
        requires = [];

    angular.module(name, requires);
})();
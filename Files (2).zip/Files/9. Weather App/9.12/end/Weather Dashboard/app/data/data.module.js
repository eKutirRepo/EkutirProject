﻿(function () {
    var name = "app.data",
        requires = [        ];

    angular.module(name, requires);
}());
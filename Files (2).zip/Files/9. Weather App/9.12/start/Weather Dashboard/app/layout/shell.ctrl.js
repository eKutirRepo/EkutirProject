﻿(function () {
    angular.module("app.shell")
        .controller("Shell", function ($scope) {

        });
})();
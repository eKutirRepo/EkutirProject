'use strict';

MyApp.controller('UserController', ['$scope', 'UserService', function($scope, UserService) {
	
	$scope.validateUser=function(){
		console.log($scope.user)
		UserService.validateUser($scope.user)
		.then(function(data){
			console.log(data)
		},function(data){
			console.log(data)
		});
	}
          
}]);

package com.ekutir.sanimark.superadmin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="sani_supplier")
public class SupplierDetails {
	
	
	private static final long serialVersionUID = -5510104336704968373L;
	@Id
	@Column(name="supplier_id")
	private int supplierId;
	
	@Column(name="login_id")
	private String loginId;
	
	@Column(name="password")
	private String password;
	
	@Column(name="business_name")
	private String businessName;
	
	@Column(name="primary_contact_first_name")
	private String primaryFirstName;
	
	@Column(name="primary_contact_middle_name")
	private String primaryMiddleName;
	
	
	@Column(name="primary_contact_last_name")
	private String primaryLastName;

	@Column(name="primary_contact_number")
	private String primaryContactNumber;
	
	@Column(name="secondary_contact_name")
	private String secondaryContactName;
	
	@Column(name="secondary_contact_number")
	private String secondaryContactNumber;
	
	@Column(name="service_description")
	private String businessDescription;
	
	@Column(name="status")
	private int status;
	
	@Column(name="address")
	private int address;

	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getPrimaryFirstName() {
		return primaryFirstName;
	}

	public void setPrimaryFirstName(String primaryFirstName) {
		this.primaryFirstName = primaryFirstName;
	}

	public String getPrimaryMiddleName() {
		return primaryMiddleName;
	}

	public void setPrimaryMiddleName(String primaryMiddleName) {
		this.primaryMiddleName = primaryMiddleName;
	}

	public String getPrimaryLastName() {
		return primaryLastName;
	}

	public void setPrimaryLastName(String primaryLastName) {
		this.primaryLastName = primaryLastName;
	}


	public String getPrimaryContactNumber() {
		return primaryContactNumber;
	}

	public void setPrimaryContactNumber(String primaryContactNumber) {
		this.primaryContactNumber = primaryContactNumber;
	}

	public String getSecondaryContactName() {
		return secondaryContactName;
	}

	public void setSecondaryContactName(String secondaryContactName) {
		this.secondaryContactName = secondaryContactName;
	}

	public String getSecondaryContactNumber() {
		return secondaryContactNumber;
	}

	public void setSecondaryContactNumber(String secondaryContactNumber) {
		this.secondaryContactNumber = secondaryContactNumber;
	}

	public String getBusinessDescription() {
		return businessDescription;
	}

	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getAddress() {
		return address;
	}

	public void setAddress(int address) {
		this.address = address;
	}
	
	
	
	

}

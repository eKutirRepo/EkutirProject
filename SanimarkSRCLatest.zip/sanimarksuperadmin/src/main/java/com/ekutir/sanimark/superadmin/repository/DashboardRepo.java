package com.ekutir.sanimark.superadmin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekutir.sanimark.superadmin.entity.SupplierDetails;



public interface DashboardRepo extends JpaRepository<SupplierDetails, Long> {
	
	
	String TOTALSUPPLIER="select count(*) from SupplierDetails where status=1";

	
	
	@Query(TOTALSUPPLIER)
	Long countTotalSupplier();
	

	
}

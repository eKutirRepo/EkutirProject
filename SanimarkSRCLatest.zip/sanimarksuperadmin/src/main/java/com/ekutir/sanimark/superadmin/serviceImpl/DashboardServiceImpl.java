package com.ekutir.sanimark.superadmin.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekutir.sanimark.superadmin.repository.DashboardRepo;
import com.ekutir.sanimark.superadmin.service.DashboardService;

@Service("DashboardService")
public class DashboardServiceImpl implements DashboardService {
  
	@Autowired
	DashboardRepo dashboardRepo;
	
	@Override
	public Long getToatlSupplier() {
		Long l=0L;
		try {
			
			l=dashboardRepo.countTotalSupplier();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return l;
	}

}

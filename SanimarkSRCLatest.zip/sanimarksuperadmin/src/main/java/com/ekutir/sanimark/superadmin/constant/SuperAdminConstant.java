package com.ekutir.sanimark.superadmin.constant;

public class SuperAdminConstant {

}

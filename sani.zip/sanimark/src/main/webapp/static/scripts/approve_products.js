var _tableProducts;
var _tableServices;

$(document).ready(function() {
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    
    fetchProducts();
    
    $("#tabService").click(function(e){
        fetchServices();
    });
} );

function fetchProducts(){
    $(".loader").show();
   $.ajax({
                url: "fetchItemsforApproval",
                error: function(e){
					showErrorAlert("Data fetch failed. Please try again.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                       $.each(data.items, function(index){
                           this.serialNo = index+1;
                       });
                      setTableData(data.items);
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    }); 
}

function fetchServices(){
    $(".loader").show();
    $.ajax({
                url: "fetchServiceForApproval",
                error: function(e){
					showErrorAlert("Services data fetch failed. Please try again.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Services data fetch failed. Please try again.");
                   else{
                       $.each(data.services, function(index){
                           this.serialNo = index+1;
                       });
                       setServiceTableData(data.services);
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
            });
}

function setServiceTableData(serviceData){
        if(_tableServices)
            _tableServices.destroy();
    //if ( ! $.fn.DataTable.isDataTable( '#tblServices' ) ) {
        _tableServices = $('#tblServices').DataTable( {
            data: serviceData,
            columns: [
                { "data": "serialNo" },
                { "data": "serviceBrandName" },
                { "data": "servCategoryName" },
                { "data": "supplierName" },
                { "data": "contactDetails" },
                { "data": "" }
            ],
            columnDefs: [ {
                "targets": -1,
                "data": null,
                "orderable": false,
                "defaultContent": "<button class='btn btn-primary btn-xs btn-serv-approve' style='margin-right:5px'>Approve</button><button class='btn btn-danger btn-xs btn-serv-reject' style='margin:5px 0px'>Reject</button>"
                }
            ]
        } );

        $('#tblServices tbody tr').css("cursor", "pointer");
        $('#tblServices tbody').off( 'click');
        $('#tblServices tbody').on( 'click', '.btn-serv-reject', function (e) {
        e.stopPropagation();
        var currRow = _tableServices.row( $(this).parents('tr'));
        var data = _tableServices.row( $(this).parents('tr') ).data();
        BootstrapDialog.show({
                                title: 'Confirm',
                                message: 'Are you sure you want to reject the service?',
                                buttons: [{
                                label: 'OK',
                                action: function(dialog) {
                                rejectService(data.serviceId, currRow);
                                dialog.close();
                                    }
                            }, {
                                label: 'Cancel',
                                action: function(dialog) {
                                dialog.close();
                                    }
                            }]
                    });
    });
        
        $('#tblServices tbody').on( 'click', 'tr', function () {
            var data = _tableServices.row(this).data();
            $("#serviceName").text(data.serviceBrandName);
            $("#servCategory").text(data.servCategoryName);
            $("#servSupplier").text(data.supplierName);
            $("#servContact").text(data.contactDetails);
            $("#servDesc").text(data.serviceDescription);
            $("#servWhenToUse").text(data.whenToUse);
            $("#servHowToUse").text(data.howToUse);
            $("#consumerBen").text(data.consumerBenifit);
            
            $("#serviceModal").modal();
        });
        
        $('#tblServices tbody').on( 'click', '.btn-serv-approve', function (e) {
        e.stopPropagation();
        var currRow = _tableServices.row( $(this).parents('tr'));
        var data = _tableServices.row( $(this).parents('tr') ).data();
        BootstrapDialog.show({
                                title: 'Confirm',
                                message: 'Are you sure you want to approve the service?',
                                buttons: [{
                                label: 'OK',
                                action: function(dialog) {
                                approveService(data.serviceId);
                                dialog.close();
                                    }
                            }, {
                                label: 'Cancel',
                                action: function(dialog) {
                                dialog.close();
                                    }
                            }]
                    });
    } );
    
    _tableServices.rows().every(function(index){
        var data = this.data();
        var row = this.node();
        if(data.serviceApprovedStatus == 1){
            $(".btn-serv-approve,.btn-serv-reject", row).remove();
        }
    });
}

function setTableData(dataSet){
    if(_tableProducts)
        _tableProducts.destroy();
    _tableProducts = $('#tblProducts').DataTable( {
        data: dataSet,
        columns: [
            { "data": "serialNo" },
            { "data": "itemName" },
            { "data": "itemBrand" },
            { "data": "categoryName" },
            { "data": "supplierName" },
            { "data": "mrp" },
            { "data": "sellingPrice" },
            { "data": "" }
        ],
        columnDefs: [ {
            "targets": -1,
            "data": null,
            "orderable": false,
            "defaultContent": "<button class='btn btn-primary btn-xs btn-approve' style='margin-right:5px'>Approve</button><button class='btn btn-danger btn-xs btn-prod-reject' style='margin:5px 0px'>Reject</button>"
            },
            {"className": "dt-center", "targets": -4}
        ]
    } );
    
    $('#tblProducts tbody tr').css("cursor", "pointer");
    $('#tblProducts tbody').off( 'click');
    $('#tblProducts tbody').on( 'click', '.btn-prod-reject', function (e) {
        e.stopPropagation();
        var currRow = _tableProducts.row( $(this).parents('tr'));
        var data = _tableProducts.row( $(this).parents('tr') ).data();
        BootstrapDialog.show({
                                title: 'Confirm',
                                message: 'Are you sure you want to reject the product?',
                                buttons: [{
                                label: 'OK',
                                action: function(dialog) {
                                rejectProduct(data.itemId);
                                dialog.close();
                                    }
                            }, {
                                label: 'Cancel',
                                action: function(dialog) {
                                dialog.close();
                                    }
                            }]
                    });
    });
    
    $('#tblProducts tbody').on( 'click', '.btn-approve', function (e) {
        e.stopPropagation();
        var currRow = _tableProducts.row( $(this).parents('tr'));
        var data = _tableProducts.row( $(this).parents('tr') ).data();
        BootstrapDialog.show({
                                title: 'Confirm',
                                message: 'Are you sure you want to approve the product?',
                                buttons: [{
                                label: 'OK',
                                action: function(dialog) {
                                approveProduct(data.itemId);
                                dialog.close();
                                    }
                            }, {
                                label: 'Cancel',
                                action: function(dialog) {
                                dialog.close();
                                    }
                            }]
                    });
    } );
    
    $('#tblProducts tbody').on( 'click', 'tr', function () {
        var data = _tableProducts.row(this).data();
        $("#itemName").text(data.itemName);
        $("#brandName").text(data.itemBrand);
        $("#category").text(data.categoryName);
        $("#supplier").text(data.supplierName);
        $("#warranty").text(data.warranty);
        $("#doman").text(data.manufactureDate);
        $("#exp").text(data.expiryDate);
        $("#mrp").text(data.mrp);
        $("#sellingPrice").text(data.sellingPrice);
        $("#itemDesc").text(data.itemDescription);
        $("#dimension").text(data.dimension);
        $("#color").text(data.color);
        $("#prodImg").attr('src', 'data:image/jpeg;base64,'+data.itemImage);
        
        $("#myModal").modal();
    } );
    
    _tableProducts.rows().every(function(index){
        var data = this.data();
        var row = this.node();
        if(data.productApprovedStatus == 1){
            $(".btn-approve,.btn-prod-reject", row).remove();
        }
    });
}

function approveProduct(itemId){
    var product = {"itemId": itemId};
    $(".loader").show();
    $.ajax({
                url: "approveItem",
                data: JSON.stringify(product),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       //currRow.remove().draw();
                       showSuccessAlert("Item approved successfully.");
                       fetchProducts();
                       //reorderProducts();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function rejectProduct(itemId){
    var product = {"itemId": itemId};
    $(".loader").show();
    $.ajax({
                url: "deleteItem",
                data: JSON.stringify(product),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       //currRow.remove().draw();
                       showSuccessAlert("Item rejected successfully.");
                       fetchProducts();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function reorderProducts(){
    if($("#tblProducts tbody tr").length > 1){
        $("#tblProducts tbody tr").each(function(index){
            $("td", this).first().text(index+1);
        });
    }
}

function rejectService(serviceId, currRow){
    var service = {"serviceId": serviceId};
    $(".loader").show();
    $.ajax({
                url: "deleteService",
                data: JSON.stringify(service),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       //currRow.remove().draw();
                       showSuccessAlert("Service rejected successfully.");
                       //reorderServices();
                       fetchServices();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function reorderServices(){
    if($("#tblServices tbody tr").length > 1){
        $("#tblServices tbody tr").each(function(index){
            $("td", this).first().text(index+1);
        });
    }
}


function approveService(serviceId){
    var service = {"serviceId": serviceId};
    $(".loader").show();
    $.ajax({
                url: "approveServices",
                data: JSON.stringify(service),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       //currRow.remove().draw();
                       showSuccessAlert("Service approved successfully.");
                       fetchServices();
                       //reorderServices();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(4000, 0, function()
        {
            	
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           	
        }); 
}
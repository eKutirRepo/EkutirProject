var _itemsData;

$(document).ready(function(){
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    
    //initially set product categories
    $(".loader").show();
    $.ajax({
                url: "fetchCategories",
                error: function(e){
                    $(".loader").hide();
					showErrorAlert("Data fetch failed. Please try again.");
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                        var options = '';
                        $.each(data.productCategories, function(index){
                            options += '<option value="'+this.categoryId+'">'+this.categoryName+'</option>';
                        });
                        $("#productCat").append(options);
                       fetchAllItems();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
    $(".fileImage").change(function(e){
            if (this.files && this.files[0]) {
                
                if(this.files[0].size > 30000){
                    alert("File Size limit exeeds!!");
                    return;
                } 
                var reader = new FileReader();
                var parent = this.parentNode.parentNode.parentNode;
                reader.onload = function (e) {
                    $('.image_preview', parent).attr('src', e.target.result);
                }

                reader.readAsDataURL(this.files[0]);
            }
    });
    
    $("#productCat").change(function(e){
        setItemsData();
    });
    
    $("#btnClearAll").click(function(e){
        $("#divTargetItems").empty();
        $("#divSourceItems .cbItem").prop("checked", false);
    });
    
    $("#btnSelectAll").click(function(e){
        $("#divSourceItems .cbItem").prop("checked", true);
        $("#divTargetItems").empty();
        
        $("#divSourceItems .linkItemView").each(function(index){
            var data = $(this.parentNode.parentNode).data();
             var item = '<div><a href="" class="linkItemView">'+data.itemName+'</a></div>';
            $(item).appendTo("#divTargetItems").data(data);
        });
        
        $("#divTargetItems .linkItemView").click(function(e){
                e.preventDefault();

                var data = $(this.parentNode).data();
                showItem(data);
        });
    });
    
    $("#myForm").validator().on('submit', function(e){
        if (e.isDefaultPrevented()) {
            alert("Please fill up all the mandatory fields and submit again.")
        }
        else if($("#divTargetItems .linkItemView").length == 0){
            e.preventDefault();
            alert("Please select at least one item.")
        }
        else {
            e.preventDefault();
            submitData();
        }
    });
    
    
    /*$("#myForm").on('keydown', '.unit', function(event){
        if(event.keyCode == 8)
            return;
        var user_input = $(this).val() + String.fromCharCode(event.keyCode);
        var regex = /^[a-zA-Z]{0,}[ -]{0,1}(?:[a-zA-Z]*)[ -]{0,1}(?:[a-zA-Z]*)+$/;
        if (!regex.test(user_input)) {
            event.preventDefault();
        }
    });*/
});

function fetchAllItems(){
    $(".loader").show();
    $.ajax({
                url: "fetchAllItems",
                error: function(e){
                    $(".loader").hide();
					showErrorAlert("Data fetch failed. Please try again.");
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                        _itemsData = data.productItems;
                       setItemsData();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
}

function setItemsData(){
    var fileredItems = [];
    $.each(_itemsData, function(index){
        if(this.productCategoryId == $("#productCat").val()){
            fileredItems.push(this);
        }
    });
    $("#divCB1,#divCB2").empty();
    $.each(fileredItems, function(index){
           if(index % 2 == 0){
                var cb1 = '<div class="checkbox">'
                                +'<label><input type="checkbox" class="cbItem" value="'+this.itemId+'"><a href="" class="linkItemView">'+this.itemName+'</a></label>'
                            +'</div>';
                $(cb1).appendTo("#divCB1").data(this);
            }
            else {
                var cb2 = '<div class="checkbox">'
                                +'<label><input type="checkbox" class="cbItem" value="'+this.itemId+'"><a href="" class="linkItemView">'+this.itemName+'</a></label>'
                            +'</div>';
                $(cb2).appendTo("#divCB2").data(this);
            } 
    });
    
    $(".cbItem").change(function(e){
        if($(this).is(':checked')){
            var data = $(this.parentNode.parentNode).data();
            var item = '<div><a href="" class="linkItemView">'+data.itemName+'</a></div>';
            $(item).appendTo("#divTargetItems").data(data);
            
            $("#divTargetItems .linkItemView").click(function(e){
                e.preventDefault();

                var data = $(this.parentNode).data();
                showItem(data);
            });
        }
        else{
            var currData = $(this.parentNode.parentNode).data();
            $("#divTargetItems .linkItemView").each(function(index){
                var targetData = $(this.parentNode).data();
                if(currData.itemId == targetData.itemId)
                   $(this.parentNode).remove(); 
            });
        }
    });
    
    $("#divSourceItems .linkItemView").click(function(e){
        e.preventDefault();
        var data = $(this.parentNode.parentNode).data();
        showItem(data);
    });
}

function addProduct(){
    //$("#myForm").submit();
}
function submitData(){
      var productObj = {};
      productObj.categoryId = $("#productCat").val();
      productObj.productName = $("#productName").val();
      productObj.productDescription = $("#productDesc").val();
    
      var base64ImageContent = $('.image_preview').attr('src').replace(/^data:image\/(png|jpg|jpeg);base64,/, "");
      if(base64ImageContent == "static/images/noimage.png")
          base64ImageContent = "";
      productObj.productImage = base64ImageContent;
      
      productObj.itemList = [];
      $("#divTargetItems .linkItemView").each(function(index){
            var targetData = $(this.parentNode).data();
            productObj.itemList.push({"itemId": targetData.itemId});
      });
      
      
      $(".btnSubmit").prop("disabled", true);
      $(".loader").show();
        $.ajax({
                url: "createProduct",
                data: JSON.stringify(productObj),
                error: function(e){
					showErrorAlert("Product creation failed.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Product creation failed.");
                   else{
                	   showSuccessAlert("Product Created Successfully.");
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
        });
}

function showItem(data){
    $("#itemName").text(data.itemName);
    $("#itemMrp").text(data.mrp);
    $("#itemPrice").text(data.sellingPrice);
    $("#itemWarranty").text(data.warranty);
    $("#dimension").text(data.dimension);
    $("#color").text(data.color);
    $("#itemImg").attr("src", "data:image/jpeg;base64,"+data.itemImage);
        
    $("#myModal").modal();
}

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(2000, 0, function()
        {
            $(".btnSubmit").prop("disabled", false);
            window.location.href = "supplierHome";
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           $(".btnSubmit").prop("disabled", false);	 	
        }); 
}
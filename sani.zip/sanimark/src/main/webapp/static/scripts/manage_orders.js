var _table;
$(document).ready(function() {
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    fetchOrderData();
    
    setInterval(fetchOrderData, 120000);
    
    $("#orderCloseForm").validator().on('submit', function(e){
        if (e.isDefaultPrevented()) {
            alert("Please enter the buy code and submit again.")
        } else {
            e.preventDefault();
            closeOrder();
        }
    });
} );

function fetchOrderData(){
    $(".loader").show();
    $.ajax({
                url: "fetchSupplierOrders",
                error: function(e){
					showErrorAlert("Data fetch failed. Please try again.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                       $.each(data.orders, function(index){
                           this.serialNo = index+1;
                           this.addressStr = '';
                           if(this.address.block)
                                this.addressStr += this.address.block+', ';
                           if(this.address.city)
                                this.addressStr += this.address.city+', ';
                           if(this.address.district)
                                this.addressStr += this.address.district;
                           
                           if(this.supplier_ack_status == 0)
                               this.order_status = "New Order";
                           else if(this.supplier_ack_status == 1)
                               this.order_status = "Delivery Pending";
                           else if(this.supplier_ack_status == 2)
                               this.order_status = "Delivered";
                       });
                      setTableData(data.orders); 
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
}

function setTableData(dataSet){
    if(_table){
       _table.destroy();
       $('#tblOrders tbody').off( 'click' );
    }
    _table = $('#tblOrders').DataTable( {
        data: dataSet,
        columns: [
            { "data": "serialNo" },
            { "data": "orderId" },
            { "data": "itemName" },
            { "data": "orderQuantity" },
            { "data": "orderPaymentMode" },
            { "data": "orderDate" },
            { "data": "addressStr" },
            { "data": "order_status" },
            { "data": "" }
        ],
        columnDefs: [ {
            "targets": -1,
            "data": null,
            "orderable": false,
            "defaultContent": "<button class='btn btn-primary btn-xs btn-ack'>Acknowledge</button><button class='btn btn-success btn-xs btn-close'>Close Order</button>"
        } ]
    } );
    $('#tblOrders tbody tr').css("cursor", "pointer");
    $('#tblOrders tbody').on( 'click', 'tr', function () {
        var data = _table.row(this).data();
        $("#orderId").text(data.orderId);
        $("#itemName").text(data.itemName);
        $("#brandName").text(data.brandName);
        $("#orderQuantity").text(data.orderQuantity);
        $("#paymentMode").text(data.orderPaymentMode);
        $("#mrp").text(data.mrp);
        $("#selling_price").text(data.sellingPrice);
        $("#delReqFromDate").text(data.orderRequestFromDate);
        $("#delReqToDate").text(data.orderRequestToDate);
        $("#customerName").text(data.customerFName + " " + data.customerMName + " " + data.customerLName);
        $("#customerPhone").text(data.customerMobileNumber);
        $("#advBookingAmt").text(data.advance);
        $("#orderDate").text(data.orderDate);
        $("#deliveryDate").text(data.deliveryDate);
        $("#address").text(data.address.addressLine1+', '+data.address.addressLine2+', '+data.address.addressLine3+', '+data.address.block+', '+data.address.city+', '+data.address.district+', '+data.address.state+', '+data.address.country+', '+data.address.pincode);
        
        $("#myModal").modal();
    } );
    
    $('#tblOrders tbody').on( 'click', '.btn-ack', function (e) {
        e.stopPropagation();
        var currRow = _table.row( $(this).parents('tr'));
        var data = _table.row( $(this).parents('tr') ).data();
        BootstrapDialog.show({
                                title: 'Confirm',
                                message: 'Are you sure you want to acknowledge the order?',
                                buttons: [
                                	{
                                		label: 'OK',
                                		action: function(dialog) {
                                			acknowledgeOrder(data, currRow);
                                			dialog.close();
                                		}
                                	}, 
                                	{
                                		label: 'Cancel',
                                		action: function(dialog) {
                                			dialog.close();
                                		}
                                	}
                                ]
                    });
    } );
    
    $('#tblOrders tbody').on( 'click', '.btn-close', function (e) {
        e.stopPropagation();
        var currRow = _table.row( $(this).parents('tr'));
        var data = _table.row( $(this).parents('tr') ).data();
        $("#orderCloseForm").validator('destroy');
        $("#buyCode").val("");
        $("#closeOrderProdId").val(data.itemId);
        $("#closeOrderOrderId").val(data.orderId);
        $("#orderCloseForm").validator();
        $("#orderCloseModal").modal();
    } );
    
    _table.rows().every(function(index){
        var data = this.data();
        var row = this.node();
        if(data.supplier_ack_status == 0){
            $(row).addClass("warning");
            $(".btn-close", row).remove();
        }
        else if(data.supplier_ack_status == 1){
            $(row).addClass("danger");
            $(".btn-ack", row).remove();
        }
        else{
            $(row).addClass("success");
            $(".btn-close", row).remove();
            $(".btn-ack", row).remove();
        }
    });
}

function acknowledgeOrder(data, currRow){
    var order = {
                    "orderId": data.orderId,
                    "itemId": data.itemId
                };
    $(".loader").show();
    $.ajax({
                url: "acknowledgeOrder",
                data: JSON.stringify(order),
                error: function(e){
					showErrorAlert("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Operation Failed");
                   else{
                       //currRow.remove().draw();
                       showSuccessAlert("Order acknowledged successfully.");
                       fetchOrderData();
                       //reorderOrders();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function closeOrder(){
    $("#btn_close_order").prop("disabled", true);
    var order = {
                    "orderId": $("#closeOrderOrderId").val(),
                    "itemId": $("#closeOrderProdId").val(),
                    "buycode": $("#buyCode").val()
                };
    $(".loader").show();
    $.ajax({
                url: "closeOrder",
                data: JSON.stringify(order),
                error: function(e){
					showErrorAlert2("Operation Failed");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert2("Invalid Buy Code!!!");
                   else{
                       //currRow.remove().draw();
                       $("#btn_close_order").prop("disabled", false);
                       $("#orderCloseModal").modal('hide');
                       showSuccessAlert("Order closed successfully.");
                       fetchOrderData();
                       //reorderOrders();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
}

function reorderOrders(){
    if($("#tblOrders tbody tr").length > 1){
        $("#tblOrders tbody tr").each(function(index){
            $("td", this).first().text(index+1);
        });
    }
}

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(4000, 0, function()
        {
            $("#btnSubmit").prop("disabled", false);	
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           $("#btnSubmit").prop("disabled", false);	 	
        }); 
}

function showErrorAlert2(msg)
{
        if(msg){
            $('#error-alert3').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert3').css("opacity", 1); 
        $('#error-alert3').css("visibility", "visible");
        $('#error-alert3').fadeTo(4000, 0, function()
        {
           $("#btn_close_order").prop("disabled", false);	 	
        }); 
}
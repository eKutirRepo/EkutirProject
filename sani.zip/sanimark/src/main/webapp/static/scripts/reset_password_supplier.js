$(document).ready(function(){
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    
    $('#formResetPassword').validator().on('submit', function (e) {
      if (e.isDefaultPrevented()) {
        alert("Enter all the mandatory fields and submit again.")
      } else {
            e.preventDefault();
            if($("#curr_pwd").val() == $("#new_pwd").val()){
                alert("Current password and new password can't be same.");
                return;
            }

            var reset = {};
            reset.currentPassword = $("#curr_pwd").val();
            reset.newPassword = $("#new_pwd").val();
            $(".btn-submit").prop("disabled", true);
            $(".loader").show();
            $.ajax({
                            url: "resetSupplierPassword",
                            data: JSON.stringify(reset),
                            error: function(e){
                                $(".loader").hide();
                                showErrorAlert();
                            },
                            success: function(data){
                                $(".loader").hide();
                               if(data.error)
                                    showErrorAlert();
                               else{
                                   showSuccessAlert("Password updated successfully.");
                               }   
                            },
                            dataType: "json",
                            contentType: 'application/json; charset=utf-8',
                            type: "POST",
                            cache: false,
                            crossDomain: true
                    });
      }
    });
});

function showSuccessAlert(msg)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(4000, 0, function()
        {
            $(".btn-submit").prop("disabled", false);
           window.location.href = "logOut";
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg)  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           	$(".btn-submit").prop("disabled", false);
        }); 
}
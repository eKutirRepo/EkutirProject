package ekutir.sanimark.service;

import java.util.List;

import ekutir.sanimark.android.dto.AddressBean;
import ekutir.sanimark.android.dto.AdminUserBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ResetPasswordBean;
import ekutir.sanimark.android.dto.UserViewBean;
import ekutir.sanimark.view.beans.UserResetPassword;

public interface UserService {
	public boolean isValidUser(UserViewBean userviewBean);

	public boolean forgetPassword(String roleBean, String email);

	public int registration(RegisterDataBean registerBean);

	public List<String> fetchAdminDetails();

	public boolean sendRegisterMailtoAdmin(String fetchAdminDetails);

	public int adminUser(AdminUserBean adminBean);

	public int changeadminpass(AdminUserBean changeadminpass);

	public List<AdminUserBean> fetchAdminData();

	public void updatedminpass(String loginId,String hashPassword);

	public List<RegisterDataBean> fetchSupplierData();

	public void updatesupplierpass(String login, String hashPassword);

	public boolean resetPassword(ResetPasswordBean resetPwd, String roleBean);

	public boolean checkForExistToken(String chkToken);

	public void clearToken(String clrtoken);

	public String returnToken(String rtnToken);

	public int resetUserPassword(UserResetPassword userResetPassword);

	public int resetAdminPassword(UserResetPassword adminResetPassword);

	public boolean duplicateRegistration(RegisterDataBean registerBean);
}

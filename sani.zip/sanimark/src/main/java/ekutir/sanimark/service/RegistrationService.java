package ekutir.sanimark.service;

import ekutir.sanimark.android.view.ResetPassword;
import ekutir.sanimark.dto.Communication;
import ekutir.sanimark.dto.CustomerAndLandDetails;
import ekutir.sanimark.dto.CustomerDto;
import ekutir.sanimark.dto.RegistrationDto;
import ekutir.sanimark.dto.RegistrationInProcessUserDto;
import ekutir.sanimark.dto.RequestValidationDto;
import ekutir.sanimark.dto.StatusDto;

public interface RegistrationService {

	public RegistrationInProcessUserDto initiateUserRegistration(long phoneNumber, String authKey, String appCode);

	public RegistrationInProcessUserDto registerUser(RegistrationDto registrationDto, String authKey);

	public StatusDto verifyOtp(Communication otp, String authKey);

	public StatusDto insertCustomerDetails(CustomerDto customer, String authKey);

	public RegistrationInProcessUserDto verifyPasscodeForExistingUser(String passCode, long phoneNumber,
			String tempAuthKey, String appCode);

	public boolean isCustomerExists(CustomerDto customer, String authkey);

	public RegistrationInProcessUserDto registerReturningOrBusinessUser(Communication registrationDto,
			String tempAuthKey);

	public CustomerAndLandDetails insertCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey);

	public RequestValidationDto verifyCustomerPhoneNumberAndAadhaarNumber(int userId, long custPhoneNumber,
			String aadhaarNumber, String typeOfRequest);

	public int resetAppUserPassword(ResetPassword resetPassword);
}

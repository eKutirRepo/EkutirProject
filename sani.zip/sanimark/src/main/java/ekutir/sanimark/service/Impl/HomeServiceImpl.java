package ekutir.sanimark.service.Impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ekutir.sanimark.android.model.Address;
import ekutir.sanimark.android.model.Customer;
import ekutir.sanimark.android.model.CustomerType;
import ekutir.sanimark.android.model.MeAndMyLand;
import ekutir.sanimark.android.model.User;
import ekutir.sanimark.constant.GatewayConstants;
import ekutir.sanimark.dao.HomeDao;
import ekutir.sanimark.dto.AddressDto;
import ekutir.sanimark.dto.CustomerAndLandDetails;
import ekutir.sanimark.dto.CustomerDto;
import ekutir.sanimark.dto.CustomerListDto;
import ekutir.sanimark.dto.CustomerTypeDto;
import ekutir.sanimark.dto.CustomerTypes;
import ekutir.sanimark.dto.LandDetailsDto;
import ekutir.sanimark.dto.StatusDto;
import ekutir.sanimark.dto.UserDto;
import ekutir.sanimark.service.HomeService;
import ekutir.sanimark.utilities.GatewayUtilties;

@Service("homeService")
public class HomeServiceImpl implements HomeService {

	@Autowired
	HomeDao homeDao;

	private static final Logger LOGGER = Logger.getLogger(HomeServiceImpl.class);

	/*@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public List<AdvertisementDto> fetchAdvertisements(String appCode, String masterKey) {
		List<AdvertisementDto> listOfAdvertisementDto = new ArrayList<AdvertisementDto>();
		AdvertisementDto advertisementDto = null;
		try {
			List<Advertisement> listOfAdvertisement = homeDao.getAdvertisements(appCode, masterKey,
					GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			for (Advertisement adv : listOfAdvertisement) {
				advertisementDto = new AdvertisementDto();
				advertisementDto.setAltText(adv.getAltText());
				advertisementDto.setStartDate(adv.getStartDateTime());
				advertisementDto.setEndDate(adv.getEndDateTime());
				advertisementDto.setAdvertisementsAsBase64(GatewayUtilties.convertBlobToBase64(adv.getGraphic()));
				listOfAdvertisementDto.add(advertisementDto);
			}
		} catch (Exception e) {
			LOGGER.error("Fetch Advertisements Failed!", e);
		}
		return listOfAdvertisementDto;
	}

	@Override
	public List<BusinessTipsDto> fetchBusinessTips(String appId, String masterKey) {
		List<BusinessTipsDto> listOfBusinessTipDto = new ArrayList<BusinessTipsDto>();
		BusinessTipsDto businessTipsDto = null;
		try {
			List<BusinessTip> listOfBusinessTip = homeDao.getBusinessTips(appId, masterKey,
					GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			for (BusinessTip btip : listOfBusinessTip) {
				businessTipsDto = new BusinessTipsDto();
				businessTipsDto.setAltText(btip.getAltText());
				businessTipsDto.setStartDate(btip.getStartDateTime());
				businessTipsDto.setEndDate(btip.getEndDateTime());
				businessTipsDto.setBusinessTipsAsBase64(GatewayUtilties.convertBlobToBase64(btip.getGraphic()));
				listOfBusinessTipDto.add(businessTipsDto);
			}
		} catch (Exception e) {
			LOGGER.error("Fetch Business Tips Failed!", e);
		}
		return listOfBusinessTipDto;
	}

	@Override
	public List<SalesAndOffersDto> fetchSalesAndOffers(String appId, String masterKey) {
		List<SalesAndOffersDto> listOfSalesAndOffersDto = new ArrayList<SalesAndOffersDto>();
		SalesAndOffersDto salesAndOffersDto = null;
		try {
			List<SaleAndOffer> listOfSalesAndOffers = homeDao.getSalesAndOffers(appId, masterKey,
					GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			for (SaleAndOffer sao : listOfSalesAndOffers) {
				salesAndOffersDto = new SalesAndOffersDto();
				salesAndOffersDto.setAltText(sao.getAltText());
				salesAndOffersDto.setStartDate(sao.getStartDateTime());
				salesAndOffersDto.setEndDate(sao.getEndDateTime());
				salesAndOffersDto.setSalesAndOffersAsBase64(GatewayUtilties.convertBlobToBase64(sao.getGraphic()));
				listOfSalesAndOffersDto.add(salesAndOffersDto);
			}
		} catch (Exception e) {
			LOGGER.error("Fetch Sales and Offers Failed!", e);
		}
		return listOfSalesAndOffersDto;
	}*/

	@Override
	public boolean isMasterKeyExists(String masterKey) {
		return homeDao.isMasterKeyExists(masterKey);
	}

	@Override
	public boolean isAppCodeExists(String appCode) {
		return homeDao.isAppCodeExists(appCode);
	}

	@Override
	public boolean isAuthKeyExists(String authKey) {
		return homeDao.isAuthKeyExists(authKey);
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public CustomerListDto fetchCustomers(int userId, int page) {
		List<Customer> customersList = homeDao.fetchCustomers(userId, page);
		CustomerListDto customerDtoList = new CustomerListDto();
		List<CustomerDto> customers = new ArrayList<>();
		CustomerDto customerDto = null;
		for (Customer customer : customersList) {
			customerDto = new CustomerDto();
			customerDto.setCustFirstName(customer.getFirstName());
			customerDto.setCustMiddleName(customer.getMiddleName());
			customerDto.setCustLastName(customer.getLastName());
			customerDto.setCustAadharNumber(customer.getAadharNumber());
			customerDto.setCustomerId(customer.getCustomerId());
			customerDto.setCustPhoneNumber(customer.getPhoneNumber());
			customerDto.setCustomerType(customer.getCustomerType().getTypeCode());
			customers.add(customerDto);
		}
		customerDtoList.setCustomers(customers);
		long count = homeDao.getCustomerCount(userId);
		// TODO Check the LOGIC over more data
		customerDtoList.setLastPage(((count - (page * GatewayConstants.MAX_SIZE_OF_CUSTOMERS))
				/ GatewayConstants.MAX_SIZE_OF_CUSTOMERS) <= 1);
		StatusDto status = new StatusDto();
		status.setStatusCode(GatewayConstants.CUSTOMERS_FETCHED_SUCCESSFULLY_STATUS_CODE);
		status.setStatusMessage(GatewayConstants.CUSTOMERS_FETCHED_SUCCESSFULLY_STATUS_MESSAGE);
		customerDtoList.setStatus(status);
		return customerDtoList;
	}

	/**
	 *
	 * first name, middle name, last name, customer type only
	 */
	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public CustomerDto saveCustomer(CustomerDto editedCustomer) {
		StatusDto status = new StatusDto();
		try {
			Customer customer = homeDao.getCustomer(editedCustomer.getCustomerId());
			customer.setMiddleName(editedCustomer.getCustMiddleName());
			customer.setFirstName(editedCustomer.getCustFirstName());
			customer.setLastName(editedCustomer.getCustLastName());
			customer.setPhoneNumber(editedCustomer.getCustPhoneNumber());
			customer.setAadharNumber(editedCustomer.getCustAadharNumber());
			CustomerType customerType = homeDao.fetchCustomerType(editedCustomer.getCustomerType());
			customer.setCustomerType(customerType);
			customer.setUpdatedBy(GatewayConstants.SYSTEM_TAG);
			customer.setUpdatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			customer = homeDao.saveCustomer(customer);
			status.setStatusCode(GatewayConstants.EDITED_CUSTOMER_SAVED_SUCCESSFULLY_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.EDITED_CUSTOMER_SAVED_SUCCESSFULLY_STATUS_MESSAGE);
			editedCustomer.setStatus(status);
		} catch (ParseException e) {
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
			editedCustomer.setStatus(status);
		}
		return editedCustomer;
	}

	/**
	 *
	 * first name, middle name, last name, address can be edited
	 */
	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public UserDto saveUser(UserDto editedUser) {
		StatusDto status = new StatusDto();
		try {
			User user = homeDao.fetchUser(editedUser.getUserId());
			user.setFirstName(editedUser.getFirstName());
			user.setMiddleName(editedUser.getMiddleName());
			user.setLastName(editedUser.getLastName());
			AddressDto editedAddress = editedUser.getAddress();
			user.getAddress().setAddressLine1(editedAddress.getAddressLine1());
			user.getAddress().setAddressLine2(editedAddress.getAddressLine2());
			user.getAddress().setAddressLine3(editedAddress.getAddressLine3());
			user.getAddress().setBlock(editedAddress.getBlock());
			user.getAddress().setCity(editedAddress.getCity());
			user.getAddress().setDistrict(editedAddress.getDistrict());
			user.getAddress().setPostalCode(editedAddress.getPostalCode());
			user.getAddress().setState(editedAddress.getState());
			user.getAddress().setCountry(editedAddress.getCountry());
			user.getAddress().setUpdatedBy(GatewayConstants.SYSTEM_TAG);
			user.getAddress()
					.setUpdatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			user.setUpdatedBy(GatewayConstants.SYSTEM_TAG);
			user.setUpdatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			status.setStatusCode(GatewayConstants.EDITED_USER_SAVED_SUCCESFULLY_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.EDITED_USER_SAVED_SUCCESFULLY_STATUS_MESSAGE);
			user = homeDao.saveUser(user);
			editedUser.setStatus(status);
		} catch (Exception e) {
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
			editedUser.setStatus(status);
		}
		return editedUser;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public boolean isAppRequestAuthorized(String masterKey, String appCode) {
		return homeDao.checkAppRequestAndMasterKey(masterKey, appCode);
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public CustomerTypes fetchCustomerTypes(String appCode) {
		CustomerTypes customerTypes = new CustomerTypes();
		StatusDto status = new StatusDto();
		try {
			List<CustomerType> listOfCustomerType = homeDao.fetchListOfCustomerType(appCode);
			List<CustomerTypeDto> listOfCustomerTypeDto = new ArrayList<>();
			CustomerTypeDto customerType = null;
			if (null != listOfCustomerType && listOfCustomerType.size() > 0) {
				for (CustomerType c : listOfCustomerType) {
					customerType = new CustomerTypeDto();
					customerType.setCustomerTypeCode(c.getTypeCode());
					customerType.setCustomerTypeDesc(c.getTypeDescription());
					listOfCustomerTypeDto.add(customerType);
				}
				customerTypes.setCustomerType(listOfCustomerTypeDto);
				status.setStatusCode(GatewayConstants.CUSTOMER_TYPE_FETCHED_SUCCESSFULLY_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.CUSTOMER_TYPE_FETCHED_SUCCESSFULLY_STATUS_MESSAGE);
			} else {
				status.setStatusCode(GatewayConstants.CUSTOMER_TYPE_NOT_AVAILABLE_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.CUSTOMER_TYPE_NOT_AVAILABLE_STATUS_MESSAGE);
			}
		} catch (Exception e) {
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
		}
		customerTypes.setStatus(status);
		return customerTypes;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public CustomerAndLandDetails fetchCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey) {
		List<MeAndMyLand> landDetails = homeDao
				.fetchLandDetailsForCustomer(customerLandDetails.getCustomer().getCustomerId());
		customerLandDetails = transformLandDetails(customerLandDetails, landDetails);
		return customerLandDetails;
	}

	private CustomerAndLandDetails transformLandDetails(CustomerAndLandDetails customerLandDetails,
			List<MeAndMyLand> landDetails) {
		CustomerAndLandDetails customerAndLandDetails = new CustomerAndLandDetails();
		CustomerDto customer = new CustomerDto();
		if (null != landDetails && landDetails.size() > 0) {
			customer.setCustFirstName(landDetails.get(0).getCustomer().getFirstName());
			customer.setCustMiddleName(landDetails.get(0).getCustomer().getMiddleName());
			customer.setCustLastName(landDetails.get(0).getCustomer().getLastName());
			customer.setCustAadharNumber(landDetails.get(0).getCustomer().getAadharNumber());
			customer.setCustomerId(landDetails.get(0).getCustomer().getCustomerId());
			customer.setCustomerType(landDetails.get(0).getCustomer().getCustomerType().getTypeCode());
			customer.setCustPhoneNumber(landDetails.get(0).getCustomer().getPhoneNumber());
			AddressDto address = new AddressDto();
			Address addressBo = landDetails.get(0).getCustomer().getAddress();
			address.setAddressId(addressBo.getAddressId());
			address.setAddressLine1(addressBo.getAddressLine1());
			address.setAddressLine2(addressBo.getAddressLine2());
			address.setAddressLine3(addressBo.getAddressLine3());
			address.setBlock(addressBo.getBlock());
			address.setCity(addressBo.getCity());
			address.setCountry(addressBo.getCountry());
			address.setDistrict(addressBo.getDistrict());
			address.setPostalCode(addressBo.getPostalCode());
			address.setState(addressBo.getState());
			customer.setAddress(address);
		} else {
			return customerLandDetails;
		}
		customerAndLandDetails.setCustomer(customer);
		List<LandDetailsDto> listOfLandDetails = new ArrayList<>();
		LandDetailsDto detailsDto = null;
		if (null != landDetails) {
			for (MeAndMyLand m : landDetails) {
				detailsDto = new LandDetailsDto();
				detailsDto.setLandArea(m.getLandArea());
				detailsDto.setLandId(m.getLandId());
				detailsDto.setLandLocation(m.getLandLocation());
				detailsDto.setLandOwnership(m.getLandOwnership());
				detailsDto.setLandUnit(m.getLandUnit());
				listOfLandDetails.add(detailsDto);
			}
			if (null != listOfLandDetails && listOfLandDetails.size() > 0
					&& listOfLandDetails.get(0).getLandId() != 0) {
				customerAndLandDetails.setLandDetails(listOfLandDetails);
			}
		}
		return customerAndLandDetails;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public CustomerAndLandDetails updateCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey) {
		try {
			CustomerDto customer = customerLandDetails.getCustomer();
			Customer customerBo = transformCustomerToBo(customer);
			customerBo = homeDao.saveCustomer(customerBo);
			List<MeAndMyLand> landDetails = null;
			if (null != customerLandDetails.getLandDetails()) {
				landDetails = transformLandDetailsBo(customerLandDetails.getLandDetails(),
						customerLandDetails.getCustomer().getCustomerId());
				landDetails = homeDao.updateLandDetails(landDetails);
			}
			customerLandDetails = transformLandDetailsBo(customerBo, landDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customerLandDetails;
	}

	private CustomerAndLandDetails transformLandDetailsBo(Customer customerBo, List<MeAndMyLand> landDetails) {
		CustomerAndLandDetails customerAndLandDetails = new CustomerAndLandDetails();
		CustomerDto customer = new CustomerDto();
		AddressDto address = new AddressDto();
		address.setAddressId(customerBo.getAddress().getAddressId());
		address.setAddressLine1(customerBo.getAddress().getAddressLine1());
		address.setAddressLine2(customerBo.getAddress().getAddressLine2());
		address.setAddressLine3(customerBo.getAddress().getAddressLine3());
		address.setBlock(customerBo.getAddress().getBlock());
		address.setCity(customerBo.getAddress().getCity());
		address.setCountry(customerBo.getAddress().getCountry());
		address.setDistrict(customerBo.getAddress().getDistrict());
		address.setPostalCode(customerBo.getAddress().getPostalCode());
		address.setState(customerBo.getAddress().getState());
		customer.setAddress(address);
		customer.setCustAadharNumber(customerBo.getAadharNumber());
		customer.setCustFirstName(customerBo.getFirstName());
		customer.setCustLastName(customerBo.getLastName());
		customer.setCustMiddleName(customerBo.getMiddleName());
		customer.setCustomerId(customerBo.getCustomerId());
		customer.setCustomerType(customerBo.getCustomerType().getTypeCode());
		customer.setCustPhoneNumber(customerBo.getPhoneNumber());
		customer.setUserId(customerBo.getUser().getUserId());
		customerAndLandDetails.setCustomer(customer);
		List<LandDetailsDto> listOfLandDetails = new ArrayList<>();
		LandDetailsDto detailsDto = null;
		if (null != landDetails) {
			for (MeAndMyLand m : landDetails) {
				detailsDto = new LandDetailsDto();
				detailsDto.setLandArea(m.getLandArea());
				detailsDto.setLandId(m.getLandId());
				detailsDto.setLandLocation(m.getLandLocation());
				detailsDto.setLandOwnership(m.getLandOwnership());
				detailsDto.setLandUnit(m.getLandUnit());
				listOfLandDetails.add(detailsDto);
			}
			customerAndLandDetails.setLandDetails(listOfLandDetails);
		}
		return customerAndLandDetails;
	}

	private List<MeAndMyLand> transformLandDetailsBo(List<LandDetailsDto> landDetails, int customerId)
			throws ParseException {
		List<MeAndMyLand> listOfLandDetail = new ArrayList<>();
		MeAndMyLand land = null;
		Customer customer = homeDao.getCustomer(customerId);
		for (LandDetailsDto l : landDetails) {
			land = new MeAndMyLand();
			land.setUpdatedBy(GatewayConstants.SYSTEM_TAG);
			land.setUpdatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			land.setCustomer(customer);
			land.setLandArea(l.getLandArea());
			if (0 != l.getLandId()) {
				land.setLandId(l.getLandId());
			}
			land.setLandLocation(l.getLandLocation());
			land.setLandOwnership(l.getLandOwnership());
			land.setLandUnit(l.getLandUnit());
			listOfLandDetail.add(land);
		}
		return listOfLandDetail;
	}

	private Customer transformCustomerToBo(CustomerDto editedCustomer) throws ParseException {
		Customer customer = homeDao.getCustomer(editedCustomer.getCustomerId());
		AddressDto editedAddress = editedCustomer.getAddress();
		if (null != editedAddress) {
			Address address = homeDao.getCustomerAddress(editedAddress.getAddressId());
			address.setAddressLine1(editedAddress.getAddressLine1());
			address.setAddressLine2(editedAddress.getAddressLine2());
			address.setAddressLine3(editedAddress.getAddressLine3());
			address.setBlock(editedAddress.getBlock());
			address.setCity(editedAddress.getCity());
			address.setCountry(editedAddress.getCountry());
			address.setCreatedBy(GatewayConstants.SYSTEM_TAG);
			address.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			address.setDistrict(editedAddress.getDistrict());
			address.setPostalCode(editedAddress.getPostalCode());
			address.setState(editedAddress.getState());
			customer.setAddress(address);
		}

		customer.setPhoneNumber(editedCustomer.getCustPhoneNumber());
		customer.setAadharNumber(editedCustomer.getCustAadharNumber());
		customer.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		customer.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		customer.setCustomerId(editedCustomer.getCustomerId());
		CustomerType customerType = homeDao.fetchCustomerType(editedCustomer.getCustomerType());
		customer.setCustomerType(customerType);
		customer.setFirstName(editedCustomer.getCustFirstName());
		customer.setLastName(editedCustomer.getCustLastName());
		customer.setMiddleName(editedCustomer.getCustMiddleName());
		customer.setPhoneNumber(editedCustomer.getCustPhoneNumber());
		User user = homeDao.getUser(editedCustomer.getUserId());
		customer.setUser(user);

		return customer;
	}
}
package ekutir.sanimark.service;

import java.util.List;

import ekutir.sanimark.dto.CustomerAndLandDetails;
import ekutir.sanimark.dto.CustomerDto;
import ekutir.sanimark.dto.CustomerListDto;
import ekutir.sanimark.dto.CustomerTypes;
import ekutir.sanimark.dto.UserDto;

public interface HomeService {
	/*public List<AdvertisementDto> fetchAdvertisements(String appId, String masterKey);

	public List<BusinessTipsDto> fetchBusinessTips(String appId, String masterKey);

	public List<SalesAndOffersDto> fetchSalesAndOffers(String appId, String masterKey);*/

	public boolean isMasterKeyExists(String masterKey);

	public boolean isAppCodeExists(String appCode);

	public boolean isAuthKeyExists(String authKey);

	public CustomerListDto fetchCustomers(int userId, int page);

	public CustomerDto saveCustomer(CustomerDto customer);

	public UserDto saveUser(UserDto user);

	public boolean isAppRequestAuthorized(String masterKey, String appCode);

	public CustomerTypes fetchCustomerTypes(String appCode);

	public CustomerAndLandDetails fetchCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey);

	public CustomerAndLandDetails updateCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey);
}

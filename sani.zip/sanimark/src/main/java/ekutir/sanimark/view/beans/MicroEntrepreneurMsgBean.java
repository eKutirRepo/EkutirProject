package ekutir.sanimark.view.beans;

public class MicroEntrepreneurMsgBean {
	
	private int messageId;
	private String messagedescription;
	
	public MicroEntrepreneurMsgBean() {
		super();
	}
	
	public MicroEntrepreneurMsgBean(int messageId, String messagedescription) {
		super();
		this.messageId = messageId;
		this.messagedescription = messagedescription;
	}
	
	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public String getMessagedescription() {
		return messagedescription;
	}
	public void setMessagedescription(String messagedescription) {
		this.messagedescription = messagedescription;
	}
	
}

package ekutir.sanimark.view.beans;

public class AckSms2Supplier {
	
		private String status;
		private String details;
		
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getDetails() {
			return details;
		}
		public void setDetails(String details) {
			this.details = details;
		}

}

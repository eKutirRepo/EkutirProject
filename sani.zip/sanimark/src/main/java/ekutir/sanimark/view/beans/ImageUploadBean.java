package ekutir.sanimark.view.beans;

public class ImageUploadBean {
	
	private byte[] responseImage;

	public ImageUploadBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ImageUploadBean(byte[] responseImage) {
		super();
		this.responseImage = responseImage;
	}

	public byte[] getResponseImage() {
		return responseImage;
	}

	public void setResponseImage(byte[] responseImage) {
		this.responseImage = responseImage;
	}

}

package ekutir.sanimark.view.beans;

public class CommDetailsBean {
	private int leadId;
	private String communicationDate;
	private String commMode;
	private int commCost;
	private int commDispositionId;
	private String communicationDetails;
	public CommDetailsBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CommDetailsBean(int leadId, String communicationDate, String commMode, int commCost, int commDispositionId,
			String communicationDetails) {
		super();
		this.leadId = leadId;
		this.communicationDate = communicationDate;
		this.commMode = commMode;
		this.commCost = commCost;
		this.commDispositionId = commDispositionId;
		this.communicationDetails = communicationDetails;
	}
	public int getLeadId() {
		return leadId;
	}
	public void setLeadId(int leadId) {
		this.leadId = leadId;
	}
	public String getCommunicationDate() {
		return communicationDate;
	}
	public void setCommunicationDate(String communicationDate) {
		this.communicationDate = communicationDate;
	}
	public String getCommMode() {
		return commMode;
	}
	public void setCommMode(String commMode) {
		this.commMode = commMode;
	}
	public int getCommCost() {
		return commCost;
	}
	public void setCommCost(int commCost) {
		this.commCost = commCost;
	}
	public int getCommDispositionId() {
		return commDispositionId;
	}
	public void setCommDispositionId(int commDispositionId) {
		this.commDispositionId = commDispositionId;
	}
	public String getCommunicationDetails() {
		return communicationDetails;
	}
	public void setCommunicationDetails(String communicationDetails) {
		this.communicationDetails = communicationDetails;
	}
	
}

package ekutir.sanimark.view.beans;

public class EditItemBean {
	
	private int itemId;
	private int categoryId;
	private String itemName;
	private String brandName;
	private String warranty;
	private String manufactureDate;
	private String expiryDate;
	private double mrp;
	private double sellingPrice;
	private String itemDescription;
	private String dimension;
	private byte[] productImg;
	private String color;
	
	public EditItemBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public EditItemBean(int itemId, int categoryId, String itemName, String brandName, String warranty,
			String manufactureDate, String expiryDate, double mrp, double sellingPrice, String itemDescription,
			String dimension, byte[] productImg, String color) {
		super();
		this.itemId = itemId;
		this.categoryId = categoryId;
		this.itemName = itemName;
		this.brandName = brandName;
		this.warranty = warranty;
		this.manufactureDate = manufactureDate;
		this.expiryDate = expiryDate;
		this.mrp = mrp;
		this.sellingPrice = sellingPrice;
		this.itemDescription = itemDescription;
		this.dimension = dimension;
		this.productImg = productImg;
		this.color = color;
	}

	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	public String getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(String manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public double getMrp() {
		return mrp;
	}
	public void setMrp(double mrp) {
		this.mrp = mrp;
	}
	public double getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	public byte[] getProductImg() {
		return productImg;
	}
	public void setProductImg(byte[] productImg) {
		this.productImg = productImg;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
}

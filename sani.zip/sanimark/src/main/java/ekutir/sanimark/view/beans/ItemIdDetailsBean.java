package ekutir.sanimark.view.beans;

public class ItemIdDetailsBean {
	
	private int itemId;
	private int productId;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}
	
}

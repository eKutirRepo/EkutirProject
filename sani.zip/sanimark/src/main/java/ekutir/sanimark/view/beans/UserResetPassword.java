package ekutir.sanimark.view.beans;

public class UserResetPassword {
	
	private String loginId;
	private String currentPassword;
	private String newPassword;
	
	public UserResetPassword() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserResetPassword(String currentPassword, String newPassword, String loginId) {
		super();
		this.loginId = loginId;
		this.currentPassword = currentPassword;
		this.newPassword = newPassword;
	}
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getCurrentPassword() {
		return currentPassword;
	}
	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
}

package ekutir.sanimark.view.beans;

public class FetchProductsForSani {
	
	private int productId;
	private String productName;
	private int prodCategoryId;
	private String prodCategoryName;
	private String productDescription;
	private int status;
	private String productImage;
	
	public FetchProductsForSani() {
		super();
	}
	public FetchProductsForSani(int productId, String productName, int prodCategoryId, String prodCategoryName,
			String productDescription, int status, String productImage) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.prodCategoryId = prodCategoryId;
		this.prodCategoryName = prodCategoryName;
		this.productDescription = productDescription;
		this.status = status;
		this.productImage = productImage;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProdCategoryId() {
		return prodCategoryId;
	}
	public void setProdCategoryId(int prodCategoryId) {
		this.prodCategoryId = prodCategoryId;
	}
	public String getProdCategoryName() {
		return prodCategoryName;
	}
	public void setProdCategoryName(String prodCategoryName) {
		this.prodCategoryName = prodCategoryName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	
}

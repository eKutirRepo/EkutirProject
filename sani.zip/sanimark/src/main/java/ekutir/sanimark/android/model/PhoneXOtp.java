package ekutir.sanimark.android.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ekutir_gateway.gtwy_phn_x_otp")
public class PhoneXOtp {

	@Id
	@Column(name = "phone_number")
	private long phoneNumber;

	@Column(name = "otp")
	private int otp;

	@Column(name = "session")
	private String session;

	@Column(name = "created_date_time")
	private Date createdDateTime;

	@Column(name = "temp_auth_key")
	private String tempAuthKey;

	@Column(name = "status")
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public String getTempAuthKey() {
		return tempAuthKey;
	}

	public void setTempAuthKey(String tempAuthKey) {
		this.tempAuthKey = tempAuthKey;
	}

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	@Override
	public String toString() {
		return "Phone Number: '" + this.phoneNumber + "', OTP: '" + this.otp + "'";
	}
}

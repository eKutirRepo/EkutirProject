package ekutir.sanimark.android.dto;

public class TokenBean {
	
	private int tokenId;
	private String token;
	private String token_expiryDate;
	
	public TokenBean() {
		super();
	}

	public TokenBean(int tokenId, String token, String token_expiryDate) {
		super();
		this.tokenId = tokenId;
		this.token = token;
		this.token_expiryDate = token_expiryDate;
	}

	public int getTokenId() {
		return tokenId;
	}

	public void setTokenId(int tokenId) {
		this.tokenId = tokenId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getToken_expiryDate() {
		return token_expiryDate;
	}

	public void setToken_expiryDate(String token_expiryDate) {
		this.token_expiryDate = token_expiryDate;
	}
	
}

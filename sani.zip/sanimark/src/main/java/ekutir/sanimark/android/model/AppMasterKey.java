package ekutir.sanimark.android.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AppMasterKey implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "user_id")
	private Integer userId;

	@Column(name = "app_id")
	private Integer appId;

	public AppMasterKey() {
	}

	public AppMasterKey(Integer userId, Integer appId) {
		this.appId = appId;
		this.userId = userId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof AppMasterKey))
			return false;
		AppMasterKey that = (AppMasterKey) o;
		return Objects.equals(getUserId(), that.getUserId()) && Objects.equals(getAppId(), that.getAppId());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getUserId(), getAppId());
	}

}

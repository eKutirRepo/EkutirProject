package ekutir.sanimark.android.dto;

public class DateWiseSearchBean {
	private String createdFromDate;
	private String createdToDate;
	private String myOrders;
	public DateWiseSearchBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public DateWiseSearchBean(String createdFromDate, String createdToDate, String myOrders) {
		super();
		this.createdFromDate = createdFromDate;
		this.createdToDate = createdToDate;
		this.myOrders = myOrders;
	}

	public String getMyOrders() {
		return myOrders;
	}

	public void setMyOrders(String myOrders) {
		this.myOrders = myOrders;
	}

	public String getCreatedFromDate() {
		return createdFromDate;
	}
	public void setCreatedFromDate(String createdFromDate) {
		this.createdFromDate = createdFromDate;
	}
	public String getCreatedToDate() {
		return createdToDate;
	}
	public void setCreatedToDate(String createdToDate) {
		this.createdToDate = createdToDate;
	}
	
}

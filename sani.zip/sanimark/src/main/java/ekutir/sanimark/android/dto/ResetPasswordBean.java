package ekutir.sanimark.android.dto;

public class ResetPasswordBean {
	
	private String loginId;
	private String password;
	private String role;
	private String token;
	
	public ResetPasswordBean() {
		super();
	}

	public ResetPasswordBean(String loginId, String password,String role,String token) {
		super();
		this.loginId = loginId;
		this.password = password;
		this.role = role;
		this.token = token;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
}

package ekutir.sanimark.android.dto;

public class ServicesDataBean {
	
	private int serviceId;
	private String serviceBrandName;
	private String contactDetails;
	private String serviceDescription;
	private String whenToUse;
	private String howToUse;
	private String consumerBenifit;
	private int servCategoryId;
	
	public ServicesDataBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServicesDataBean(int serviceId, String serviceBrandName, String contactDetails,
			String serviceDescription, String whenToUse, String howToUse, String consumerBenifit, int servCategoryId) {
		super();
		this.serviceId = serviceId;
		this.serviceBrandName = serviceBrandName;
		//this.servCategoryId = servCategoryId;
		this.contactDetails = contactDetails;
		this.serviceDescription = serviceDescription;
		this.whenToUse = whenToUse;
		this.howToUse = howToUse;
		this.consumerBenifit = consumerBenifit;
		this.servCategoryId = servCategoryId;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceBrandName() {
		return serviceBrandName;
	}

	public void setServiceBrandName(String serviceBrandName) {
		this.serviceBrandName = serviceBrandName;
	}

	/*public int getServCategoryId() {
		return servCategoryId;
	}

	public void setServCategoryId(int servCategoryId) {
		this.servCategoryId = servCategoryId;
	}
*/
	public String getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(String contactDetails) {
		this.contactDetails = contactDetails;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public String getWhenToUse() {
		return whenToUse;
	}

	public void setWhenToUse(String whenToUse) {
		this.whenToUse = whenToUse;
	}

	public String getHowToUse() {
		return howToUse;
	}

	public void setHowToUse(String howToUse) {
		this.howToUse = howToUse;
	}

	public String getConsumerBenifit() {
		return consumerBenifit;
	}

	public void setConsumerBenifit(String consumerBenifit) {
		this.consumerBenifit = consumerBenifit;
	}

	public int getServCategoryId() {
		return servCategoryId;
	}

	public void setServCategoryId(int servCategoryId) {
		this.servCategoryId = servCategoryId;
	}
	
}

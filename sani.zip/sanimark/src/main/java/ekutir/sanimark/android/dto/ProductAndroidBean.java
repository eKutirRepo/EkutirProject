package ekutir.sanimark.android.dto;

public class ProductAndroidBean {
	private int productId;
	private String productBrandName;
	private String companyName;
	private int prodCategoryId;
	private String warranty;
	private String dateOfManufacture;
	private String expiryDate;
	private String productFeatures;
	//private byte[] productImg;
	private String productImg;
	private double mrp;
	private int discountInPercent;
	private double sellingPrice;
	public ProductAndroidBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductAndroidBean(int productId, String productBrandName, String companyName, int prodCategoryId,
			String warranty, String dateOfManufacture, String expiryDate, String productFeatures, String productImg,
			double mrp, int discountInPercent, double sellingPrice) {
		super();
		this.productId = productId;
		this.productBrandName = productBrandName;
		this.companyName = companyName;
		this.prodCategoryId = prodCategoryId;
		this.warranty = warranty;
		this.dateOfManufacture = dateOfManufacture;
		this.expiryDate = expiryDate;
		this.productFeatures = productFeatures;
		this.productImg = productImg;
		this.mrp = mrp;
		this.discountInPercent = discountInPercent;
		this.sellingPrice = sellingPrice;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductBrandName() {
		return productBrandName;
	}
	public void setProductBrandName(String productBrandName) {
		this.productBrandName = productBrandName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public int getProdCategoryId() {
		return prodCategoryId;
	}
	public void setProdCategoryId(int prodCategoryId) {
		this.prodCategoryId = prodCategoryId;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	public String getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(String dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getProductFeatures() {
		return productFeatures;
	}
	public void setProductFeatures(String productFeatures) {
		this.productFeatures = productFeatures;
	}
	public String getProductImg() {
		return productImg;
	}
	public void setProductImg(String productImg) {
		this.productImg = productImg;
	}
	public double getMrp() {
		return mrp;
	}
	public void setMrp(double mrp) {
		this.mrp = mrp;
	}
	public int getDiscountInPercent() {
		return discountInPercent;
	}
	public void setDiscountInPercent(int discountInPercent) {
		this.discountInPercent = discountInPercent;
	}
	public double getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

}

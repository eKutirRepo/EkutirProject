package ekutir.sanimark.android.dto;

public class SupplierDataViewBean {
	
	private int supplierId;
	private String loginId;
	private String businessName;
	private String primaryContactName;
	private String primaryContactNumber;
	private String secondaryContactName;
	private String secondaryContactNumber;
	private String businessDescription;
	private int status;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String block;
	private String city;
	private String district;
	private String state;
	private String country;
	private int pincode;
	
	public SupplierDataViewBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SupplierDataViewBean(int supplierId, String loginId, String businessName, String primaryContactName,
			String primaryContactNumber, String secondaryContactName, String secondaryContactNumber,
			String businessDescription, int status, String addressLine1, String addressLine2, String addressLine3,
			String block, String city, String district, String state, String country, int pincode) {
		super();
		this.supplierId = supplierId;
		this.loginId = loginId;
		this.businessName = businessName;
		this.primaryContactName = primaryContactName;
		this.primaryContactNumber = primaryContactNumber;
		this.secondaryContactName = secondaryContactName;
		this.secondaryContactNumber = secondaryContactNumber;
		this.businessDescription = businessDescription;
		this.status = status;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.block = block;
		this.city = city;
		this.district = district;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
	}

	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getPrimaryContactName() {
		return primaryContactName;
	}

	public void setPrimaryContactName(String primaryContactName) {
		this.primaryContactName = primaryContactName;
	}

	public String getPrimaryContactNumber() {
		return primaryContactNumber;
	}

	public void setPrimaryContactNumber(String primaryContactNumber) {
		this.primaryContactNumber = primaryContactNumber;
	}

	public String getSecondaryContactName() {
		return secondaryContactName;
	}

	public void setSecondaryContactName(String secondaryContactName) {
		this.secondaryContactName = secondaryContactName;
	}

	public String getSecondaryContactNumber() {
		return secondaryContactNumber;
	}

	public void setSecondaryContactNumber(String secondaryContactNumber) {
		this.secondaryContactNumber = secondaryContactNumber;
	}

	public String getBusinessDescription() {
		return businessDescription;
	}

	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
}

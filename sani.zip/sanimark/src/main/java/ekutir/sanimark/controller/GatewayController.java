package ekutir.sanimark.controller;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.ServletContext;

//import javax.servlet.ServletContext;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ekutir.sanimark.android.dto.DataManipulationBean;
import ekutir.sanimark.android.view.ResetPassword;
import ekutir.sanimark.constant.GatewayConstants;
import ekutir.sanimark.dto.Communication;
import ekutir.sanimark.dto.CustomerAndLandDetails;
import ekutir.sanimark.dto.CustomerDto;
import ekutir.sanimark.dto.RegistrationDto;
import ekutir.sanimark.dto.RegistrationInProcessUserDto;
import ekutir.sanimark.dto.RequestValidationDto;
import ekutir.sanimark.dto.StatusDto;
import ekutir.sanimark.dto.UserDto;
import ekutir.sanimark.service.HomeService;
import ekutir.sanimark.service.RegistrationService;
import ekutir.sanimark.utilities.CommonException;
import ekutir.sanimark.utilities.GatewayUtilties;

@Controller
public class GatewayController {
	private ObjectMapper mapper = null;

	@Autowired
	RegistrationService registrationService;

	@Autowired
	HomeService homeService;

	@Autowired
	ServletContext servletContext;
	
	@Autowired
	MessageSource messageSource;
	
	private Locale locale;

	//private static final Logger LOGGER = Logger.getLogger(GatewayController.class);
	
	private DataManipulationBean datamanipulation = null;

	@RequestMapping(value = { "/register/initiate" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> initiateRegistration(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communication) {
		RegistrationDto registrationDto = new RegistrationDto();
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		boolean isSystemError = false;
		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		long phonenumber = communication.getPhoneNumber();
		RegistrationInProcessUserDto registrationInProcessUserDetails = registrationService.initiateUserRegistration(
				phonenumber	, tempAuthKey, communication.getApplicationCode());
		UserDto userDto = new UserDto();
		if (null != registrationInProcessUserDetails) {
			headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
			isRequestProcessingSucessfull = true;
			status = registrationInProcessUserDetails.getStatus();
			userDto.setTypeOfUser(registrationInProcessUserDetails.getTypeOfUser());
			registrationDto.setUser(userDto);
		} else {
			isSystemError = true;
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationDto.setStatus(status);
		RequestValidationDto validationDto = new RequestValidationDto();
		registrationDto.setRequestValidation(validationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		} else {
			if (isSystemError) {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				//LOGGER.debug("Bad request");
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
			}
		}
	}

	@RequestMapping(value = { "/register/verifypasscode" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> verifyPasscode(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communication) {
		RegistrationDto registrationDto = new RegistrationDto();
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		boolean isSystemError = false;
		RegistrationInProcessUserDto registrationInProcessUserDetails = registrationService
				.verifyPasscodeForExistingUser(communication.getPassword(), communication.getPhoneNumber(), tempAuthKey,
						communication.getApplicationCode());
		if (null != registrationInProcessUserDetails) {
			headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
			isRequestProcessingSucessfull = true;
			status = registrationInProcessUserDetails.getStatus();
		} else {
			isSystemError = true;
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationDto.setStatus(status);
		RequestValidationDto validationDto = new RequestValidationDto();
		registrationDto.setRequestValidation(validationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		} else {
			if (isSystemError) {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
			}
		}
	}

	@RequestMapping(value = { "/register/verifyotp" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> verifyOtp(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communicationDto) {
		RegistrationDto registrationDto = new RegistrationDto();
		RequestValidationDto validationDto = GatewayUtilties.validateRequestForOtp(communicationDto);
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		boolean isSystemError = false;
		if ((validationDto != null) && (validationDto.isSuccesfullyValidated())) {
			StatusDto otpVerificationStatus = registrationService.verifyOtp(communicationDto, tempAuthKey);
			if (null != otpVerificationStatus) {
				if (null != otpVerificationStatus.getStatusCode()) {
					if (otpVerificationStatus.getStatusCode()
							.equalsIgnoreCase(GatewayConstants.OTP_VERIFICATION_COMPLETED_STATUS_CODE)) {
						isRequestProcessingSucessfull = true;
						headers.add(GatewayConstants.MASTER_KEY_TAG,
								GatewayUtilties.getMasterKey(communicationDto.getApplicationCode()));
					} else {
						isRequestProcessingSucessfull = false;
					}
				} else {
					isRequestProcessingSucessfull = false;
					isSystemError = true;
				}
				communicationDto.setStatus(GatewayConstants.VERIFIED_STATUS_TAG);
				status = otpVerificationStatus;
			} else {
				isSystemError = true;
				status.setStatusCode(GatewayConstants.OTP_VERIFICATION_FAILED_STATUS_CODE);
				status.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_OTP_VERIFICATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
				headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
			}
		} else {
			status.setStatusCode(GatewayConstants.OTP_VERIFICATION_FAILED_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.REGISTERATION_RESPONSE_OTP_VERIFICATION_FAILED_STAUTS_MESSAGE);
		}
		registrationDto.setStatus(status);
		registrationDto.setRequestValidation(validationDto);
		registrationDto.setCommunication(communicationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		} else {
			if (isSystemError) {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
			}
		}
	}

	@RequestMapping(value = { "/register/user" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationInProcessUserDto> register(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody RegistrationDto registrationDto) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		RequestValidationDto validation = null;
		validation = GatewayUtilties.validateRequestForMicroEntrepreneur(registrationDto);
		RegistrationInProcessUserDto registrationInProcessUserDetails = new RegistrationInProcessUserDto();
		if ((validation != null) && (validation.isSuccesfullyValidated())) {
			registrationInProcessUserDetails = registrationService.registerUser(registrationDto, tempAuthKey);
			if (null != registrationInProcessUserDetails) {
				if (registrationInProcessUserDetails.getStatus().getStatusCode()
						.equalsIgnoreCase(GatewayConstants.REGISTRATION_PROCESS_COMPLETED_STATUS_CODE)) {
					headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
					headers.add(GatewayConstants.MASTER_KEY_TAG, registrationInProcessUserDetails.getMasterKey());
					return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
							HttpStatus.OK);
				} else {
					headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
				}
				status = registrationInProcessUserDetails.getStatus();
			} else {
				status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
				status.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
				headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
			}
		} else {
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationInProcessUserDetails.setStatus(status);
		registrationInProcessUserDetails.setValidation(validation);
		return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
				HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/register/user/update" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationInProcessUserDto> register(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communication) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		RequestValidationDto validation = null;
		RegistrationInProcessUserDto registrationInProcessUserDetails = new RegistrationInProcessUserDto();
		if (null != communication.getTypeOfUser() && !communication.getTypeOfUser().isEmpty()) {
			validation = GatewayUtilties.checkRequestForReturningAndBusinessDelegateUser(communication);
		} else {
			status.setStatusCode(GatewayConstants.TYPE_OF_USER_MISSING_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.TYPE_OF_USER_MISSING_STATUS_MESSAGE);
			registrationInProcessUserDetails.setStatus(status);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
			return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
					HttpStatus.BAD_REQUEST);
		}
		boolean isRequestProcessingSucessfull = false;
		if ((validation != null) && (validation.isSuccesfullyValidated())) {
			registrationInProcessUserDetails = registrationService.registerReturningOrBusinessUser(communication,
					tempAuthKey);
			if (null != registrationInProcessUserDetails) {
				if (registrationInProcessUserDetails.getStatus().getStatusCode()
						.equalsIgnoreCase(GatewayConstants.REGISTRATION_PROCESS_COMPLETED_STATUS_CODE)) {
					headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
					headers.add(GatewayConstants.MASTER_KEY_TAG, registrationInProcessUserDetails.getMasterKey());
					isRequestProcessingSucessfull = true;
				} else {
					headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
				}
				status = registrationInProcessUserDetails.getStatus();
			} else {
				status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
				status.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
				headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
			}
		} else {
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationInProcessUserDetails.setStatus(status);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
					HttpStatus.OK);
		} else {
			return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
					HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = { "/register/customer" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> registerCustomerForMe(@RequestHeader("auth_key") String authkey,
			@RequestBody CustomerDto customer) {
		RegistrationDto registrationDto = new RegistrationDto();
		RequestValidationDto validationDto = GatewayUtilties.validateRequestForCustomer(customer);
		RequestValidationDto verifyCustomerPhoneNumber = registrationService.verifyCustomerPhoneNumberAndAadhaarNumber(
				customer.getUserId(), customer.getCustPhoneNumber(), customer.getCustAadharNumber(),
				"REGISTER_CUSTOMER");
		validationDto.setSuccesfullyValidated(verifyCustomerPhoneNumber.isSuccesfullyValidated());
		if (!verifyCustomerPhoneNumber.isSuccesfullyValidated()) {
			validationDto.getListOfValidationMessagesWithCodes()
					.addAll(verifyCustomerPhoneNumber.getListOfValidationMessagesWithCodes());
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authkey);
		StatusDto statusDto = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		if ((validationDto != null) && (validationDto.isSuccesfullyValidated())) {
			if (registrationService.isCustomerExists(customer, authkey)) {
				statusDto.setStatusCode(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_CUSTOMER_ALREADY_REGISTERED_FOR_USER_STATUS_CODE);
				statusDto.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_CUSTOMER_ALREADY_REGISTERED_FOR_USER_STATUS_MESSAGE);
				isRequestProcessingSucessfull = false;
			} else {
				registrationService.insertCustomerDetails(customer, authkey);
				statusDto.setStatusCode(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_CODE);
				statusDto.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_MESSAGE);
				isRequestProcessingSucessfull = true;
			}
		} else {
			statusDto.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			statusDto.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
		}
		registrationDto.setStatus(statusDto);
		registrationDto.setRequestValidation(validationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		}
		return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/customer/meandmyland/create" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<CustomerAndLandDetails> insertLandDetailsForCustomer(
			@RequestHeader("auth_key") String authkey, @RequestBody CustomerAndLandDetails customerLandDetails) {
		RequestValidationDto validationDto = GatewayUtilties.validateRequestForMeAndMyLand(customerLandDetails,
				GatewayConstants.CREATE_CUSTOMER_AND_LAND_DETAILS);
		RequestValidationDto verifyCustomerPhoneNumber = registrationService.verifyCustomerPhoneNumberAndAadhaarNumber(
				customerLandDetails.getCustomer().getUserId(), customerLandDetails.getCustomer().getCustPhoneNumber(),
				customerLandDetails.getCustomer().getCustAadharNumber(), "CREATE_LAND_DETAILS");
		validationDto.setSuccesfullyValidated(verifyCustomerPhoneNumber.isSuccesfullyValidated());
		if (!verifyCustomerPhoneNumber.isSuccesfullyValidated()) {
			validationDto.getListOfValidationMessagesWithCodes()
					.addAll(verifyCustomerPhoneNumber.getListOfValidationMessagesWithCodes());
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authkey);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		if ((validationDto != null) && (validationDto.isSuccesfullyValidated())) {
			customerLandDetails = registrationService.insertCustomerAndLandDetails(customerLandDetails, authkey);
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_MESSAGE);
			isRequestProcessingSucessfull = true;
		} else {
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			customerLandDetails.setStatus(status);
		}
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<CustomerAndLandDetails>(customerLandDetails, headers, HttpStatus.OK);
		}
		return new ResponseEntity<CustomerAndLandDetails>(customerLandDetails, headers, HttpStatus.BAD_REQUEST);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/resetAppUserPassword", method = RequestMethod.POST, consumes = { "application/json" })
	public ResponseEntity resetAppUserPassword(@RequestBody final String json, Locale locale)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			ResetPassword resetPassword = mapper.readValue(json, ResetPassword.class);
			int userId = registrationService.resetAppUserPassword(resetPassword);
			if (userId > 0) {
				datamanipulation.setMessage(messageSource.getMessage("valid.resetpwd", null, locale));
				datamanipulation.setId(userId);
			} /*else if (userId == 2) {
				throw new CommonException(messageSource.getMessage("incorrect.password", null, locale));
			}*/ else {
				datamanipulation.setMessage(messageSource.getMessage("valid.error", null, locale));
				datamanipulation.setId(0);
			}
			return new ResponseEntity(datamanipulation, HttpStatus.OK);
		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

}
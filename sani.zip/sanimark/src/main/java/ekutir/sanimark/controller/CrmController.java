package ekutir.sanimark.controller;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ekutir.sanimark.android.dto.DataManipulationBean;
import ekutir.sanimark.android.dto.ErrorResponseBean;
import ekutir.sanimark.android.dto.FetchPCategoryBean;
import ekutir.sanimark.dto.ErrorDto;
import ekutir.sanimark.dto.ProductCategoryDto;
import ekutir.sanimark.erp.dto.crm.AdvertisementsDto;
import ekutir.sanimark.erp.dto.crm.BizTipsDto;
import ekutir.sanimark.erp.dto.crm.CatalogItemDto;
import ekutir.sanimark.erp.dto.crm.FetchBusinessCategoryDto;
import ekutir.sanimark.erp.dto.crm.FetchClusterDetailsDto;
import ekutir.sanimark.erp.dto.crm.FetchCustomerDataBeanDto;
import ekutir.sanimark.erp.dto.crm.FetchDispositionsDto;
import ekutir.sanimark.erp.dto.crm.FetchItemDetailsDto;
import ekutir.sanimark.erp.dto.crm.FetchOrdersDto;
import ekutir.sanimark.erp.dto.crm.FetchPaymentModesDto;
import ekutir.sanimark.erp.dto.crm.LeadPlaceOrderDto;
import ekutir.sanimark.erp.dto.crm.OrderFollowUpDto;
import ekutir.sanimark.erp.dto.crm.ProductdetailDto;
import ekutir.sanimark.erp.dto.crm.SalesOfferdto;
import ekutir.sanimark.erp.view.beans.crm.AdvertisementsBean;
import ekutir.sanimark.erp.view.beans.crm.CatalogBean;
import ekutir.sanimark.erp.view.beans.crm.CustomerCommDetailBean;
import ekutir.sanimark.erp.view.beans.crm.CustomerPlaceOrderBean;
import ekutir.sanimark.erp.view.beans.crm.FetchBusinessCategoryBean;
import ekutir.sanimark.erp.view.beans.crm.FetchClusterDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchCustomerDataBean;
import ekutir.sanimark.erp.view.beans.crm.FetchDispositionsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchItemDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchOrdersBean;
import ekutir.sanimark.erp.view.beans.crm.FetchPaymentModesBean;
import ekutir.sanimark.erp.view.beans.crm.FetchPriceChangeDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.LeadPlaceOrderItemBean;
import ekutir.sanimark.erp.view.beans.crm.OrderDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.OrderFollowUpDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.ProductdetailBean;
import ekutir.sanimark.service.CrmService;
import ekutir.sanimark.utilities.CommonException;


@Controller
@RequestMapping("/")
@CrossOrigin(origins = "*", maxAge = 3600)
public class CrmController {

	@Autowired
	CrmService customerService;

	@Autowired
	MessageSource messageSource;
	@Autowired
	HttpSession httpSession;
	private List<FetchCustomerDataBean> fetchCustomerData = null;
	private List<FetchClusterDetailsBean> fetchClusterDetails = null;
	private List<FetchCustomerDataBean> searchCustomer = null;
	private List<FetchBusinessCategoryBean> fetchBusinessCategory = null;
	
	private List<FetchDispositionsBean> fetchDispositions = null;
	private List<FetchItemDetailsBean> fetchItemDetails = null;
	private List<CatalogBean> catalogItemDetails = null;
	private List<FetchPCategoryBean> productItemDetails = null;
	private List<FetchPaymentModesBean> fetchPaymentModes = null;
	private List<FetchOrdersBean> fetchOrders = null;
	private List<OrderDetailsBean> orderDetails = null;
	private DataManipulationBean datamanipulation = null;
	private FetchCustomerDataBean addCustomerData = null;
	private FetchCustomerDataBean editCustomer = null;
	private CustomerCommDetailBean saveCustomerComm = null;
	private CustomerPlaceOrderBean placeorderbean = null;
	private List<LeadPlaceOrderItemBean> placeorderitemBean = null;
	private OrderFollowUpDetailsBean saveOrderFollowUpData = null;
	private List<OrderFollowUpDetailsBean> orderFollowUpHistory = null;
	private List<FetchOrdersBean> fetchOrdersCustomer = null;
	private List<FetchOrdersBean> OrdersCustomerhistory = null;
	private List<FetchOrdersBean> fetchPartialOrders = null;
	private List<AdvertisementsBean> Advertisements = null;
	private List<AdvertisementsBean> biztips = null;
	private List<AdvertisementsBean> salesoffer = null;
	private FetchPriceChangeDetailsBean fetchPriceChangeDetails = null;
	private ObjectMapper mapper = null;
	private Locale locale;
	private static final Logger logger = Logger.getLogger(CrmController.class);

	@ExceptionHandler(CommonException.class)
	public ResponseEntity<ErrorDto> exceptionHandler(Exception ex) {
		ErrorResponseBean error = new ErrorResponseBean();
		error.setErrorCode(HttpStatus.PRECONDITION_FAILED.value());
		error.setMessage(ex.getMessage());
		ErrorDto errorDto = new ErrorDto();
		errorDto.setError(error);
		return new ResponseEntity<ErrorDto>(errorDto, HttpStatus.OK);
	}

	/*@RequestMapping(value = "/fetchCustomerData", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchCustomerDataBeanDto> fetchCustomerData() throws CommonException {
		fetchCustomerData = customerService.fetchCustomerData();
		if (fetchCustomerData == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		logger.info(fetchCustomerData);
		FetchCustomerDataBeanDto fetchCustomerDataBeanDto = new FetchCustomerDataBeanDto();
		fetchCustomerDataBeanDto.setCustomers(fetchCustomerData);
		return new ResponseEntity<FetchCustomerDataBeanDto>(fetchCustomerDataBeanDto, HttpStatus.OK);

	}

	@RequestMapping(value = "/fetchClusterDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchClusterDetailsDto> fetchClusterDetails() throws CommonException {
		fetchClusterDetails = customerService.fetchClusterDetails();
		if (fetchClusterDetails == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchClusterDetailsDto fetchClusterDetailsDto = new FetchClusterDetailsDto();
		fetchClusterDetailsDto.setClusters(fetchClusterDetails);
		return new ResponseEntity<FetchClusterDetailsDto>(fetchClusterDetailsDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchCustomer", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchCustomerDataBeanDto> searchCustomer(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			String CreatedFromDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedFromDate();
			String createdToDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedToDate();
			searchCustomer = customerService.searchCustomer(CreatedFromDate, createdToDate);

			if (searchCustomer == null) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			FetchCustomerDataBeanDto searchCustomerDto = new FetchCustomerDataBeanDto();
			searchCustomerDto.setCustomers(searchCustomer);
			return new ResponseEntity<FetchCustomerDataBeanDto>(searchCustomerDto, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/deleteCustomer", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DataManipulationBean> deleteCustomer(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {
			DataManipulationBean datamanipulation = new DataManipulationBean();
			mapper = new ObjectMapper();
			int customerId = mapper.readValue(json, FetchCustomerDataBean.class).getCustomerId();
			int deleteCid = customerService.deleteCustomer(customerId);

			if (customerId == 0) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			datamanipulation.setMessage(messageSource.getMessage("valid.delete", null, locale));
			datamanipulation.setId(deleteCid);
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/fetchBusinessCategory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchBusinessCategoryDto> fetchBusinessCategory() throws CommonException {
		fetchBusinessCategory = customerService.fetchBusinessCategory();
		if (fetchBusinessCategory == null) {

			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		FetchBusinessCategoryDto fetchBusinessCategoryDto = new FetchBusinessCategoryDto();
		fetchBusinessCategoryDto.setCategories(fetchBusinessCategory);
		return new ResponseEntity<FetchBusinessCategoryDto>(fetchBusinessCategoryDto, HttpStatus.OK);

	}

	@RequestMapping(value = "/fetchCustomerCommHistory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommHistoryDto> fetchCustomerCommHistory(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {

			mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			int customerId = mapper.readValue(json, FetchCustomerDataBean.class).getCustomerId();
			int prevId = mapper.readValue(json, FetchCustomerDataBean.class).getPrevLeadId();
			customerCommHistory = customerService.fetchCustomerCommHistory(customerId,prevId);

			if (customerCommHistory == null) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			CommHistoryDto customerCommHistoryDto = new CommHistoryDto();
			customerCommHistoryDto.setCommDetails(customerCommHistory);
			return new ResponseEntity<CommHistoryDto>(customerCommHistoryDto, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	// Fetch Data for Order Follow-Up History

	@RequestMapping(value = "/fetchOrderFollowUpHistory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OrderFollowUpDto> fetchOrderFollowUpHistory(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {

			mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			int orderId = mapper.readValue(json, OrderFollowUpDetailsBean.class).getOrderId();
			orderFollowUpHistory = customerService.fetchOrderFollowUpHistory(orderId);

			if (orderFollowUpHistory == null) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}

			OrderFollowUpDto orderFollowUpDto = new OrderFollowUpDto();
			orderFollowUpDto.setCommDetails(orderFollowUpHistory);
			return new ResponseEntity<OrderFollowUpDto>(orderFollowUpDto, HttpStatus.OK);

		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/fetchDispositions", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchDispositionsDto> fetchDispositions() throws CommonException {
		mapper = new ObjectMapper();
		fetchDispositions = customerService.fetchDispositions();

		if (fetchDispositions == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		FetchDispositionsDto fetchDispositionsDto = new FetchDispositionsDto();
		fetchDispositionsDto.setDispositions(fetchDispositions);
		return new ResponseEntity<FetchDispositionsDto>(fetchDispositionsDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchItemDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchItemDetailsDto> fetchItemDetails() throws CommonException {
		mapper = new ObjectMapper();
		fetchItemDetails = customerService.fetchItemDetails();

		if (fetchItemDetails == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		FetchItemDetailsDto fetchItemDetailsDto = new FetchItemDetailsDto();
		fetchItemDetailsDto.setItems(fetchItemDetails);
		return new ResponseEntity<FetchItemDetailsDto>(fetchItemDetailsDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchPaymentModes", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchPaymentModesDto> fetchPaymentModes() throws CommonException {
		mapper = new ObjectMapper();
		fetchPaymentModes = customerService.fetchPaymentModes();

		if (fetchPaymentModes == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		FetchPaymentModesDto fetchPaymentModesDto = new FetchPaymentModesDto();
		fetchPaymentModesDto.setPaymentModes(fetchPaymentModes);
		return new ResponseEntity<FetchPaymentModesDto>(fetchPaymentModesDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchOpenOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> fetchOrders() throws CommonException {
		mapper = new ObjectMapper();
		fetchOrders = customerService.fetchOrders();
		// orderDetails = customerService.orderDetails();

		if (fetchOrders == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchOrdersBean orderDetailsBean = new FetchOrdersBean();
		orderDetailsBean.setOrderDetails(orderDetails);
		FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
		fetchOrdersDto.setOrders(fetchOrders);
		// fetchOrdersDto.setOrderDetails(orderDetails);
		return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
	}
	
	Fetch Partial Orders
	
	@RequestMapping(value = "/fetchPartialDeliveryOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> fetchPartialDeliveryOrders() throws CommonException {
		mapper = new ObjectMapper();
		fetchPartialOrders = customerService.fetchPartialOrders();
		// orderDetails = customerService.orderDetails();

		if (fetchPartialOrders == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchOrdersBean orderDetailsBean = new FetchOrdersBean();
		orderDetailsBean.setOrderDetails(orderDetails);
		FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
		fetchOrdersDto.setOrders(fetchPartialOrders);
		// fetchOrdersDto.setOrderDetails(orderDetails);
		return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
	}

	// Fetch Orders Customer

	@RequestMapping(value = "/fetchOrdersCustomer", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> fetchOrdersCustomer(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		int customerId = mapper.readValue(json, FetchOrdersBean.class).getCustomerId();
		fetchOrdersCustomer = customerService.fetchCustomerOrderHistory(customerId);

		if (fetchOrdersCustomer == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
		fetchOrdersDto.setOrders(fetchOrdersCustomer);
		return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchClosedOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> closeOrders() throws CommonException {
		mapper = new ObjectMapper();
		fetchOrders = customerService.closeOrders();
		// orderDetails = customerService.orderDetails();

		if (fetchOrders == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchOrdersBean orderDetailsBean = new FetchOrdersBean();
		orderDetailsBean.setOrderDetails(orderDetails);
		FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
		fetchOrdersDto.setOrders(fetchOrders);
		// fetchOrdersDto.setOrderDetails(orderDetails);
		return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/fetchDroppedOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> dropOrders() throws CommonException {
		mapper = new ObjectMapper();
		fetchOrders = customerService.dropOrders();
		// orderDetails = customerService.orderDetails();

		if (fetchOrders == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchOrdersBean orderDetailsBean = new FetchOrdersBean();
		orderDetailsBean.setOrderDetails(orderDetails);
		FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
		fetchOrdersDto.setOrders(fetchOrders);
		// fetchOrdersDto.setOrderDetails(orderDetails);
		return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchOpenOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> searchOrders(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {

			mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			String CreatedFromDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedFromDate();
			String createdToDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedToDate();
			String myOrders = mapper.readValue(json, DateWiseSearchBean.class).getMyOrders();
			mapper = new ObjectMapper();
			fetchOrders = customerService.searchOrders(CreatedFromDate, createdToDate, myOrders);
			if (fetchOrders == null) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}
			FetchOrdersBean orderDetailsBean = new FetchOrdersBean();
			orderDetailsBean.setOrderDetails(orderDetails);
			FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
			fetchOrdersDto.setOrders(fetchOrders);
			// fetchOrdersDto.setOrderDetails(orderDetails);
			return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/searchClosedOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> searchClosedOrders(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {

			mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			String CreatedFromDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedFromDate();
			String createdToDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedToDate();
			String myOrders = mapper.readValue(json, DateWiseSearchBean.class).getMyOrders();
			mapper = new ObjectMapper();
			fetchOrders = customerService.searchClosedOrders(CreatedFromDate, createdToDate, myOrders);
			if (fetchOrders == null) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}
			FetchOrdersBean orderDetailsBean = new FetchOrdersBean();
			orderDetailsBean.setOrderDetails(orderDetails);
			FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
			fetchOrdersDto.setOrders(fetchOrders);
			// fetchOrdersDto.setOrderDetails(orderDetails);
			return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}
	
	@RequestMapping(value = "/searchPartialDeliveryOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> searchPartialDeliveryOrders(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {

			mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			String CreatedFromDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedFromDate();
			String createdToDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedToDate();
			String myOrders = mapper.readValue(json, DateWiseSearchBean.class).getMyOrders();
			mapper = new ObjectMapper();
			fetchOrders = customerService.searchPartialOrders(CreatedFromDate, createdToDate, myOrders);
			if (fetchOrders == null) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}
			FetchOrdersBean orderDetailsBean = new FetchOrdersBean();
			orderDetailsBean.setOrderDetails(orderDetails);
			FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
			fetchOrdersDto.setOrders(fetchOrders);
			// fetchOrdersDto.setOrderDetails(orderDetails);
			return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	@RequestMapping(value = "/searchDropedOrders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> searchDropedOrders(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {
		try {

			mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			String CreatedFromDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedFromDate();
			String createdToDate = mapper.readValue(json, DateWiseSearchBean.class).getCreatedToDate();
			String myOrders = mapper.readValue(json, DateWiseSearchBean.class).getMyOrders();
			mapper = new ObjectMapper();
			fetchOrders = customerService.searchDropedOrders(CreatedFromDate, createdToDate, myOrders);
			if (fetchOrders == null) {
				throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
			}
			FetchOrdersBean orderDetailsBean = new FetchOrdersBean();
			orderDetailsBean.setOrderDetails(orderDetails);
			FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
			fetchOrdersDto.setOrders(fetchOrders);
			// fetchOrdersDto.setOrderDetails(orderDetails);
			return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
		} catch (JsonProcessingException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}

	// add customer

	@RequestMapping(value = "/addCustomer", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> addCustomer(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			addCustomerData = mapper.readValue(json, FetchCustomerDataBean.class);
			int addCustomer = customerService.addCustomer(addCustomerData);
			if (addCustomer > 0) {
				datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
				datamanipulation.setId(addCustomer);
			} else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}
		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	@RequestMapping(value = "/editCustomer", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> editCustomer(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			editCustomer = mapper.readValue(json, FetchCustomerDataBean.class);
			int editCustomerData = customerService.editCustomer(editCustomer);
			datamanipulation.setMessage(messageSource.getMessage("valid.update", null, locale));
			datamanipulation.setId(editCustomerData);

		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	@RequestMapping(value = "/saveCommDetail", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> saveCustomerCommDetails(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			saveCustomerComm = mapper.readValue(json, CustomerCommDetailBean.class);
			int saveCustomerCommData = customerService.saveCustomerCommDetails(saveCustomerComm);
			if (saveCustomerCommData > 0) {
				datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
				datamanipulation.setId(saveCustomerCommData);
			} else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}
		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}*/

	@RequestMapping(value = "/placeOrder", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> placeOrders(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		    datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			placeorderbean = mapper.readValue(json, CustomerPlaceOrderBean.class);
			placeorderitemBean = (List<LeadPlaceOrderItemBean>) mapper.readValue(json, LeadPlaceOrderDto.class).getItemDetails();
			int placeOrderData = customerService.placeOrder(placeorderbean, placeorderitemBean);
			//datamanipulation.setMessage(messageSource.getMessage("valid.placed", null, locale));
			datamanipulation.setMessage("Order placed successfully.");
			datamanipulation.setId(placeOrderData);

		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	// Save Order Follow-Up Detail

	@RequestMapping(value = "/saveOrderFollowUpDetail", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<DataManipulationBean> saveOrderFollowUpDetail(@RequestBody final String json)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
		datamanipulation = new DataManipulationBean();
		try {
			mapper = new ObjectMapper();
			saveOrderFollowUpData = mapper.readValue(json, OrderFollowUpDetailsBean.class);
			int saveOrderFollowUpDetail = customerService.saveOrderFollowUpDetail(saveOrderFollowUpData);
			if (saveOrderFollowUpDetail > 0) {
				datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
				datamanipulation.setId(saveOrderFollowUpDetail);
			} else {
				throw new CommonException(messageSource.getMessage("error.msg", null, locale));
			}
		} catch (JsonParseException jpe) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (JsonMappingException jme) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		} catch (IOException io) {
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}

		return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchItemDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CatalogItemDto> searchItemDetails(@RequestBody final String json)
			throws CommonException, JsonParseException, IOException {
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		int itemid = mapper.readValue(json, CatalogBean.class).getCatalogId();
		catalogItemDetails = customerService.searchItemDetails(itemid);

		if (catalogItemDetails == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		CatalogItemDto catalogItemDetailsDto = new CatalogItemDto();
		catalogItemDetailsDto.setCatalog(catalogItemDetails);
		return new ResponseEntity<CatalogItemDto>(catalogItemDetailsDto, HttpStatus.OK);
	}
	
	
	//order history for customer for android
	@RequestMapping(value = "/ordersCustomerHistory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchOrdersDto> ordersCustomerHistory(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		int customerId = mapper.readValue(json, FetchOrdersBean.class).getCustomerId();
		int orderId = mapper.readValue(json, FetchOrdersBean.class).getOrderId();
		OrdersCustomerhistory = customerService.ordersCustomerHistory(customerId,orderId);

		if (OrdersCustomerhistory == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		FetchOrdersDto fetchOrdersDto = new FetchOrdersDto();
		fetchOrdersDto.setOrders(OrdersCustomerhistory);
		return new ResponseEntity<FetchOrdersDto>(fetchOrdersDto, HttpStatus.OK);
	}
	@RequestMapping(value = "/fetchcatalog", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CatalogItemDto> fetchcatalog(@RequestBody final String json)
			throws CommonException, JsonParseException, IOException {
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		int catalogid = mapper.readValue(json, CatalogBean.class).getCatalogId();
		catalogItemDetails = customerService.fetchcatalog(catalogid);

		if (catalogItemDetails == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		CatalogItemDto catalogItemDetailsDto = new CatalogItemDto();
		catalogItemDetailsDto.setCatalog(catalogItemDetails);
		return new ResponseEntity<CatalogItemDto>(catalogItemDetailsDto, HttpStatus.OK);
	}
	@RequestMapping(value = "/getAdvertisements", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AdvertisementsDto> getAdvertisements() throws CommonException, JsonParseException, IOException {
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		int masterkey = 0;//mapper.readValue(json, AdvertisementsBean.class).getMasterKey();
		Advertisements = customerService.getAdvertisements(masterkey);

		if (Advertisements == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		AdvertisementsDto advertisementsDto = new AdvertisementsDto();
		advertisementsDto.setAdvertisement(Advertisements);
		return new ResponseEntity<AdvertisementsDto>(advertisementsDto, HttpStatus.OK);
	}	
	
	
	@RequestMapping(value = "/getbiztips", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BizTipsDto> getbiztips() throws CommonException, JsonParseException, IOException {
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		int masterkey = 0;//mapper.readValue(json, AdvertisementsBean.class).getMasterKey();
		biztips = customerService.getbiztips(masterkey);

		if (biztips == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		BizTipsDto bizTipsDto = new BizTipsDto();
		bizTipsDto.setBiztipsDetails(biztips);
		return new ResponseEntity<BizTipsDto>(bizTipsDto, HttpStatus.OK);
	}	
	
	@RequestMapping(value = "/advClicable", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ProductCategoryDto> advClicable(@RequestBody final String json)
			throws CommonException, JsonParseException, IOException {
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		int catalogid = mapper.readValue(json, CatalogBean.class).getCatalogId();
		productItemDetails = customerService.advClicable(catalogid);

		if (productItemDetails == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		ProductCategoryDto productdetailDto = new ProductCategoryDto();
		productdetailDto.setProducts(productItemDetails);
		return new ResponseEntity<ProductCategoryDto>(productdetailDto, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getSaleOffer", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SalesOfferdto> getSaleOffer() throws CommonException, JsonParseException, IOException {
		mapper = new ObjectMapper();
		
		salesoffer = customerService.getSaleOffer();

		if (salesoffer == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		SalesOfferdto salesOfferdto = new SalesOfferdto();
		salesOfferdto.setSalesoffer(salesoffer);
		return new ResponseEntity<SalesOfferdto>(salesOfferdto, HttpStatus.OK);
	}	
	
	@RequestMapping(value = "/getNewSaleOffer", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SalesOfferdto> getNewSaleOffer() throws CommonException, JsonParseException, IOException {
		mapper = new ObjectMapper();
		
		salesoffer = customerService.getNewSaleOffer();

		if (salesoffer == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		SalesOfferdto salesOfferdto = new SalesOfferdto();
		salesOfferdto.setSalesoffer(salesoffer);
		return new ResponseEntity<SalesOfferdto>(salesOfferdto, HttpStatus.OK);
	}	
	/*@RequestMapping(value = "/getRoleAction", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SalesOfferdto> getRoleAction() throws CommonException, JsonParseException, IOException {
		mapper = new ObjectMapper();
		
		roleaction = customerService.getRoleAction();
		
		httpSession.setAttribute("feature", roleaction.getFeature());
		httpSession.setAttribute("create", roleaction.getCreate());
		httpSession.setAttribute("delete", roleaction.getDelete());
		httpSession.setAttribute("read", roleaction.getRead());
		httpSession.setAttribute("update", roleaction.getUpdate());
		httpSession.setAttribute("acesslevel", roleaction.getAcessLevel());
		System.out.println("gfggrgrgrtr"+roleaction.getDiscount());
		if (salesoffer == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}

		SalesOfferdto salesOfferdto = new SalesOfferdto();
		salesOfferdto.setSalesoffer(salesoffer);
		return new ResponseEntity<SalesOfferdto>(salesOfferdto, HttpStatus.OK);
	}	*/
	
	@RequestMapping(value = "/checkForPriceChange", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FetchPriceChangeDetailsBean> checkForPriceChange(@RequestBody final String json)
			throws CommonException, IOException, JsonProcessingException {

		mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		int customerId = mapper.readValue(json, FetchOrdersBean.class).getCustomerId();
		orderDetails = (List<OrderDetailsBean>)mapper.readValue(json, FetchOrdersBean.class).getOrderDetails();
		fetchPriceChangeDetails = customerService.checkForPriceChange(customerId,orderDetails);

		if (fetchPriceChangeDetails == null) {
			throw new CommonException(messageSource.getMessage("valid.nodatafound", null, locale));
		}
		return new ResponseEntity<FetchPriceChangeDetailsBean>(fetchPriceChangeDetails, HttpStatus.OK);
	}
}

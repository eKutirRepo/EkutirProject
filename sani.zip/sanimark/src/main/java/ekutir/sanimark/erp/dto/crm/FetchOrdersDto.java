package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.FetchOrdersBean;

public class FetchOrdersDto {

	private List<FetchOrdersBean> orders;

	public List<FetchOrdersBean> getOrders() {
		return orders;
	}

	public void setOrders(List<FetchOrdersBean> orders) {
		this.orders = orders;
	}

}

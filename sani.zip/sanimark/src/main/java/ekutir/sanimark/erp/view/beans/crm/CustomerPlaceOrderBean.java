package ekutir.sanimark.erp.view.beans.crm;

public class CustomerPlaceOrderBean {
	private int customerId;
	private double orderAmount;
	private double orderDiscount;
	private String deliveryRequestedDate;
	private int orderPaymentMode;
	//private int clusterID;

	public CustomerPlaceOrderBean() {
		super();
	}

	public CustomerPlaceOrderBean(int customerId, double orderAmount, double orderDiscount,
			String deliveryRequestedDate, int orderPaymentMode) {
		super();
		this.customerId = customerId;
		this.orderAmount = orderAmount;
		this.orderDiscount = orderDiscount;
		this.deliveryRequestedDate = deliveryRequestedDate;
		this.orderPaymentMode = orderPaymentMode;
		//this.clusterID = clusterID;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(double orderAmount) {
		this.orderAmount = orderAmount;
	}

	public double getOrderDiscount() {
		return orderDiscount;
	}

	public void setOrderDiscount(double orderDiscount) {
		this.orderDiscount = orderDiscount;
	}

	public String getDeliveryRequestedDate() {
		return deliveryRequestedDate;
	}

	public void setDeliveryRequestedDate(String deliveryRequestedDate) {
		this.deliveryRequestedDate = deliveryRequestedDate;
	}

	public int getOrderPaymentMode() {
		return orderPaymentMode;
	}

	public void setOrderPaymentMode(int orderPaymentMode) {
		this.orderPaymentMode = orderPaymentMode;
	}

/*	public int getClusterID() {
		return clusterID;
	}

	public void setClusterID(int clusterID) {
		this.clusterID = clusterID;
	}*/

}

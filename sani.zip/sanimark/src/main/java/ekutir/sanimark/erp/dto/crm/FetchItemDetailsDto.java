package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.FetchItemDetailsBean;

public class FetchItemDetailsDto {
	private List<FetchItemDetailsBean> items;

	public List<FetchItemDetailsBean> getItems() {
		return items;
	}

	public void setItems(List<FetchItemDetailsBean> items) {
		this.items = items;
	}

}

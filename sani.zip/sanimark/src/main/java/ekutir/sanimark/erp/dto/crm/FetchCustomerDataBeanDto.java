package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.FetchCustomerDataBean;

public class FetchCustomerDataBeanDto {
	private List<FetchCustomerDataBean> customers;

	public List<FetchCustomerDataBean> getCustomers() {
		return customers;
	}

	public void setCustomers(List<FetchCustomerDataBean> customers) {
		this.customers = customers;
	}

}

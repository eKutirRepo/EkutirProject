package ekutir.sanimark.erp.view.beans.crm;

import java.util.List;

public class CatalogBean {
	private int catalogId;
	private String catalogName;
	private List<ProductdetailBean> productDetails;
	public CatalogBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CatalogBean(int catalogId, String catalogName, List<ProductdetailBean> productDetails) {
		super();
		this.catalogId = catalogId;
		this.catalogName = catalogName;
		this.productDetails = productDetails;
	}
	public int getCatalogId() {
		return catalogId;
	}
	public void setCatalogId(int catalogId) {
		this.catalogId = catalogId;
	}
	public String getCatalogName() {
		return catalogName;
	}
	public void setCatalogName(String catalogName) {
		this.catalogName = catalogName;
	}
	public List<ProductdetailBean> getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(List<ProductdetailBean> productDetails) {
		this.productDetails = productDetails;
	}
	

}

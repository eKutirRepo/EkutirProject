package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.FetchBusinessCategoryBean;

public class FetchBusinessCategoryDto {

	private List<FetchBusinessCategoryBean> categories;

	public List<FetchBusinessCategoryBean> getCategories() {
		return categories;
	}

	public void setCategories(List<FetchBusinessCategoryBean> categories) {
		this.categories = categories;
	}
}

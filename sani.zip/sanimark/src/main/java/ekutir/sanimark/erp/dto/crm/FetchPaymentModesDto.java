package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.FetchPaymentModesBean;

public class FetchPaymentModesDto {
	private List<FetchPaymentModesBean> paymentModes;

	public List<FetchPaymentModesBean> getPaymentModes() {
		return paymentModes;
	}

	public void setPaymentModes(List<FetchPaymentModesBean> paymentModes) {
		this.paymentModes = paymentModes;
	}

}

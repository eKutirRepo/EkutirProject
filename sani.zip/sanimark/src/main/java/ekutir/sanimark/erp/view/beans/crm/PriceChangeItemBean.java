package ekutir.sanimark.erp.view.beans.crm;

public class PriceChangeItemBean {

	private int newItemId;
	private double newUnitPrice;
	private double priceDifference;
	
	
	
	public PriceChangeItemBean() {
		super();
	}
	
	public PriceChangeItemBean(int newItemId, double newUnitPrice, double priceDifference) {
		super();
		this.newItemId = newItemId;
		this.newUnitPrice = newUnitPrice;
		this.priceDifference = priceDifference;
	}

	public int getNewItemId() {
		return newItemId;
	}
	public void setNewItemId(int newItemId) {
		this.newItemId = newItemId;
	}
	public double getNewUnitPrice() {
		return newUnitPrice;
	}
	public void setNewUnitPrice(double newUnitPrice) {
		this.newUnitPrice = newUnitPrice;
	}
	public double getPriceDifference() {
		return priceDifference;
	}
	public void setPriceDifference(double priceDifference) {
		this.priceDifference = priceDifference;
	}
	
	
}

package ekutir.sanimark.utilities;

import static ekutir.sanimark.constant.MailConstant.*;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class MailForgetPassword implements Runnable{
	
	String email = "";
	String password = "";
	String businessName = "";
	String getToken = "";
	String roleBean = "";

	public MailForgetPassword() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		try {
			System.out.println("inside thread");
			this.publishSendingToUser();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setParameters(String email, String password, String businessName, String getToken, String roleBean) {
		this.email = email;
		this.password = password;
		this.businessName = businessName;
		this.getToken = getToken;
		this.roleBean = roleBean;

	}
    public static String status;
	private static String subject = "forget Password";
	//Local
	//private static String notes = "http://localhost:8080/Sanimark/resetPassword";
	//Testing IP
	//private static String notes = "http://13.126.210.84:8080/Sanimark/resetPassword";
	//Production IP
	private static String notes = "http://13.126.219.190:8080/Sanimark/resetPassword";
	private static String note = "Note : Please do not share the  account details outside Sanimark domain, under confidentiality compliance.";
	private static String text = "";
	public Properties properties = System.getProperties();
	public Session session = Session.getDefaultInstance(properties);
	Transport transport = null;
	public MimeMessage message = new MimeMessage(session);

	public String publishSendingToUser() {
		String tokens = notes+"?emailLoginToken="+getToken+"&email="+email+"&role="+roleBean;
		text = "Dear " + businessName + ",\n\nClick on Link for reset your password  : " +tokens+"\n\n" + note
				+ "\n\nThanks,\nTeam Sanimark \n";
		properties.put("mail.smtp.host", emailServiceProvider);
		properties.put("mail.smtp.user", emailServiceUser);
		properties.put("mail.smtp.password", emailServicePassword);
		properties.put("mail.smtp.port", emailServicePort);
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");

		properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		properties.put("mail.smtp.socketFactory.fallback", "false");
		properties.put("mail.smtp.socketFactory.port", emailServicePort);
		properties.put("mail.debug", "true");
		properties.put("mail.store.protocol", "pop3");
		properties.put("mail.transport.protocol", "smtp");
		properties.put("mail.debug.auth", "true");
		properties.put("mail.pop3.socketFactory.fallback", "false");
		
		
		try {
			message.setFrom(new InternetAddress(emailServiceUser));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
			message.setSubject(subject);
			message.setText(text);
			transport = session.getTransport("smtp");
			transport.connect(emailServiceProvider, emailServiceUser, emailServicePassword);
			transport.sendMessage(message, message.getAllRecipients());
			status = "success";

		} catch (AddressException ae) {
			status = "failure";
			ae.printStackTrace();
		} catch (MessagingException me) {
			status = "failure";
			me.printStackTrace();
		} catch (Exception e) {
			status = "failure";
			e.printStackTrace();
		} finally {
			try {
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;
	}

}

package ekutir.sanimark.model.erp;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "`dbsanimarkdlink`.tbl_product_items")
public class ProductItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column
	private int ItemID;
	@Column
	private int ProductID;
	@Column
	private String ItemName;
	@Column
	private int ItemSKU;
	@Column
	private double ItemDescription;
	@Column
	private double UnitPrice;
	@Column
	private String Dimensions;
	@Column
	private int CreatedBy;
	@Column
	private Date CreatedDateTime;
	@Column
	private int UpdatedBy;
	@Column
	private Date UpdatedDateTime;

	public ProductItem() {
		super();

	}

	public ProductItem(int itemID, int productID, String itemName, int itemSKU, double itemDescription,
			double unitPrice, String dimensions, int createdBy, Date createdDateTime, int updatedBy,
			Date updatedDateTime) {
		super();
		ItemID = itemID;
		ProductID = productID;
		ItemName = itemName;
		ItemSKU = itemSKU;
		ItemDescription = itemDescription;
		UnitPrice = unitPrice;
		Dimensions = dimensions;
		CreatedBy = createdBy;
		CreatedDateTime = createdDateTime;
		UpdatedBy = updatedBy;
		UpdatedDateTime = updatedDateTime;
	}

	public int getItemID() {
		return ItemID;
	}

	public void setItemID(int itemID) {
		ItemID = itemID;
	}

	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int productID) {
		ProductID = productID;
	}

	public String getItemName() {
		return ItemName;
	}

	public void setItemName(String itemName) {
		ItemName = itemName;
	}

	public int getItemSKU() {
		return ItemSKU;
	}

	public void setItemSKU(int itemSKU) {
		ItemSKU = itemSKU;
	}

	public double getItemDescription() {
		return ItemDescription;
	}

	public void setItemDescription(double itemDescription) {
		ItemDescription = itemDescription;
	}

	public double getUnitPrice() {
		return UnitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		UnitPrice = unitPrice;
	}

	public String getDimensions() {
		return Dimensions;
	}

	public void setDimensions(String dimensions) {
		Dimensions = dimensions;
	}

	public int getCreatedBy() {
		return CreatedBy;
	}

	public void setCreatedBy(int createdBy) {
		CreatedBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return CreatedDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		CreatedDateTime = createdDateTime;
	}

	public int getUpdatedBy() {
		return UpdatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		UpdatedBy = updatedBy;
	}

	public Date getUpdatedDateTime() {
		return UpdatedDateTime;
	}

	public void setUpdatedDateTime(Date updatedDateTime) {
		UpdatedDateTime = updatedDateTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ProductItem [ItemID=" + ItemID + ", ProductID=" + ProductID + ", ItemName=" + ItemName + ", ItemSKU="
				+ ItemSKU + ", ItemDescription=" + ItemDescription + ", UnitPrice=" + UnitPrice + ", Dimensions="
				+ Dimensions + ", CreatedBy=" + CreatedBy + ", CreatedDateTime=" + CreatedDateTime + ", UpdatedBy="
				+ UpdatedBy + ", UpdatedDateTime=" + UpdatedDateTime + "]";
	}

}

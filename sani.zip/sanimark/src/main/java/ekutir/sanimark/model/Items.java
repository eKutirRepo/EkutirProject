package ekutir.sanimark.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.tbl_items")
public class Items implements Serializable{
	
	/*
	 * This is our model class and it corresponds to items table in database.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int itemid;
	@Column
	private String itemname;
	@Column
	private String itembrand;
	@Column
	private int product_cat_id;
	@Column
	private double mrp;
	@Column
	private double selling_price;
	@Column
	private String warranty;
	@Column
	private String dimension;
	@Column
	private String item_description;
	@Column
	private String itemImage;
	@Column
	private Date manufactureDate;
	@Column
	private Date expiryDate;
	@Column
	private String color;
	@Column
	private String CreatedBy;
	@Column
	private Date CreatedDateTime;
	@Column
	private String UpdatedBy;
	@Column
	private Date UpdatedDateTime;
	@Column
	private int approvalStatus;
	@Column
	private int productid;
	public Items() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Items(int itemid, String itemname, String itembrand, int product_cat_id, double mrp, double selling_price,
			String warranty, String dimension, String item_description, String itemImage, Date manufactureDate,
			Date expiryDate, String color, String createdBy, Date createdDateTime, String updatedBy, Date updatedDateTime, int approvalStatus) {
		super();
		this.itemid = itemid;
		this.itemname = itemname;
		this.itembrand = itembrand;
		this.product_cat_id = product_cat_id;
		this.mrp = mrp;
		this.selling_price = selling_price;
		this.warranty = warranty;
		this.dimension = dimension;
		this.item_description = item_description;
		this.itemImage = itemImage;
		this.manufactureDate = manufactureDate;
		this.expiryDate = expiryDate;
		this.color = color;
		CreatedBy = createdBy;
		CreatedDateTime = createdDateTime;
		UpdatedBy = updatedBy;
		UpdatedDateTime = updatedDateTime;
		this.approvalStatus = approvalStatus;
	}
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getItembrand() {
		return itembrand;
	}
	public void setItembrand(String itembrand) {
		this.itembrand = itembrand;
	}
	public int getProduct_cat_id() {
		return product_cat_id;
	}
	public void setProduct_cat_id(int product_cat_id) {
		this.product_cat_id = product_cat_id;
	}
	public double getMrp() {
		return mrp;
	}
	public void setMrp(double mrp) {
		this.mrp = mrp;
	}
	public double getSelling_price() {
		return selling_price;
	}
	public void setSelling_price(double selling_price) {
		this.selling_price = selling_price;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	public String getItem_description() {
		return item_description;
	}
	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}
	public String getItemImage() {
		return itemImage;
	}
	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}
	public Date getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public Date getCreatedDateTime() {
		return CreatedDateTime;
	}
	public void setCreatedDateTime(Date createdDateTime) {
		CreatedDateTime = createdDateTime;
	}
	public String getUpdatedBy() {
		return UpdatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		UpdatedBy = updatedBy;
	}
	public Date getUpdatedDateTime() {
		return UpdatedDateTime;
	}
	public void setUpdatedDateTime(Date updatedDateTime) {
		UpdatedDateTime = updatedDateTime;
	}
	public int getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(int approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

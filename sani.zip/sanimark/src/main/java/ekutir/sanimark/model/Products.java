package ekutir.sanimark.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_product")
public class Products implements Serializable{
	
	/*
	 * This is our model class and it corresponds to product table in database.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productid;
	@Column
	private String product_name;
	@Column
	private int product_cat_id;
	@Column
	private String product_description;
	@Column
	private String created_by;
	@Column
	private Date created_date;
	@Column
	private String updated_by;
	@Column
	private Date updated_date;
	@Column
	private String product_image;
	@Column
	private int active_status;
	
	public Products() {
		super();
	}

	public Products(int productid, String product_name, int product_cat_id, String product_description,
			String created_by, Date created_date, String updated_by, Date updated_date, String product_image, int active_status) {
		super();
		this.productid = productid;
		this.product_name = product_name;
		this.product_cat_id = product_cat_id;
		this.product_description = product_description;
		this.created_by = created_by;
		this.created_date = created_date;
		this.updated_by = updated_by;
		this.updated_date = updated_date;
		this.product_image = product_image;
		this.active_status = active_status;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getProduct_cat_id() {
		return product_cat_id;
	}

	public void setProduct_cat_id(int product_cat_id) {
		this.product_cat_id = product_cat_id;
	}

	public String getProduct_description() {
		return product_description;
	}

	public void setProduct_description(String product_description) {
		this.product_description = product_description;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public Date getUpdated_date() {
		return updated_date;
	}

	public void setUpdated_date(Date updated_date) {
		this.updated_date = updated_date;
	}
	
	public String getProduct_image() {
		return product_image;
	}

	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}

	public int getActive_status() {
		return active_status;
	}

	public void setActive_status(int active_status) {
		this.active_status = active_status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

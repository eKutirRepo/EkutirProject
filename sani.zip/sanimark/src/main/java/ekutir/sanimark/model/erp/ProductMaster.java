package ekutir.sanimark.model.erp;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "`dbsvadha.erp`.tbl_product_master")
public class ProductMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column
	private int ProductID;
	@Column
	private int CatalogID;
	@Column
	private String ProductName;
	@Column
	private String ProductDisplayName;
	@Column
	private double UnitPrice;
	@Column
	private int DiscountThreshold;
	@Column
	private String ProductPicture;
	@Column
	private String ProductType;
	@Column
	private int CreatedBy;
	@Column
	private Date CreatedDateTime;
	@Column
	private int UpdatedBy;
	@Column
	private Date UpdatedDateTime;

	public ProductMaster() {
		super();
	}

	public ProductMaster(int productID, int catalogID, String productName, String productDisplayName, double unitPrice,
			int discountThreshold, String productPicture, String productType, int createdBy, Date createdDateTime,
			int updatedBy, Date updatedDateTime) {
		super();
		ProductID = productID;
		CatalogID = catalogID;
		ProductName = productName;
		ProductDisplayName = productDisplayName;
		UnitPrice = unitPrice;
		DiscountThreshold = discountThreshold;
		ProductPicture = productPicture;
		ProductType = productType;
		CreatedBy = createdBy;
		CreatedDateTime = createdDateTime;
		UpdatedBy = updatedBy;
		UpdatedDateTime = updatedDateTime;
	}

	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int productID) {
		ProductID = productID;
	}

	public int getCatalogID() {
		return CatalogID;
	}

	public void setCatalogID(int catalogID) {
		CatalogID = catalogID;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public String getProductDisplayName() {
		return ProductDisplayName;
	}

	public void setProductDisplayName(String productDisplayName) {
		ProductDisplayName = productDisplayName;
	}

	public double getUnitPrice() {
		return UnitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		UnitPrice = unitPrice;
	}

	public int getDiscountThreshold() {
		return DiscountThreshold;
	}

	public void setDiscountThreshold(int discountThreshold) {
		DiscountThreshold = discountThreshold;
	}

	public String getProductPicture() {
		return ProductPicture;
	}

	public void setProductPicture(String productPicture) {
		ProductPicture = productPicture;
	}

	public String getProductType() {
		return ProductType;
	}

	public void setProductType(String productType) {
		ProductType = productType;
	}

	public int getCreatedBy() {
		return CreatedBy;
	}

	public void setCreatedBy(int createdBy) {
		CreatedBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return CreatedDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		CreatedDateTime = createdDateTime;
	}

	public int getUpdatedBy() {
		return UpdatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		UpdatedBy = updatedBy;
	}

	public Date getUpdatedDateTime() {
		return UpdatedDateTime;
	}

	public void setUpdatedDateTime(Date updatedDateTime) {
		UpdatedDateTime = updatedDateTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ProductMaster [ProductID=" + ProductID + ", CatalogID=" + CatalogID + ", ProductName=" + ProductName
				+ ", ProductDisplayName=" + ProductDisplayName + ", UnitPrice=" + UnitPrice + ", DiscountThreshold="
				+ DiscountThreshold + ", ProductPicture=" + ProductPicture + ", ProductType=" + ProductType
				+ ", CreatedBy=" + CreatedBy + ", CreatedDateTime=" + CreatedDateTime + ", UpdatedBy=" + UpdatedBy
				+ ", UpdatedDateTime=" + UpdatedDateTime + "]";
	}

}

package ekutir.sanimark.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_tokens")
public class TokenGenerate implements Serializable{
	
	/*
	 * This is our model class and it corresponds to Token Generate table in database.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int tokenId;
	@Column
	private String token;
	@Column
	private Date token_expiryDate;
	
	public TokenGenerate() {
		super();
	}
	
	public TokenGenerate(int tokenId, String token, Date token_expiryDate) {
		super();
		this.tokenId = tokenId;
		this.token = token;
		this.token_expiryDate = token_expiryDate;
	}
	
	public int getTokenId() {
		return tokenId;
	}
	public void setTokenId(int tokenId) {
		this.tokenId = tokenId;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public Date getToken_expiryDate() {
		return token_expiryDate;
	}
	public void setToken_expiryDate(Date token_expiryDate) {
		this.token_expiryDate = token_expiryDate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

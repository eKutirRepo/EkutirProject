package ekutir.sanimark.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_me_message")
public class MicroEntrepreneurMsgs implements Serializable{
	
	private static final long serialVersionUID = -7988799579036225137L;
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int messageId;
	@Column
	private String messagedescription;
	@Column
	private int read_status;
	@Column
	private String created_date;
	@Column
	private String created_by;
	@Column
	private String message_type;
	
	public MicroEntrepreneurMsgs() {
		super();
	}

	public MicroEntrepreneurMsgs(int messageId, String messagedescription, int read_status, 
								String created_date, String created_by, String message_type) {
		super();
		this.messageId = messageId;
		this.messagedescription = messagedescription;
		//this.userId = userId;
		this.read_status = read_status;
		this.created_date = created_date;
		this.created_by = created_by;
		this.message_type = message_type;
	}

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public String getMessagedescription() {
		return messagedescription;
	}

	public void setMessagedescription(String messagedescription) {
		this.messagedescription = messagedescription;
	}

	public int getRead_status() {
		return read_status;
	}

	public void setRead_status(int read_status) {
		this.read_status = read_status;
	}

	public String getCreated_date() {
		return created_date;
	}

	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getMessage_type() {
		return message_type;
	}

	public void setMessage_type(String message_type) {
		this.message_type = message_type;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

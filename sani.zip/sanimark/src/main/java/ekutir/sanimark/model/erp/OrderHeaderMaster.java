package ekutir.sanimark.model.erp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "`dbsanimarkdlink`.`tbl_order_header_master`")
public class OrderHeaderMaster {
	@Id
	@Column
	private int OrderID;
	@Column
	private String CustomerID;
	@Column
	private String UserID;
	@Column
	private String OrderDate;
	@Column
	private String DeliveryRequestedDate;
	@Column
	private String OrderDiscount;
	@Column
	private String Adjustments;
	@Column
	private String OrderAmount;
	@Column
	private String OrderPaymentMode;
	@Column
	private String Status;
	@Column
	private int ShipToWareHouse;
	public OrderHeaderMaster(int orderID, String customerID, String userID, String orderDate,
			String deliveryRequestedDate, String orderDiscount, String adjustments, String orderAmount,
			String orderPaymentMode, String status,int shipToWareHouse) {
		super();
		OrderID = orderID;
		CustomerID = customerID;
		UserID = userID;
		OrderDate = orderDate;
		DeliveryRequestedDate = deliveryRequestedDate;
		OrderDiscount = orderDiscount;
		Adjustments = adjustments;
		OrderAmount = orderAmount;
		OrderPaymentMode = orderPaymentMode;
		Status = status;
		ShipToWareHouse = shipToWareHouse;
		
		
	}
	public int getOrderID() {
		return OrderID;
	}
	public void setOrderID(int orderID) {
		OrderID = orderID;
	}
	public String getCustomerID() {
		return CustomerID;
	}
	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getOrderDate() {
		return OrderDate;
	}
	public void setOrderDate(String orderDate) {
		OrderDate = orderDate;
	}
	public String getDeliveryRequestedDate() {
		return DeliveryRequestedDate;
	}
	public void setDeliveryRequestedDate(String deliveryRequestedDate) {
		DeliveryRequestedDate = deliveryRequestedDate;
	}
	public String getOrderDiscount() {
		return OrderDiscount;
	}
	public void setOrderDiscount(String orderDiscount) {
		OrderDiscount = orderDiscount;
	}
	public String getAdjustments() {
		return Adjustments;
	}
	public void setAdjustments(String adjustments) {
		Adjustments = adjustments;
	}
	public String getOrderAmount() {
		return OrderAmount;
	}
	public void setOrderAmount(String orderAmount) {
		OrderAmount = orderAmount;
	}
	public String getOrderPaymentMode() {
		return OrderPaymentMode;
	}
	public void setOrderPaymentMode(String orderPaymentMode) {
		OrderPaymentMode = orderPaymentMode;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public int getShipToWareHouse() {
		return ShipToWareHouse;
	}
	public void setShipToWareHouse(int shipToWareHouse) {
		ShipToWareHouse = shipToWareHouse;
	}
	@Override
	public String toString() {
		return "OrderHeaderMaster [OrderID=" + OrderID + ", CustomerID=" + CustomerID + ", UserID=" + UserID
				+ ", OrderDate=" + OrderDate + ", DeliveryRequestedDate=" + DeliveryRequestedDate + ", OrderDiscount="
				+ OrderDiscount + ", Adjustments=" + Adjustments + ", OrderAmount=" + OrderAmount
				+ ", OrderPaymentMode=" + OrderPaymentMode + ", Status=" + Status + ", ShipToWareHouse="
				+ ShipToWareHouse + "]";
	}
	
}

package ekutir.sanimark.web.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_product")
public class NewProduct implements Serializable{
	
	/*
	 * This is our model class and it corresponds to product table in database.
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productid;
	@Column
	private String product_brand_name;
	@Column
	private String company_name;
	@Column
	private int product_cat_id;
	@Column
	private int warranty;
	@Column
	private String date_of_manufacturing;
	@Column
	private String expiry_date;
	@Column
	private String when_to_use;
	@Column
	private String how_to_use;
	@Column
	private String product_features;
	@Column
	private String productImg;
	@Column
	private String SeedType;
	@Column
	private String Crop;
	@Column
	private String Season;
	@Column
	private String SowingMonthFrom;
	@Column
	private String SowingMonthTo;
	@Column
	private String Productivity;
	@Column
	private String PreferredDuration;
	@Column
	private String DiseasesResistance;
	@Column
	private String PestResistance;
	@Column
	private String SeedRequirement;
	@Column
	private String LandUnit;
	@Column
	private String Germination;
	@Column
	private String HowToApply;
	@Column
	private String GenericFertilizer;
	@Column
	private String Nitrogen;
	@Column
	private String Phosphorus;
	@Column
	private String Potassium;
	@Column
	private String Sulfur;
	@Column
	private String PestandDiseases;
	@Column
	private String ChemicalName;
	@Column
	private String Dose;
	@Column
	private double mrp;

	@Column
	private int discountInpercent;

	@Column
	private double sellingprice;


	public NewProduct() {
		super();
		// TODO Auto-generated constructor stub
	}


	

	public NewProduct(int productid, String product_brand_name, String company_name, int product_cat_id, int warranty,
			String date_of_manufacturing, String expiry_date, String when_to_use, String how_to_use,
			String product_features, String productImg, String seedType, String crop, String season,
			String sowingMonthFrom, String sowingMonthTo, String productivity, String preferredDuration,
			String diseasesResistance, String pestResistance, String seedRequirement, String landUnit,
			String germination, String howToApply, String genericFertilizer, String nitrogen, String phosphorus,
			String potassium, String sulfur, String pestandDiseases, String chemicalName, String dose, double mrp,
			int discountInpercent, double sellingprice) {
		super();
		this.productid = productid;
		this.product_brand_name = product_brand_name;
		this.company_name = company_name;
		this.product_cat_id = product_cat_id;
		this.warranty = warranty;
		this.date_of_manufacturing = date_of_manufacturing;
		this.expiry_date = expiry_date;
		this.when_to_use = when_to_use;
		this.how_to_use = how_to_use;
		this.product_features = product_features;
		this.productImg = productImg;
		SeedType = seedType;
		Crop = crop;
		Season = season;
		SowingMonthFrom = sowingMonthFrom;
		SowingMonthTo = sowingMonthTo;
		Productivity = productivity;
		PreferredDuration = preferredDuration;
		DiseasesResistance = diseasesResistance;
		PestResistance = pestResistance;
		SeedRequirement = seedRequirement;
		LandUnit = landUnit;
		Germination = germination;
		HowToApply = howToApply;
		GenericFertilizer = genericFertilizer;
		Nitrogen = nitrogen;
		Phosphorus = phosphorus;
		Potassium = potassium;
		Sulfur = sulfur;
		PestandDiseases = pestandDiseases;
		ChemicalName = chemicalName;
		Dose = dose;
		this.mrp = mrp;
		this.discountInpercent = discountInpercent;
		this.sellingprice = sellingprice;
	}




	public double getMrp() {
		return mrp;
	}




	public void setMrp(double mrp) {
		this.mrp = mrp;
	}




	public int getDiscountInpercent() {
		return discountInpercent;
	}




	public void setDiscountInpercent(int discountInpercent) {
		this.discountInpercent = discountInpercent;
	}




	public double getSellingprice() {
		return sellingprice;
	}




	public void setSellingprice(double sellingprice) {
		this.sellingprice = sellingprice;
	}




	public int getProductid() {
		return productid;
	}


	public void setProductid(int productid) {
		this.productid = productid;
	}


	public String getProduct_brand_name() {
		return product_brand_name;
	}


	public void setProduct_brand_name(String product_brand_name) {
		this.product_brand_name = product_brand_name;
	}


	public String getCompany_name() {
		return company_name;
	}


	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}


	public int getProduct_cat_id() {
		return product_cat_id;
	}


	public void setProduct_cat_id(int product_cat_id) {
		this.product_cat_id = product_cat_id;
	}


	public int getWarranty() {
		return warranty;
	}


	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}


	public String getDate_of_manufacturing() {
		return date_of_manufacturing;
	}


	public void setDate_of_manufacturing(String date_of_manufacturing) {
		this.date_of_manufacturing = date_of_manufacturing;
	}


	public String getExpiry_date() {
		return expiry_date;
	}


	public void setExpiry_date(String expiry_date) {
		this.expiry_date = expiry_date;
	}


	public String getWhen_to_use() {
		return when_to_use;
	}


	public void setWhen_to_use(String when_to_use) {
		this.when_to_use = when_to_use;
	}


	public String getHow_to_use() {
		return how_to_use;
	}


	public void setHow_to_use(String how_to_use) {
		this.how_to_use = how_to_use;
	}


	public String getProduct_features() {
		return product_features;
	}


	public void setProduct_features(String product_features) {
		this.product_features = product_features;
	}


	public String getProductImg() {
		return productImg;
	}


	public void setProductImg(String productImg) {
		this.productImg = productImg;
	}


	public String getSeedType() {
		return SeedType;
	}


	public void setSeedType(String seedType) {
		SeedType = seedType;
	}


	public String getCrop() {
		return Crop;
	}


	public void setCrop(String crop) {
		Crop = crop;
	}


	public String getSeason() {
		return Season;
	}


	public void setSeason(String season) {
		Season = season;
	}


	public String getSowingMonthFrom() {
		return SowingMonthFrom;
	}


	public void setSowingMonthFrom(String sowingMonthFrom) {
		SowingMonthFrom = sowingMonthFrom;
	}


	public String getSowingMonthTo() {
		return SowingMonthTo;
	}


	public void setSowingMonthTo(String sowingMonthTo) {
		SowingMonthTo = sowingMonthTo;
	}


	public String getProductivity() {
		return Productivity;
	}


	public void setProductivity(String productivity) {
		Productivity = productivity;
	}


	public String getPreferredDuration() {
		return PreferredDuration;
	}


	public void setPreferredDuration(String preferredDuration) {
		PreferredDuration = preferredDuration;
	}


	public String getDiseasesResistance() {
		return DiseasesResistance;
	}


	public void setDiseasesResistance(String diseasesResistance) {
		DiseasesResistance = diseasesResistance;
	}


	public String getPestResistance() {
		return PestResistance;
	}


	public void setPestResistance(String pestResistance) {
		PestResistance = pestResistance;
	}


	public String getSeedRequirement() {
		return SeedRequirement;
	}


	public void setSeedRequirement(String seedRequirement) {
		SeedRequirement = seedRequirement;
	}


	public String getLandUnit() {
		return LandUnit;
	}


	public void setLandUnit(String landUnit) {
		LandUnit = landUnit;
	}


	public String getGermination() {
		return Germination;
	}


	public void setGermination(String germination) {
		Germination = germination;
	}


	public String getHowToApply() {
		return HowToApply;
	}


	public void setHowToApply(String howToApply) {
		HowToApply = howToApply;
	}


	public String getGenericFertilizer() {
		return GenericFertilizer;
	}


	public void setGenericFertilizer(String genericFertilizer) {
		GenericFertilizer = genericFertilizer;
	}


	public String getNitrogen() {
		return Nitrogen;
	}


	public void setNitrogen(String nitrogen) {
		Nitrogen = nitrogen;
	}


	public String getPhosphorus() {
		return Phosphorus;
	}


	public void setPhosphorus(String phosphorus) {
		Phosphorus = phosphorus;
	}


	public String getPotassium() {
		return Potassium;
	}


	public void setPotassium(String potassium) {
		Potassium = potassium;
	}


	public String getSulfur() {
		return Sulfur;
	}


	public void setSulfur(String sulfur) {
		Sulfur = sulfur;
	}


	public String getPestandDiseases() {
		return PestandDiseases;
	}


	public void setPestandDiseases(String pestandDiseases) {
		PestandDiseases = pestandDiseases;
	}


	public String getChemicalName() {
		return ChemicalName;
	}


	public void setChemicalName(String chemicalName) {
		ChemicalName = chemicalName;
	}


	public String getDose() {
		return Dose;
	}


	public void setDose(String dose) {
		Dose = dose;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

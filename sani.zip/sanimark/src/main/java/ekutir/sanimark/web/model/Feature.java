package ekutir.sanimark.web.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_feature")
public class Feature implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column
	private int feature_id;
	
	@Column
	private String feature_name;
	
	@Column
	private String feature_description;

	public Feature() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Feature(int feature_id, String feature_name, String feature_description) {
		super();
		this.feature_id = feature_id;
		this.feature_name = feature_name;
		this.feature_description = feature_description;
	}

	public int getFeature_id() {
		return feature_id;
	}

	public void setFeature_id(int feature_id) {
		this.feature_id = feature_id;
	}

	public String getFeature_name() {
		return feature_name;
	}

	public void setFeature_name(String feature_name) {
		this.feature_name = feature_name;
	}

	public String getFeature_description() {
		return feature_description;
	}

	public void setFeature_description(String feature_description) {
		this.feature_description = feature_description;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

package ekutir.sanimark.web.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_admin")
public class AdminUsers implements Serializable {

		private static final long serialVersionUID = -7988799579036225137L;
		@Id
		@Column
		private int admin_id;
		@Column
		private String admin_name;
		@Column
		private String login_id;
		@Column
		private String password;
		@Column
		private int status;
		@Column
		private String created_date_time;
		@Column
		private String created_by;
		@Column
		private String updated_date_time;
		@Column
		private String updated_by;
		
		public AdminUsers() {
			super();
		}

		public AdminUsers(int admin_id, String admin_name, String login_id, String password, int status, String created_date_time,
				String created_by, String updated_date_time, String updated_by) {
			super();
			this.admin_id = admin_id;
			this.admin_name = admin_name;
			this.login_id = login_id;
			this.password = password;
			this.status = status;
			this.created_date_time = created_date_time;
			this.created_by = created_by;
			this.updated_date_time = updated_date_time;
			this.updated_by = updated_by;
		}

		public int getAdmin_id() {
			return admin_id;
		}

		public void setAdmin_id(int admin_id) {
			this.admin_id = admin_id;
		}
		
		public String getAdmin_name() {
			return admin_name;
		}

		public void setAdmin_name(String admin_name) {
			this.admin_name = admin_name;
		}

		public String getLogin_id() {
			return login_id;
		}

		public void setLogin_id(String login_id) {
			this.login_id = login_id;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}

		public String getCreated_date_time() {
			return created_date_time;
		}

		public void setCreated_date_time(String created_date_time) {
			this.created_date_time = created_date_time;
		}

		public String getCreated_by() {
			return created_by;
		}

		public void setCreated_by(String created_by) {
			this.created_by = created_by;
		}

		public String getUpdated_date_time() {
			return updated_date_time;
		}

		public void setUpdated_date_time(String updated_date_time) {
			this.updated_date_time = updated_date_time;
		}

		public String getUpdated_by() {
			return updated_by;
		}

		public void setUpdated_by(String updated_by) {
			this.updated_by = updated_by;
		}

		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		
}

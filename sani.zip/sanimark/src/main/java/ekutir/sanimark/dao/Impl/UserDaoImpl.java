package ekutir.sanimark.dao.Impl;

import static ekutir.sanimark.dao.Impl.UserSqlUtility.SEARCH_ADMIN_MAIL_QUERY;
import static ekutir.sanimark.dao.Impl.UserSqlUtility.SEARCH_SUPPLIER_MAIL_QUERY;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import ekutir.sanimark.android.dto.AdminUserBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ResetPasswordBean;
import ekutir.sanimark.android.dto.UserViewBean;
import ekutir.sanimark.dao.BaseDao;
import ekutir.sanimark.dao.UserDao;
import ekutir.sanimark.utilities.CommonUtilities;
import ekutir.sanimark.utilities.EncryptionDecryption;
import ekutir.sanimark.utilities.PasswordHasher;
import ekutir.sanimark.view.beans.UserResetPassword;
import ekutir.sanimark.web.model.AdminUsers;
import ekutir.sanimark.web.model.AgrimarkUsers;
import ekutir.sanimark.web.model.WebAddress;

@SuppressWarnings("deprecation")
@Repository("userDao")
public class UserDaoImpl extends BaseDao<Integer, AgrimarkUsers> implements UserDao {

	private static final Logger logger = Logger.getLogger(SanimarkDaoImpl.class);
	public static final String SALT = "my-salt-text";

	@Autowired
	@Qualifier(value = "hibernate4AnnotatedSessionFactoryForSanimark")
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	Session session = null;
	Transaction tx = null;

	@Autowired
	PasswordHasher passwordHasher;

	public AgrimarkUsers findById(int id) {

		return null;
	}

	@Autowired
	HttpSession httpSession;
	private Criteria criteria;
	List<Object[]> rows = null;
	List<Object[]> rows1 = null;
	private Query query;
	private Query varify_query;
	private Query varify_query1;

	public EncryptionDecryption encryptionDecryption = new EncryptionDecryption();

	@SuppressWarnings("unchecked")
	public String findByNameAndPassword(UserViewBean userviewBean) {
		String msg = null;
		String hashedPassword = PasswordHasher.generateHash(userviewBean.getPassword());
		// System.out.println("==============hsdb==============="+hashedPassword);
		String hql = "";
		// System.out.println(" Role : "+userviewBean.getRole());
		if (userviewBean.getRole().equalsIgnoreCase("admin")) {
			System.out.println(" if qry");
			hql = "from AdminUsers where login_id=:loginId";
			@SuppressWarnings({ "rawtypes" })
			Query query = super.getSession().createQuery(hql).setCacheable(true);
			query.setParameter("loginId", userviewBean.getLoginId());
			// query.setParameter("pwd", userviewBean.getPassword());
			List<AdminUsers> admin = query.list();
			if (admin != null && !admin.isEmpty()) {
				userviewBean.setUserId(admin.get(0).getAdmin_id());
				userviewBean.setStatus(admin.get(0).getStatus());
				userviewBean.setUserName(admin.get(0).getAdmin_name());
				userviewBean.setPassword(admin.get(0).getPassword());
				msg = "admin";
				// return msg;
			}

		} else {
			System.out.println("else qry");
			// List<AgrimarkUsers> supplierUser = query1.list();
			hql = "from AgrimarkUsers where login_id=:loginId";
			@SuppressWarnings({ "rawtypes" })
			Query query1 = super.getSession().createQuery(hql).setCacheable(true);
			query1.setParameter("loginId", userviewBean.getLoginId());
			List<AgrimarkUsers> supplierUser = query1.list();

			userviewBean.setUserName(supplierUser.get(0).getBusiness_name());
			userviewBean.setUserId(supplierUser.get(0).getSupplier_id());
			userviewBean.setStatus(supplierUser.get(0).getStatus());
			userviewBean.setPassword(supplierUser.get(0).getPassword());
			msg = "supplierUser";
			// return msg;
		}

		/*
		 * @SuppressWarnings({ "rawtypes" }) Query query
		 * =super.getSession().createQuery(hql).setCacheable(true);
		 * query.setParameter("loginId", userviewBean.getLoginId());
		 * query.setParameter("pwd", userviewBean.getPassword());
		 */
		/*
		 * hashuser = query.list(); for(AgrimarkUsers myList:hashuser) {
		 * 
		 * }
		 */

		// System.out.println("==dao== loginID
		// :"+userviewBean.getLoginId()+"=====dao========password:
		// "+userviewBean.getPassword());

		/*
		 * if(userviewBean.getRole().equals("admin")){ List<AdminUsers> admin =
		 * query.list(); if (admin != null && !admin.isEmpty()) {
		 * userviewBean.setUserId(admin.get(0).getAdmin_id());
		 * userviewBean.setStatus(admin.get(0).getStatus());
		 * userviewBean.setUserName(admin.get(0).getAdmin_name()); msg =
		 * "admin"; } }else{ List<AgrimarkUsers> supplierUser = query.list();
		 * System.out.println("supplierUser :"+supplierUser.size()); if
		 * (supplierUser != null && !supplierUser.isEmpty()) {
		 * userviewBean.setUserName(supplierUser.get(0).getBusiness_name());
		 * userviewBean.setUserId(supplierUser.get(0).getSupplier_id());
		 * userviewBean.setStatus(supplierUser.get(0).getStatus());
		 * userviewBean.setPassword(supplierUser.get(0).getPassword()); msg =
		 * "supplierUser"; } }
		 */

		return msg;
	}

	public void logoutUser(AgrimarkUsers user) {

	}

	public List<AgrimarkUsers> findAllUsers() {
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> forgetPassword(String roleBean, String email) {
		session = sessionFactory.openSession();
		try {
			session.getTransaction().begin();

			if (roleBean.equalsIgnoreCase("admin")) {

				// System.out.println("==============admin===================");

				@SuppressWarnings("rawtypes")
				Query query = session.createSQLQuery(SEARCH_ADMIN_MAIL_QUERY).setCacheable(true);
				query.setParameter(0, email);
				rows = query.list();

			} else {

				// System.out.println("==============supplier===================");

				@SuppressWarnings("rawtypes")
				Query query1 = session.createSQLQuery(SEARCH_SUPPLIER_MAIL_QUERY).setCacheable(true);
				query1.setParameter(0, email);
				rows = query1.list();

			}

			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return rows;
	}

	@Override
	public int registration(RegisterDataBean registerBean) {

		System.out.println("===============registerBean=================" + registerBean);
		// System.out.println("==================addressBean=============="+addressBean);
		/*
		 * userId = 1; if (httpSession.getAttribute("userId") == null) { userId
		 * = 1; } else { userId = (int) httpSession.getAttribute("userId"); }
		 */
		session = sessionFactory.openSession();
		CommonUtilities commonUtilities = new CommonUtilities();
		String hashedPassword = passwordHasher.signup(registerBean.getLoginId(), registerBean.getPassword());
		int supplierId = 0;
		int addressId = 0;
		String sql_address = UserSqlUtility.INSERT_SUPPLIER_ADDRESS_QUERY;
		String sql_addsupplier = UserSqlUtility.INSERT_SUPPLIER_REGISTER_QUERY;
		
		//String sql_ekt_regd = UserSqlUtility.INSERT_GATWAY_REGISTRATION_QUERY;
		//String sql_max_regd_id = UserSqlUtility.MAX_REGD_ID_QUERY;
		//String sql_ekt_address = UserSqlUtility.INSERT_GATWAY_ADDRESS_QUERY;
		//String sql_max_address_id = UserSqlUtility.MAX_ADDRESS_ID_QUERY;
		//String sql_auth_id = UserSqlUtility.AUTH_ID_QUERY;
		//String sql_ekt_user = UserSqlUtility.INSERT_GATWAY_USER_QUERY;

		try {
			session.getTransaction().begin();
			@SuppressWarnings("rawtypes")
			Query query_address = session.createSQLQuery(sql_address).setCacheable(true);
			//System.out.println("===========query_address============== " + query_address);
			query_address.setParameter(0, registerBean.getAddress().getAddressLine1());
			query_address.setParameter(1, registerBean.getAddress().getAddressLine2());
			query_address.setParameter(2, registerBean.getAddress().getAddressLine3());
			query_address.setParameter(3, registerBean.getAddress().getBlock());
			query_address.setParameter(4, registerBean.getAddress().getCity());
			if (registerBean.getAddress().getDistrict() == null) {
				query_address.setParameter(5, "");
			} else {
				query_address.setParameter(5, registerBean.getAddress().getDistrict());
			}
			query_address.setParameter(6, registerBean.getAddress().getState());
			query_address.setParameter(7, registerBean.getAddress().getCountry());
			query_address.setParameter(8, registerBean.getAddress().getPincode());
			query_address.executeUpdate();

			System.out.println(" insert address ");

			criteria = session.createCriteria(WebAddress.class).setProjection(Projections.max("address_id"));
			int address = (Integer) criteria.uniqueResult();
			System.out.println(" max address id " + addressId);
			Query query_addsupplier = session.createSQLQuery(sql_addsupplier).setCacheable(true);
			query_addsupplier.setParameter(0, registerBean.getLoginId());
			query_addsupplier.setParameter(1, hashedPassword);
			query_addsupplier.setParameter(2, registerBean.getBusinessName());
			query_addsupplier.setParameter(3, registerBean.getPrimaryFirstName());
			query_addsupplier.setParameter(4, registerBean.getPrimaryMiddleName());
			query_addsupplier.setParameter(5, registerBean.getPrimaryLastName());
			query_addsupplier.setParameter(6, registerBean.getPrimaryContactNumber());
			query_addsupplier.setParameter(7, registerBean.getSecondaryContactName());
			query_addsupplier.setParameter(8, registerBean.getSecondaryContactNumber());
			query_addsupplier.setParameter(9, registerBean.getBusinessDescription());
			query_addsupplier.setParameter(10, registerBean.getStatus());
			try {
				query_addsupplier.setParameter(11, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_addsupplier.setParameter(12, address);

			supplierId = query_addsupplier.executeUpdate();
			
			/*Insert into gtwy_registration table*/
			/*Query query_ekt_regd = sessionFactory.getCurrentSession().createSQLQuery(sql_ekt_regd).setCacheable(true);
			query_ekt_regd.setParameter(0, registerBean.getPrimaryContactNumber());
			try {
			query_ekt_regd.setParameter(1, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_ekt_regd.setParameter(2, 0);
			query_ekt_regd.setParameter(3, 5);
			query_ekt_regd.executeUpdate();*/
			
			/*Search max reg id*/
			/*Query query_max_regd_id = sessionFactory.getCurrentSession().createSQLQuery(sql_max_regd_id).setCacheable(true);
			List list_regd_id=query_max_regd_id.list();
			int max_regd_id =Integer.parseInt(list_regd_id.get(0).toString());
			
			Insert into gtwy_address table
			Query query_ekt_address = sessionFactory.getCurrentSession().createSQLQuery(sql_ekt_address).setCacheable(true);
			query_ekt_address.setParameter(0, registerBean.getAddress().getAddressLine1());
			query_ekt_address.setParameter(1, registerBean.getAddress().getAddressLine2());
			query_ekt_address.setParameter(2, registerBean.getAddress().getAddressLine3());
			query_ekt_address.setParameter(3, registerBean.getAddress().getBlock());

			if (registerBean.getAddress().getDistrict() == null) {
				query_ekt_address.setParameter(4, "");
			} else {
				query_ekt_address.setParameter(4, registerBean.getAddress().getDistrict());
			}
			query_ekt_address.setParameter(5, registerBean.getAddress().getCity());
			query_ekt_address.setParameter(6, registerBean.getAddress().getState());
			query_ekt_address.setParameter(7, registerBean.getAddress().getCountry());
			query_ekt_address.setParameter(8, registerBean.getAddress().getPincode());
			query_ekt_address.setParameter(9, "SYSTEM");
			try {
			query_ekt_address.setParameter(10, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_ekt_address.executeUpdate();

			Query query_max_address_id = sessionFactory.getCurrentSession().createSQLQuery(sql_max_address_id).setCacheable(true);
			List list_address_id=query_max_address_id.list();
			int max_address_id =Integer.parseInt(list_address_id.get(0).toString());
			
			
			Query query_auth_id = sessionFactory.getCurrentSession().createSQLQuery(sql_auth_id).setCacheable(true);
			query_auth_id.setParameter(0, "SANI_MASTER");
			query_auth_id.setParameter(1, "master_key");
			List list_auth_id=query_auth_id.list();
			int auth_id =Integer.parseInt(list_auth_id.get(0).toString());*/
			
			/*Insert into gtwy_user_master table*/
			/*Query query_adduser =sessionFactory.getCurrentSession().createSQLQuery(sql_ekt_user).setCacheable(true);
			query_adduser.setParameter(0, max_regd_id);
			query_adduser.setParameter(1, auth_id);
			query_adduser.setParameter(2, registerBean.getPrimaryFirstName());
			query_adduser.setParameter(3, registerBean.getPassword());
			query_adduser.setParameter(4, registerBean.getPrimaryMiddleName());
			query_adduser.setParameter(5, registerBean.getPrimaryLastName());
			query_adduser.setParameter(6, registerBean.getBusinessName());
			query_adduser.setParameter(7, "SUPPLIER");
			query_adduser.setParameter(8, max_address_id);
			query_adduser.setParameter(9, 0);
			query_adduser.setParameter(10, "SYSTEM");
			try
			{
			query_adduser.setParameter(11, commonUtilities.currentDateTime());
			} catch (ParseException e) {
	
				e.printStackTrace();
			}
			query_adduser.executeUpdate();*/
			
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
			supplierId = -1;
		} catch (PersistenceException e) {
			e.printStackTrace();
			supplierId = -1;
		} finally {
			session.close();
		}
		return supplierId;
	}

	@SuppressWarnings({ "unchecked" })
	@Override
	public boolean duplicateRegistration(RegisterDataBean registerBean) {
		session = sessionFactory.openSession();
		boolean chk = false;
		String checkduplicatequery = UserSqlUtility.CHECK_DUPLICATE;

		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(checkduplicatequery).setCacheable(true);
			query.setParameter(0, registerBean.getLoginId());
			rows = query.list();
			if (query.list().size() > 0) {
				chk = true;
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return chk;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> fetchAdminDetails() {
		session = sessionFactory.openSession();

		List<String> adminDetails = null;

		String admindata = UserSqlUtility.FETCH_ADMIN_DETAILS;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(admindata).setCacheable(true);
			rows = query.list();
			adminDetails = new ArrayList(rows.size());
			for (Object row : rows) {

				adminDetails.add(row.toString());
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return adminDetails;
	}

	@SuppressWarnings({ "unused", "rawtypes" })
	@Override
	public int adminBean(AdminUserBean adminBean) {
		session = sessionFactory.openSession();
		CommonUtilities commonUtilities = new CommonUtilities();
		String hashedPassword = passwordHasher.signup(adminBean.getLoginId(), adminBean.getPassword());
		int adminId = 0;
		String sql_admin = UserSqlUtility.INSERT_ADMIN_QUERY;

		try {
			session.getTransaction().begin();

			Query query_admin = session.createSQLQuery(sql_admin).setCacheable(true);
			query_admin.setParameter(0, adminBean.getAdminId());
			query_admin.setParameter(1, adminBean.getAdminName());
			query_admin.setParameter(2, adminBean.getLoginId());
			query_admin.setParameter(3, hashedPassword);
			query_admin.setParameter(4, adminBean.getStatus());
			/*
			 * try { query_admin.setParameter(5,
			 * commonUtilities.currentDateTime()); } catch (ParseException e) {
			 * 
			 * e.printStackTrace(); }
			 */
			criteria = session.createCriteria(AdminUsers.class).setProjection(Projections.max("admin_id"));
			adminId = (Integer) criteria.uniqueResult();

			query_admin.executeUpdate();

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return adminId;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public int changeadminpass(AdminUserBean changeadminpass) {
		String hashedPassword = passwordHasher.signup(changeadminpass.getLoginId(), changeadminpass.getPassword());
		Integer adminId = 0;
		session = sessionFactory.openSession();
		String sql_changepassword = UserSqlUtility.UPADTE_ADMIN_PASSWORD;

		try {
			session.getTransaction().begin();
			Query query_changepassword = session.createSQLQuery(sql_changepassword).setCacheable(true);

			query_changepassword.setParameter(0, hashedPassword);

			/*
			 * try { query_editservices.setParameter(6,
			 * commonUtilities.currentDateTime()); } catch (ParseException e) {
			 * 
			 * e.printStackTrace(); }
			 */

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return adminId;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<AdminUserBean> fetchAdminData() {
		session = sessionFactory.openSession();

		List adminData = null;

		String admindetails = UserSqlUtility.FETCH_ADMIN_DATA;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(admindetails).setCacheable(true);
			rows = query.list();
			adminData = new ArrayList(rows.size());
			for (Object[] row : rows) {

				adminData.add(new AdminUserBean(0, null, row[0].toString(), row[1].toString(), null));
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return adminData;
	}

	public void updatedminpass(String loginId, String hashPassword) {
		Integer adminId = 0;
		session = sessionFactory.openSession();
		String sql_changepassword = UserSqlUtility.UPADTE_ADMIN_PASSWORD;

		try {
			session.getTransaction().begin();
			Query query_changepassword = session.createSQLQuery(sql_changepassword).setCacheable(true);

			query_changepassword.setParameter(0, hashPassword);
			query_changepassword.setParameter(1, loginId);

			query_changepassword.executeUpdate();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<RegisterDataBean> fetchSupplierData() {
		session = sessionFactory.openSession();

		List supplierData = null;

		String supplierdetails = UserSqlUtility.FETCH_SUPPLIER_DATA;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(supplierdetails).setCacheable(true);
			rows = query.list();
			supplierData = new ArrayList(rows.size());
			for (Object[] row : rows) {

				supplierData.add(new RegisterDataBean(0, row[0].toString(), row[1].toString(),null, null, null, null, null, null, null,
						null, null, 0, null));
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return supplierData;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void updatesupplierpass(String login, String hashPassword) {
		session = sessionFactory.openSession();
		String sql_changepassword = UserSqlUtility.UPADTE_SUPPLIER_PASSWORD;

		try {
			session.getTransaction().begin();
			Query query_changepassword = session.createSQLQuery(sql_changepassword).setCacheable(true);

			query_changepassword.setParameter(0, hashPassword);
			query_changepassword.setParameter(1, login);

			query_changepassword.executeUpdate();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@SuppressWarnings({ "rawtypes", "static-access" })
	@Override
	public boolean resetPassword(ResetPasswordBean resetPwd, String roleBean) {
		String hashedPassword = passwordHasher.generateHash("my-salt-text" + resetPwd.getPassword());
		// System.out.println("=====================hashedPassword================="+hashedPassword);
		boolean updateMsg = false;
		session = sessionFactory.openSession();
		try {
			session.getTransaction().begin();
			if (roleBean.equalsIgnoreCase("admin")) {
				// System.out.println("==============Admin==============");
				String sql_adminresetpassword = UserSqlUtility.RESET_ADMIN_PASSWORD;

				Query query_adminresetpassword = session.createSQLQuery(sql_adminresetpassword).setCacheable(true);
				query_adminresetpassword.setParameter(0, hashedPassword);
				query_adminresetpassword.setParameter(1, resetPwd.getLoginId());
				if (query_adminresetpassword.executeUpdate() > 0)
					updateMsg = true;

			} else {
				// System.out.println("==============Supplier==============");
				String sql_supplierresetpassword = UserSqlUtility.RESET_SUPPLIE_PASSWORD;

				Query query_supplierresetpassword = session.createSQLQuery(sql_supplierresetpassword)
						.setCacheable(true);

				query_supplierresetpassword.setParameter(0, hashedPassword);
				query_supplierresetpassword.setParameter(1, resetPwd.getLoginId());
				if (query_supplierresetpassword.executeUpdate() > 0)
					updateMsg = true;
			}

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return updateMsg;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public boolean insertToken(String nextToken) {

		session = sessionFactory.openSession();
		CommonUtilities commonUtilities = new CommonUtilities();
		boolean tokenId = false;
		String sql_token = UserSqlUtility.INSERT_TOKEN;

		try {
			session.getTransaction().begin();

			Query query_token = session.createSQLQuery(sql_token).setCacheable(true);
			query_token.setParameter(0, nextToken);

			try {
				System.out.println("================EXP Date==================" + commonUtilities.expiryDateTime());
				query_token.setParameter(1, commonUtilities.expiryDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}

			int i = query_token.executeUpdate();
			if (i > 0)
				tokenId = true;

			/*
			 * criteria =
			 * session.createCriteria(AgrimarkUsers.class).setProjection(
			 * Projections.max("supplier_id")); supplierId = (Integer)
			 * criteria.uniqueResult();
			 */

			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return tokenId;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public String fetchToken(String nextToken) {
		session = sessionFactory.openSession();

		String getToken = null;

		String tokendata = UserSqlUtility.FETCH_TOKEN_DETAILS;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(tokendata).setCacheable(true);
			query.setParameter(0, nextToken);
			List list = query.list();
			getToken = list.get(0).toString();
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return getToken;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public boolean checkForExistToken(String chkToken) {
		session = sessionFactory.openSession();
		CommonUtilities commonUtilities = new CommonUtilities();
		boolean chkExistToken = false;

		String tokendata = UserSqlUtility.FETCH_TOKEN_EXST_DETAILS;
		try {
			System.out.println(" chkToken ==========  " + chkToken);
			session.getTransaction().begin();
			query = session.createSQLQuery(tokendata).setCacheable(true);
			query.setParameter(0, chkToken);

			List list = query.list();
			System.out.println("========list.size() ====== " + list.size());
			if (list.size() > 0) {
				chkExistToken = true;
				// System.out.println("=============== "+list.get(0));
			}

			// chkexistToken=list.get(0).toString();
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return chkExistToken;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void clearToken(String clrtoken) {
		session = sessionFactory.openSession();
		String sqlproduct = UserSqlUtility.DELETE_TOKEN;

		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sqlproduct).setCacheable(true);
			query.setParameter(0, clrtoken);
			if (query.executeUpdate() > 0)
				System.out.println(clrtoken + " : Token Deleted Success");
			;

			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public String returnToken(String rtnToken) {
		session = sessionFactory.openSession();
		String rtnchkToken = null;

		String rtntokendata = UserSqlUtility.FETCH_RETURN_TOKEN;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(rtntokendata).setCacheable(true);
			query.setParameter(0, rtnToken);
			List list = query.list();
			System.out.println("========list.size() ====== " + list.size());
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return rtnchkToken;
	}

	@SuppressWarnings({ "static-access", "rawtypes", "unused" })
	@Override
	public int resetUserPassword(UserResetPassword userResetPassword, String loginUserId) {
		int userID=0;
		String existsSupplierID=null;
		Thread[] thread = new Thread[2];
		session = sessionFactory.openSession();
		session.getTransaction().begin();
		CommonUtilities cu=new CommonUtilities();
		String varifyquery = UserSqlUtility.PASSWORD_VARIFY_QUERY;
		String resetpwdquery = UserSqlUtility.RESET_PASSWORD_QUERY;
		String oldSaltedPassword = SALT + userResetPassword.getCurrentPassword();
		String oldHashedPassword = cu.generateHash(oldSaltedPassword);

		String saltedPassword = SALT + userResetPassword.getNewPassword();
		String hashedPassword = cu.generateHash(saltedPassword);

		varify_query = session.createSQLQuery(varifyquery).setCacheable(true);
		varify_query.setParameter(0, loginUserId);
		varify_query.setParameter(1, oldHashedPassword);
		Query query = session.createSQLQuery(resetpwdquery).setCacheable(true);
		//query.setParameter(0, loginUserId);
		try {
			List list = varify_query.list();
			if(list.size() > 0)
			{
			existsSupplierID=list.get(0).toString();
			}
			
			if(existsSupplierID !=null)
			{
				query.setParameter(0, hashedPassword);
				try {
					query.setParameter(1, cu.currentDateTime());
				} catch (ParseException e) {
					e.printStackTrace();
				}
				query.setParameter(2, loginUserId);

				query.executeUpdate();
				session.getTransaction().commit();
				userID=1;
				//ResetPasswordMail mail = new ResetPasswordMail();
				//mail.setParameters(httpSession.getAttribute("userId").toString(), httpSession.getAttribute("loggedInUser").toString(), userResetPassword.getNewPassword());
				//thread[1] = new Thread(mail);
				//thread[1].start();
			}
			else
			{
				userID=2;	
			}
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
			userID=0;
		} catch (PersistenceException e) {
			e.printStackTrace();
			userID=0;;
		} finally {
			session.close();
		}
		return userID;
	}

	@SuppressWarnings({ "static-access", "rawtypes" })
	@Override
	public int resetAdminPassword(UserResetPassword adminResetPassword, String loginUserId) {
		int userID=0;
		String existsAdminID=null;
		Thread[] thread = new Thread[2];
		session = sessionFactory.openSession();
		session.getTransaction().begin();
		CommonUtilities cu=new CommonUtilities();
		String varifyquery1 = UserSqlUtility.ADMIN_PASSWORD_VARIFY_QUERY;
		String resetpwdquery = UserSqlUtility.ADMIN_RESET_PASSWORD_QUERY;
		String oldSaltedPassword = SALT + adminResetPassword.getCurrentPassword();
		String oldHashedPassword = cu.generateHash(oldSaltedPassword);

		String saltedPassword = SALT + adminResetPassword.getNewPassword();
		String hashedPassword = cu.generateHash(saltedPassword);

		varify_query1 = session.createSQLQuery(varifyquery1).setCacheable(true);
		varify_query1.setParameter(0, loginUserId);
		varify_query1.setParameter(1, oldHashedPassword);
		Query query = session.createSQLQuery(resetpwdquery).setCacheable(true);
		//query.setParameter(0, loginUserId);
		try {
			List list = varify_query1.list();
			if(list.size() > 0)
			{
				existsAdminID=list.get(0).toString();
			}
			
			if(existsAdminID !=null)
			{
				query.setParameter(0, hashedPassword);
				try {
					query.setParameter(1, cu.currentDateTime());
				} catch (ParseException e) {
					e.printStackTrace();
				}
				query.setParameter(2, loginUserId);

				query.executeUpdate();
				session.getTransaction().commit();
				userID=1;
				//ResetPasswordMail mail = new ResetPasswordMail();
				//mail.setParameters(httpSession.getAttribute("userId").toString(), httpSession.getAttribute("loggedInUser").toString(), userResetPassword.getNewPassword());
				//thread[1] = new Thread(mail);
				//thread[1].start();
			}
			else
			{
				userID=2;	
			}
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
			userID=0;
		} catch (PersistenceException e) {
			e.printStackTrace();
			userID=0;;
		} finally {
			session.close();
		}
		return userID;
	}
}

package ekutir.sanimark.dao.Impl;

public class UserSqlUtility {

	public static final String INSERT_SUPPLIER_REGISTER_QUERY = "INSERT INTO dbsanimarkdlink.sani_supplier (login_id,password,business_name,primary_contact_first_name,primary_contact_middle_name,primary_contact_last_name,primary_Contact_Number,secondary_contact_name,secondary_contact_number,service_description,status,created_date_time,address) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String INSERT_SUPPLIER_ADDRESS_QUERY = "INSERT INTO dbsanimarkdlink.sani_address (addressLine1,addressLine2,addressLine3,block,city,district,state,country,pincode) VALUES (?,?,?,?,?,?,?,?,?)";
	
	public static final String SEARCH_ADMIN_MAIL_QUERY = "SELECT login_id, password, admin_name FROM dbsanimarkdlink.sani_admin where login_id=? ";
	public static final String SEARCH_SUPPLIER_MAIL_QUERY = "SELECT login_id,password,business_name FROM dbsanimarkdlink.sani_supplier where login_id=? ";

	public static final String CHECK_DUPLICATE = "SELECT login_id FROM dbsanimarkdlink.sani_supplier where login_id=? ";

	public static final String FETCH_ADMIN_DETAILS = "SELECT login_id FROM dbsanimarkdlink.sani_admin where status = 1 ";

	public static final String INSERT_ADMIN_QUERY = "INSERT INTO dbsanimarkdlink.sani_admin(admin_id,admin_name,login_id,password,status) VALUES (?,?,?,?,?) ";

	public static final String UPADTE_ADMIN_PASSWORD = "update dbsanimarkdlink.sani_admin set password= ? where login_id= ? ";

	public static final String FETCH_ADMIN_DATA = "SELECT login_id, password FROM dbsanimarkdlink.sani_admin where status = 1 ";

	public static final String FETCH_SUPPLIER_DATA = "SELECT login_id, password FROM dbsanimarkdlink.sani_supplier ";

	public static final String UPADTE_SUPPLIER_PASSWORD = "update dbsanimarkdlink.sani_supplier set password= ? where login_id= ?";

	public static final String RESET_ADMIN_PASSWORD = "update dbsanimarkdlink.sani_admin set password= ? where login_id= ?";

	public static final String RESET_SUPPLIE_PASSWORD = "update dbsanimarkdlink.sani_supplier set password= ? where login_id= ?";

	public static final String INSERT_TOKEN = "INSERT INTO dbsanimarkdlink.sani_tokens (token,token_expiryDate) VALUES (?,?);";

	public static final String FETCH_TOKEN_DETAILS = "SELECT token FROM dbsanimarkdlink.sani_tokens where token = ? ";

	public static final String FETCH_TOKEN_EXST_DETAILS = "SELECT token FROM dbsanimarkdlink.sani_tokens where token = ? and token_expiryDate < convert_tz(now(),'+00:00','+05:45') ";

	public static final String DELETE_TOKEN = "DELETE FROM dbsanimarkdlink.sani_tokens WHERE token = ? ";

	public static final String FETCH_RETURN_TOKEN = "SELECT token FROM dbsanimarkdlink.sani_tokens where token = ? ";

	public static final String PASSWORD_VARIFY_QUERY = "SELECT login_id FROM dbsanimarkdlink.sani_supplier where login_id= ? and password= ? ";

	public static final String RESET_PASSWORD_QUERY = "UPDATE dbsanimarkdlink.sani_supplier SET Password = ?, updated_date_time = ? WHERE login_id = ? ";

	public static final String ADMIN_PASSWORD_VARIFY_QUERY = "SELECT login_id FROM dbsanimarkdlink.sani_admin where login_id= ? and password= ? ";

	public static final String ADMIN_RESET_PASSWORD_QUERY = "UPDATE dbsanimarkdlink.sani_admin SET Password = ?, updated_date_time = ? WHERE login_id = ? ";

	public static final String INSERT_GATWAY_REGISTRATION_QUERY = "INSERT INTO ekutir_gateway.gtwy_registration (`phone_number`,`date_time_of_registration`,`status`,`application`) VALUES (?,?,?,?)";

	public static final String MAX_REGD_ID_QUERY = "SELECT max(registration_id) FROM ekutir_gateway.gtwy_registration ";

	public static final String INSERT_GATWAY_ADDRESS_QUERY = "INSERT INTO ekutir_gateway.gtwy_address "
			+ " (`address_line_1`,`address_line_2`,`address_line_3`,`block`,`district`,`city`,`state`,`country`, "
			+ " `postal_code`,`created_by`,`created_date_time`) VALUES (?,?,?,?,?,?,?,?,?,?,?) ";

	public static final String MAX_ADDRESS_ID_QUERY = "SELECT max(address_id) FROM ekutir_gateway.gtwy_address ";

	public static final String AUTH_ID_QUERY = "SELECT auth_id FROM ekutir_gateway.gtwy_auth where token=? and type=? ";

	public static final String INSERT_GATWAY_USER_QUERY = "INSERT INTO ekutir_gateway.`gtwy_user_master` "
			+ " (`registration`,`auth`,`first_name`,`password`,`middle_name`,`last_name`,`business_name`, "
			+ " `typeOfUser`,`address`,`status`,`created_by`,`created_date_time`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ";

	
	
}
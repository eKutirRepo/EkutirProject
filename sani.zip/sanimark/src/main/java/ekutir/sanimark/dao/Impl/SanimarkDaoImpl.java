package ekutir.sanimark.dao.Impl;

import org.springframework.http.MediaType;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import ekutir.sanimark.android.dto.AddressBean;
import ekutir.sanimark.android.dto.EditProductDataBean;
import ekutir.sanimark.android.dto.FetchBusinessCategoryBean;
import ekutir.sanimark.android.dto.FetchPCategoryBean;
import ekutir.sanimark.android.dto.FetchProductCategoryBean;
import ekutir.sanimark.android.dto.FetchProductsBean;
import ekutir.sanimark.android.dto.FetchServiceCategoryBean;
import ekutir.sanimark.android.dto.FetchServiceForApprovalBean;
import ekutir.sanimark.android.dto.FetchServicesDataBean;
import ekutir.sanimark.android.dto.FetchSupplierOrderDataBean;
import ekutir.sanimark.android.dto.ProductAndroidBean;
import ekutir.sanimark.android.dto.ProductDataBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ServicesDataBean;
import ekutir.sanimark.android.dto.ServicesEditDataBean;
import ekutir.sanimark.constant.AckSmsConstatnt;
import ekutir.sanimark.dao.SanimarkDao;
import ekutir.sanimark.dto.FetchProductServiceCategoryDto;
import ekutir.sanimark.model.Items;
import ekutir.sanimark.model.MicroEntrepreneurMsgs;
import ekutir.sanimark.model.Products;
import ekutir.sanimark.model.Services;
import ekutir.sanimark.utilities.CommonUtilities;
import ekutir.sanimark.view.beans.AckSms2Supplier;
import ekutir.sanimark.view.beans.CreateProductBean;
import ekutir.sanimark.view.beans.EditItemBean;
import ekutir.sanimark.view.beans.FetchItemsApprovalBean;
import ekutir.sanimark.view.beans.FetchItemsForProductBean;
import ekutir.sanimark.view.beans.FetchProductsForSani;
import ekutir.sanimark.view.beans.FetchSupplierItemsBean;
import ekutir.sanimark.view.beans.FetchSupplierServicesBean;
import ekutir.sanimark.view.beans.ItemBean;
import ekutir.sanimark.view.beans.ItemIdDetailsBean;
import ekutir.sanimark.view.beans.MicroEntrepreneurMsgBean;
import ekutir.sanimark.view.beans.ServiceCategoryBean;
import ekutir.sanimark.web.model.NewProduct;


@SuppressWarnings("deprecation")
@Repository("SanimarkDao")
public class SanimarkDaoImpl implements SanimarkDao {

	private static final Logger logger = Logger.getLogger(SanimarkDaoImpl.class);

	@Autowired
	@Qualifier(value = "hibernate4AnnotatedSessionFactoryForSanimark")
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	Session session = null;
	Transaction tx = null;
	private int userId = 0;
	private List<Object[]> rows = null;
	private List<Object[]> categoryrows = null;
	private List<Object[]> row = null;
	private Query query;
	private Query query1;
	private Query query2;
	private Query query3;
	private Query query7;
	private Query fetchquery;
	private List<Object[]> fetchrows = null;
	private List suppliercommhistory = null;

	private Criteria criteria;
	private Criteria criteria2;
	private Criteria criteria3;
	private Criteria criteria4;
	@Autowired
	HttpSession httpSession;
	CommonUtilities commonUtilities = new CommonUtilities();
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<RegisterDataBean> fetchSuppliersDetails() {
		session = sessionFactory.openSession();
		List suppliersDetails = null;
		String supplierDetailsQuery = SanimarkSqlUtility.FETCH_SUPPLIER_QUERY;
		String supplierAddressQuery = SanimarkSqlUtility.FETCH_SUPPLIER_ADDRESS_QUERY;
		List<RegisterDataBean> registerDataBeanList = new ArrayList<RegisterDataBean>();

		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(supplierDetailsQuery).setCacheable(true);
			rows = query.list();
			suppliersDetails = new ArrayList(rows.size());
			for (Object[] row : rows) {
				RegisterDataBean registerDataBean = new RegisterDataBean();
				AddressBean addr = new AddressBean();
				registerDataBean.setBusinessName(row[1].toString());
				registerDataBean.setLoginId(row[2].toString());
				registerDataBean.setSupplierId(Integer.parseInt(row[3].toString()));
				int addressId = Integer.parseInt(row[0].toString());
				fetchquery = session.createSQLQuery(supplierAddressQuery).setCacheable(true);
				fetchquery.setParameter(0, addressId);
				fetchrows = fetchquery.list();
				for (Object[] row1 : fetchrows) {
					System.out.println("=============================" + row1);
					addr.setAddressLine1(row1[0].toString());
					addr.setAddressLine2(commonUtilities.nullValueCheck(row1[1]));
					addr.setAddressLine3(commonUtilities.nullValueCheck(row1[2]));
					addr.setBlock(commonUtilities.nullValueCheck(row1[3]));
					addr.setCity(commonUtilities.nullValueCheck(row1[4]));
					addr.setDistrict(row1[5].toString());
					addr.setState(row1[6].toString());
					addr.setCountry(row1[7].toString());
					addr.setPincode(Integer.parseInt(row1[8].toString()));
				}
				registerDataBean.setAddress(addr);
				registerDataBean.setPrimaryContactName(row[4].toString());
				registerDataBean.setPrimaryContactNumber(row[5].toString());
				registerDataBean.setSecondaryContactName(commonUtilities.nullValueCheck(row[6]));
				registerDataBean.setSecondaryContactNumber(commonUtilities.nullValueCheck(row[7]));
				registerDataBean.setBusinessDescription(commonUtilities.nullValueCheck(row[8]));
				registerDataBean.setStatus(Integer.parseInt(row[9].toString()));
				// suppliersDetails.add(new
				// RegisterDataBean(null,null,row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),row[7].toString(),row[8].toString(),0,address));
				registerDataBeanList.add(registerDataBean);
			}

			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return registerDataBeanList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int rejectSupplier(int supplierId) {
		session = sessionFactory.openSession();
		String sqlsupplieraddress = SanimarkSqlUtility.SUPPLIER_ADDRESS;
		String sqlsupplier = SanimarkSqlUtility.SUPPLIER_REJECT;
		try {
			session.getTransaction().begin();
			query1 = session.createSQLQuery(sqlsupplieraddress).setCacheable(true);
			query1.setParameter(0, supplierId);
			query1.executeUpdate();

			query = session.createSQLQuery(sqlsupplier).setCacheable(true);
			query.setParameter(0, supplierId);
			query.executeUpdate();

			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return supplierId;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int approveSupplier(int supplierId) {
		session = sessionFactory.openSession();
		String sql = SanimarkSqlUtility.SUPPLIER_Approve;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sql).setCacheable(true);
			query.setParameter(0, supplierId);
			query.executeUpdate();
			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return supplierId;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<FetchBusinessCategoryBean> fetchBusinessCategory() {
		session = sessionFactory.openSession();
		List<FetchBusinessCategoryBean> category = new ArrayList<FetchBusinessCategoryBean>();

		String categorydata = SanimarkSqlUtility.FETCH_BUSINESS_CATEGORY_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(categorydata).setCacheable(true);
			rows = query.list();
			category = new ArrayList(rows.size());
			for (Object[] row : rows) {

				category.add(new FetchBusinessCategoryBean(Integer.parseInt(row[0].toString()), row[1].toString(),
						row[2].toString()));
			}

			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return category;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchProductsBean> fetchProductsDetails() {
		session = sessionFactory.openSession();
		// FetchProductDto fetchProdDto = new FetchProductDto();
		List<FetchProductsBean> fetchProducts = new ArrayList<FetchProductsBean>();
		String orderproductDetailsquery = SanimarkSqlUtility.FETCH_ORDER_PRODUCT_DETAILS_QUERY;
		try {
			session.getTransaction().begin();
			fetchquery = session.createSQLQuery(orderproductDetailsquery).setCacheable(true);
			fetchrows = fetchquery.list();
			fetchProducts = new ArrayList(fetchrows.size());
			for (Object[] row : fetchrows) {
				// query.setParameter(0,
				// Integer.parseInt(String.valueOf(row[0])));
				// rows = query.list();
				fetchProducts.add(new FetchProductsBean(Integer.parseInt(row[0].toString()),
						Integer.parseInt(row[1].toString()), commonUtilities.nullValueCheck(row[2].toString()),
						row[3].toString(), Integer.parseInt(row[4].toString()), row[5].toString(), row[6].toString(),
						row[7].toString(), row[8].toString(), row[9].toString(), Double.parseDouble(row[10].toString()),
						Integer.parseInt(row[11].toString()), Double.parseDouble(row[12].toString()),
						commonUtilities.base64ToString(row[13]), row[14].toString()));
			}

			// fetchProdDto.setProducts(fetchProducts);

			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchProducts;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public int addProduct(ProductDataBean productBean) {
		session = sessionFactory.openSession();
		logger.info(httpSession.getAttribute("userId"));
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		// int userId = 59;
		Integer productId = 0;
		Integer UnitId = 0;
		Integer supplierId = 0;
		CommonUtilities commonUtilities = new CommonUtilities();
		String sql_product = SanimarkSqlUtility.INSERT_NEWPRODUCT_QUERY;
		// String sql_units = SanimarkSqlUtility.INSERT_UNIT_DETAILS_QUERY;
		// String sql_xunits = NukkadkartSqlUtility.INSERT_XUNIT_QUERY;
		// String sql_prditems = SanimarkSqlUtility.INSERT_PRODUCT_ITEMS;
		String sql_xsupplier = SanimarkSqlUtility.INSERT_XSUPPLIER_QUERY;
		try {
			session.getTransaction().begin();
			Query query_product = session.createSQLQuery(sql_product).setCacheable(true);
			query_product.setParameter(0, productBean.getProductBrandName());
			query_product.setParameter(1, productBean.getCompanyName());
			query_product.setParameter(2, productBean.getProdCategoryId());
			query_product.setParameter(3, productBean.getWarranty());
			if (productBean.getDateOfManufacture().equals("")) {
				productBean.setDateOfManufacture(null);
			}
			query_product.setParameter(4, productBean.getDateOfManufacture());

			if (productBean.getExpiryDate().equals("")) {
				productBean.setExpiryDate(null);
			}
			query_product.setParameter(5, productBean.getExpiryDate());
			/*
			 * query_product.setParameter(6, productBean.getWhenToUse());
			 * query_product.setParameter(7, productBean.getHowToUse());
			 */
			query_product.setParameter(6, productBean.getProductFeatures());
			query_product.setParameter(7, productBean.getProductImg());
			query_product.setParameter(8, productBean.getMrp());
			query_product.setParameter(9, productBean.getDiscountInPercent());
			query_product.setParameter(10, productBean.getSellingPrice());
			query_product.setParameter(11, 0);

			try {
				query_product.setParameter(12, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_product.executeUpdate();

			criteria = session.createCriteria(NewProduct.class).setProjection(Projections.max("productid"));
			productId = (Integer) criteria.uniqueResult();

			Query query_xsupplier = session.createSQLQuery(sql_xsupplier).setCacheable(true);

			query_xsupplier.setParameter(0, productId);
			query_xsupplier.setParameter(1, userId);
			query_xsupplier.executeUpdate();

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return productId;
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	@Override
	public List<FetchSupplierOrderDataBean> fetchSuppliersOrderDetails() {
		session = sessionFactory.openSession();
		CommonUtilities commonUtilities = new CommonUtilities();
		/*logger.info("in DAO User Id : " + httpSession.getAttribute("userId"));
		if (httpSession.getAttribute("userId") != null) {
			userId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		} */
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		//int userId = 1;
		List suppliersDetails = null;
		String supplierorderDetailsQuery = SanimarkSqlUtility.FETCH_SUPPLIER_ORDER_QUERY;
		String supplierAddressQuery = SanimarkSqlUtility.FETCH_SUPPLIER_ORDER_ADDRESS_QUERY;
		List<FetchSupplierOrderDataBean> supplierDataBeanList = new ArrayList<FetchSupplierOrderDataBean>();

		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(supplierorderDetailsQuery).setCacheable(true);
			query.setParameter(0, userId);
			rows = query.list();
			suppliersDetails = new ArrayList(rows.size());
			for (Object[] row : rows) {
				FetchSupplierOrderDataBean supplierOrderDataBean = new FetchSupplierOrderDataBean();
				AddressBean addr = new AddressBean();
				supplierOrderDataBean.setOrderId(Integer.parseInt(row[1].toString()));
				supplierOrderDataBean.setItemId(Integer.parseInt(row[2].toString()));
				supplierOrderDataBean.setItemName(commonUtilities.nullValueCheck(row[3]));
				supplierOrderDataBean.setBrandName(row[4].toString());
				supplierOrderDataBean.setOrderQuantity(Double.parseDouble(row[5].toString()));
				supplierOrderDataBean.setMrp(Double.parseDouble(row[6].toString()));
				supplierOrderDataBean.setSellingPrice(Double.parseDouble(row[7].toString()));
				supplierOrderDataBean.setOrderDate(row[8].toString());
				supplierOrderDataBean.setOrderRequestFromDate(commonUtilities.nullValueCheck(row[9]));
				supplierOrderDataBean.setOrderRequestToDate(commonUtilities.nullValueCheck(row[10]));
				supplierOrderDataBean.setDeliveryDate(commonUtilities.nullValueCheck(row[11]));
				supplierOrderDataBean.setSupplier_ack_status(Integer.parseInt(row[12].toString()));
				supplierOrderDataBean.setCustomerId(Integer.parseInt(row[13].toString()));
				supplierOrderDataBean.setCustomerFName(commonUtilities.nullValueCheck(row[14]));
				supplierOrderDataBean.setCustomerMName(commonUtilities.nullValueCheck(row[15]));
				supplierOrderDataBean.setCustomerLName(commonUtilities.nullValueCheck(row[16]));
				supplierOrderDataBean.setCustomerMobileNumber(Long.parseLong(row[17].toString()));
				//supplierOrderDataBean.setProductId(Integer.parseInt(row[18].toString()));
				supplierOrderDataBean.setOrderPaymentMode(commonUtilities.nullValueCheck(row[18]));
				
				int addressId = Integer.parseInt(row[0].toString());
				fetchquery = session.createSQLQuery(supplierAddressQuery).setCacheable(true);
				fetchquery.setParameter(0, addressId);
				fetchrows = fetchquery.list();
				for (Object[] row1 : fetchrows) {
					addr.setAddressLine1(row1[0].toString());
					addr.setAddressLine2(row1[1].toString());
					addr.setAddressLine3(row1[2].toString());
					addr.setBlock(row1[3].toString());
					addr.setCity(row1[4].toString());
					addr.setDistrict(row1[5].toString());
					addr.setState(row1[6].toString());
					addr.setCountry(row1[7].toString());
					addr.setPincode(Integer.parseInt(row1[8].toString()));
				}
				supplierOrderDataBean.setAddress(addr);
				supplierDataBeanList.add(supplierOrderDataBean);
			}

			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return supplierDataBeanList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int acknowledgeOrder(int orderId,int productId) {
		session = sessionFactory.openSession();
		String sql = SanimarkSqlUtility.ACKNOWLEDGE_ORDER_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sql).setCacheable(true);
			try {
				query.setParameter(0, commonUtilities.currentDateTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			query.setParameter(1, orderId);
			 query.setParameter(2, productId);
			int j = query.executeUpdate();
			if(j>0){
				RestTemplate restTemplate = new RestTemplate();
				HttpHeaders headers = new HttpHeaders();
				MultiValueMap<String, String> parts = 
				         new LinkedMultiValueMap<String, String>();
				headers.setContentType(MediaType.MULTIPART_FORM_DATA);
				String contactNumber1 = SanimarkSqlUtility.FIND_PHONE_NUMBER;
				query = session.createSQLQuery(contactNumber1).setCacheable(true);
				query.setParameter(0, orderId);
				query.setParameter(1, productId);
				List<Object[]> list=query.list();
				String mobno=null;
				String productName=null;
				if(!list.isEmpty()){
					for(Object[] obj:list){
						mobno=obj[0].toString();
						productName=obj[1].toString();
					}
				}
				//Msg to registered user
				//String primaryContactNumber = null;
				String To="+91"+String.valueOf(mobno);	
				String From="EKAKSU";
				String TemplateName="ACKSUC";
				String prodName = "Khyeti";
				String VAR1=""+prodName+"";
				parts.add("From", From);
				parts.add("To", To);
				parts.add("TemplateName", TemplateName);
				parts.add("VAR1", VAR1);
				parts.add("VAR2", productName);
				HttpEntity<MultiValueMap<String, String>> requestEntity =
				         new HttpEntity<MultiValueMap<String, String>>(parts, headers);
				String urlmod="http://2factor.in/API/V1/{apiKey}/ADDON_SERVICES/SEND/TSMS";
				String apiKey = AckSmsConstatnt.TWO_PLAN_OTP_SERVICE_API_KEY;
				ResponseEntity<AckSms2Supplier> response = restTemplate.exchange(urlmod,HttpMethod.POST, requestEntity, AckSms2Supplier.class,apiKey);
			}
			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return orderId;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchProductServiceCategoryDto> fetchProductCategory() {
		session = sessionFactory.openSession();

		List productCategory = null;

		String categoryproductdata = SanimarkSqlUtility.FETCH_PRODUCT_CATEGORY_QUERY;
		// String categoryservicedata =
		// AgrimarkSqlUtility.FETCH_SERVICE_CATEGORY_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(categoryproductdata).setCacheable(true);
			System.out.println("===============query==================" + query);
			// query.setParameter(0, productCategories);
			row = query.list();
			productCategory = new ArrayList(row.size());
			for (Object[] row : row) {

				productCategory
						.add(new FetchProductCategoryBean(Integer.parseInt(row[0].toString()), row[1].toString()));
			}

			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return productCategory;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchProductServiceCategoryDto> fetchServiceCategory() {
		session = sessionFactory.openSession();

		List serviceCategory = null;

		String categoryservicedata = SanimarkSqlUtility.FETCH_SERVICE_CATEGORY_QUERY;
		try {
			session.getTransaction().begin();
			query1 = session.createSQLQuery(categoryservicedata).setCacheable(true);
			System.out.println("===============query1==================" + query1);
			rows = query1.list();
			serviceCategory = new ArrayList(rows.size());
			for (Object[] row : rows) {

				serviceCategory
						.add(new FetchServiceCategoryBean(Integer.parseInt(row[0].toString()), row[1].toString()));
			}

			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return serviceCategory;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int deleteProduct(int productId) {
		session = sessionFactory.openSession();
		String sqlproduct = SanimarkSqlUtility.DELETE_PRODUCT;
		//String sqlunit = SanimarkSqlUtility.DELETE_PRODUCT_UNIT;
		//String sqlxunit = SanimarkSqlUtility.DELETE_PRODUCT_X_UNIT;
		//String sqlsupplier = SanimarkSqlUtility.DELETE_PRODUCT_X_SUPPLIER;

		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sqlproduct).setCacheable(true);
			query.setParameter(0, productId);
			query.executeUpdate();

			/*query3 = session.createSQLQuery(sqlunit).setCacheable(true);
			query3.setParameter(0, productId);
			query3.executeUpdate();

			query2 = session.createSQLQuery(sqlxunit).setCacheable(true);
			query2.setParameter(0, productId);
			query2.executeUpdate();

			query1 = session.createSQLQuery(sqlsupplier).setCacheable(true);
			query1.setParameter(0, productId);
			query1.executeUpdate();*/

			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return productId;
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	@Override
	public int editProducts(EditProductDataBean editProducts) {
		session = sessionFactory.openSession();
		
		  if (httpSession.getAttribute("userId") == null) { userId = 1; } else
		  { userId = (int) httpSession.getAttribute("userId"); }
		 
		//Integer userId = 1;
		Integer productId = 0;
		Integer UnitId = 0;
		// Integer supplierId = 0;
		CommonUtilities commonUtilities = new CommonUtilities();
		String sql_product = SanimarkSqlUtility.EDIT_PRODUCTS_QUERY;
		String sql_unitid = SanimarkSqlUtility.SELECT_ITEM_ID;
		String sql_itemsdelete = SanimarkSqlUtility.DELETE_ITEMS_DETAILS_QUERY;
		String sql_insertItem = SanimarkSqlUtility.INSERT_ITEMS_DETAILS_QUERY;

		try {
			session.getTransaction().begin();
			Query query_product = session.createSQLQuery(sql_product).setCacheable(true);
			query_product.setParameter(0, editProducts.getProductName());
			query_product.setParameter(1, editProducts.getCategoryId());
			query_product.setParameter(2, editProducts.getProductDescription());
			query_product.setParameter(3, editProducts.getProductImage());
			query_product.setParameter(4, userId);

			try {
				query_product.setParameter(5, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_product.setParameter(6, editProducts.getProductId());
			int j = query_product.executeUpdate();

			if (j > 0) {
				productId = editProducts.getProductId();

				List<ItemIdDetailsBean> itemsBean = editProducts.getItemList();
				List<Integer> itemsDBIds = new ArrayList<Integer>();
				List<Integer> itemsBeanIds = new ArrayList<Integer>();
				// System.out.println(" itemsBean.size"+itemsBean.size());

				for (ItemIdDetailsBean eachItemBean : itemsBean) {
					itemsBeanIds.add(eachItemBean.getItemId());
				}
				for (ItemIdDetailsBean eachItemBean : itemsBean) {
					Query query_unitid = session.createSQLQuery(sql_unitid).setCacheable(true);
					query_unitid.setParameter(0, editProducts.getProductId());
					itemsDBIds = query_unitid.list();

					if (itemsDBIds.size() > 0 && !itemsDBIds.contains(eachItemBean.getItemId())) {

						// System.out.println(" else ItemId not in DB exist
						// insert : " + eachItemBean.getItemid());
						Query query_insertItem = session.createSQLQuery(sql_insertItem).setCacheable(true);
						query_insertItem.setParameter(0, productId);
						query_insertItem.setParameter(1, eachItemBean.getItemId());
						int i = query_insertItem.executeUpdate();

					}
				}

				for (Integer itemId : itemsDBIds) {
					if (!itemsBeanIds.contains(itemId)) {
						// System.out.println(" if ItemId not Exist in UI delete
						// from DB : ");
						Query query_itemsdelete = session.createSQLQuery(sql_itemsdelete).setCacheable(true);
						query_itemsdelete.setParameter(0, itemId);
						query_itemsdelete.setParameter(1, productId);
						int k = query_itemsdelete.executeUpdate();
					}
				}
			}

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return productId;
	}

	@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	@Override
	public int createServices(ServicesDataBean createServicesData) {
		CommonUtilities commonUtilities = new CommonUtilities();
		logger.info(httpSession.getAttribute("userId"));
		//int userId = 1;
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		Integer serviceId = 0;
		session = sessionFactory.openSession();
		String sql_services = SanimarkSqlUtility.INSERT_SERVICES_DETAILS;
		String sql_address_services = SanimarkSqlUtility.SELECT_SERVICES_ADDRESS_DETAILS;
		String sql_xservices = SanimarkSqlUtility.INSERT_SERVICEXSUPPLIER_QUERY;

		try {
			session = sessionFactory.openSession();
			session.getTransaction().begin();
			Query query_services = session.createSQLQuery(sql_services).setCacheable(true);

			query_services.setParameter(0, createServicesData.getServiceBrandName());
			query_services.setParameter(1, createServicesData.getContactDetails());
			query_services.setParameter(2, createServicesData.getServiceDescription());
			query_services.setParameter(3, createServicesData.getWhenToUse());
			query_services.setParameter(4, createServicesData.getHowToUse());
			query_services.setParameter(5, createServicesData.getConsumerBenifit());
			query_services.setParameter(6, createServicesData.getServCategoryId());
			query = session.createSQLQuery(sql_address_services).setCacheable(true);
			query.setParameter(0, userId);
			rows = query.list();
			System.out.println(userId + " ---- rows length : " + rows.size());
			for (Object[] row1 : rows) {
				query_services.setParameter(7, row1[0]);
				query_services.setParameter(8, row1[1]);
				query_services.setParameter(9, row1[2]);
				query_services.setParameter(10, row1[3]);
				query_services.setParameter(11, row1[4]);
				query_services.setParameter(12, row1[5]);
				query_services.setParameter(13, row1[6]);
			}

			try {
				query_services.setParameter(14, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			//query_services.setParameter(14, 1);

			query_services.executeUpdate();

			criteria = session.createCriteria(Services.class).setProjection(Projections.max("serviceid"));
			serviceId = (Integer) criteria.uniqueResult();

			Query query_xservices = session.createSQLQuery(sql_xservices).setCacheable(true);

			// System.out.println("======================userId========================"+userId);

			query_xservices.setParameter(0, serviceId);
			query_xservices.setParameter(1, userId);
			query_xservices.executeUpdate();

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return serviceId;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int approveProduct(int productId) {
		session = sessionFactory.openSession();
		String sql = SanimarkSqlUtility.PRODUCT_APPROVE;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sql).setCacheable(true);
			query.setParameter(0, productId);
			query.executeUpdate();
			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return productId;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<FetchServicesDataBean> fetchServicesDetails() {
		session = sessionFactory.openSession();
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		//int userId = 1;
		List servicedetails = null;

		String servicesdata = SanimarkSqlUtility.FETCH_SERVICE_DETAILS_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(servicesdata).setCacheable(true);
			query.setParameter(0, userId);
			rows = query.list();
			servicedetails = new ArrayList(rows.size());
			for (Object[] row : rows) {

				servicedetails.add(new FetchServicesDataBean(Integer.parseInt(row[0].toString()), row[1].toString(),
						row[2].toString(), row[3].toString(),
						row[4].toString(), commonUtilities.nullValueCheck(row[5]),
						commonUtilities.nullValueCheck(row[6]), commonUtilities.nullValueCheck(row[7]), Integer.parseInt(row[8].toString()), commonUtilities.nullValueCheck(row[9])));
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return servicedetails;
	}

	/*
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Override public List<FetchProductsBean> fetchProducts() { session =
	 * sessionFactory.openSession();
	 * logger.info("in DAO User Id : "+httpSession.getAttribute("userId")); if
	 * (httpSession.getAttribute("userId") == null) { userId = 1; } else {
	 * userId = (int) httpSession.getAttribute("userId"); } //userId = 59;
	 * FetchProductDto fetchProdDto = new FetchProductDto();
	 * List<FetchProductsBean> fetchProducts = new
	 * ArrayList<FetchProductsBean>();
	 * 
	 * //String fetchunitquery = NukkadkartSqlUtility.FETCH_UNITS_QUERY; String
	 * orderproductsquery = NukkadkartSqlUtility.FETCH_PRODUCT_DETAILS_QUERY;
	 * try { session.getTransaction().begin(); fetchquery =
	 * session.createSQLQuery(orderproductsquery).setCacheable(true);
	 * fetchquery.setParameter(0, userId); fetchrows = fetchquery.list();
	 * 
	 * for (Object[] row2 : fetchrows) { query =
	 * session.createSQLQuery(fetchunitquery).setCacheable(true);
	 * query.setParameter(0, Integer.parseInt(String.valueOf(row2[0]))); rows =
	 * query.list(); List<ProductUnitsBean> productUnitDetails = new
	 * ArrayList<ProductUnitsBean>(); for (Object[] row1 : rows) {
	 * productUnitDetails.add(new
	 * ProductUnitsBean(Integer.parseInt(row1[0].toString()),
	 * row1[1].toString(),Double.parseDouble(row1[2].toString()),commonUtilities
	 * .emptyIntegerValueCheck(row1[3]),Double.parseDouble(row1[4].toString())))
	 * ; } fetchProducts.add( new FetchProductsBean(c }
	 * fetchProdDto.setProducts(fetchProducts);
	 * 
	 * session.flush(); session.getTransaction().commit(); } catch
	 * (HibernateException e) { if (session.getTransaction() != null)
	 * session.getTransaction().rollback(); e.printStackTrace(); } catch
	 * (javax.persistence.PersistenceException e) { e.printStackTrace(); } catch
	 * (NullPointerException nxe) { nxe.printStackTrace(); } finally {
	 * session.close(); } return fetchProducts; }
	 */

	/*public List<FetchProductsBean> fetchProducts() {
		session = sessionFactory.openSession();

		List<FetchProductsBean> fetchProducts = new ArrayList<FetchProductsBean>();
		String orderproductsquery = SanimarkSqlUtility.FETCH_PRODUCT_DETAILS_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(orderproductsquery).setCacheable(true);
			rows = query.list();
			fetchProducts = new ArrayList(rows.size());
			for (Object[] row : rows) {

				fetchProducts.add(new FetchProductsBean(Integer.parseInt(row[0].toString()), 0, row[1].toString(),
						row[2].toString(), Integer.parseInt(row[3].toString()), row[4].toString(), row[5].toString(),
						row[6].toString(), row[7].toString(), row[8].toString(), Double.parseDouble(row[9].toString()),
						Integer.parseInt(row[10].toString()), Double.parseDouble(row[11].toString()),
						commonUtilities.base64ToString(row[12]), ""));
			}

			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return fetchProducts;
	}*/

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<FetchServiceForApprovalBean> fetchServicesApprovalDetails() {
		session = sessionFactory.openSession();

		List servicedetails = null;
		String servicesdata = SanimarkSqlUtility.FETCH_SERVICE_APPROVAL_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(servicesdata).setCacheable(true);
			rows = query.list();
			servicedetails = new ArrayList(rows.size());
			for (Object[] row : rows) {

				servicedetails.add(new FetchServiceForApprovalBean(Integer.parseInt(row[0].toString()),
						row[1].toString(), Integer.parseInt(row[2].toString()), row[3].toString(),
						row[4].toString(), row[5].toString(),
						commonUtilities.nullValueCheck(row[6]), commonUtilities.nullValueCheck(row[7]),
						commonUtilities.nullValueCheck(row[8]), Integer.parseInt(row[9].toString()), commonUtilities.nullValueCheck(row[10])));
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return servicedetails;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int approveService(int serviceId) {
		session = sessionFactory.openSession();
		String sql = SanimarkSqlUtility.SERVICES_APPROVED;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sql).setCacheable(true);
			query.setParameter(0, serviceId);
			query.executeUpdate();
			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return serviceId;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int deleteService(int serviceId) {
		session = sessionFactory.openSession();
		String sqlservice = SanimarkSqlUtility.DELETE_SERVICE;
		//String sqlxservice = SanimarkSqlUtility.DELETE_X_SERVICE;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sqlservice).setCacheable(true);
			query.setParameter(0, serviceId);
			query.executeUpdate();

			/*query1 = session.createSQLQuery(sqlxservice).setCacheable(true);
			query1.setParameter(0, serviceId);
			query1.executeUpdate();*/

			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return serviceId;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public int editService(ServicesEditDataBean editService) {
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		//int userId = 1;
		Integer serviceId = 0;
		session = sessionFactory.openSession();
		String sql_editservices = SanimarkSqlUtility.EDIT_SERVICES_DETAILS;

		try {
			session.getTransaction().begin();
			Query query_editservices = session.createSQLQuery(sql_editservices).setCacheable(true);

			query_editservices.setParameter(0, editService.getServiceBrandName());
			query_editservices.setParameter(1, editService.getContactDetails());
			query_editservices.setParameter(2, editService.getServiceDescription());
			query_editservices.setParameter(3, editService.getWhenToUse());
			query_editservices.setParameter(4, editService.getHowToUse());
			query_editservices.setParameter(5, editService.getConsumerBenifit());
			query_editservices.setParameter(6, editService.getServCategoryId());
			//query_editservices.setParameter(7, editService.getServCategoryName());

			try {
				query_editservices.setParameter(7, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_editservices.setParameter(8, editService.getServiceId());

			int servis = query_editservices.executeUpdate();
			if (servis > 0) {
				serviceId = editService.getServiceId();
			}

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return serviceId;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int rejectProduct(int productId) {
		session = sessionFactory.openSession();
		String sqlrjectproduct = SanimarkSqlUtility.REJECT_PRODUCT;
		String sqlrejectunit = SanimarkSqlUtility.REJECT_PRODUCT_UNIT;
		String sqlrejectxunit = SanimarkSqlUtility.REJECT_PRODUCT_X_UNIT;
		String sqlrejectsupplier = SanimarkSqlUtility.REJECT_PRODUCT_X_SUPPLIER;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sqlrjectproduct).setCacheable(true);
			query.setParameter(0, productId);
			query.executeUpdate();

			query3 = session.createSQLQuery(sqlrejectunit).setCacheable(true);
			query3.setParameter(0, productId);
			query3.executeUpdate();

			query2 = session.createSQLQuery(sqlrejectxunit).setCacheable(true);
			query2.setParameter(0, productId);
			query2.executeUpdate();

			query1 = session.createSQLQuery(sqlrejectsupplier).setCacheable(true);
			query1.setParameter(0, productId);
			query1.executeUpdate();

			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return productId;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int rejectService(int serviceId) {
		session = sessionFactory.openSession();
		String sqlreject = SanimarkSqlUtility.REJECT_SERVICE;
		String sqlrejectxservice = SanimarkSqlUtility.REJECT_X_SERVICE;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sqlreject).setCacheable(true);
			query.setParameter(0, serviceId);
			query.executeUpdate();

			query1 = session.createSQLQuery(sqlrejectxservice).setCacheable(true);
			query1.setParameter(0, serviceId);
			query1.executeUpdate();

			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return serviceId;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> fetchAdminDetails() {
		session = sessionFactory.openSession();

		List adminDetails = null;

		String admindata = SanimarkSqlUtility.FETCH_ADMIN_DETAILS;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(admindata).setCacheable(true);
			rows = query.list();
			adminDetails = new ArrayList(rows.size());
			for (Object row : rows) {

				adminDetails.add(row.toString());
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return adminDetails;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> fetchApprovalLogin(int itemId) {
		session = sessionFactory.openSession();

		List<String> idDetails = null;

		String iddata = SanimarkSqlUtility.FETCH_ID_DETAILS;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(iddata).setCacheable(true);
			query.setParameter(0, itemId);
			rows = query.list();
			idDetails = new ArrayList(rows.size());
			for (Object row : rows) {

				idDetails.add(row.toString());
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return idDetails;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> fetchSupplierApproval(int supplierId) {
		session = sessionFactory.openSession();

		List<String> supplierlogin = null;

		String sqlloginid = SanimarkSqlUtility.FETCH_SUPPLIER_ID_DETAILS;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sqlloginid).setCacheable(true);
			query.setParameter(0, supplierId);
			rows = query.list();
			supplierlogin = new ArrayList(rows.size());
			for (Object row : rows) {

				supplierlogin.add(row.toString());
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return supplierlogin;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<ProductDataBean> fetchSupplierProducts(int suplierid) {
		// TODO Auto-generated method stub
		session = sessionFactory.openSession();

		List supliierproduct = null;
		String suplierdata = SanimarkSqlUtility.FETCH_SUPLLIER_PRODUCT_QUERY;
		try {

			query = session.createSQLQuery(suplierdata).setCacheable(true);
			query.setParameter(0, suplierid);
			rows = query.list();
			supliierproduct = new ArrayList(rows.size());
			for (Object[] row : rows) {

				supliierproduct.add(new FetchProductsBean(Integer.parseInt(row[0].toString()), 0, row[1].toString(),
						row[2].toString(), Integer.parseInt(row[3].toString()), row[4].toString(), row[5].toString(),
						row[6].toString(), row[7].toString(), row[8].toString(), Double.parseDouble(row[9].toString()),
						Integer.parseInt(row[10].toString()), Double.parseDouble(row[11].toString()),
						commonUtilities.base64ToString(row[12]), ""));
			}

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return supliierproduct;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FetchPCategoryBean> fetchProdCategory() {
		session = sessionFactory.openSession();
		List productDataBean = null ;
		List<FetchPCategoryBean> fetchProdCategoryDetails = new ArrayList<FetchPCategoryBean>();
		String prodcategoryquery = SanimarkSqlUtility.FETCH_PRODUCT_CATEGORY_DEATILS;
		String productdetails = SanimarkSqlUtility.FETCH_PRODUCT_DEATILS;

		try {
			
			fetchquery = session.createSQLQuery(prodcategoryquery).setCacheable(true);
			categoryrows = fetchquery.list();
			
			for (Object[] row4 : categoryrows) {	
			query7 = session.createSQLQuery(productdetails).setCacheable(true);
			query7.setParameter(0, Integer.parseInt(row4[0].toString()));
			rows = query7.list();
			productDataBean = new ArrayList(rows.size());
			//List<FetchPCategoryBean> ordercategryDetails = new ArrayList<FetchPCategoryBean>();
			for (Object[] row : rows) {
				productDataBean.add(new ProductAndroidBean(Integer.parseInt(row[0].toString()),row[1].toString(),
						row[2].toString(), Integer.parseInt(row[3].toString()), row[4].toString(), row[5].toString(),
						row[6].toString(), row[7].toString(),commonUtilities.base64ToString(row[8]), Double.parseDouble(row[9].toString()),Integer.parseInt(row[10].toString()),Double.parseDouble(row[11].toString())));
			}
			fetchProdCategoryDetails.add(
					new FetchPCategoryBean(Integer.parseInt(row4[0].toString()), row4[1].toString(),productDataBean));
		}
		
		
			

		
			
		
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return fetchProdCategoryDetails;
	}

	@Override
	public int closeOrder(int orderId, int productId) {
		session = sessionFactory.openSession();
		String sql = SanimarkSqlUtility.CLOSED_ORDER_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sql).setCacheable(true);
			query.setParameter(0, orderId);
			 query.setParameter(1, productId);
			query.executeUpdate();
			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return orderId;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchProductsForSani> fetchSaniProducts() {
		session = sessionFactory.openSession();
		if (httpSession.getAttribute("userId") != null) {
			userId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		} 
		//Integer userId = 1 ;
		List<FetchProductsForSani> fetchSaniProducts = new ArrayList<FetchProductsForSani>();
		String ordersaniproductsquery = SanimarkSqlUtility.FETCH_SANI_PRODUCT_DETAILS_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(ordersaniproductsquery).setCacheable(true);
			query.setParameter(0, userId);
			rows = query.list();
			fetchSaniProducts = new ArrayList(rows.size());
			for (Object[] row : rows) {

				fetchSaniProducts.add(new FetchProductsForSani(Integer.parseInt(row[0].toString()), row[1].toString(),
						Integer.parseInt(row[2].toString()), row[3].toString(),commonUtilities.nullValueCheck(row[4]), Integer.parseInt(row[5].toString()), commonUtilities.base64ToString(row[6])));
			}

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return fetchSaniProducts;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchItemsForProductBean> fetchSaniProductItems(int productId) {
		session = sessionFactory.openSession();
		List<FetchItemsForProductBean> fetchSaniProductItems = new ArrayList<FetchItemsForProductBean>();
		String ordersaniproductitemsquery = SanimarkSqlUtility.FETCH_SANI_PRODUCT_ITEMS_DETAILS_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(ordersaniproductitemsquery).setCacheable(true);
			query.setParameter(0, productId);
			rows = query.list();
			fetchSaniProductItems = new ArrayList(rows.size());
			for (Object[] row : rows) {

				fetchSaniProductItems.add(new FetchItemsForProductBean(Integer.parseInt(row[0].toString()), commonUtilities.nullValueCheck(row[1]), commonUtilities.nullValueCheck(row[2]),
						Integer.parseInt(row[3].toString()), commonUtilities.emptyIntegerValueCheck(row[4]), commonUtilities.emptyIntegerValueCheck(row[5]) ,commonUtilities.nullValueCheck(row[6]),
						commonUtilities.base64ToString(row[7]), commonUtilities.nullValueCheck(row[8]),commonUtilities.nullValueCheck(row[9]),commonUtilities.nullValueCheck(row[10]),commonUtilities.nullValueCheck(row[11]), Integer.parseInt(row[12].toString()), commonUtilities.nullValueCheck(row[13])));
			}

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return fetchSaniProductItems;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchItemsForProductBean> fetchAllItems() {
		session = sessionFactory.openSession();
		if (httpSession.getAttribute("userId") != null) {
			userId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		} 
		//Integer userId = 1 ;
		List<FetchItemsForProductBean> fetchAllItems = new ArrayList<FetchItemsForProductBean>();
		String allitemsquery = SanimarkSqlUtility.FETCH_ALL_ITEMS_DETAILS_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(allitemsquery).setCacheable(true);
			query.setParameter(0, userId);
			rows = query.list();
			fetchAllItems = new ArrayList(rows.size());
			for (Object[] row : rows) {

				fetchAllItems.add(new FetchItemsForProductBean(Integer.parseInt(row[0].toString()), commonUtilities.nullValueCheck(row[1]), commonUtilities.nullValueCheck(row[2]),
						Integer.parseInt(row[3].toString()), commonUtilities.emptyIntegerValueCheck(row[4]), commonUtilities.emptyIntegerValueCheck(row[5]) ,commonUtilities.nullValueCheck(row[6]),commonUtilities.base64ToString(row[7]), commonUtilities.nullValueCheck(row[8]),commonUtilities.nullValueCheck(row[9]),commonUtilities.nullValueCheck(row[10]),commonUtilities.nullValueCheck(row[11]),Integer.parseInt(row[12].toString()), commonUtilities.nullValueCheck(row[13])));
			}

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return fetchAllItems;
	}

	@Override
	public int createItem(ItemBean createItemData) {
		CommonUtilities commonUtilities = new CommonUtilities();
		logger.info(httpSession.getAttribute("userId"));
		//int userId = 1;
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		Integer itemId = 0;
		session = sessionFactory.openSession();
		String sql_items = SanimarkSqlUtility.INSERT_ITEMS_DETAILS;
		String sql_supplieritems = SanimarkSqlUtility.INSERT_SUPPLIERXITEMS_DETAILS;

		try {
			session = sessionFactory.openSession();
			session.getTransaction().begin();
			Query query_items = session.createSQLQuery(sql_items).setCacheable(true);

			query_items.setParameter(0, createItemData.getItemName());
			query_items.setParameter(1, createItemData.getBrandName());
			query_items.setParameter(2, createItemData.getCategoryId());
			query_items.setParameter(3, createItemData.getMrp());
			query_items.setParameter(4, createItemData.getSellingPrice());
			query_items.setParameter(5, createItemData.getItemDescription());
			query_items.setParameter(6, createItemData.getProductImg());
			query_items.setParameter(7, createItemData.getWarranty());
			query_items.setParameter(8, createItemData.getDimension());
			query_items.setParameter(9, createItemData.getManufactureDate());
			query_items.setParameter(10, createItemData.getExpiryDate());
			query_items.setParameter(11, createItemData.getColor());
			
			query_items.setParameter(12, userId);

			try {
				query_items.setParameter(13, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}

			query_items.executeUpdate();
			
			criteria = session.createCriteria(Items.class).setProjection(Projections.max("itemid"));
			itemId = (Integer) criteria.uniqueResult();
			
			Query query_supplieritems = session.createSQLQuery(sql_supplieritems).setCacheable(true);
			
			query_supplieritems.setParameter(0,itemId);
			query_supplieritems.setParameter(1, userId);
			query_supplieritems.executeUpdate();

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return itemId;
	}

	@Override
	public int createProduct(CreateProductBean createProduct, List<ItemIdDetailsBean> itemList) {
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		//Integer userId = 1;
		session = sessionFactory.openSession();
		Integer productid = 0;
		//String producttype = "pan";
		String sql_addproduct = SanimarkSqlUtility.CREATE_PRODUCT;
		String sql_additem = SanimarkSqlUtility.CREATE_ITEM;
		String sql_pxsupplier = SanimarkSqlUtility.INSERT_PRODUCTXSUPPLIER_QUERY;
		try {

			session.getTransaction().begin();
			Query query_addproduct = session.createSQLQuery(sql_addproduct).setCacheable(true);
			
			query_addproduct.setParameter(0, createProduct.getProductName());
			query_addproduct.setParameter(1, createProduct.getCategoryId());
			query_addproduct.setParameter(2, createProduct.getProductDescription());
			query_addproduct.setParameter(3, userId);
			try {
				query_addproduct.setParameter(4, commonUtilities.currentDateTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			query_addproduct.setParameter(5, createProduct.getProductImage());
			query_addproduct.executeUpdate();
			criteria = session.createCriteria(Products.class).setProjection(Projections.max("productid"));
			productid = (Integer) criteria.uniqueResult();
			
			Query query_additem = session.createSQLQuery(sql_additem).setCacheable(true);
			Query query_pxsupplier = session.createSQLQuery(sql_pxsupplier).setCacheable(true);
			
			for (ItemIdDetailsBean itemlist : itemList) {
				query_additem.setParameter(0, productid);
				query_additem.setParameter(1, itemlist.getItemId());
				query_additem.executeUpdate();
			}
			query_pxsupplier.setParameter(0,productid);
			query_pxsupplier.setParameter(1, userId);
			query_pxsupplier.executeUpdate();
			
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return productid;
	}

	@Override
	public int approveItems(int itemId) {
		session = sessionFactory.openSession();
		String sql_approve = SanimarkSqlUtility.ITEM_APPROVE;
		String sql_memsg = SanimarkSqlUtility.INSERT_MSG_INTO_MEMSG;
		String msg = "New items on sale! Click to see more.";
		String createdBy = "SYSTEM";
		String messageType = "New";
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sql_approve).setCacheable(true);
			query.setParameter(0, itemId);
			int j = query.executeUpdate();
			if(j>0){
				query = session.createSQLQuery(sql_memsg).setCacheable(true);
				Query query_memsg = session.createSQLQuery(sql_memsg).setCacheable(true);
				query_memsg.setParameter(0, msg);
				try {
					query_memsg.setParameter(1, commonUtilities.currentDateTime());
				} catch (ParseException e) {

					e.printStackTrace();
				}
				query_memsg.setParameter(2, createdBy);
				query_memsg.setParameter(3, messageType);
				query_memsg.executeUpdate();
			}
			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return itemId;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> fetchServicesApprovalLogin(int serviceId) {
		session = sessionFactory.openSession();
		
		List<String> idDetails = null;

		String iddata = SanimarkSqlUtility.FETCH_SERVICE_ID_DETAILS;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(iddata).setCacheable(true);
			query.setParameter(0, serviceId);
			rows = query.list();
			idDetails = new ArrayList(rows.size());
			for (Object row : rows) {

				idDetails.add(row.toString());
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return idDetails;
	}

	@Override
	public int editItem(EditItemBean editItem) {
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		Integer itemId = 0;
		//int approvalStatus = 0;
		session = sessionFactory.openSession();
		String sql_edititem = SanimarkSqlUtility.EDIT_ITEM_DETAILS;
		
		try {
			session.getTransaction().begin();
			Query query_edititem = session.createSQLQuery(sql_edititem).setCacheable(true);
			
			query_edititem.setParameter(0, editItem.getItemName());
			query_edititem.setParameter(1, editItem.getBrandName());
			query_edititem.setParameter(2, editItem.getCategoryId());
			query_edititem.setParameter(3, editItem.getMrp());
			query_edititem.setParameter(4, editItem.getSellingPrice());
			query_edititem.setParameter(5, editItem.getWarranty());
			query_edititem.setParameter(6, editItem.getDimension());
			query_edititem.setParameter(7, editItem.getItemDescription());
			query_edititem.setParameter(8, editItem.getProductImg());
			if(editItem.getManufactureDate() !="")
			{
			query_edititem.setParameter(9, editItem.getManufactureDate());
			}
			else
			{
				query_edititem.setParameter(9, null);
			}
			if(editItem.getExpiryDate() !="")
			{
				query_edititem.setParameter(10, editItem.getExpiryDate());
			}
			else
			{
				query_edititem.setParameter(10, null);
			}
			query_edititem.setParameter(11, editItem.getColor());
			
			query_edititem.setParameter(12, userId);
			
			try {
				query_edititem.setParameter(13, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_edititem.setParameter(14, editItem.getItemId());
			
			int itms=query_edititem.executeUpdate();
			if(itms>0){
				itemId = editItem.getItemId();
			}
			System.out.println("itemId "+itemId);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return itemId;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<FetchItemsApprovalBean> fetchItemsforApproval() {
		session = sessionFactory.openSession();
		List<FetchItemsApprovalBean> fetchItemsForApproval = new ArrayList<FetchItemsApprovalBean>();
		String ordersaniproductitemsquery = SanimarkSqlUtility.FETCH_ITEMS_APPROVAL_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(ordersaniproductitemsquery).setCacheable(true);
			rows = query.list();
			fetchItemsForApproval = new ArrayList(rows.size());
			for (Object[] row : rows) {

				fetchItemsForApproval.add(new FetchItemsApprovalBean(Integer.parseInt(row[0].toString()), commonUtilities.nullValueCheck(row[1]), Integer.parseInt(row[2].toString()), commonUtilities.nullValueCheck(row[3]), commonUtilities.nullValueCheck(row[4]),
						Integer.parseInt(row[5].toString()), commonUtilities.emptyIntegerValueCheck(row[6]), commonUtilities.emptyIntegerValueCheck(row[7]) ,commonUtilities.nullValueCheck(row[8]),
						commonUtilities.base64ToString(row[9]), commonUtilities.nullValueCheck(row[10]),commonUtilities.nullValueCheck(row[11]),commonUtilities.nullValueCheck(row[12]),commonUtilities.nullValueCheck(row[13]), Integer.parseInt(row[14].toString()), commonUtilities.nullValueCheck(row[15]), commonUtilities.nullValueCheck(row[16])));
			}

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return fetchItemsForApproval;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<FetchSupplierItemsBean> fetchSupplierItems(int supplierId) {
		session = sessionFactory.openSession();
		List<FetchSupplierItemsBean> fetchSaniSupplierItems = new ArrayList<FetchSupplierItemsBean>();
		String ordersupplieritemsquery = SanimarkSqlUtility.FETCH_SUPPLIER_ITEMS_DETAILS_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(ordersupplieritemsquery).setCacheable(true);
			query.setParameter(0, supplierId);
			rows = query.list();
			fetchSaniSupplierItems = new ArrayList(rows.size());
			for (Object[] row : rows) {

				fetchSaniSupplierItems.add(new FetchSupplierItemsBean(Integer.parseInt(row[0].toString()), commonUtilities.nullValueCheck(row[1]), commonUtilities.nullValueCheck(row[2]),
						Integer.parseInt(row[3].toString()), commonUtilities.emptyIntegerValueCheck(row[4]), commonUtilities.emptyIntegerValueCheck(row[5]) ,commonUtilities.nullValueCheck(row[6]),
						commonUtilities.base64ToString(row[7]), commonUtilities.nullValueCheck(row[8]),commonUtilities.nullValueCheck(row[9]),commonUtilities.nullValueCheck(row[10]),commonUtilities.nullValueCheck(row[11]), Integer.parseInt(row[12].toString()), commonUtilities.nullValueCheck(row[13])));
			}

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return fetchSaniSupplierItems;
	}

	@Override
	public int deleteItem(int itemId) {
		session = sessionFactory.openSession();
		String sqlitem = SanimarkSqlUtility.DELETE_ITEM;
		String sqlitemsupplier = SanimarkSqlUtility.DELETE_ITEM_X_SUPPLIER;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sqlitem).setCacheable(true);
			query.setParameter(0, itemId);
			query.executeUpdate();
			
			query1 = session.createSQLQuery(sqlitemsupplier).setCacheable(true);
			query1.setParameter(0, itemId);
			query1.executeUpdate();

			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return itemId;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<FetchSupplierServicesBean> fetchSupplierServices(int supplierId) {
		session = sessionFactory.openSession();
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		List servicedetails = null;

		String servicesdata = SanimarkSqlUtility.FETCH_SUPPLIER_SERVICE_DETAILS_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(servicesdata).setCacheable(true);
			query.setParameter(0, supplierId);
			rows = query.list();
			servicedetails = new ArrayList(rows.size());
			for (Object[] row : rows) {

				servicedetails.add(new FetchSupplierServicesBean(Integer.parseInt(row[0].toString()), row[1].toString(),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),
						commonUtilities.nullValueCheck(row[6])));
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return servicedetails;
	}

	@Override
	public boolean updateAckStatus(int orderId, int productId) {
		session = sessionFactory.openSession();
		boolean closAackStatus = false;
		String sql = SanimarkSqlUtility.UPDATE_ACK_STATUS_CLOSE;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sql).setCacheable(true);
			try {
				query.setParameter(0, commonUtilities.currentDateTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			query.setParameter(1, orderId);
			query.setParameter(2, productId);
			
			if(query.executeUpdate()>0){
				closAackStatus = true;
			};
			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return closAackStatus;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean fetchBuycode(int orderId, int buyCode) {
		session = sessionFactory.openSession();
		boolean fetchbuycode = false;
		String buycodequery = SanimarkSqlUtility.FETCH_BUYCODE_DETAILS;
		
		try {
			session.getTransaction().begin();
			fetchquery = session.createSQLQuery(buycodequery).setCacheable(true);
			fetchquery.setParameter(0, orderId);
			fetchquery.setParameter(1, buyCode);
			fetchrows = fetchquery.list();
			if(fetchrows.size()>0){
				fetchbuycode = true;
			}
			
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchbuycode;
	}

	@Override
	public int sendMicroEntrepreneurMsg(MicroEntrepreneurMsgBean microEntrepreneurMsgData) {
		session = sessionFactory.openSession();
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		//int userId = 1;
		logger.info(httpSession.getAttribute("userId"));
		int messageId = 0;
		String createdBy = "SYSTEM";
		String messageType = "FRADMIN";
		String sql_memessages = SanimarkSqlUtility.INSERT_MESSAGE_DETAILS;
		
		try {
			session = sessionFactory.openSession();
			session.getTransaction().begin();
			Query query_memessages = session.createSQLQuery(sql_memessages).setCacheable(true);
			
			query_memessages.setParameter(0, microEntrepreneurMsgData.getMessagedescription());
			//query_memessages.setParameter(1, userId);
			try {
				query_memessages.setParameter(1, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_memessages.setParameter(2, createdBy);
			query_memessages.setParameter(3, messageType);
			
			query_memessages.executeUpdate();
			
			criteria = session.createCriteria(MicroEntrepreneurMsgs.class)
					.setProjection(Projections.max("messageId"));
			messageId = (Integer) criteria.uniqueResult();
			
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return messageId;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<ServiceCategoryBean> fetchServiceCategories() {
		session = sessionFactory.openSession();
		List<ServiceCategoryBean> servicecategory = new ArrayList<ServiceCategoryBean>();

		String categorydata = SanimarkSqlUtility.FETCH_SERVICE_CATEGORY_QUERY;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(categorydata).setCacheable(true);
			rows = query.list();
			servicecategory = new ArrayList(rows.size());
			for (Object[] row : rows) {

				servicecategory.add(new ServiceCategoryBean(Integer.parseInt(row[0].toString()), row[1].toString()));
			}

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return servicecategory;
	}

	

}
package ekutir.sanimark.dao.Impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ekutir.sanimark.android.dto.FetchPCategoryBean;
import ekutir.sanimark.android.dto.ProductAndroidBean;
import ekutir.sanimark.dao.CrmDao;
import ekutir.sanimark.erp.view.beans.crm.AdvertisementsBean;
import ekutir.sanimark.erp.view.beans.crm.CatalogBean;
import ekutir.sanimark.erp.view.beans.crm.CustomerCommDetailBean;
import ekutir.sanimark.erp.view.beans.crm.CustomerPlaceOrderBean;
import ekutir.sanimark.erp.view.beans.crm.FetchBusinessCategoryBean;
import ekutir.sanimark.erp.view.beans.crm.FetchClusterDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchCustomerDataBean;
import ekutir.sanimark.erp.view.beans.crm.FetchDispositionsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchItemDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchOrdersBean;
import ekutir.sanimark.erp.view.beans.crm.FetchPaymentModesBean;
import ekutir.sanimark.erp.view.beans.crm.FetchPriceChangeDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.LeadPlaceOrderItemBean;
import ekutir.sanimark.erp.view.beans.crm.OrderDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.OrderFollowUpDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.PriceChangeItemBean;
import ekutir.sanimark.erp.view.beans.crm.ProductdetailBean;
import ekutir.sanimark.model.erp.AddressErp;
import ekutir.sanimark.model.erp.CommunicationDisposition;
import ekutir.sanimark.model.erp.MeCustomerMaster;
import ekutir.sanimark.model.erp.OrderHeaderMaster;
import ekutir.sanimark.utilities.CommonUtilities;


@SuppressWarnings("deprecation")
@Repository("CrmDao")
public class CrmDaoimpl implements CrmDao {
	private static final Logger logger = Logger.getLogger(CrmDaoimpl.class);
	private static SessionFactory sessionFactory;

	@SuppressWarnings("static-access")
	@Autowired
	public CrmDaoimpl(SessionFactory sessionFactory) {
		try {
			this.sessionFactory = sessionFactory;
		} catch (HibernateException exception) {
			System.out.println("Problem creating session factory");
			exception.printStackTrace();
		}
	}

	private Session session;
	private List<Object[]> rows = null;
	private List<Object[]> outstandrows = null;
	private List<Object[]> fetchrows = null;
	private List<Object[]> productrows = null;
	private Query query;
	private Query queryrole;
	private Query outstandingquery;
	private Query canceldisablerows = null;
	private Query sqlcanceldisbale;
	private Query fetchquery;
	private Query productquery;
	private Query searchclosequery;
	@SuppressWarnings("rawtypes")
	private List searchCustomer = null;
	@SuppressWarnings("rawtypes")
	private List customercommhistory = null;
	@SuppressWarnings("rawtypes")
	private List orderfollowupquery = null;
	private Criteria criteria;
	@SuppressWarnings({ "rawtypes", "unused" })
	private List orderDetails = null;
	@SuppressWarnings("rawtypes")
	private List orderDetails1;
	@SuppressWarnings("rawtypes")
	private List orderDetails2 = null;
	private int userId = 0;
	private Query rolequery;
	private List<Object[]> rolerows = null;
	@Autowired
	HttpSession httpSession;
	CommonUtilities commonUtilities = new CommonUtilities();
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchCustomerDataBean> fetchCustomerData() {
		session = sessionFactory.openSession();
		List<FetchCustomerDataBean> customer = new ArrayList<FetchCustomerDataBean>();
		userId = (int) httpSession.getAttribute("userId");
		int roleid = (int) httpSession.getAttribute("roleId");
		// List customer=null;
		String customerdata = CrmSqlUtility.FETCH_CUSTOMER_QUERY;
		String customerdatarole = CrmSqlUtility.FETCH_CUSTOMER_ROLE_QUERY;
		try {
			//session.getTransaction().begin();
			query = session.createSQLQuery(customerdata).setCacheable(true);
			queryrole = session.createSQLQuery(customerdatarole).setCacheable(true);
			if(roleid != 5){
			rows = query.list();
			customer = new ArrayList(rows.size());
			for (Object[] row : rows) {
				
				

				customer.add(new FetchCustomerDataBean(Integer.parseInt(row[0].toString()), row[1].toString(),
						row[2].toString(), row[3].toString(), Integer.parseInt(row[4].toString()), row[5].toString(),
						row[6].toString(), row[7].toString(), row[8].toString(), row[9].toString(), row[10].toString(),
						row[11].toString(), row[12].toString(), Long.parseLong(row[13].toString()),
						Long.parseLong(row[14].toString()), Integer.parseInt(row[15].toString()), row[16].toString(),
						row[17].toString(),Integer.parseInt(row[18].toString()),commonUtilities.nullValueCheck(row[19])));
			}
				}else{
					queryrole.setParameter(0, userId);
					rows = queryrole.list();
					customer = new ArrayList(rows.size());
					for (Object[] rowrole : rows) {
						customer.add(new FetchCustomerDataBean(Integer.parseInt(rowrole[0].toString()), rowrole[1].toString(),
								rowrole[2].toString(), rowrole[3].toString(), Integer.parseInt(rowrole[4].toString()), rowrole[5].toString(),
								rowrole[6].toString(), rowrole[7].toString(), rowrole[8].toString(), rowrole[9].toString(), rowrole[10].toString(),
								rowrole[11].toString(), rowrole[12].toString(), Long.parseLong(rowrole[13].toString()),
								Long.parseLong(rowrole[14].toString()), Integer.parseInt(rowrole[15].toString()), rowrole[16].toString(),
								rowrole[17].toString(),Integer.parseInt(rowrole[18].toString()),commonUtilities.nullValueCheck(rowrole[19])));
						
					
				}
			}

			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return customer;
	}

	@Override
	public List<FetchClusterDetailsBean> fetchClusterDetails() {

		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int deleteCustomer(int customerId) {

		session = sessionFactory.openSession();
		String sql = CrmSqlUtility.CUSTOMER_DELETE;
		try {
			session.getTransaction().begin();
			query = session.createSQLQuery(sql).setCacheable(true);
			query.setParameter(0, customerId);
			query.executeUpdate();
			session.flush();
			session.getTransaction().commit();

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return customerId;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchCustomerDataBean> searchCustomer(String createdFromDate, String createdToDate) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date createdToDate1 = null;
		session = sessionFactory.openSession();
		String sql = CrmSqlUtility.SEARCH_CUSTOMER_QUERY;
		try {
			try {
				if (createdFromDate.equals(createdToDate)) {

					Date myDate = format.parse(createdToDate);
					createdToDate1 = (commonUtilities.addDays(myDate, 1));
				} else {
					Date myDate = format.parse(createdToDate);
					createdToDate1 = commonUtilities.addDays(myDate, 1);
				}
			} catch (ParseException e) {

				e.printStackTrace();
			}
			//session.getTransaction().begin();
			query = session.createSQLQuery(sql).setCacheable(true);
			query.setParameter(0, createdFromDate);
			query.setParameter(1, createdToDate1);
			rows = query.list();
			searchCustomer = new ArrayList(rows.size());
			for (Object[] row : rows) {
				searchCustomer.add(new FetchCustomerDataBean(Integer.parseInt(row[0].toString()), row[1].toString(),
						row[2].toString(), row[3].toString(), Integer.parseInt(row[4].toString()), row[5].toString(),
						row[6].toString(), row[7].toString(), row[8].toString(), row[9].toString(), row[10].toString(),
						row[11].toString(), row[12].toString(), Long.parseLong(row[13].toString()),
						Long.parseLong(row[14].toString()), Integer.parseInt(row[15].toString()), row[16].toString(),
						row[17].toString(),Integer.parseInt(row[18].toString()),commonUtilities.nullValueCheck(row[19])));
			}
			/*session.flush();
			session.getTransaction().commit();*/

		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return searchCustomer;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchBusinessCategoryBean> fetchBusinessCategory() {
		session = sessionFactory.openSession();
		List businessCategory = null;
		String businessCategoryquery = CrmSqlUtility.FETCH_BUZ_QUERY;
		try {
		//	session.getTransaction().begin();
			query = session.createSQLQuery(businessCategoryquery).setCacheable(true);
			rows = query.list();
			businessCategory = new ArrayList(rows.size());
			for (Object[] row : rows) {
				businessCategory.add(new FetchBusinessCategoryBean(Integer.parseInt(row[0].toString()),
						row[1].toString(), row[2].toString()));
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return businessCategory;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	/*public List<CommDetailsBean> fetchCustomerCommHistory(int customerid,int prevId) {
		session = sessionFactory.openSession();
		int commcost = 0;
		String custohistoryquery = CrmSqlUtility.CUSTOMER_HISTORY_QUERY;
		//String orderid =CrmSqlUtility.Order_ID_QUERY;
		try {
			//session.getTransaction().begin();
			query = session.createSQLQuery(custohistoryquery).setCacheable(true);
			query.setParameter(0, customerid);
			query.setParameter(1, prevId);
			rows = query.list();

			customercommhistory = new ArrayList(rows.size());
			for (Object[] row : rows) {
				commcost = commonUtilities.emptyIntegerValue(row[5]);
				customercommhistory.add(new LeadCommHistoryBean(row[0].toString(), row[1].toString(), row[2].toString(),
						row[3].toString(), row[4].toString(), commcost, 0, 0));
			}
			session.flush();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return customercommhistory;
	}*/

	//@SuppressWarnings({ "unchecked", "rawtypes" })
	//@Override
	public List<FetchDispositionsBean> fetchDispositions() {
		session = sessionFactory.openSession();
		List fetchDispositions = null;
		String dispositionsquery = CrmSqlUtility.FETCH_DISPO_QUERY;
		try {
			//session.getTransaction().begin();
			query = session.createSQLQuery(dispositionsquery).setCacheable(true);
			rows = query.list();
			fetchDispositions = new ArrayList(rows.size());
			for (Object[] row : rows) {
				fetchDispositions
						.add(new FetchDispositionsBean(Integer.parseInt(row[0].toString()), row[1].toString()));
			}

			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchDispositions;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchItemDetailsBean> fetchItemDetails() {
		session = sessionFactory.openSession();

		List fetchItemDetails = null;
		String ItemDetailsquery = CrmSqlUtility.FETCH_ITEM_DETAILS;
		try {
			//session.getTransaction().begin();
			query = session.createSQLQuery(ItemDetailsquery).setCacheable(true);
			rows = query.list();
			fetchItemDetails = new ArrayList(rows.size());
			for (Object[] row : rows) {
				String ItemImage = commonUtilities.base64ToString(row[4]);
				fetchItemDetails.add(new FetchItemDetailsBean(Integer.parseInt(row[0].toString()), row[1].toString(),
						row[2].toString(), Double.parseDouble(row[3].toString()), Double.parseDouble(row[4].toString()),ItemImage,"","",0));
			}

			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchItemDetails;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchPaymentModesBean> fetchPaymentModes() {
		session = sessionFactory.openSession();
		List fetchPaymentModes = null;
		String Paymentquery = CrmSqlUtility.FETCH_PAYMENT_QUERY;
		try {
			//session.getTransaction().begin();
			query = session.createSQLQuery(Paymentquery).setCacheable(true);
			rows = query.list();
			fetchPaymentModes = new ArrayList(rows.size());
			for (Object[] row : rows) {
				fetchPaymentModes
						.add(new FetchPaymentModesBean(Integer.parseInt(row[0].toString()), row[1].toString()));
			}

			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}

		return fetchPaymentModes;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> fetchOrders() {
		session = sessionFactory.openSession();
		FetchOrdersBean order = new FetchOrdersBean();
		List<FetchOrdersBean> fetchOrders = new ArrayList<FetchOrdersBean>();
		String fetchOrdersquery = CrmSqlUtility.FETCH_ORDER_QUERY;
		String orderDetailsquery = CrmSqlUtility.ORDER_DETAILS_QUERY;
		String outstanding = CrmSqlUtility.FETCH_OUTSTANDING;
		String canceldisbalequery = CrmSqlUtility.FETCH_CANCELDISBLE;
		
		try {
			//session.getTransaction().begin();

			fetchquery = session.createSQLQuery(fetchOrdersquery).setCacheable(true);
			fetchrows = fetchquery.list();
			for (Object[] row : fetchrows) {

				// fetchOrders.add(new
				// FetchOrdersBean(Integer.parseInt(row[0].toString()),Integer.parseInt(row[1].toString()),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),row[7].toString(),orderDetails1,
				// row[8].toString()));

				// for(Object[] frow : fetchrows){
				int leadId = Integer.parseInt(row[0].toString());
				query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
				query.setParameter(0, leadId);

				rows = query.list();
				orderDetails2 = new ArrayList(rows.size());
				for (Object[] row1 : rows) {
					
					orderDetails2.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
							Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
							"", commonUtilities.nullValueCheck(row1[4]),Double.parseDouble(row1[5].toString())));
					order.setOrderDetails(orderDetails2);
				}

				// }
				outstandingquery = session.createSQLQuery(outstanding).setCacheable(true);
				outstandingquery.setParameter(0, leadId);
				outstandrows = outstandingquery.list();
				double outstandingdata = Double.parseDouble((String.valueOf(outstandrows.get(0))));
				sqlcanceldisbale = session.createSQLQuery(canceldisbalequery).setCacheable(true);
				sqlcanceldisbale.setParameter(0, leadId);
				//canceldisablerows = sqlcanceldisbale.list();
				//int disblecancel = Integer.parseInt((String.valueOf(canceldisablerows.get(0))));
				fetchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
						Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(), row[4].toString(),
						row[5].toString(), row[6].toString(), row[7].toString(), orderDetails2, row[8].toString(),
						row[9].toString(),Integer.parseInt(row[10].toString()), outstandingdata,0));

			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchOrders;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<OrderDetailsBean> orderDetails() {
		session = sessionFactory.openSession();
		String orderDetailsquery = CrmSqlUtility.ORDER_DETAILS_QUERY;
		try {
			//session.getTransaction().begin();
			for (Object[] frow : fetchrows) {
				int leadId = Integer.parseInt(frow[0].toString());
				query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
				query.setParameter(0, leadId);

				rows = query.list();
				orderDetails1 = new ArrayList(rows.size());
				if (rows.toString() == " ") {
					orderDetails1 = null;
				} else {
					for (Object[] row : rows) {
						orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row[0].toString()), row[1].toString(),
								Double.parseDouble(row[2].toString()), Double.parseDouble(row[3].toString()),
								"", commonUtilities.nullValueCheck(row[4]),Double.parseDouble(row[5].toString())));

					}
				}
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return orderDetails1;
	}

	/*@SuppressWarnings("rawtypes")
	@Override
	public int addCustomer(FetchCustomerDataBean addCustomerData) {
		CommonUtilities commonUtilities = new CommonUtilities();
		logger.info(httpSession.getAttribute("userId"));
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		session = sessionFactory.openSession();
		Integer customerid = 0;
		Integer leadid = 0;
		String sql_address = CrmSqlUtility.INSERT_ADDRESSS_QUERY;
		String sql_addCustomer = CrmSqlUtility.INSERT_ADDCUSTOMER_MASTER_QUERY;

		try {

			session.getTransaction().begin();
			Query query_address = session.createSQLQuery(sql_address).setCacheable(true);
			query_address.setParameter(0, addCustomerData.getAddressLine1());
			query_address.setParameter(1, addCustomerData.getAddressLine2());
			query_address.setParameter(2, addCustomerData.getAddressLine3());
			query_address.setParameter(3, addCustomerData.getBlock());
			if (addCustomerData.getDistrict() == null) {
				query_address.setParameter(4, "");
			} else {
				query_address.setParameter(4, addCustomerData.getDistrict());
			}
			// query_address.setParameter(5, addCustomerData.getCity());
			query_address.setParameter(5, addCustomerData.getState());
			query_address.setParameter(6, addCustomerData.getCountry());
			query_address.setParameter(7, addCustomerData.getPostalCode());
			query_address.executeUpdate();
			criteria = session.createCriteria(AddressErp.class).setProjection(Projections.max("addressID"));
			Integer addressid = (Integer) criteria.uniqueResult();
			Query query_addcustomer = session.createSQLQuery(sql_addCustomer).setCacheable(true);
			query_addcustomer.setParameter(0, addCustomerData.getCustomerFName());
			query_addcustomer.setParameter(1, addCustomerData.getCustomerMName());
			query_addcustomer.setParameter(2, addCustomerData.getCustomerLName());
			query_addcustomer.setParameter(3, addressid);
			query_addcustomer.setParameter(4, addCustomerData.getBusinessName());
			query_addcustomer.setParameter(5, addCustomerData.getBusinessCategory());
			query_addcustomer.setParameter(6, addCustomerData.getDescription());
			query_addcustomer.setParameter(7, addCustomerData.getPrimaryPhone());
			query_addcustomer.setParameter(8, addCustomerData.getSecondaryPhone());
			query_addcustomer.setParameter(9, leadid);
			query_addcustomer.setParameter(10, userId);
			try {
				query_addcustomer.setParameter(11, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_addcustomer.setParameter(12, "active");
			query_addcustomer.setParameter(13, addCustomerData.getTinNo());
			query_addcustomer.executeUpdate();

			criteria = session.createCriteria(MeCustomerMaster.class).setProjection(Projections.max("customerID"));
			customerid = (Integer) criteria.uniqueResult();

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}

		return customerid;
	}*/

	@SuppressWarnings("rawtypes")
	@Override
	public int editCustomer(FetchCustomerDataBean editCustomer) {

		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		String sql_editcustomer = CrmSqlUtility.EDIT_CUSTOMER_QUERY;
		String sql_address = CrmSqlUtility.UPDATE_ADDRESS_QUERY;
		Integer customerid = 0;
		try {
			session = sessionFactory.openSession();
			session.getTransaction().begin();
			Query query_editcustomer = session.createSQLQuery(sql_editcustomer).setCacheable(true);
			Query query_editaddress = session.createSQLQuery(sql_address).setCacheable(true);

			query_editcustomer.setParameter(0, editCustomer.getCustomerFName());
			query_editcustomer.setParameter(1, editCustomer.getCustomerMName());
			query_editcustomer.setParameter(2, editCustomer.getCustomerLName());
			query_editcustomer.setParameter(3, editCustomer.getPrimaryPhone());
			query_editcustomer.setParameter(4, editCustomer.getSecondaryPhone());
			query_editcustomer.setParameter(5, editCustomer.getBusinessCategory());
			query_editcustomer.setParameter(6, editCustomer.getBusinessName());
			query_editcustomer.setParameter(7, editCustomer.getDescription());
			query_editcustomer.setParameter(8, userId);

			try {
				query_editcustomer.setParameter(9, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}
			query_editcustomer.setParameter(10, editCustomer.getCustomerId());
			query_editcustomer.executeUpdate();
			customerid = editCustomer.getCustomerId();
			query_editaddress.setParameter(0, editCustomer.getAddressLine1());
			query_editaddress.setParameter(1, editCustomer.getAddressLine2());
			query_editaddress.setParameter(2, editCustomer.getAddressLine3());
			query_editaddress.setParameter(3, editCustomer.getBlock());
			if (editCustomer.getDistrict() == null) {
				query_editaddress.setParameter(4, "");
			} else {
				query_editaddress.setParameter(4, editCustomer.getDistrict());
			}

			// query_editaddress.setParameter(5, editCustomer.getCity());
			query_editaddress.setParameter(5, editCustomer.getState());
			query_editaddress.setParameter(6, editCustomer.getCountry());
			query_editaddress.setParameter(7, editCustomer.getPostalCode());
			query_editaddress.setParameter(8, editCustomer.getAddressId());
			query_editaddress.executeUpdate();
			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return customerid;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public int saveCustomerCommDetails(CustomerCommDetailBean saveCustomerComm) {
		Integer commid = 0;
		userId = 1;
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}

		String sql_customercomm = CrmSqlUtility.INSERT_CUSTOMER_COMM;
		try {
			session = sessionFactory.openSession();
			session.getTransaction().begin();

			Query query_customercomm = session.createSQLQuery(sql_customercomm).setCacheable(true);
			query_customercomm.setParameter(0, saveCustomerComm.getCustomerId());
			query_customercomm.setParameter(1, saveCustomerComm.getCommunicationDate());
			query_customercomm.setParameter(2, saveCustomerComm.getCommMode());
			query_customercomm.setParameter(3, saveCustomerComm.getCommCost());
			query_customercomm.setParameter(4, saveCustomerComm.getCommDispositionId());
			query_customercomm.setParameter(5, saveCustomerComm.getCommunicationDetails());
			query_customercomm.setParameter(6, userId);
			

			query_customercomm.executeUpdate();
			criteria = session.createCriteria(CommunicationDisposition.class).setProjection(Projections.max("CommID"));
			commid = (Integer) criteria.uniqueResult();

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return commid;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public int placeOrder(CustomerPlaceOrderBean placeorderbean, List<LeadPlaceOrderItemBean> placeorderitemBean) {
		userId = 1;
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		CommonUtilities commonUtilities = new CommonUtilities();
		Integer orderId = 0;
		Integer status = 1;
		String sql_placeorder = CrmSqlUtility.INSERT_PLACEORDER_QUERY;
		String sql_placeitem = CrmSqlUtility.INSERT_ITEM_DETAILS_QUERY;

		try {
			session = sessionFactory.openSession();
			session.getTransaction().begin();
			Query query_placeorder = session.createSQLQuery(sql_placeorder).setCacheable(true);
			query_placeorder.setParameter(0, placeorderbean.getCustomerId());
			query_placeorder.setParameter(1, placeorderbean.getOrderAmount());
			query_placeorder.setParameter(2, placeorderbean.getOrderDiscount());
			query_placeorder.setParameter(3, placeorderbean.getDeliveryRequestedDate());
			query_placeorder.setParameter(4, placeorderbean.getOrderPaymentMode());
			// query_placeorder.setParameter(5, placeorderbean.getClusterID());
			query_placeorder.setParameter(5, status);
			query_placeorder.setParameter(6, userId);
			try {
				query_placeorder.setParameter(7, commonUtilities.currentDateTime());
			} catch (ParseException e) {

				e.printStackTrace();
			}

			query_placeorder.executeUpdate();
			criteria = session.createCriteria(OrderHeaderMaster.class).setProjection(Projections.max("OrderID"));
			orderId = (Integer) criteria.uniqueResult();
			System.out.println("frehfhfekfef"+orderId);
			Query query_placeitem = session.createSQLQuery(sql_placeitem).setCacheable(true);
			for (LeadPlaceOrderItemBean lpib : placeorderitemBean) {
				query_placeitem.setParameter(0, orderId);
				query_placeitem.setParameter(1, lpib.getItemId());
				query_placeitem.setParameter(2, lpib.getOrderQunatity());
				query_placeitem.executeUpdate();
			}

			
			/* criteria =
			  session.createCriteria(MeCustomerMaster.class).setProjection( Projections.max("CustomerID")); 
			int customerid =(Integer)criteria.uniqueResult();
			 */

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return orderId;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> searchOrders(String createdFromDate, String createdToDate, String myOrders) {
		session = sessionFactory.openSession();
		Date createdToDate1 = null;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		// userId=14;
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}
		// userId= (int) httpSession.getAttribute("userId");
		List<FetchOrdersBean> searchOrders = new ArrayList<FetchOrdersBean>();
		FetchOrdersBean order = new FetchOrdersBean();
		String fetchOrdersquery = CrmSqlUtility.SEARCH_ORDER_QUERY;
		String orderDetailsquery = CrmSqlUtility.SEARCH_ORDER_DETAILS_QUERY;
		String mydateOrdersquery = CrmSqlUtility.SEARCH_MYDATE_ORDER_QUERY;
		// String myOrdersquery = CrmSqlUtility.SEARCH_MYORDER_QUERY;
		String outstanding = CrmSqlUtility.FETCH_OUTSTANDING;
		try {
		//	session.getTransaction().begin();
			try {
				if (createdFromDate.equals(createdToDate)) {

					Date myDate = format.parse(createdToDate);
					createdToDate1 = (commonUtilities.addDays(myDate, 1));
				} else {
					Date myDate = format.parse(createdToDate);
					createdToDate1 = commonUtilities.addDays(myDate, 1);
				}
			} catch (ParseException e) {

				e.printStackTrace();
			}
			if (myOrders.equalsIgnoreCase("check") && createdFromDate != null) {
				fetchquery = session.createSQLQuery(mydateOrdersquery).setCacheable(true);
				fetchquery.setParameter(0, createdFromDate);
				fetchquery.setParameter(1, createdToDate1);
				fetchquery.setParameter(2, userId);
				fetchrows = fetchquery.list();
				for (Object[] row : fetchrows) {
					int leadId = Integer.parseInt(row[0].toString());
					query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
					query.setParameter(0, createdFromDate);
					query.setParameter(1, createdToDate1);
					query.setParameter(2, leadId);

					rows = query.list();
					orderDetails1 = new ArrayList(rows.size());
					for (Object[] row1 : rows) {
						orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
								Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
								"",commonUtilities.nullValueCheck(row1[4]),Double.parseDouble(row1[5].toString())));
						order.setOrderDetails(orderDetails1);
					}

					outstandingquery = session.createSQLQuery(outstanding).setCacheable(true);
					outstandingquery.setParameter(0, leadId);
					outstandrows = outstandingquery.list();
					double outstandingdata = Double.parseDouble((String.valueOf(outstandrows.get(0))));
					int disblecancel = 0;
					searchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
							Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(),
							row[4].toString(), row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1,
							row[8].toString(), row[9].toString(),Integer.parseInt(row[10].toString()), outstandingdata,disblecancel));
					// }

				}

			} else {
				try {
					if (createdFromDate.equals(createdToDate)) {

						Date myDate = format.parse(createdToDate);
						createdToDate1 = (commonUtilities.addDays(myDate, 1));
					} else {
						Date myDate = format.parse(createdToDate);
						createdToDate1 = commonUtilities.addDays(myDate, 1);
					}
				} catch (ParseException e) {

					e.printStackTrace();
				}
				fetchquery = session.createSQLQuery(fetchOrdersquery).setCacheable(true);
				fetchquery.setParameter(0, createdFromDate);
				fetchquery.setParameter(1, createdToDate1);
				fetchrows = fetchquery.list();
				for (Object[] row : fetchrows) {
					// searchOrders.add(new
					// FetchOrdersBean(Integer.parseInt(row[0].toString()),Integer.parseInt(row[1].toString()),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),row[7].toString(),orderDetails,
					// row[8].toString()));
					// for(Object[] frow : fetchrows){
					int leadId = Integer.parseInt(row[0].toString());
					query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
					query.setParameter(0, createdFromDate);
					query.setParameter(1, createdToDate1);
					query.setParameter(2, leadId);

					rows = query.list();
					orderDetails1 = new ArrayList(rows.size());
					for (Object[] row1 : rows) {
						orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
								Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
								row1[4].toString(), row1[5].toString(),Double.parseDouble(row1[6].toString())));
						order.setOrderDetails(orderDetails1);
					}
					outstandingquery = session.createSQLQuery(outstanding).setCacheable(true);
					outstandingquery.setParameter(0, leadId);
					outstandrows = outstandingquery.list();
					double outstandingdata = Double.parseDouble((String.valueOf(outstandrows.get(0))));
					searchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
							Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(),
							row[4].toString(), row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1,
							row[8].toString(), row[9].toString(),Integer.parseInt(row[10].toString()), outstandingdata,0));
					// }

				}
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return searchOrders;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> closeOrders() {

		session = sessionFactory.openSession();
		List<FetchOrdersBean> fetchOrders = new ArrayList<FetchOrdersBean>();
		FetchOrdersBean order = new FetchOrdersBean();
		String fetchOrdersquery = CrmSqlUtility.CLOSE_ORDER_QUERY;
		String orderDetailsquery = CrmSqlUtility.ORDER_DETAILS_QUERY;
		String outstanding = CrmSqlUtility.FETCH_OUTSTANDING;
		try {
			//session.getTransaction().begin();
			// query =
			// session.createSQLQuery(orderDetailsquery).setCacheable(true);
			// rows = query.list();
			// orderDetails=new ArrayList(rows.size());
			/*
			 * for(Object[] row : rows){ orderDetails.add(new
			 * OrderDetailsBean(Integer.parseInt(row[0].toString()),row[1].
			 * toString(),Double.parseDouble(row[2].toString()),Long.parseLong(
			 * row[3].toString()),row[4].toString(),row[5].toString()));
			 * 
			 * }
			 */
			fetchquery = session.createSQLQuery(fetchOrdersquery).setCacheable(true);
			fetchrows = fetchquery.list();
			for (Object[] row : fetchrows) {
				// fetchOrders.add(new
				// FetchOrdersBean(Integer.parseInt(row[0].toString()),Integer.parseInt(row[1].toString()),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),row[7].toString(),orderDetails,
				// row[8].toString()));
				// for(Object[] frow : fetchrows){
				int leadId = Integer.parseInt(row[0].toString());
				query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
				query.setParameter(0, leadId);

				rows = query.list();
				orderDetails1 = new ArrayList(rows.size());
				for (Object[] row1 : rows) {
					orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
							Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
							"", commonUtilities.nullValueCheck(row1[4]),Double.parseDouble(row1[5].toString())));
					order.setOrderDetails(orderDetails1);
				}
				outstandingquery = session.createSQLQuery(outstanding).setCacheable(true);
				outstandingquery.setParameter(0, leadId);
				outstandrows = outstandingquery.list();
				double outstandingdata = Double.parseDouble((String.valueOf(outstandrows.get(0))));
				fetchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
						Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(), row[4].toString(),
						row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1, row[8].toString(),
						row[9].toString(),Integer.parseInt(row[10].toString()), outstandingdata,0));
				// }

			}

			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchOrders;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> dropOrders() {
		session = sessionFactory.openSession();
		List<FetchOrdersBean> fetchOrders = new ArrayList<FetchOrdersBean>();
		FetchOrdersBean order = new FetchOrdersBean();
		String fetchOrdersquery = CrmSqlUtility.DROP_ORDER_QUERY;
		String orderDetailsquery = CrmSqlUtility.ORDER_DETAILS_QUERY;
		try {
			//session.getTransaction().begin();
			/*
			 * query =
			 * session.createSQLQuery(orderDetailsquery).setCacheable(true);
			 * rows = query.list(); orderDetails=new ArrayList(rows.size());
			 * for(Object[] row : rows){ orderDetails.add(new
			 * OrderDetailsBean(Integer.parseInt(row[0].toString()),row[1].
			 * toString(),Double.parseDouble(row[2].toString()),Long.parseLong(
			 * row[3].toString()),row[4].toString(),row[5].toString()));
			 * 
			 * }
			 */
			fetchquery = session.createSQLQuery(fetchOrdersquery).setCacheable(true);
			fetchrows = fetchquery.list();
			for (Object[] row : fetchrows) {
				// fetchOrders.add(new
				// FetchOrdersBean(Integer.parseInt(row[0].toString()),Integer.parseInt(row[1].toString()),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),row[7].toString(),orderDetails,
				// row[8].toString()));
				// for(Object[] frow : fetchrows){
				int leadId = Integer.parseInt(row[0].toString());
				query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
				query.setParameter(0, leadId);

				rows = query.list();
				orderDetails1 = new ArrayList(rows.size());
				for (Object[] row1 : rows) {
					orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
							Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
							"", commonUtilities.nullValueCheck(row1[4]),Double.parseDouble(row1[5].toString())));
					order.setOrderDetails(orderDetails1);
				}
				fetchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
						Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(), row[4].toString(),
						row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1, row[8].toString(),
						row[9].toString(), 0,0,0));
				// }

			}

			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchOrders;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> searchClosedOrders(String createdFromDate, String createdToDate, String myOrders) {

		session = sessionFactory.openSession();
		Date createdToDate1 = null;
		userId = (int) httpSession.getAttribute("userId");
		List<FetchOrdersBean> searchOrders = new ArrayList<FetchOrdersBean>();
		FetchOrdersBean order = new FetchOrdersBean();
		String searchCloseOrdersquery = CrmSqlUtility.SEARCH_CLOSED_ORDER_QUERY;
		String searchOrderDetailsquery = CrmSqlUtility.SEARCH_ORDER_DETAILS_QUERY;
		String mydateOrdersquery = CrmSqlUtility.SEARCH_MYCLOSED_ORDER_QUERY;
		try {
			//session.getTransaction().begin();
			try {
				if (createdFromDate.equals(createdToDate)) {
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					Date myDate = format.parse(createdToDate);
					createdToDate1 = (commonUtilities.addDays(myDate, 1));
				} else {
					Date myDate = format.parse(createdToDate);
					createdToDate1 = commonUtilities.addDays(myDate, 1);
				}
			} catch (ParseException e) {

				e.printStackTrace();
			}

			if (myOrders.equalsIgnoreCase("check") && createdFromDate != null) {
				fetchquery = session.createSQLQuery(mydateOrdersquery).setCacheable(true);
				fetchquery.setParameter(0, createdFromDate);
				fetchquery.setParameter(1, createdToDate1);
				fetchquery.setParameter(2, userId);
				fetchrows = fetchquery.list();
				for (Object[] row : fetchrows) {
					int leadId = Integer.parseInt(row[0].toString());
					searchclosequery = session.createSQLQuery(searchOrderDetailsquery).setCacheable(true);
					searchclosequery.setParameter(0, createdFromDate);
					searchclosequery.setParameter(1, createdToDate1);
					searchclosequery.setParameter(2, leadId);

					rows = searchclosequery.list();
					orderDetails1 = new ArrayList(rows.size());
					for (Object[] row1 : rows) {
						orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
								Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
								"",commonUtilities.nullValueCheck( row1[4]),Double.parseDouble(row1[5].toString())));
						order.setOrderDetails(orderDetails1);
					}

					searchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
							Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(),
							row[4].toString(), row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1,
							row[8].toString(), row[9].toString(), Integer.parseInt(row[10].toString()),0,0));
					// }
				}

			} else {
				try {
					if (createdFromDate.equals(createdToDate)) {
						SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
						Date myDate = format.parse(createdToDate);
						createdToDate1 = (commonUtilities.addDays(myDate, 1));
					} else {
						Date myDate = format.parse(createdToDate);
						createdToDate1 = commonUtilities.addDays(myDate, 1);
					}
				} catch (ParseException e) {

					e.printStackTrace();
				}
				fetchquery = session.createSQLQuery(searchCloseOrdersquery).setCacheable(true);
				fetchquery.setParameter(0, createdFromDate);
				fetchquery.setParameter(1, createdToDate1);
				fetchrows = fetchquery.list();
				for (Object[] row : fetchrows) {
					int leadId = Integer.parseInt(row[0].toString());
					query = session.createSQLQuery(searchOrderDetailsquery).setCacheable(true);
					query.setParameter(0, createdFromDate);
					query.setParameter(1, createdToDate1);
					query.setParameter(2, leadId);

					rows = query.list();
					orderDetails1 = new ArrayList(rows.size());
					for (Object[] row1 : rows) {
						orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
								Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
								row1[4].toString(), row1[5].toString(),Double.parseDouble(row1[6].toString())));
						order.setOrderDetails(orderDetails1);
					}
					searchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
							Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(),
							row[4].toString(), row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1,
							row[8].toString(), row[9].toString(), Integer.parseInt(row[10].toString()),0,0));
				}
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return searchOrders;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> searchDropedOrders(String createdFromDate, String createdToDate, String myOrders) {
		session = sessionFactory.openSession();
		Date createdToDate1 = null;
		userId = (int) httpSession.getAttribute("userId");
		List<FetchOrdersBean> searchOrders = new ArrayList<FetchOrdersBean>();
		FetchOrdersBean order = new FetchOrdersBean();
		String fetchOrdersquery = CrmSqlUtility.SEARCH_DROPED_ORDER_QUERY;
		String orderDetailsquery = CrmSqlUtility.SEARCH_ORDER_DETAILS_QUERY;
		String mydateOrdersquery = CrmSqlUtility.SEARCH_MYDROPED_ORDER_QUERY;
		try {
			//session.getTransaction().begin();
			try {
				if (createdFromDate.equals(createdToDate)) {
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					Date myDate = format.parse(createdToDate);
					createdToDate1 = (commonUtilities.addDays(myDate, 1));
				} else {
					Date myDate = format.parse(createdToDate);
					createdToDate1 = commonUtilities.addDays(myDate, 1);
				}
			} catch (ParseException e) {

				e.printStackTrace();
			}

			if (myOrders.equalsIgnoreCase("check") && createdFromDate != null) {
				fetchquery = session.createSQLQuery(mydateOrdersquery).setCacheable(true);
				fetchquery.setParameter(0, createdFromDate);
				fetchquery.setParameter(1, createdToDate1);
				fetchquery.setParameter(2, userId);
				fetchrows = fetchquery.list();
				for (Object[] row : fetchrows) {
					int leadId = Integer.parseInt(row[0].toString());
					query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
					query.setParameter(0, createdFromDate);
					query.setParameter(1, createdToDate1);
					query.setParameter(2, leadId);

					rows = query.list();
					orderDetails1 = new ArrayList(rows.size());
					for (Object[] row1 : rows) {
						orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
								Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
								"",commonUtilities.nullValueCheck( row1[4]),Double.parseDouble(row1[5].toString())));
						order.setOrderDetails(orderDetails1);
					}

					searchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
							Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(),
							row[4].toString(), row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1,
							row[8].toString(), row[9].toString(), 0,0,0));
					// }

				}
			} else {
				try {
					if (createdFromDate.equals(createdToDate)) {
						SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
						Date myDate = format.parse(createdToDate);
						createdToDate1 = (commonUtilities.addDays(myDate, 1));
					} else {
						Date myDate = format.parse(createdToDate);
						createdToDate1 = commonUtilities.addDays(myDate, 1);
					}
				} catch (ParseException e) {

					e.printStackTrace();
				}
				fetchquery = session.createSQLQuery(fetchOrdersquery).setCacheable(true);
				fetchquery.setParameter(0, createdFromDate);
				fetchquery.setParameter(1, createdToDate1);
				fetchrows = fetchquery.list();
				for (Object[] row : fetchrows) {
					// searchOrders.add(new
					// FetchOrdersBean(Integer.parseInt(row[0].toString()),Integer.parseInt(row[1].toString()),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),row[7].toString(),orderDetails,
					// row[8].toString()));
					for (Object[] frow : fetchrows) {
						int leadId = Integer.parseInt(frow[0].toString());
						query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
						query.setParameter(0, createdFromDate);
						query.setParameter(1, createdToDate1);
						query.setParameter(2, leadId);

						rows = query.list();
						orderDetails1 = new ArrayList(rows.size());
						for (Object[] row1 : rows) {
							orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()),
									row1[1].toString(), Double.parseDouble(row1[2].toString()),
									Double.parseDouble(row1[3].toString()), row1[4].toString(), row1[5].toString(),Double.parseDouble(row1[6].toString())));
							order.setOrderDetails(orderDetails1);
						}

						searchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
								Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(),
								row[4].toString(), row[5].toString(), row[6].toString(), row[7].toString(),
								orderDetails1, row[8].toString(), row[9].toString(), 0,0,0));
					}
				}
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return searchOrders;
	}

	@SuppressWarnings({ "rawtypes" })
	@Override
	public int saveOrderFollowUpDetail(OrderFollowUpDetailsBean saveOrderFollowUpData) {
		session = sessionFactory.openSession();
		Integer commid = 0;
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}

		String sql_orderfollowup = CrmSqlUtility.INSERT_ORDER_FOLLOW_UP;
		try {
			session = sessionFactory.openSession();
			session.getTransaction().begin();

			Query query_orderfollowup = session.createSQLQuery(sql_orderfollowup).setCacheable(true);
			query_orderfollowup.setParameter(0, saveOrderFollowUpData.getCustomerId());
			query_orderfollowup.setParameter(1, saveOrderFollowUpData.getOrderId());
			query_orderfollowup.setParameter(2, saveOrderFollowUpData.getCommunicationDate());
			query_orderfollowup.setParameter(3, saveOrderFollowUpData.getCommMode());
			query_orderfollowup.setParameter(4, saveOrderFollowUpData.getCommDisposition());
			query_orderfollowup.setParameter(5, saveOrderFollowUpData.getCommCost());
			query_orderfollowup.setParameter(6, saveOrderFollowUpData.getCommunicationDetails());
			query_orderfollowup.setParameter(7, userId);
			query_orderfollowup.setParameter(8,saveOrderFollowUpData.getPrevLeadId() );
			query_orderfollowup.executeUpdate();
			criteria = session.createCriteria(CommunicationDisposition.class).setProjection(Projections.max("CommID"));
			commid = (Integer) criteria.uniqueResult();

			session.getTransaction().commit();
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (PersistenceException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return commid;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<OrderFollowUpDetailsBean> fetchOrderFollowUpHistory(int orderId) {
		session = sessionFactory.openSession();
		int commcost = 0;
		// double outstandingAmount = 0;
		String orderfollowuphistoryquery = CrmSqlUtility.ORDER_FOLLOWUP_HISTORY_QUERY;
		try {
			//session.getTransaction().begin();
			query = session.createSQLQuery(orderfollowuphistoryquery).setCacheable(true);
			query.setParameter(0, orderId);
			rows = query.list();

			orderfollowupquery = new ArrayList(rows.size());
			for (Object[] row : rows) {
				commcost = commonUtilities.emptyIntegerValue(row[5]);
				// outstandingAmount
				// =commonUtilities.emptyIntegerValueCheck(row[7]);
				//orderfollowupquery.add(new LeadCommHistoryBean(row[0].toString(), row[1].toString(), row[2].toString(),
					//	row[3].toString(), row[4].toString(), commcost, 0, 0));
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return orderfollowupquery;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<FetchOrdersBean> fetchCustomerOrderHistory(int customerId) {
		session = sessionFactory.openSession();
		FetchOrdersBean order = new FetchOrdersBean();
		List<FetchOrdersBean> fetchOrders = new ArrayList<FetchOrdersBean>();
		String fetchcustomerOrdersquery = CrmSqlUtility.FETCH_CUSTOMER_ORDER_QUERY;
		String ordercustomerDetailsquery = CrmSqlUtility.ORDER_CUSTOMER_DETAILS_QUERY;
		String outstanding = CrmSqlUtility.FETCH_OUTSTANDING;
		try {
			//session.getTransaction().begin();

			fetchquery = session.createSQLQuery(fetchcustomerOrdersquery).setCacheable(true);
			fetchquery.setParameter(0, customerId);
			fetchrows = fetchquery.list();
			for (Object[] row : fetchrows) {
				query = session.createSQLQuery(ordercustomerDetailsquery).setCacheable(true);
				query.setParameter(0, Integer.parseInt(row[0].toString()));
				rows = query.list();
				orderDetails2 = new ArrayList(rows.size());
				for (Object[] row1 : rows) {
					orderDetails2.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
							Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
							"",commonUtilities.nullValueCheck( row1[4]),Double.parseDouble(row1[5].toString())));
					order.setOrderDetails(orderDetails2);
				}
				int orderId = Integer.parseInt(row[0].toString());
				outstandingquery = session.createSQLQuery(outstanding).setCacheable(true);
				outstandingquery.setParameter(0, orderId);
				outstandrows = outstandingquery.list();
				double outstandingdata = Double.parseDouble((String.valueOf(outstandrows.get(0))));
				fetchOrders.add(
						new FetchOrdersBean(Integer.parseInt(row[0].toString()), Integer.parseInt(row[1].toString()),
								row[2].toString(), row[3].toString(), row[4].toString(), row[5].toString(),
								row[6].toString(), row[7].toString(), orderDetails2, row[8].toString(), "",0, outstandingdata,0));

			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchOrders;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<CatalogBean> searchItemDetails(int itemid) {
		session = sessionFactory.openSession();
		List<CatalogBean> catalogdetails = new ArrayList<CatalogBean>();
		List searchItemDetails = null;
		//List productDetails = null;
		//List catalogdetails = null;
		String catalogquery = CrmSqlUtility.CATALOG_DETAILS;
		String productDetailsquery = CrmSqlUtility.PRODUCT_DETAILS;
		String searchItemDetailsquery = CrmSqlUtility.SEARCH_ITEM_DETAILS;
		try {
			//session.getTransaction().begin();
			
			fetchquery = session.createSQLQuery(catalogquery).setCacheable(true);
			//fetchquery.setParameter(0, itemid );
			fetchrows = fetchquery.list();
		
			for (Object[] catalogrow : fetchrows) {
			
				productquery = session.createSQLQuery(productDetailsquery).setCacheable(true);
				productquery.setParameter(0, Integer.parseInt(catalogrow[0].toString()));
				productrows = productquery.list();
				List productDetails = new ArrayList(productrows.size());
				for (Object[] productrow : productrows) {
					
			query = session.createSQLQuery(searchItemDetailsquery).setCacheable(true);
			query.setParameter(0, Integer.parseInt(productrow[0].toString()));
			rows = query.list();
			searchItemDetails = new ArrayList(rows.size());
			for (Object[] row : rows) {
				String ItemImage = commonUtilities.base64ToString(row[5]);
				//String itemName = commonUtilities.nullValueCheck(row[1]);
				searchItemDetails.add(new FetchItemDetailsBean(Integer.parseInt(row[0].toString()), commonUtilities.nullValueCheck(row[1]),
						commonUtilities.nullValueCheck(row[2]), commonUtilities.emptyIntegerValueCheck(row[3]), commonUtilities.emptyIntegerValueCheck(row[4]),ItemImage,commonUtilities.nullValueCheck(row[6]),commonUtilities.nullValueCheck(row[7]),Integer.parseInt(row[8].toString())));
			}
			productDetails.add(new ProductdetailBean(Integer.parseInt(productrow[0].toString()), commonUtilities.nullValueCheck(productrow[1]),commonUtilities.nullValueCheck(productrow[2]),searchItemDetails));
				}
				catalogdetails.add(new CatalogBean(Integer.parseInt(catalogrow[0].toString()), commonUtilities.nullValueCheck(catalogrow[1]),productDetails));
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} /*finally {
			session.close();
		}*/
		return catalogdetails;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> ordersCustomerHistory(int customerId, int orderId) {
		session = sessionFactory.openSession();
		FetchOrdersBean order = new FetchOrdersBean();
		List<FetchOrdersBean> fetchOrders = new ArrayList<FetchOrdersBean>();
		String customerOrdersdetail = CrmSqlUtility.HISTORY_CUSTOMER_ORDER_QUERY;
		String ordercustomerDetailsquery = CrmSqlUtility.ORDER_CUSTOMER_DETAILS_QUERY;
		try {
			//session.getTransaction().begin();

			fetchquery = session.createSQLQuery(customerOrdersdetail).setCacheable(true);
			fetchquery.setParameter(0, customerId);
			fetchquery.setParameter(1, orderId);
			fetchrows = fetchquery.list();
			for (Object[] row : fetchrows) {
				query = session.createSQLQuery(ordercustomerDetailsquery).setCacheable(true);
				query.setParameter(0, Integer.parseInt(row[0].toString()));
				rows = query.list();
				orderDetails2 = new ArrayList(rows.size());
				for (Object[] row1 : rows) {
					orderDetails2.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
							Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
							"",commonUtilities.nullValueCheck( row1[4]),Double.parseDouble(row1[5].toString())));
					order.setOrderDetails(orderDetails2);
				}
				fetchOrders.add(
						new FetchOrdersBean(Integer.parseInt(row[0].toString()), Integer.parseInt(row[1].toString()),
								"", "", "", row[2].toString(),
								row[3].toString(), row[4].toString(), orderDetails2, row[5].toString(), "",0, 0,0));

			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} /*finally {
			session.close();
		}*/
		return fetchOrders;
	}

	@Override
	public List<CatalogBean> fetchcatalog(int catalogid) {
		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<AdvertisementsBean> getAdvertisements(int masterkey) {
		
		session = sessionFactory.openSession();
		List	advsanimark = null ;
		String advquery = CrmSqlUtility.ADV_SANIMARK_QUERY;
		try {
			
		//	session.getTransaction().begin();
			query = session.createSQLQuery(advquery).setCacheable(true);
			
			rows = query.list();

			advsanimark = new ArrayList(rows.size());
			for (Object[] row : rows) {
				String Image = commonUtilities.base64ToString(row[2]);
				advsanimark.add(new AdvertisementsBean(Integer.parseInt(row[0].toString()), row[1].toString(), Image,row[3].toString(), row[4].toString(),Integer.parseInt(row[5].toString())));
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} /*finally {
			session.close();
		}*/
		return advsanimark;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<FetchPCategoryBean> advClicable(int catalogid) {
		
		session = sessionFactory.openSession();
		
		List productDetails = null;
		List searchItemDetails = null;
		//List productDetails = null;
		//List catalogdetails = null;
		//String catalogquery = CrmSqlUtility.CATALOG_DETAILS;
		String productDetailsquery = CrmSqlUtility.PRODUCT_DETAILS_ADV;
		//String searchItemDetailsquery = CrmSqlUtility.SEARCH_ITEM_DETAILS;
		try {
			//session.getTransaction().begin();
			
			//fetchquery = session.createSQLQuery(catalogquery).setCacheable(true);
			//fetchquery.setParameter(0, itemid );
			//fetchrows = fetchquery.list();
		
			//for (Object[] catalogrow : fetchrows) {
			
				productquery = session.createSQLQuery(productDetailsquery).setCacheable(true);
				productquery.setParameter(0, catalogid);
				productrows = productquery.list();
				 productDetails = new ArrayList(productrows.size());
				for (Object[] productrow : productrows) {
					
			//query = session.createSQLQuery(searchItemDetailsquery).setCacheable(true);
		/*	query.setParameter(0, Integer.parseInt(productrow[0].toString()));
			rows = query.list();
			searchItemDetails = new ArrayList(rows.size());
			for (Object[] row : rows) {
				String ItemImage = commonUtilities.base64ToString(row[4]);
				searchItemDetails.add(new FetchItemDetailsBean(Integer.parseInt(row[0].toString()), row[1].toString(),
						row[2].toString(), Double.parseDouble(row[3].toString()), ItemImage,Double.parseDouble(row[5].toString()),row[6].toString(),row[7].toString()));
			}*/
					productDetails.add(new ProductAndroidBean(Integer.parseInt(productrow[0].toString()),productrow[1].toString(),
							productrow[2].toString(), Integer.parseInt(productrow[3].toString()), productrow[4].toString(), productrow[5].toString(),
							productrow[6].toString(), productrow[7].toString(),commonUtilities.base64ToString(productrow[8]), Double.parseDouble(productrow[9].toString()),Integer.parseInt(productrow[10].toString()),Double.parseDouble(productrow[11].toString())));
				}
				//catalogdetails.add(new CatalogBean(Integer.parseInt(catalogrow[0].toString()), catalogrow[1].toString(),productDetails));
			//}
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} /*finally {
			session.close();
		}*/
		return productDetails;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<AdvertisementsBean> getSaleOffer() {
		
		session = sessionFactory.openSession();
		List	salesoffer = null ;
		String salesquery = CrmSqlUtility.ADV_SALESOFFER_QUERY;
		try {
			
			//session.getTransaction().begin();
			query = session.createSQLQuery(salesquery).setCacheable(true);
			
			rows = query.list();

			salesoffer = new ArrayList(rows.size());
			for (Object[] row : rows) {
				String Image = commonUtilities.base64ToString(row[1]);
				salesoffer.add(new AdvertisementsBean(0, row[0].toString(), Image,row[2].toString(), row[3].toString(),0));
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		}/* finally {
			session.close();
		}*/
		return salesoffer;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<AdvertisementsBean> getNewSaleOffer() {
		
		session = sessionFactory.openSession();
		
		List	newsalesoffer = null ;
		String newsalesquery = CrmSqlUtility.ADV_SALESOFFER_QUERY;
		try {
			
			//session.getTransaction().begin();
			query = session.createSQLQuery(newsalesquery).setCacheable(true);
			
			rows = query.list();

			newsalesoffer = new ArrayList(rows.size());
			for (Object[] row : rows) {
				String Image = commonUtilities.base64ToString(row[2]);
				newsalesoffer.add(new AdvertisementsBean(Integer.parseInt(row[0].toString()), row[1].toString(), Image,row[3].toString(), row[4].toString(),Integer.parseInt(row[5].toString())));
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		}/* finally {
			session.close();
		}*/
		return newsalesoffer;
	}

	/*@SuppressWarnings("unchecked")
	@Override
	public RoleActionBean getRoleAction() {
		
		if (httpSession.getAttribute("userId") == null) {
			userId = 1;
		} else {
			userId = (int) httpSession.getAttribute("userId");
		}	
	
          session = sessionFactory.openSession();
		
		RoleActionBean	roleActionBean = new RoleActionBean(); 
		String rolequery1 = CrmSqlUtility.ROLE_ACTION_QUERY;
		try {
		session.getTransaction().begin();
		rolequery = session.createSQLQuery(rolequery1).setCacheable(true);
		rolequery.setParameter(0, userId);
		rolerows = rolequery.list();

		//roleActionBean = new ArrayList(rows.size());
		for (Object[] row : rolerows) {
			roleActionBean.setFeature(row[0].toString());
			roleActionBean.setCreate(Integer.parseInt(row[1].toString()));
			roleActionBean.setUpdate(Integer.parseInt(row[2].toString()));
			roleActionBean.setRead(Integer.parseInt(row[3].toString()));
			roleActionBean.setDelete(Integer.parseInt(row[4].toString()));
			roleActionBean.setAcessLevel(row[5].toString());
			roleActionBean.setDiscount(Integer.parseInt(row[6].toString()));
			
			//roleActionBean.add(new RoleActionBean(Integer.parseInt(row[0].toString()), row[1].toString(),row[3].toString(), row[4].toString(),Integer.parseInt(row[5].toString())));
		}
		System.out.println(""+roleActionBean.getAcessLevel());
		httpSession.setAttribute("feature", roleActionBean.getFeature());
		
		session.flush();
		session.getTransaction().commit();
	} catch (HibernateException e) {
		if (session.getTransaction() != null)
			session.getTransaction().rollback();
		e.printStackTrace();
	} catch (javax.persistence.PersistenceException e) {
		e.printStackTrace();
	} catch (NullPointerException nxe) {
		nxe.printStackTrace();
	} finally {
		session.close();
	}
		
		return roleActionBean;
	}*/

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<AdvertisementsBean> getbiztips(int masterkey) {
		
		session = sessionFactory.openSession();
		List	biztips = null ;
		String biztipssanimark = CrmSqlUtility.BIZ_TIPS_SANIMARK_QUERY;
		try {
			
			//session.getTransaction().begin();
			query = session.createSQLQuery(biztipssanimark).setCacheable(true);
			
			rows = query.list();

			biztips = new ArrayList(rows.size());
			for (Object[] row : rows) {
				String Image = commonUtilities.base64ToString(row[1]);
				biztips.add(new AdvertisementsBean(0, row[0].toString(), Image,row[2].toString(), row[3].toString(),0));
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} /*finally {
			session.close();
		}*/
		return biztips;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> fetchPartialOrders() {
		session = sessionFactory.openSession();
		FetchOrdersBean order = new FetchOrdersBean();
		List<FetchOrdersBean> fetchPartialOrder = new ArrayList<FetchOrdersBean>();
		String fetchOrdersquery = CrmSqlUtility.FETCH_PARTIAL_ORDER_QUERY;
		String orderDetailsquery = CrmSqlUtility.PARTIAL_ORDER_DETAILS_QUERY;
		String outstanding = CrmSqlUtility.FETCH_OUTSTANDING;
		
		try {
			//session.getTransaction().begin();

			fetchquery = session.createSQLQuery(fetchOrdersquery).setCacheable(true);
			fetchrows = fetchquery.list();
			for (Object[] row : fetchrows) {

				// fetchPartialOrder.add(new
				// FetchOrdersBean(Integer.parseInt(row[0].toString()),Integer.parseInt(row[1].toString()),row[2].toString(),row[3].toString(),row[4].toString(),row[5].toString(),row[6].toString(),row[7].toString(),orderDetails1,
				// row[8].toString()));

				// for(Object[] frow : fetchrows){
				int orderId = Integer.parseInt(row[0].toString());
				query = session.createSQLQuery(orderDetailsquery).setCacheable(true);
				query.setParameter(0, orderId);

				rows = query.list();
				orderDetails2 = new ArrayList(rows.size());
				for (Object[] row1 : rows) {
					
					orderDetails2.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
							Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
							"", commonUtilities.nullValueCheck(row1[4]),Double.parseDouble(row1[5].toString())));
					order.setOrderDetails(orderDetails2);
				}

				// }
				outstandingquery = session.createSQLQuery(outstanding).setCacheable(true);
				outstandingquery.setParameter(0, orderId);
				outstandrows = outstandingquery.list();
				double outstandingdata = Double.parseDouble((String.valueOf(outstandrows.get(0))));
				fetchPartialOrder.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
						Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(), row[4].toString(),
						row[5].toString(), row[6].toString(), row[7].toString(), orderDetails2, row[8].toString(),
						row[9].toString(),0, outstandingdata,0));

			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return fetchPartialOrder;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<FetchOrdersBean> searchPartialOrders(String createdFromDate, String createdToDate, String myOrders) {
		session = sessionFactory.openSession();
		Date createdToDate1 = null;
		userId = (int) httpSession.getAttribute("userId");
		List<FetchOrdersBean> searchOrders = new ArrayList<FetchOrdersBean>();
		FetchOrdersBean order = new FetchOrdersBean();
		String searchPartialOrdersquery = CrmSqlUtility.SEARCH_PARTIAL_ORDER_QUERY;
		String searchPartialDetailsquery = CrmSqlUtility.SEARCH_PARTIAL_DETAILS_QUERY;
		String mydateOrdersquery = CrmSqlUtility.SEARCH_MYCLOSED_ORDER_QUERY;
		try {
			//session.getTransaction().begin();
			try {
				if (createdFromDate.equals(createdToDate)) {
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					Date myDate = format.parse(createdToDate);
					createdToDate1 = (commonUtilities.addDays(myDate, 1));
				} else {
					Date myDate = format.parse(createdToDate);
					createdToDate1 = commonUtilities.addDays(myDate, 1);
				}
			} catch (ParseException e) {

				e.printStackTrace();
			}

			if (myOrders.equalsIgnoreCase("check") && createdFromDate != null) {
				fetchquery = session.createSQLQuery(mydateOrdersquery).setCacheable(true);
				fetchquery.setParameter(0, createdFromDate);
				fetchquery.setParameter(1, createdToDate1);
				fetchquery.setParameter(2, userId);
				fetchrows = fetchquery.list();
				for (Object[] row : fetchrows) {
					int leadId = Integer.parseInt(row[0].toString());
					searchclosequery = session.createSQLQuery(searchPartialDetailsquery).setCacheable(true);
					searchclosequery.setParameter(0, createdFromDate);
					searchclosequery.setParameter(1, createdToDate1);
					searchclosequery.setParameter(2, leadId);

					rows = searchclosequery.list();
					orderDetails1 = new ArrayList(rows.size());
					for (Object[] row1 : rows) {
						orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
								Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
								"",commonUtilities.nullValueCheck( row1[4]),Double.parseDouble(row1[5].toString())));
						order.setOrderDetails(orderDetails1);
					}

					searchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
							Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(),
							row[4].toString(), row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1,
							row[8].toString(), row[9].toString(), 0,0,0));
					// }
				}

			} else {
				try {
					if (createdFromDate.equals(createdToDate)) {
						SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
						Date myDate = format.parse(createdToDate);
						createdToDate1 = (commonUtilities.addDays(myDate, 1));
					} else {
						Date myDate = format.parse(createdToDate);
						createdToDate1 = commonUtilities.addDays(myDate, 1);
					}
				} catch (ParseException e) {

					e.printStackTrace();
				}
				fetchquery = session.createSQLQuery(searchPartialOrdersquery).setCacheable(true);
				fetchquery.setParameter(0, createdFromDate);
				fetchquery.setParameter(1, createdToDate1);
				fetchrows = fetchquery.list();
				for (Object[] row : fetchrows) {
					int leadId = Integer.parseInt(row[0].toString());
					query = session.createSQLQuery(searchPartialDetailsquery).setCacheable(true);
					query.setParameter(0, createdFromDate);
					query.setParameter(1, createdToDate1);
					query.setParameter(2, leadId);

					rows = query.list();
					orderDetails1 = new ArrayList(rows.size());
					for (Object[] row1 : rows) {
						orderDetails1.add(new OrderDetailsBean(Integer.parseInt(row1[0].toString()), row1[1].toString(),
								Double.parseDouble(row1[2].toString()), Double.parseDouble(row1[3].toString()),
								row1[4].toString(), row1[5].toString(),Double.parseDouble(row1[6].toString())));
						order.setOrderDetails(orderDetails1);
					}
					searchOrders.add(new FetchOrdersBean(Integer.parseInt(row[0].toString()),
							Integer.parseInt(row[1].toString()), row[2].toString(), row[3].toString(),
							row[4].toString(), row[5].toString(), row[6].toString(), row[7].toString(), orderDetails1,
							row[8].toString(), row[9].toString(), 0,0,0));
				}
			}
			/*session.flush();
			session.getTransaction().commit();*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		} finally {
			session.close();
		}
		return searchOrders;
	}

	@Override
	public FetchPriceChangeDetailsBean checkForPriceChange(int customerId, List<OrderDetailsBean> orderDetails) {
		session = sessionFactory.openSession();
		FetchPriceChangeDetailsBean fetchPriceChangeDetailsBean=new FetchPriceChangeDetailsBean();
		String searchItemDetailsquery = CrmSqlUtility.SEARCH_ITEM_PRICECHANGE_DETAILS;
		try {
			double oldPrice = 0.0f;	
			double newPrice = 0.0f;
			List<PriceChangeItemBean> priceChangeItemBeanList=new ArrayList<PriceChangeItemBean>();
			for (OrderDetailsBean orderDetailsBean : orderDetails) {	
				query = session.createSQLQuery(searchItemDetailsquery).setCacheable(true);
				query.setParameter(0, orderDetailsBean.getItemId());
				rows = query.list();
				oldPrice = orderDetailsBean.getUnitPrice();
						
				for (Object[] row : rows) {
					
				newPrice = Double.parseDouble(row[3].toString());
				if(oldPrice-newPrice != 0){
				
				PriceChangeItemBean priceChangeItemBean=new PriceChangeItemBean();
				priceChangeItemBean.setNewItemId(Integer.parseInt(row[0].toString()));
				priceChangeItemBean.setNewUnitPrice(Double.parseDouble(row[3].toString()));
				priceChangeItemBean.setPriceDifference(Math.abs(newPrice-oldPrice));
				priceChangeItemBeanList.add(priceChangeItemBean);
				}
							   
				}
				
			  }
			if(priceChangeItemBeanList.size()>0){
			       fetchPriceChangeDetailsBean.setPriceChange(true);
			       fetchPriceChangeDetailsBean.setChangedItemList(priceChangeItemBeanList);
		    }else{
		    	fetchPriceChangeDetailsBean.setPriceChange(false);
		    }
			
			
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
		} catch (javax.persistence.PersistenceException e) {
			e.printStackTrace();
		} catch (NullPointerException nxe) {
			nxe.printStackTrace();
		}
		return fetchPriceChangeDetailsBean;
	}
}

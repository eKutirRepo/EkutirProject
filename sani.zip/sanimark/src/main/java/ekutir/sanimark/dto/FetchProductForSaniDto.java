package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.view.beans.FetchProductsForSani;

public class FetchProductForSaniDto {
	
	private List<FetchProductsForSani> products;

	public List<FetchProductsForSani> getProducts() {
		return products;
	}

	public void setProducts(List<FetchProductsForSani> products) {
		this.products = products;
	}

}

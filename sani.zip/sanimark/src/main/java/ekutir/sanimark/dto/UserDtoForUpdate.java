package ekutir.sanimark.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties("meShopPicture")
public class UserDtoForUpdate implements Serializable {

	private static final long serialVersionUID = 1L;
	private int userId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String eMailId;
	private String businessName;
	private String typeOfUser;
	private AddressDto address;
	private String shopLicenseNumber;
	private Date shopLicenseExpiryDate;
	private String shopPicture;
	private String profilePic;
	private String profileWriteUp;
	private String aadharNumber;
	private String tinNumber;
	private BigDecimal rating;
	private StatusDto status;
	private String bankAccountName;
	private String bankAccountNumber;
	private String bankName;
	private String bankIfscCode;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String geteMailId() {
		return eMailId;
	}

	public void seteMailId(String eMailId) {
		this.eMailId = eMailId;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getTypeOfUser() {
		return typeOfUser;
	}

	public void setTypeOfUser(String typeOfUser) {
		this.typeOfUser = typeOfUser;
	}

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}

	public String getShopLicenseNumber() {
		return shopLicenseNumber;
	}

	public void setShopLicenseNumber(String shopLicenseNumber) {
		this.shopLicenseNumber = shopLicenseNumber;
	}

	public Date getShopLicenseExpiryDate() {
		return shopLicenseExpiryDate;
	}

	public void setShopLicenseExpiryDate(String shopLicenseExpiryDate) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		dateFormat.setLenient(false);
		this.shopLicenseExpiryDate = dateFormat.parse(shopLicenseExpiryDate);
	}

	public String getProfileWriteUp() {
		return profileWriteUp;
	}

	public void setProfileWriteUp(String profileWriteUp) {
		this.profileWriteUp = profileWriteUp;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public BigDecimal getRating() {
		return rating;
	}

	public void setRating(BigDecimal rating) {
		this.rating = rating;
	}

	public void setShopLicenseExpiryDate(Date shopLicenseExpiryDate) {
		this.shopLicenseExpiryDate = shopLicenseExpiryDate;
	}

	public String getTinNumber() {
		return tinNumber;
	}

	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}

	public String getShopPicture() {
		return shopPicture;
	}

	public void setShopPicture(String shopPicture) {
		this.shopPicture = shopPicture;
	}

	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public String getBankAccountName() {
		return bankAccountName;
	}

	public void setBankAccountName(String bankAccountName) {
		this.bankAccountName = bankAccountName;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankIfscCode() {
		return bankIfscCode;
	}

	public void setBankIfscCode(String bankIfscCode) {
		this.bankIfscCode = bankIfscCode;
	}

}

package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.ProductDataBean;

public class SupplierProductsDto {
	private List<ProductDataBean> suplierproduct;

	public List<ProductDataBean> getSuplierproduct() {
		return suplierproduct;
	}

	public void setSuplierproduct(List<ProductDataBean> suplierproduct) {
		this.suplierproduct = suplierproduct;
	}

}

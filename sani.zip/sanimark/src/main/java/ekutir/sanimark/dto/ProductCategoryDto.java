package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.FetchPCategoryBean;

public class ProductCategoryDto {
	
	private List<FetchPCategoryBean> products;

	public List<FetchPCategoryBean> getProducts() {
		return products;
	}

	public void setProducts(List<FetchPCategoryBean> products) {
		this.products = products;
	}
	
}

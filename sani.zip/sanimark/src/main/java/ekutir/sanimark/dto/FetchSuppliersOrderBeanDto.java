package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.FetchSupplierOrderDataBean;

public class FetchSuppliersOrderBeanDto {
	
	private List<FetchSupplierOrderDataBean> orders;

	public List<FetchSupplierOrderDataBean> getOrders() {
		return orders;
	}

	public void setOrders(List<FetchSupplierOrderDataBean> orders) {
		this.orders = orders;
	}

}

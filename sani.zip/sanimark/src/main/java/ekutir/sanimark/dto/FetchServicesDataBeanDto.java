package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.FetchServicesDataBean;

public class FetchServicesDataBeanDto {
	
	private List<FetchServicesDataBean> Services;

	public List<FetchServicesDataBean> getServices() {
		return Services;
	}

	public void setServices(List<FetchServicesDataBean> services) {
		Services = services;
	}

}

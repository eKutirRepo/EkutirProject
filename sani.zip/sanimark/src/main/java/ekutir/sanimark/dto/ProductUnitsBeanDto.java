package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.ProductUnitsBean;

public class ProductUnitsBeanDto {
	
	private List<ProductUnitsBean> productUnits;

	public List<ProductUnitsBean> getProductUnits() {
		return productUnits;
	}

	public void setProductUnits(List<ProductUnitsBean> productUnits) {
		this.productUnits = productUnits;
	}

}

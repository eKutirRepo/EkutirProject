package ekutir.sanimark.constant;

public class AckSmsConstatnt {
	
	 public static final String TWO_PLAN_OTP_SERVICE_API_KEY = "136260fb-29b8-11e7-929b-00163ef91450";

}

package com.ekutir.gateway.utilities;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class EKutirJsonMapper extends ObjectMapper {
	private static final long serialVersionUID = 1L;

	public EKutirJsonMapper() {
		this.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	}
}

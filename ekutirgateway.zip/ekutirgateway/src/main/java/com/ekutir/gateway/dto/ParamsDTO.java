package com.ekutir.gateway.dto;
import java.io.Serializable;
public class ParamsDTO {
	
	private static final long serialVersionUID = 1L;
private String mfId;
private Integer licenseDetailsId;
private Integer masterFranchiseId;
private Integer appId;
public Integer getAppId() {
	return appId;
}
public void setAppId(Integer appId) {
	this.appId = appId;
}
public Integer getMasterFranchiseId() {
	return masterFranchiseId;
}
public void setMasterFranchiseId(Integer masterFranchiseId) {
	this.masterFranchiseId = masterFranchiseId;
}
public Integer getLicenseDetailsId() {
	return licenseDetailsId;
}
public void setLicenseDetailsId(Integer licenseDetailsId) {
	this.licenseDetailsId = licenseDetailsId;
}
public String getMfId() {
	return mfId;
}
public void setMfId(String mfId) {
	this.mfId = mfId;
}
private String appName;

public String getAppName() {
	return appName;
}
public void setAppName(String appName) {
	this.appName = appName;
}
}

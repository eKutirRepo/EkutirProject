package com.ekutir.gateway.dto;

import java.io.Serializable;

import com.ekutir.gateway.model.BusinessUser;

public class RegistrationInProcessUserDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private UserDtoForUpdate user;
	private StatusDto status;
	private String authKey;
	private String masterKey;
	private String typeOfUser;
	private BusinessUser businessUser;
	private RequestValidationDto validation;
	private Communication communication;
	private int connectedAppUserId;
	/*private boolean isBasicPro;

	

	public boolean isBasicPro() {
		return isBasicPro;
	}

	public void setBasicPro(boolean isBasicPro) {
		this.isBasicPro = isBasicPro;
	}
*/
	public String getTypeOfUser() {
		return typeOfUser;
	}

	public void setTypeOfUser(String typeOfUser) {
		this.typeOfUser = typeOfUser;
	}

	public Communication getCommunication() {
		return communication;
	}

	public void setCommunication(Communication communication) {
		this.communication = communication;
	}

	public UserDtoForUpdate getUser() {
		return user;
	}

	public RequestValidationDto getValidation() {
		return validation;
	}

	public void setValidation(RequestValidationDto validation) {
		this.validation = validation;
	}

	public void setUser(UserDtoForUpdate user) {
		this.user = user;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public BusinessUser getBusinessUser() {
		return businessUser;
	}

	public void setBusinessUser(BusinessUser businessUser) {
		this.businessUser = businessUser;
	}

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

	public String getMasterKey() {
		return masterKey;
	}

	public void setMasterKey(String masterKey) {
		this.masterKey = masterKey;
	}

	public int getConnectedAppUserId() {
		return connectedAppUserId;
	}

	public void setConnectedAppUserId(int connectedAppUserId) {
		this.connectedAppUserId = connectedAppUserId;
	}

}

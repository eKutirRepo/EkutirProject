package com.ekutir.gateway.controller;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ekutir.gateway.constants.GatewayConstants;
import com.ekutir.gateway.dto.Communication;
import com.ekutir.gateway.dto.CustomerAndLandDetails;
import com.ekutir.gateway.dto.CustomerDto;
import com.ekutir.gateway.dto.RegistrationDto;
import com.ekutir.gateway.dto.RegistrationInProcessUserDto;
import com.ekutir.gateway.dto.RequestValidationDto;
import com.ekutir.gateway.dto.StatusDto;
import com.ekutir.gateway.dto.UserDto;
import com.ekutir.gateway.model.MasterFranchiseUserMappingTO;
import com.ekutir.gateway.model.User;
import com.ekutir.gateway.services.HomeService;
import com.ekutir.gateway.services.RegistrationService;
import com.ekutir.gateway.utilities.GatewayUtilties;

@Controller
public class GatewayController {

	@Autowired
	RegistrationService registrationService;

	@Autowired
	HomeService homeService;

	@Autowired
	ServletContext servletContext;

	private static final Logger LOGGER = Logger.getLogger(GatewayController.class);

	@RequestMapping(value = { "/register/initiate" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> initiateRegistration(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communication) {
		RegistrationDto registrationDto = new RegistrationDto();
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		boolean isSystemError = false;
		RegistrationInProcessUserDto registrationInProcessUserDetails = registrationService.initiateUserRegistration(
				communication.getPhoneNumber(), tempAuthKey, communication.getApplicationCode());
		UserDto userDto = new UserDto();
		if (null != registrationInProcessUserDetails) {
			headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
			isRequestProcessingSucessfull = true;
			status = registrationInProcessUserDetails.getStatus();
			userDto.setTypeOfUser(registrationInProcessUserDetails.getTypeOfUser());
			registrationDto.setUser(userDto);
		} else {
			isSystemError = true;
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationDto.setStatus(status);
		RequestValidationDto validationDto = new RequestValidationDto();
		registrationDto.setRequestValidation(validationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		} else {
			if (isSystemError) {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				LOGGER.debug("Bad request");
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
			}
		}
	}

	@RequestMapping(value = { "/register/verifypasscode" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> verifyPasscode(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communication) {
		RegistrationDto registrationDto = new RegistrationDto();
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		boolean isSystemError = false;
		RegistrationInProcessUserDto registrationInProcessUserDetails = registrationService
				.verifyPasscodeForExistingUser(communication.getPassword(), communication.getPhoneNumber(), tempAuthKey,
						communication.getApplicationCode());
		if (null != registrationInProcessUserDetails) {
			headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
			isRequestProcessingSucessfull = true;
			status = registrationInProcessUserDetails.getStatus();
		} else {
			isSystemError = true;
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationDto.setStatus(status);
		RequestValidationDto validationDto = new RequestValidationDto();
		registrationDto.setRequestValidation(validationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		} else {
			if (isSystemError) {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
			}
		}
	}

	@RequestMapping(value = { "/register/verifyotp" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> verifyOtp(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communicationDto) {
		RegistrationDto registrationDto = new RegistrationDto();
		RequestValidationDto validationDto = GatewayUtilties.validateRequestForOtp(communicationDto);
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		boolean isSystemError = false;
		if ((validationDto != null) && (validationDto.isSuccesfullyValidated())) {
			StatusDto otpVerificationStatus = registrationService.verifyOtp(communicationDto, tempAuthKey);
			if (null != otpVerificationStatus) {
				if (null != otpVerificationStatus.getStatusCode()) {
					if (otpVerificationStatus.getStatusCode()
							.equalsIgnoreCase(GatewayConstants.OTP_VERIFICATION_COMPLETED_STATUS_CODE)) {
						isRequestProcessingSucessfull = true;
						headers.add(GatewayConstants.MASTER_KEY_TAG,
								GatewayUtilties.getMasterKey(communicationDto.getApplicationCode()));
					} else {
						isRequestProcessingSucessfull = false;
					}
				} else {
					isRequestProcessingSucessfull = false;
					isSystemError = true;
				}
				communicationDto.setStatus(GatewayConstants.VERIFIED_STATUS_TAG);
				status = otpVerificationStatus;
			} else {
				isSystemError = true;
				status.setStatusCode(GatewayConstants.OTP_VERIFICATION_FAILED_STATUS_CODE);
				status.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_OTP_VERIFICATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
				headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
			}
		} else {
			status.setStatusCode(GatewayConstants.OTP_VERIFICATION_FAILED_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.REGISTERATION_RESPONSE_OTP_VERIFICATION_FAILED_STAUTS_MESSAGE);
		}
		registrationDto.setStatus(status);
		registrationDto.setRequestValidation(validationDto);
		registrationDto.setCommunication(communicationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		} else {
			if (isSystemError) {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
			}
		}
	}

	@RequestMapping(value = { "/register/user" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationInProcessUserDto> register(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody RegistrationDto registrationDto) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		RequestValidationDto validation = null;
		validation = GatewayUtilties.validateRequestForMicroEntrepreneur(registrationDto);
		RegistrationInProcessUserDto registrationInProcessUserDetails = new RegistrationInProcessUserDto();
		if ((validation != null) && (validation.isSuccesfullyValidated())) {
			registrationInProcessUserDetails = registrationService.registerUser(registrationDto, tempAuthKey);
			if (null != registrationInProcessUserDetails) {
				if (registrationInProcessUserDetails.getStatus().getStatusCode()
						.equalsIgnoreCase(GatewayConstants.REGISTRATION_PROCESS_COMPLETED_STATUS_CODE)) {
					headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
					headers.add(GatewayConstants.MASTER_KEY_TAG, registrationInProcessUserDetails.getMasterKey());
					return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
							HttpStatus.OK);
				} else {
					headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
				}
				status = registrationInProcessUserDetails.getStatus();
			} else {
				status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
				status.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
				headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
			}
		} else {
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationInProcessUserDetails.setStatus(status);
		registrationInProcessUserDetails.setValidation(validation);
		return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
				HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/register/user/update" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationInProcessUserDto> register(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communication) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		RequestValidationDto validation = null;
		RegistrationInProcessUserDto registrationInProcessUserDetails = new RegistrationInProcessUserDto();
		if (null != communication.getTypeOfUser() && !communication.getTypeOfUser().isEmpty()) {
			validation = GatewayUtilties.checkRequestForReturningAndBusinessDelegateUser(communication);
		} else {
			status.setStatusCode(GatewayConstants.TYPE_OF_USER_MISSING_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.TYPE_OF_USER_MISSING_STATUS_MESSAGE);
			registrationInProcessUserDetails.setStatus(status);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
			return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
					HttpStatus.BAD_REQUEST);
		}
		boolean isRequestProcessingSucessfull = false;
		if ((validation != null) && (validation.isSuccesfullyValidated())) {
			registrationInProcessUserDetails = registrationService.registerReturningOrBusinessUser(communication,
					tempAuthKey);
			if (null != registrationInProcessUserDetails) {
				if (registrationInProcessUserDetails.getStatus().getStatusCode()
						.equalsIgnoreCase(GatewayConstants.REGISTRATION_PROCESS_COMPLETED_STATUS_CODE)) {
					headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
					headers.add(GatewayConstants.MASTER_KEY_TAG, registrationInProcessUserDetails.getMasterKey());
					isRequestProcessingSucessfull = true;
				} else {
					headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
				}
				status = registrationInProcessUserDetails.getStatus();
			} else {
				status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
				status.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
				headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
			}
		} else {
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationInProcessUserDetails.setStatus(status);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
					HttpStatus.OK);
		} else {
			return new ResponseEntity<RegistrationInProcessUserDto>(registrationInProcessUserDetails, headers,
					HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = { "/register/customer" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> registerCustomerForMe(@RequestHeader("auth_key") String authkey,
			@RequestBody CustomerDto customer) {
		RegistrationDto registrationDto = new RegistrationDto();
	
		RequestValidationDto validationDto = GatewayUtilties.validateRequestForCustomer(customer);
		
		RequestValidationDto verifyCustomerPhoneNumber = registrationService.verifyCustomerPhoneNumberAndAadhaarNumber(
				customer.getUserId(), customer.getCustPhoneNumber(), customer.getCustAadharNumber(),
				"REGISTER_CUSTOMER");
		validationDto.setSuccesfullyValidated(verifyCustomerPhoneNumber.isSuccesfullyValidated());
		if (!verifyCustomerPhoneNumber.isSuccesfullyValidated()) {
			validationDto.getListOfValidationMessagesWithCodes()
					.addAll(verifyCustomerPhoneNumber.getListOfValidationMessagesWithCodes());
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authkey);
		StatusDto statusDto = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		if ((validationDto != null) && (validationDto.isSuccesfullyValidated())) {
			if (registrationService.isCustomerExists(customer, authkey)) {
				statusDto.setStatusCode(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_CUSTOMER_ALREADY_REGISTERED_FOR_USER_STATUS_CODE);
				statusDto.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_CUSTOMER_ALREADY_REGISTERED_FOR_USER_STATUS_MESSAGE);
				isRequestProcessingSucessfull = false;
			} else {
				registrationService.insertCustomerDetails(customer, authkey);
				statusDto.setStatusCode(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_CODE);
				statusDto.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_MESSAGE);
				isRequestProcessingSucessfull = true;
			}
		} else {
			statusDto.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			statusDto.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
		}
		registrationDto.setStatus(statusDto);
		registrationDto.setRequestValidation(validationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		}
		return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = { "/customer/meandmyland/create" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<CustomerAndLandDetails> insertLandDetailsForCustomer(
			@RequestHeader("auth_key") String authkey, @RequestBody CustomerAndLandDetails customerLandDetails) {
		RequestValidationDto validationDto = GatewayUtilties.validateRequestForMeAndMyLand(customerLandDetails,
				GatewayConstants.CREATE_CUSTOMER_AND_LAND_DETAILS);
		RequestValidationDto verifyCustomerPhoneNumber = registrationService.verifyCustomerPhoneNumberAndAadhaarNumber(
				customerLandDetails.getCustomer().getUserId(), customerLandDetails.getCustomer().getCustPhoneNumber(),
				customerLandDetails.getCustomer().getCustAadharNumber(), "CREATE_LAND_DETAILS");
		validationDto.setSuccesfullyValidated(verifyCustomerPhoneNumber.isSuccesfullyValidated());
		if (!verifyCustomerPhoneNumber.isSuccesfullyValidated()) {
			validationDto.getListOfValidationMessagesWithCodes()
					.addAll(verifyCustomerPhoneNumber.getListOfValidationMessagesWithCodes());
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		headers.add(GatewayConstants.AUTH_KEY_TAG, authkey);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		if ((validationDto != null) && (validationDto.isSuccesfullyValidated())) {
			customerLandDetails = registrationService.insertCustomerAndLandDetails(customerLandDetails, authkey);
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_MESSAGE);
			isRequestProcessingSucessfull = true;
		} else {
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			customerLandDetails.setStatus(status);
		}
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<CustomerAndLandDetails>(customerLandDetails, headers, HttpStatus.OK);
		}
		return new ResponseEntity<CustomerAndLandDetails>(customerLandDetails, headers, HttpStatus.BAD_REQUEST);
	}
	
	@RequestMapping(value = { "/register/updatepasscode" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.POST }, consumes = { "application/json" })
	public ResponseEntity<RegistrationDto> updatepasscode(@RequestHeader("auth_key") String tempAuthKey,
			@RequestBody Communication communication) {
		RegistrationDto registrationDto = new RegistrationDto();
		HttpHeaders headers = new HttpHeaders();
		headers.add(GatewayConstants.HEADER_CONTENT_TYPE_TAG, GatewayConstants.HEADER_CONTENT_TYPE_JSON);
		StatusDto status = new StatusDto();
		boolean isRequestProcessingSucessfull = false;
		boolean isSystemError = false;
		RegistrationInProcessUserDto registrationInProcessUserDetails = registrationService
				.resetPasswordForExistingUser(communication.getPassword(), communication.getPhoneNumber(), tempAuthKey,
						communication.getApplicationCode());
		if (null != registrationInProcessUserDetails) {
			headers.add(GatewayConstants.AUTH_KEY_TAG, registrationInProcessUserDetails.getAuthKey());
			isRequestProcessingSucessfull = true;
			status = registrationInProcessUserDetails.getStatus();
		} else {
			isSystemError = true;
			status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
			status.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_SYSTEM_ERROR_STATUS_MESSAGE);
			headers.add(GatewayConstants.AUTH_KEY_TAG, tempAuthKey);
		}
		registrationDto.setStatus(status);
		RequestValidationDto validationDto = new RequestValidationDto();
		registrationDto.setRequestValidation(validationDto);
		if (isRequestProcessingSucessfull) {
			return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.OK);
		} else {
			if (isSystemError) {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				return new ResponseEntity<RegistrationDto>(registrationDto, headers, HttpStatus.BAD_REQUEST);
			}
		}
	}
	
	@RequestMapping(value = "/resetpassword", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject saveMasterFranchiseMapping(@RequestBody Communication communication) {
		JSONObject obj = new JSONObject();
		try {
			obj = registrationService.resetpassword(communication.getPhoneNumber(),communication.getPassword(),communication.getApplicationCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	@RequestMapping(value = "/forgotpassword", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject forgotpassword(@RequestBody Communication communication) {
		JSONObject obj = new JSONObject();
		try {
			obj = registrationService.forgotpassword(communication.getPhoneNumber(),communication.getApplicationCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

}
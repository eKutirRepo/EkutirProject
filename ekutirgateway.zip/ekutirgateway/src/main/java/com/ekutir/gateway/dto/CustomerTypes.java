package com.ekutir.gateway.dto;

import java.io.Serializable;
import java.util.List;

public class CustomerTypes implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<CustomerTypeDto> customerType;
	private StatusDto status;

	public List<CustomerTypeDto> getCustomerType() {
		return customerType;
	}

	public void setCustomerType(List<CustomerTypeDto> customerType) {
		this.customerType = customerType;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}

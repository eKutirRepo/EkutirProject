package com.ekutir.gateway.services;

import org.json.simple.JSONObject;

import com.ekutir.gateway.dto.ParamsDTO;
import com.ekutir.gateway.model.LicenseMappingTO;
import com.ekutir.gateway.model.MasterFranchiseUserMappingTO;

public interface SuperAdminService {

	JSONObject fetchActiveUsers(ParamsDTO paramsDto);

	JSONObject fetchActiveUserswithFilter(ParamsDTO paramsDto);

	JSONObject fetchMasterFranchise(ParamsDTO paramsDto);

	JSONObject saveMasterFranchiseMapping(MasterFranchiseUserMappingTO mfTO);

	JSONObject fetchLicenseDetailsand();

	JSONObject saveLicenseMappingData(LicenseMappingTO licenseMappingTO);

	JSONObject getIsBasicProExists(int userId);

	/*JSONObject updateLicensePurchaseStatus(int licenseDetailsId);*/
	JSONObject updateLicensePurchaseStatus(int licenseDetailsId,int appId,int masterFranId);
	

}

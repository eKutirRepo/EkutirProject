package com.ekutir.gateway.dto;

import java.util.List;

public class CustomerAndLandDetails {
	private CustomerDto customer;
	private List<LandDetailsDto> landDetails;
	private StatusDto status;

	public CustomerDto getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerDto customer) {
		this.customer = customer;
	}

	public List<LandDetailsDto> getLandDetails() {
		return landDetails;
	}

	public void setLandDetails(List<LandDetailsDto> landDetails) {
		this.landDetails = landDetails;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}

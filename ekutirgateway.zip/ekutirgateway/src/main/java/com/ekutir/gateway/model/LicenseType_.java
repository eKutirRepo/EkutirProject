
package com.ekutir.gateway.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "licType",
    "licenseName",
    "durationInDays",
    "costInr",
    "createdDate",
    "createdBy",
    "updatedDate",
    "updatedBy"
})
public class LicenseType_ {

    @JsonProperty("licType")
    private long licType;
    @JsonProperty("licenseName")
    private String licenseName;
    @JsonProperty("durationInDays")
    private long durationInDays;
    @JsonProperty("costInr")
    private long costInr;
    @JsonProperty("createdDate")
    private Object createdDate;
    @JsonProperty("createdBy")
    private Object createdBy;
    @JsonProperty("updatedDate")
    private Object updatedDate;
    @JsonProperty("updatedBy")
    private Object updatedBy;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("licType")
    public long getLicType() {
        return licType;
    }

    @JsonProperty("licType")
    public void setLicType(long licType) {
        this.licType = licType;
    }

    @JsonProperty("licenseName")
    public String getLicenseName() {
        return licenseName;
    }

    @JsonProperty("licenseName")
    public void setLicenseName(String licenseName) {
        this.licenseName = licenseName;
    }

    @JsonProperty("durationInDays")
    public long getDurationInDays() {
        return durationInDays;
    }

    @JsonProperty("durationInDays")
    public void setDurationInDays(long durationInDays) {
        this.durationInDays = durationInDays;
    }

    @JsonProperty("costInr")
    public long getCostInr() {
        return costInr;
    }

    @JsonProperty("costInr")
    public void setCostInr(long costInr) {
        this.costInr = costInr;
    }

    @JsonProperty("createdDate")
    public Object getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("createdDate")
    public void setCreatedDate(Object createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("createdBy")
    public Object getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("createdBy")
    public void setCreatedBy(Object createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("updatedDate")
    public Object getUpdatedDate() {
        return updatedDate;
    }

    @JsonProperty("updatedDate")
    public void setUpdatedDate(Object updatedDate) {
        this.updatedDate = updatedDate;
    }

    @JsonProperty("updatedBy")
    public Object getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("updatedBy")
    public void setUpdatedBy(Object updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

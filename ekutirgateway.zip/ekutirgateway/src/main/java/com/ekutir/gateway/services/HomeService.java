package com.ekutir.gateway.services;

import java.util.List;

import com.ekutir.gateway.dto.AdvertisementDto;
import com.ekutir.gateway.dto.BusinessTipsDto;
import com.ekutir.gateway.dto.CustomerAndLandDetails;
import com.ekutir.gateway.dto.CustomerDto;
import com.ekutir.gateway.dto.CustomerListDto;
import com.ekutir.gateway.dto.CustomerTypes;
import com.ekutir.gateway.dto.SalesAndOffersDto;
import com.ekutir.gateway.dto.UserDto;

public interface HomeService {
	public List<AdvertisementDto> fetchAdvertisements(String appId, String masterKey);

	public List<BusinessTipsDto> fetchBusinessTips(String appId, String masterKey);

	public List<SalesAndOffersDto> fetchSalesAndOffers(String appId, String masterKey);

	public boolean isMasterKeyExists(String masterKey);

	public boolean isAppCodeExists(String appCode);

	public boolean isAuthKeyExists(String authKey);

	public CustomerListDto fetchCustomers(int userId, int page, String auth);

	public CustomerDto saveCustomer(CustomerDto customer,String auth);

	public UserDto saveUser(UserDto user);

	public boolean isAppRequestAuthorized(String masterKey, String appCode);

	public CustomerTypes fetchCustomerTypes(String appCode);

	public CustomerAndLandDetails fetchCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey);

	public CustomerAndLandDetails updateCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey);
}

package com.ekutir.gateway.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "master_franchise_mapping")
public class MasterFranchiseUserMappingTO {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "master_franchise_mapping_id")
	private int masterFranchiseMappingId;
	
	
	@Column(name = "mf_id")
	private Integer mfId;
	
	@Column(name = "user_id")
	private Integer userId;
	
	
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	
	@Column(name = "updated_date")
	private Date updatedDate;
	
	@Column(name = "user_mf_approval_status")
	private Integer userMfAprovalStatus;


	public Integer getUserMfAprovalStatus() {
		return userMfAprovalStatus;
	}


	public void setUserMfAprovalStatus(Integer userMfAprovalStatus) {
		this.userMfAprovalStatus = userMfAprovalStatus;
	}


	public int getMasterFranchiseMappingId() {
		return masterFranchiseMappingId;
	}


	public void setMasterFranchiseMappingId(int masterFranchiseMappingId) {
		this.masterFranchiseMappingId = masterFranchiseMappingId;
	}


	public Integer getMfId() {
		return mfId;
	}


	public void setMfId(Integer mfId) {
		this.mfId = mfId;
	}


	public Integer getUserId() {
		return userId;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public Date getUpdatedDate() {
		return updatedDate;
	}


	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
}

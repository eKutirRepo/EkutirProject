package com.ekutir.gateway.dto;

public class UserIdDto {
	private int userId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}

package com.ekutir.gateway.dto;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;

import com.ekutir.gateway.model.Auth;
import com.ekutir.gateway.model.Registration;

public class UserLicenseDTO {
	private static final long serialVersionUID = 1L;
	/*private int userId;
	private int registration;
	private int auth;*/
	private String firstName;
	private String middleName;
	private String lastName;
	/*private String eMailId;*/
	private String businessName;
	/*private String typeOfUser;*/
	private int address;
	/*private String shopLicenseNumber;
	private Date shopLicenseExpiryDate;
	private byte[] shopPicture;
	private byte[] profilePic;
	private String profileWriteUp;
	private String aadharNumber;
	private String tinNumber;
	private BigDecimal rating;
	private StatusDto status;
	private String created_by;
	private String updated_by;
	private Date created_date_time;
	private Date updated_date_time;
	private int licMappingId;*/
	private Integer licDetailsId;
	//private Integer gtwyUserId;
	private String subscriptionDate;
	private String expiryDate;
	private Integer mfid;
	private String appName;
	private String licenseName;
	

	public UserLicenseDTO(String firstName, String middleName, String lastName, String businessName, int address,
			Integer licDetailsId, String subscriptionDate, String expiryDate, Integer mfid, String appName,
			String licenseName) {
		super();
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.businessName = businessName;
		this.address = address;
		this.licDetailsId = licDetailsId;
		this.subscriptionDate = subscriptionDate;
		this.expiryDate = expiryDate;
		this.mfid = mfid;
		this.appName = appName;
		this.licenseName = licenseName;
	}
	public Integer getMfid() {
		return mfid;
	}
	public void setMfid(Integer mfid) {
		this.mfid = mfid;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getLicenseName() {
		return licenseName;
	}
	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}
	public int getAddress() {
		return address;
	}
	public void setAddress(int address) {
		this.address = address;
	}
	

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public Integer getLicDetailsId() {
		return licDetailsId;
	}
	public void setLicDetailsId(Integer licDetailsId) {
		this.licDetailsId = licDetailsId;
	}
	public String getSubscriptionDate() {
		return subscriptionDate;
	}
	public void setSubscriptionDate(String subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	/*private String createdBy;
	private String updatedBy;
	private Date createdDate;
	private Date updatedDate;*/
	
	
	
	

}

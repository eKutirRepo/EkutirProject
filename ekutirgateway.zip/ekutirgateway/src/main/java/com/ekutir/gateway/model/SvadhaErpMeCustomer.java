package com.ekutir.gateway.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_mecustomer_master")
public class SvadhaErpMeCustomer {

	@Id
	@GeneratedValue
	@Column(name = "CustomerID")
	private int customerId;

	@Column(name = "PrevLeadID")
	private Integer prevLeadId;

	@Column(name = "CustomerFName")
	private String customerFirstName;

	@Column(name = "MName")
	private String customerMiddleName;

	@Column(name = "CustomerLName")
	private String customerLastName;

	@Column(name = "PrimaryPhone")
	private Long primaryPhoneNumber;

	@Column(name = "SecondaryPhone")
	private Long secondaryPhoneNumber;

	@Column(name = "Address")
	private Integer addressId;

	@Column(name = "BusinessCategory")
	private Integer businessCatId;

	@Column(name = "BusinessName")
	private String businessName;

	@Column(name = "AadhaarNumber")
	private Long aadhaarNumber;

	@Column(name = "Description")
	private String description;

	@Column(name = "CreatedBy")
	private Integer createdBy;

	@Column(name = "CreatedDateTime")
	private Date createdDateTime;

	@Column(name = "UpdatedBy")
	private Integer updatedBy;

	@Column(name = "UpdatedDateTime")
	private Date updatedDateTime;

	@Column(name = "CustomerStatus")
	private String customerStatus;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public Integer getPrevLeadId() {
		return prevLeadId;
	}

	public void setPrevLeadId(Integer prevLeadId) {
		this.prevLeadId = prevLeadId;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public String getCustomerMiddleName() {
		return customerMiddleName;
	}

	public void setCustomerMiddleName(String customerMiddleName) {
		this.customerMiddleName = customerMiddleName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public Long getPrimaryPhoneNumber() {
		return primaryPhoneNumber;
	}

	public void setPrimaryPhoneNumber(Long primaryPhoneNumber) {
		this.primaryPhoneNumber = primaryPhoneNumber;
	}

	public Long getSecondaryPhoneNumber() {
		return secondaryPhoneNumber;
	}

	public void setSecondaryPhoneNumber(Long secondaryPhoneNumber) {
		this.secondaryPhoneNumber = secondaryPhoneNumber;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public Integer getBusinessCatId() {
		return businessCatId;
	}

	public void setBusinessCatId(Integer businessCatId) {
		this.businessCatId = businessCatId;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public Long getAadhaarNumber() {
		return aadhaarNumber;
	}

	public void setAadhaarNumber(Long aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public String getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}

}

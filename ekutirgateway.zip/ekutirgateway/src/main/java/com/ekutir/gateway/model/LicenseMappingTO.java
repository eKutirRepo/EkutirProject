package com.ekutir.gateway.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "licencse_mapping")
public class LicenseMappingTO {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "license_mapping_id")
	private int licMappingId;
	
	
	@Column(name = "license_details_id")
	private Integer licDetailsId;
	
	@Column(name = "gtwy_user_id")
	private Integer gtwyUserId;
	
	@Column(name = "expiry_date")
	private Date expiryDate;
	
	@Column(name = "subscription_date")
	private Date subscriptionDate;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	
	@Column(name = "updated_date")
	private Date updatedDate;
	
	
	@Column(name = "master_franchise_id")
	private Integer masterFranchiseId;
	
	
	@Column(name = "app_name")
	private Integer appName;
	

	@Column(name = "license_name")
	private String licenseName;
	
	@Transient
	private Integer durationOfLicense;
	
	@Transient
	private Integer licenseTypeId;


	public Integer getLicenseTypeId() {
		return licenseTypeId;
	}


	public void setLicenseTypeId(Integer licenseTypeId) {
		this.licenseTypeId = licenseTypeId;
	}


	public Integer getDurationOfLicense() {
		return durationOfLicense;
	}


	public void setDurationOfLicense(Integer durationOfLicense) {
		this.durationOfLicense = durationOfLicense;
	}


	public String getLicenseName() {
		return licenseName;
	}


	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}


	public Integer getAppName() {
		return appName;
	}


	public void setAppName(Integer appName) {
		this.appName = appName;
	}


	public Integer getMasterFranchiseId() {
		return masterFranchiseId;
	}


	public void setMasterFranchiseId(Integer masterFranchiseId) {
		this.masterFranchiseId = masterFranchiseId;
	}


	


	public int getLicMappingId() {
		return licMappingId;
	}


	public void setLicMappingId(int licMappingId) {
		this.licMappingId = licMappingId;
	}


	public Integer getLicDetailsId() {
		return licDetailsId;
	}


	public void setLicDetailsId(Integer licDetailsId) {
		this.licDetailsId = licDetailsId;
	}


	public Integer getGtwyUserId() {
		return gtwyUserId;
	}


	public void setGtwyUserId(Integer gtwyUserId) {
		this.gtwyUserId = gtwyUserId;
	}


	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}


	public Date getSubscriptionDate() {
		return subscriptionDate;
	}


	public void setSubscriptionDate(Date subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public Date getUpdatedDate() {
		return updatedDate;
	}


	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}


	
}

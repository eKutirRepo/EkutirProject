package com.ekutir.gateway.dto;

import java.io.Serializable;

public class RegistrationDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private StatusDto status;
	private RequestValidationDto requestValidation;
	private Communication communication;
	private UserDto user;
	private CustomerDto customer;
	private LandDetailsDto landDetails;
	private String userLat;
	private String userLong;

	public String getUserLat() {
		return userLat;
	}

	public void setUserLat(String userLat) {
		this.userLat = userLat;
	}

	public String getUserLong() {
		return userLong;
	}

	public void setUserLong(String userLong) {
		this.userLong = userLong;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public RequestValidationDto getRequestValidation() {
		return requestValidation;
	}

	public void setRequestValidation(RequestValidationDto requestValidation) {
		this.requestValidation = requestValidation;
	}

	public Communication getCommunication() {
		return communication;
	}

	public void setCommunication(Communication communication) {
		this.communication = communication;
	}

	public UserDto getUser() {
		return user;
	}

	public void setUser(UserDto user) {
		this.user = user;
	}

	public CustomerDto getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerDto customer) {
		this.customer = customer;
	}

	public LandDetailsDto getLandDetails() {
		return landDetails;
	}

	public void setLandDetails(LandDetailsDto landDetails) {
		this.landDetails = landDetails;
	}

}

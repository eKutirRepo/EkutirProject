package com.ekutir.gateway.services;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ekutir.gateway.dao.RestUtility;
import com.ekutir.gateway.dto.ParamsDTO;
import com.ekutir.gateway.dto.UserLicenseDTO;
import com.ekutir.gateway.model.Address;
import com.ekutir.gateway.model.LicenseDetailsUpdateStatus;
import com.ekutir.gateway.model.LicenseMappingTO;
import com.ekutir.gateway.model.MasterFranchise;
import com.ekutir.gateway.model.MasterFranchiseUserMappingTO;
import com.ekutir.gateway.model.User;
import com.ekutir.gateway.utilities.*;

@Service
public class SuperAdminServiceImpl implements SuperAdminService {

	@Autowired
	RestUtility restUtil;
	
	@Autowired
	RegistrationService registrationService;
	

	@Override
	public JSONObject fetchActiveUsers(ParamsDTO paramsDto) {
		JSONObject obj = new JSONObject();
		try {
			int n = 15;
			int mffid=paramsDto.getMasterFranchiseId();
			int appId=paramsDto.getAppId();
			Set<Integer> msSet = new HashSet<>();
			Set<Integer> apSet = new HashSet<>();
			
			List<Map<String, Object>> datalist = new ArrayList<Map<String, Object>>();
			List<LicenseMappingTO> licMapTO = restUtil.fetchLicenseMapping();
			if(!licMapTO.isEmpty()){
			for (LicenseMappingTO licMap : licMapTO) {
				msSet.add(licMap.getMasterFranchiseId());
				apSet.add(licMap.getAppName());
			}
			
				
				Map<String, Object> mfMap = new HashMap<String, Object>();
				List<Map<String, Object>> datalistapps = new ArrayList<Map<String, Object>>();
					List<UserLicenseDTO> userapp = restUtil.fetchUsersbasedOnapps(appId, mffid);
					List<Map<String, Object>> appandUserList = new ArrayList<Map<String, Object>>();
					if(!userapp.isEmpty()){
						
					Map<String, Object> appMap = new HashMap<String, Object>();
					for (UserLicenseDTO us : userapp) {
						
						Map<String, Object> userMap = new HashMap<String, Object>();
						java.util.Date dt = new java.util.Date();
						java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						sdf.setTimeZone(TimeZone.getTimeZone("IST"));
						String currentTime = sdf.format(dt);
						String expiryDate = us.getExpiryDate();
						Date expiryD = sdf.parse(expiryDate);
						Date previousDate = (Date) CommonUtil.subtractDays(expiryD, n);
						String expFifteenDaysDate = sdf.format(previousDate);
						userMap.put("userFname", us.getFirstName());
						userMap.put("userMname", us.getMiddleName());
						userMap.put("userLname", us.getLastName());
						userMap.put("appName", us.getAppName());
						userMap.put("licensePackage", us.getLicenseName());
						userMap.put("dateOfSubscription", us.getSubscriptionDate().substring(0, 10));
						userMap.put("expiryDate", us.getExpiryDate().substring(0, 10));
						List<Address> address = restUtil.getAddress(us.getAddress());
						for (Address ad : address) {
							userMap.put("address",
									ad.getAddressLine1() + ", " + ad.getAddressLine2() + ", " + ad.getAddressLine3()
											+ ", " + ad.getBlock() + ", " + ad.getCity() + ", " + ad.getDistrict()
											+ ", " + ad.getDistrict() + ", " + ad.getState() + ", " + ad.getCountry()
											+ ", " + ad.getPostalCode());
						}
						if (us.getExpiryDate().toString().compareTo(currentTime) > 0
								&& expFifteenDaysDate.compareTo(currentTime) > 0) {
							userMap.put("status", "active");
						} else if (us.getExpiryDate().toString().compareTo(currentTime) > 0
								&& currentTime.compareTo(expFifteenDaysDate) > 0) {
							userMap.put("status", "expiring");
						} else if (currentTime.compareTo(us.getExpiryDate().toString()) > 0) {
							userMap.put("status", "inactive");
						}
						appandUserList.add(userMap);
						
					}
					appMap.put("users", appandUserList);
					datalistapps.add(appMap);
					}
				
					obj.put("Users", appandUserList);
				
		}

		} catch (Exception e) {

		}
		return obj;
	}

	@Override
	public JSONObject fetchActiveUserswithFilter(ParamsDTO paramsDto) {
		JSONObject obj = new JSONObject();
		try{
			int n=45;
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			List<Map<String, Object>> datalistactive = new ArrayList<Map<String, Object>>();
			List<Map<String, Object>> datalistinactive = new ArrayList<Map<String, Object>>();
			List<Map<String, Object>> datalistexpiring = new ArrayList<Map<String, Object>>();
			List<UserLicenseDTO> user=restUtil.fetchActiveUserswithFilter(paramsDto);
			for(UserLicenseDTO us:user){
				java.util.Date dt = new java.util.Date();
				java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				sdf.setTimeZone(TimeZone.getTimeZone("IST")); 
				String currentTime = sdf.format(dt);
				String expiryDate=us.getExpiryDate();
				Date expiryD=sdf.parse(expiryDate);
				Date previousDate = (Date) CommonUtil.subtractDays(expiryD, n);
				String expFifteenDaysDate=sdf.format(previousDate);
				if(us.getExpiryDate().toString().compareTo(currentTime)>0 && expFifteenDaysDate.compareTo(currentTime)>0){
				Map<String, Object> serviceMap = new HashMap<String, Object>();
				serviceMap.put("userFname", us.getFirstName());
				serviceMap.put("userMname", us.getMiddleName());
				serviceMap.put("userLname", us.getLastName());
				serviceMap.put("appName", us.getAppName());
				serviceMap.put("licensePackage", us.getLicenseName());
				serviceMap.put("dateOfSubscription", us.getSubscriptionDate());
				serviceMap.put("expiryDate", us.getExpiryDate());
				List<Address> address=restUtil.getAddress(us.getAddress());
				for(Address ad:address){
					serviceMap.put("address", ad.getAddressLine1()+", "+ad.getAddressLine2()+", "+ad.getAddressLine3()+", "+ad.getBlock()+", "+ad.getCity()+", "+ad.getDistrict()+", "+ad.getDistrict()+", "+ad.getState()+", "+ad.getCountry()+", "+ad.getPostalCode());
					
				}
				datalistactive.add(serviceMap);
				}else if(us.getExpiryDate().toString().compareTo(currentTime)>0 && currentTime.compareTo(expFifteenDaysDate)>0){
					Map<String, Object> serviceMap = new HashMap<String, Object>();
					serviceMap.put("userFname", us.getFirstName());
					serviceMap.put("userMname", us.getMiddleName());
					serviceMap.put("userLname", us.getLastName());
					serviceMap.put("appName", us.getAppName());
					serviceMap.put("licensePackage", us.getLicenseName());
					serviceMap.put("dateOfSubscription", us.getSubscriptionDate());
					serviceMap.put("expiryDate", us.getExpiryDate());
					List<Address> address=restUtil.getAddress(us.getAddress());
					for(Address ad:address){
						serviceMap.put("address", ad.getAddressLine1()+", "+ad.getAddressLine2()+", "+ad.getAddressLine3()+", "+ad.getBlock()+", "+ad.getCity()+", "+ad.getDistrict()+", "+ad.getDistrict()+", "+ad.getState()+", "+ad.getCountry()+", "+ad.getPostalCode());
						
					}
					datalistexpiring.add(serviceMap);
				}else if(currentTime.compareTo(us.getExpiryDate().toString())>0 ){
					Map<String, Object> serviceMap = new HashMap<String, Object>();
					serviceMap.put("userFname", us.getFirstName());
					serviceMap.put("userMname", us.getMiddleName());
					serviceMap.put("userLname", us.getLastName());
					serviceMap.put("appName", us.getAppName());
					serviceMap.put("licensePackage", us.getLicenseName());
					serviceMap.put("dateOfSubscription", us.getSubscriptionDate());
					serviceMap.put("expiryDate", us.getExpiryDate());
					List<Address> address=restUtil.getAddress(us.getAddress());
					for(Address ad:address){
						serviceMap.put("address", ad.getAddressLine1()+", "+ad.getAddressLine2()+", "+ad.getAddressLine3()+", "+ad.getBlock()+", "+ad.getCity()+", "+ad.getDistrict()+", "+ad.getDistrict()+", "+ad.getState()+", "+ad.getCountry()+", "+ad.getPostalCode());
						
					}
					datalistinactive.add(serviceMap);
				}
			}
			obj.put("activeUsers", datalistactive);
			obj.put("inactiveUsers", datalistinactive);
			obj.put("expiringUsers", datalistexpiring);
		}catch(Exception e){
			
		}
		return obj;
	}


	@Override
	public JSONObject fetchMasterFranchise(ParamsDTO paramsDto) {
		JSONObject obj = new JSONObject();
		try{
			
			String urlForMasterFranchiseList = "http://localhost:8080/superadmin/fetchMasterFranchiseDetails";
			
			RestTemplate restTemplate = new RestTemplate();
			Map<String, String> params = new HashMap<String, String>();
			MasterFranchise mfs = restTemplate.postForObject(urlForMasterFranchiseList, paramsDto,MasterFranchise.class);
			
			
			obj.put("masterFranchisesList", mfs);
			
		}catch(Exception e){
			
		}
		return obj;
	}


	@Override
	public JSONObject saveMasterFranchiseMapping(MasterFranchiseUserMappingTO mfTO) {
		JSONObject obj = new JSONObject();
		try{
			java.util.Date dt = new java.util.Date();
			mfTO.setCreatedBy("SYSTEM");
			mfTO.setUpdatedBy("SYSTEM");
			mfTO.setCreatedDate(dt);
			mfTO.setUpdatedDate(dt);
			mfTO.setUserMfAprovalStatus(0);
			mfTO=restUtil.saveMasterFranchiseMapping(mfTO);
			if(mfTO.getMasterFranchiseMappingId()!=0){
			obj.put("isBasicPro", true);
			obj.put("status", "Success");
			}else{
				obj.put("isBasicPro", "false");
				obj.put("status", "Error");
				obj.put("isMFApproved", false);
			}
			}catch(Exception e){
				obj.put("status", e);
		}
		return obj;
	}
	
	@Override
	public JSONObject fetchLicenseDetailsand() {
		JSONObject obj = new JSONObject();
		try{
			
			String urlForMasterFranchiseList = "http://localhost:8080/superadmin/fetchLicenseDetailsand";
			
			RestTemplate restTemplate = new RestTemplate();
			Map<String, String> params = new HashMap<String, String>();
			MasterFranchise mfs = restTemplate.getForObject(urlForMasterFranchiseList,
					MasterFranchise.class, params);
			
			
			obj.put("licenseTypeList", mfs);
			
		}catch(Exception e){
			
		}
		return obj;
	}


	@Override
	public JSONObject saveLicenseMappingData(LicenseMappingTO licenseMappingTO) {
		JSONObject obj = new JSONObject();
			try{
				java.util.Date dt = new java.util.Date();
				licenseMappingTO.setCreatedBy("SYSTEM");
				licenseMappingTO.setCreatedDate(dt);
				licenseMappingTO.setUpdatedBy("SYSTEM");
				licenseMappingTO.setUpdatedDate(dt);
				licenseMappingTO.setSubscriptionDate(dt);
				int duration=licenseMappingTO.getDurationOfLicense();
				Date expiryDate=CommonUtil.addDays(dt, duration);
				licenseMappingTO.setExpiryDate(expiryDate);
				licenseMappingTO=restUtil.saveLicenseMapping(licenseMappingTO);
				
				if(licenseMappingTO.getLicMappingId()!=0){
					obj.put("isLicenseMapped", true);
					obj.put("status", "Success");
					}else{
						obj.put("isLicenseMapped", "false");
						obj.put("status", "Error");
					}
			}catch(Exception e){
			
		}
		return obj;
	
	}


	@Override
	public JSONObject getIsBasicProExists(int userId) {
		JSONObject obj = new JSONObject();
		try{
			boolean isLicExists=registrationService.getUserMappingStatus(userId);
			boolean isMFApproved=registrationService.getMFApproval(userId);
			boolean isWithinExpiryDate=registrationService.getWithinExpiryDate(userId);
			if(isLicExists==true && isWithinExpiryDate==true ){
			obj.put("isBasicPro", true);
			}
			else{
				obj.put("isBasicPro", false);
			}
			if(isMFApproved==true){
				obj.put("isMFApproved", true);
			}else{
				obj.put("isMFApproved", false);
			}
		}catch(Exception e){
			
		}
		return obj;
	}


	/*@Override
	public JSONObject updateLicensePurchaseStatus(int licenseDetailsId) {
		JSONObject obj = new JSONObject();
try{
			
	String appUrlIndiaRuhaat =  "http://localhost:8080/superadmin/updateLicensePurchaseStatus";
	 
			  RestTemplate restTemplate = new RestTemplate();
			  ParamsDTO  paramsDto=new ParamsDTO(); 
			  paramsDto.setLicenseDetailsId(licenseDetailsId);
			
			  Map<String, String> params = new HashMap<String, String>(); 
			 
			
			  LicenseDetailsUpdateStatus licenseDetailsUpdateStatus =  restTemplate.postForObject(appUrlIndiaRuhaat, paramsDto,LicenseDetailsUpdateStatus.class);
			  obj.put("licenseUpdateStatus",licenseDetailsUpdateStatus); 
			
			
			
		}catch(Exception e){
			
		}
		return obj;
	}*/
	@Override
	public JSONObject updateLicensePurchaseStatus(int licenseDetailsId,int appId,int masterFranId) {
		JSONObject obj = new JSONObject();
try{
			
	String appUrlIndiaRuhaat =  "http://localhost:8080/superadmin/updateLicensePurchaseStatus";
	 
			  RestTemplate restTemplate = new RestTemplate();
			  ParamsDTO  paramsDto=new ParamsDTO(); 
			  paramsDto.setLicenseDetailsId(licenseDetailsId);
			  paramsDto.setAppId(appId);
			  paramsDto.setMasterFranchiseId(masterFranId);
			  Map<String, String> params = new HashMap<String, String>(); 
			 
			
			  LicenseDetailsUpdateStatus licenseDetailsUpdateStatus =  restTemplate.postForObject(appUrlIndiaRuhaat, paramsDto,LicenseDetailsUpdateStatus.class);
			  if(licenseDetailsUpdateStatus.getNewLicenseDetailsId()!=licenseDetailsId){
				 boolean update= restUtil.updateLicLocal(licenseDetailsUpdateStatus.getNewLicenseDetailsId(),licenseDetailsId);
			  }
			  obj.put("licenseUpdateStatus",true); 
			
			
			
		}catch(Exception e){
			obj.put("exception", e);
		}
		return obj;
	}
	
}

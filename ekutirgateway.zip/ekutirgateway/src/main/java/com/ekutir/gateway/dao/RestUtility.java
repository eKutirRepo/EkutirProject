package com.ekutir.gateway.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ekutir.gateway.dto.ParamsDTO;
import com.ekutir.gateway.dto.UserLicenseDTO;
import com.ekutir.gateway.model.Address;
import com.ekutir.gateway.model.Advertisement;
import com.ekutir.gateway.model.LicenseMappingTO;
import com.ekutir.gateway.model.MasterFranchiseUserMappingTO;
import com.ekutir.gateway.model.SaleAndOffer;
import com.ekutir.gateway.model.User;

@Repository
public class RestUtility {
	@Autowired 
	@Qualifier("manas")
	private SessionFactory sessionFactory;
	
	private List<Object[]> rows = null;
	private List<Object[]> fetchrows = null;
	Session session = null;
	private Query query;
	private Query fetchquery;
	private int userId = 0;
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
	
	@Transactional
	public List<UserLicenseDTO> fetchActiveUsers() {
		List productCategory = null;
		try {
			SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(
					"SELECT g.first_name,g.middle_name,g.last_name,g.business_name,g.address,l.license_details_id,l.subscription_date,l.expiry_date,l.master_franchise_id,l.app_name,l.license_name from gtwy_user_master as g inner join licencse_mapping  as l on g.user_id=l.gtwy_user_id ");
			rows = query.list();
			productCategory = new ArrayList(rows.size());
			for (Object[] row : rows) {

				productCategory.add(new UserLicenseDTO(row[0].toString(), row[1].toString(), row[2].toString(),
						row[3].toString(), Integer.parseInt(row[4].toString()), Integer.parseInt(row[5].toString()),
						row[6].toString(), row[7].toString(),Integer.parseInt(row[8].toString()),
						row[9].toString(),row[10].toString()));
			}
		} catch (Exception e) {

		}

		return productCategory;
	}

	@Transactional
	public List<Address> getAddress(int addressid) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Address.class).add(Restrictions.eq("addressId",addressid));
		return (List<Address>) criteria.setResultTransformer(criteria.DISTINCT_ROOT_ENTITY).list();
	}
	
	@Transactional
	public List<UserLicenseDTO> fetchActiveUserswithFilter(ParamsDTO paramsDto) {
		List productCategory = null;
		int mfId1=Integer.parseInt(paramsDto.getMfId());
		String appName=paramsDto.getAppName();
		try {
			SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(
					"SELECT g.first_name,g.middle_name,g.last_name,g.business_name,g.address,l.license_details_id,l.subscription_date,l.expiry_date,l.master_franchise_id,l.app_name,l.license_name from gtwy_user_master as g inner join licencse_mapping  as l on g.user_id=l.gtwy_user_id where l.master_franchise_id = " + mfId1 + " and l.app_name = '" + appName + "'");
			rows = query.list();
			productCategory = new ArrayList(rows.size());
			for (Object[] row : rows) {

				productCategory.add(new UserLicenseDTO(row[0].toString(), row[1].toString(), row[2].toString(),
						row[3].toString(), Integer.parseInt(row[4].toString()), Integer.parseInt(row[5].toString()),
						row[6].toString(), row[7].toString(),Integer.parseInt(row[8].toString()),
						row[9].toString(),row[10].toString()));
			}
		} catch (Exception e) {

		}

		return productCategory;
	}
@Transactional
	public List<LicenseMappingTO> fetchLicenseMapping() {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(LicenseMappingTO.class);
		return (List<LicenseMappingTO>) criteria.setResultTransformer(criteria.DISTINCT_ROOT_ENTITY).list();
	}
@Transactional
	public List<UserLicenseDTO> fetchUsers(Integer ms) {
		List productCategory = null;
		try {
			SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(
					"SELECT g.first_name,g.middle_name,g.last_name,g.business_name,g.address,l.license_details_id,l.subscription_date,l.expiry_date,l.master_franchise_id,l.app_name,l.license_name from gtwy_user_master as g inner join licencse_mapping  as l on g.user_id=l.gtwy_user_id where l.master_franchise_id = " + ms );
			rows = query.list();
			productCategory = new ArrayList(rows.size());
			for (Object[] row : rows) {

				productCategory.add(new UserLicenseDTO(row[0].toString(), row[1].toString(), row[2].toString(),
						row[3].toString(), Integer.parseInt(row[4].toString()), Integer.parseInt(row[5].toString()),
						row[6].toString(), row[7].toString(),Integer.parseInt(row[8].toString()),
						row[9].toString(),row[10].toString()));
			}
		} catch (Exception e) {

		}

		return productCategory;
		
	}
@Transactional
	public List<UserLicenseDTO> fetchUsersbasedOnapps(Integer ap,Integer ms) {
		List productCategory = null;
		try {
			SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(
					"SELECT g.first_name,g.middle_name,g.last_name,g.business_name,g.address,l.license_details_id,l.subscription_date,l.expiry_date,l.master_franchise_id,l.app_name,l.license_name from gtwy_user_master as g inner join licencse_mapping  as l on g.user_id=l.gtwy_user_id where l.app_name = " + ap + " and l.master_franchise_id = " + ms);
			rows = query.list();
			productCategory = new ArrayList(rows.size());
			for (Object[] row : rows) {

				productCategory.add(new UserLicenseDTO(row[0].toString(), row[1].toString(), row[2].toString(),
						row[3].toString(), Integer.parseInt(row[4].toString()), Integer.parseInt(row[5].toString()),
						row[6].toString(), row[7].toString(),Integer.parseInt(row[8].toString()),
						row[9].toString(),row[10].toString()));
			}
		} catch (Exception e) {

		}

		return productCategory;
	}

@Transactional
public MasterFranchiseUserMappingTO saveMasterFranchiseMapping(MasterFranchiseUserMappingTO mfTO) {
	int mfMappingId;
	session = this.sessionFactory.getCurrentSession();
	mfMappingId= (int) session.save(mfTO);
	mfTO.setMasterFranchiseMappingId(mfMappingId);
	return mfTO;
}

@Transactional
public LicenseMappingTO saveLicenseMapping(LicenseMappingTO licenseMappingTO) {
	int licMappingId;
	session = this.sessionFactory.getCurrentSession();
	licMappingId= (int) session.save(licenseMappingTO);
	licenseMappingTO.setLicMappingId(licMappingId);
	return licenseMappingTO;
}

@Transactional
public boolean updateLicLocal(long newLicenseDetailsId,int oldLicId) {
	try{
	SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery("update licencse_mapping set license_details_id = " + newLicenseDetailsId + " where license_details_id = " + oldLicId);
	query.executeUpdate();
	return true;
	}catch(Exception e){
		
	}
	return false;
}

@Transactional
public int updatePass(long phone, String password, String appcode) {
	session = this.sessionFactory.getCurrentSession();
	Criteria criteria = session.createCriteria(User.class).createAlias("registration", "r")
			.add(Restrictions.eq("r.phoneNumber", phone)).createAlias("r.application", "a")
			.add(Restrictions.eq("a.applicationCode", appcode));
	User user = (User) criteria.uniqueResult();
	String hqlUpdate = "update User c set c.password = :newPassword where c.userId = :UserId";
	int updatedEntities = session.createQuery( hqlUpdate )
	        .setString("newPassword", password )
	        .setInteger("UserId", user.getUserId())
	        .executeUpdate();
	return updatedEntities;
}

@Transactional
public String forgotpassword(long phoneNumber, String appCode) {
	String forgottenpass="";
	session = this.sessionFactory.getCurrentSession();
	Criteria criteria = session.createCriteria(User.class).createAlias("registration", "r")
			.add(Restrictions.eq("r.phoneNumber", phoneNumber)).createAlias("r.application", "a")
			.add(Restrictions.eq("a.applicationCode", appCode));
	User user = (User) criteria.uniqueResult();
	forgottenpass=user.getPassword();
	return forgottenpass;
}

	
	

}

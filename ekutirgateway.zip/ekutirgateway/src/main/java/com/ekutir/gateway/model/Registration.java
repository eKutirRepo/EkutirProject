package com.ekutir.gateway.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "gtwy_registration")
public class Registration implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "registration_id")
	private int registrationId;

	@Column(name = "phone_number")
	private long phoneNumber;

	@Column(name = "aadhar_number")
	private String aadharNumber;

	@Column(name = "imei")
	private String imei;

	@Column(name = "otp")
	private int otp;

	@Column(name = "date_time_of_registration")
	private Date dateTimeOfRegistration;

	@Column(name = "registration_end_date_time")
	private Date registrationEndDateTime;

	@Column(name = "status")
	private int status;

	@Column(name = "tin_number")
	private String tinNumber;

	@ManyToOne
	@JoinColumn(name = "application")
	private Application application;

	@Column(name = "bank_account_name")
	private String bankAccountName;

	@Column(name = "bank_account_number")
	private String bankAccountNumber;

	@Column(name = "bank_name")
	private String bankName;

	@Column(name = "ban_ifsc_code")
	private String bankAccountIfscCode;

	public int getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public Date getDateTimeOfRegistration() {
		return dateTimeOfRegistration;
	}

	public void setDateTimeOfRegistration(Date dateTimeOfRegistration) {
		this.dateTimeOfRegistration = dateTimeOfRegistration;
	}

	public Date getRegistrationEndDateTime() {
		return registrationEndDateTime;
	}

	public void setRegistrationEndDateTime(Date registrationEndDateTime) {
		this.registrationEndDateTime = registrationEndDateTime;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getTinNumber() {
		return tinNumber;
	}

	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getBankAccountName() {
		return bankAccountName;
	}

	public void setBankAccountName(String bankAccountName) {
		this.bankAccountName = bankAccountName;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAccountIfscCode() {
		return bankAccountIfscCode;
	}

	public void setBankAccountIfscCode(String bankAccountIfscCode) {
		this.bankAccountIfscCode = bankAccountIfscCode;
	}

}

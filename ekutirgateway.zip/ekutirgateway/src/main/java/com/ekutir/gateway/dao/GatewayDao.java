package com.ekutir.gateway.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ekutir.gateway.model.AppMaster;
import com.ekutir.gateway.model.Application;
import com.ekutir.gateway.model.BusinessUser;
import com.ekutir.gateway.model.Customer;
import com.ekutir.gateway.model.CustomerType;
import com.ekutir.gateway.model.MeAndMyLand;
import com.ekutir.gateway.model.PhoneXOtp;
import com.ekutir.gateway.model.Registration;
import com.ekutir.gateway.model.SvadhaErpAddress;
import com.ekutir.gateway.model.SvadhaErpMeCustomer;
import com.ekutir.gateway.model.User;
import com.ekutir.gateway.model.UserLocation;

public interface GatewayDao {

	public int insertCustomerDetails(Customer customer);

	public Map<String, Boolean> isPhoneNumberAlreadyRegistered(long phoneNumber, String appCode);

	public void savePhoneNumberTempAuthKeyAndOtp(PhoneXOtp phoneXOtp);

	public void saveTempAuthKey(long phoneNumber, String authKey);

	public boolean verifyPassword(String password, long phoneNumber, String tempAuthKey, String appCode);

	public boolean verifyOtp(long phoneNumber, int otp, String tempAuthKey);

	public User insertNewUserRegistrationDetails(User user);

	public BusinessUser updateBusinessUser(BusinessUser businessUser);

	public BusinessUser fetchBusinessUser(long phoneNumber);

	public void writeToAudit(String string, String string2);

	public User getMicroentrepreneur(int microentrepreneurId);

	public Registration fetchRegistrationDetails(long phoneNumber, String applicationCode);

	public User updateRegistrationForReturningUser(User user);

	public void removeTempAuth(long phoneNumber);

	public Application fetchApplication(String applicationCode);

	public boolean isCustomerExistsForMicroentrepreneur(String custAadharNumber);

	public User fetchUser(long phoneNumber, String appCode);

	public boolean checkTempAuth(long phoneNumber, String tempAuthKey);

	public Customer fetchCustomer(int customerId);

	public List<MeAndMyLand> saveMeAndMyLandDetailsForCustomer(List<MeAndMyLand> listOfMeAndMyLands);

	public CustomerType fetchCustomerTypes(String customerTypeDesc);

	public User fetchUserById(int userId);

	public int saveSvadhaCustomerInfo(SvadhaErpMeCustomer erpMeCustomer);

	public int saveSvadhaErpMeAddress(SvadhaErpAddress erpAddress);

	public void saveAppMapping(AppMaster appMaster);

	public int getConnectedAppCustomerId(long phoneNumber, String aadharNumber);

	public Customer saveCustomer(Customer customer);

	public boolean isCustomerPhoneNumberAndAadhaarNumberPresent(long custPhoneNumber, int userId, String aadhaarNumber);

	public boolean isCustomerExistsForMicroentrepreneur(long custPhoneNumber);

	public boolean getUserMappingStatus(int userId);

	public Date getWithinExpiryDate(int userId);

	public boolean getMFApprovedStatusForUser(int userId);

	public UserLocation insertUserLocation(UserLocation userLoc);

	public boolean resetPassword(String password, long phoneNumber, String tempAuthKey, String appCode);

	
}

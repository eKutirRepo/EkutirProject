package com.ekutir.gateway.dto;

import java.io.Serializable;

public class CustomerDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private int customerId;
	private String custFirstName;
	private String custMiddleName;
	private String custLastName;
	private long custPhoneNumber;
	private String custAadharNumber;
	private String customerType;
	private StatusDto status;
	private int userId;
	private AddressDto address;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getCustomerType() {
		return customerType;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getCustFirstName() {
		return this.custFirstName;
	}

	public void setCustFirstName(String custFirstName) {
		this.custFirstName = custFirstName;
	}

	public String getCustMiddleName() {
		return this.custMiddleName;
	}

	public void setCustMiddleName(String custMiddleName) {
		this.custMiddleName = custMiddleName;
	}

	public String getCustLastName() {
		return this.custLastName;
	}

	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}

	public long getCustPhoneNumber() {
		return this.custPhoneNumber;
	}

	public void setCustPhoneNumber(long custPhoneNumber) {
		this.custPhoneNumber = custPhoneNumber;
	}

	public String getCustAadharNumber() {
		return this.custAadharNumber;
	}

	public void setCustAadharNumber(String custAadharNumber) {
		this.custAadharNumber = custAadharNumber;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}

}

package com.ekutir.gateway.dto;

public class LicenseParamDTO {

}

package com.ekutir.gateway.testdata;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import com.ekutir.gateway.constants.GatewayConstants;
import com.ekutir.gateway.dto.AddressDto;
import com.ekutir.gateway.dto.AdvertisementDto;
import com.ekutir.gateway.dto.BusinessTipsDto;
import com.ekutir.gateway.dto.Communication;
import com.ekutir.gateway.dto.CustomerAndLandDetails;
import com.ekutir.gateway.dto.CustomerDto;
import com.ekutir.gateway.dto.LandDetailsDto;
import com.ekutir.gateway.dto.RegistrationDto;
import com.ekutir.gateway.dto.SalesAndOffersDto;
import com.ekutir.gateway.dto.UserDto;
import com.google.gson.Gson;

public class TestDataGenerator {

	public static void main(String args[]) throws ParseException {
		// getCommunicationAsJson();
		// getOtpAsJson();
		// getRegistrationDetailsAsJson();
		// checkDateFormat("30-06-2017 23:21");
		// getCustomerAsJsonForReg();
		// getCustomerAsJson();
		// getUserForFetchCustomers();
		// getUserAsJsonForEditing();
		// getCustomerLandDetailsAsJson();
		getCustomerLandDetailsAsJsonForFetchingCust();
		// getUserForReg();
	}

	private static void getUserForReg() {
		RegistrationDto registrationDto = new RegistrationDto();
		Communication communication = new Communication();
		communication.setApplicationCode("SANI");
		communication.setImei("IMEI123456789");
		communication.setOtp(1234);
		registrationDto.setCommunication(communication);
	}

	private static void getCustomerLandDetailsAsJson() {
		CustomerAndLandDetails customerAndLandDetails = new CustomerAndLandDetails();
		CustomerDto customer = new CustomerDto();
		customer.setCustAadharNumber("ADHAAR1234");
		customer.setCustFirstName("CUSTFNAME");
		customer.setCustMiddleName("CUSTMNAME");
		customer.setCustLastName("CUSTLNAME");
		customer.setCustomerType(GatewayConstants.CUSTOMER_TYPE_MICROENTREPRENEUR);
		customer.setCustPhoneNumber(9090909090L);
		customer.setUserId(1);
		AddressDto address = new AddressDto();
		address.setAddressLine1("ADDRLine1");
		address.setAddressLine2("ADDRLINE2");
		address.setAddressLine3("ADDRLINE3");
		address.setBlock("BLOCK");
		address.setCity("BBSR");
		address.setCountry("INDIA");
		address.setDistrict("KHORDA");
		address.setPostalCode(751029L);
		address.setState("ODISHA");
		customer.setAddress(address);
		customerAndLandDetails.setCustomer(customer);
		List<LandDetailsDto> landDetails = new ArrayList<LandDetailsDto>();
		LandDetailsDto detailsDto = new LandDetailsDto();
		detailsDto.setLandArea(new Double(234.23));
		detailsDto.setLandLocation("Jharpada");
		detailsDto.setLandOwnership("SELF");
		detailsDto.setLandUnit("ACRE");
		landDetails.add(detailsDto);

		detailsDto = new LandDetailsDto();
		detailsDto.setLandArea(new Double(23.23));
		detailsDto.setLandLocation("Khorda");
		detailsDto.setLandOwnership("SELF");
		detailsDto.setLandUnit("ACRE");
		landDetails.add(detailsDto);

		customerAndLandDetails.setLandDetails(landDetails);

		Gson gson = new Gson();
		System.out.println(gson.toJson(customerAndLandDetails));
	}

	private static void getCustomerLandDetailsAsJsonForFetchingCust() {
		CustomerAndLandDetails customerAndLandDetails = new CustomerAndLandDetails();
		CustomerDto customer = new CustomerDto();
		customer.setCustomerId(1);
		customerAndLandDetails.setCustomer(customer);
		Gson gson = new Gson();
		System.out.println(gson.toJson(customerAndLandDetails));
	}

	private static void getUserAsJsonForEditing() {
		UserDto user = new UserDto();
		user.setUserId(23);
		user.setFirstName("Jonhee");
		user.setMiddleName("middleJohnee");
		user.setLastName("last johnee");
		AddressDto addressDto = new AddressDto();
		addressDto.setAddressLine1("Joohneee's Address");
		user.setAddress(addressDto);
		Gson gson = new Gson();
		System.out.println(gson.toJson(user));
	}

	private static void getUserForFetchCustomers() {
		UserDto userDto = new UserDto();
		userDto.setUserId(1234);
		Gson gson = new Gson();
		System.out.println(gson.toJson(userDto));

	}

	private static void checkDateFormat(String sampleDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
		dateFormat.setLenient(false);
		try {
			System.out.println(dateFormat.parse(sampleDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	private static void getCommunicationAsJson() {
		Gson gson = new Gson();
		Communication communication = new Communication();
		communication.setPhoneNumber(9999999999L);
		communication.setPassword("TEMP_PASS");
		System.out.println(gson.toJson(communication));
	}

	public static void getOtpAsJson() throws ParseException {
		Communication otpDto = new Communication();
		otpDto.setOtp(1234);
		otpDto.setPhoneNumber(9999999999L);
		otpDto.setOtpGenerationDate("31-07-1982 22:00");
		Gson gson = new Gson();
		System.out.println(gson.toJson(otpDto));
	}

	public static void getCustomerAsJsonForReg() throws ParseException {
		RegistrationDto registrationDto = new RegistrationDto();
		CustomerDto customerDto = new CustomerDto();
		customerDto.setCustAadharNumber("ABC123456789");
		customerDto.setCustFirstName("John");
		customerDto.setCustLastName("Doe");
		customerDto.setCustMiddleName("middle");
		customerDto.setCustPhoneNumber(9777711122L);
		registrationDto.setCustomer(customerDto);
		UserDto userDto = new UserDto();
		userDto.setUserId(1);
		registrationDto.setUser(userDto);
		Gson gson = new Gson();
		System.out.println(gson.toJson(registrationDto));
	}

	public static void getCustomerAsJson() throws ParseException {
		CustomerDto customerDto = new CustomerDto();
		customerDto.setCustomerId(1);
		customerDto.setCustAadharNumber("ABC123456789");
		customerDto.setCustFirstName("John");
		customerDto.setCustLastName("Doe");
		customerDto.setCustMiddleName("middle");
		customerDto.setCustPhoneNumber(9999999999L);
		customerDto.setCustomerType("CUST_TYPE_2");
		Gson gson = new Gson();
		System.out.println(gson.toJson(customerDto));
	}

	public static void getRegistrationDetailsAsJson() throws ParseException {
		RegistrationDto registrationDto = new RegistrationDto();
		Communication communicationDto = new Communication();
		communicationDto.setApplicationCode("SANIMARK");
		communicationDto.setImei("ABC1234567890");
		communicationDto.setOtp(1234);
		communicationDto.setOtpGenerationDate("31-07-2017 22:00");
		communicationDto.setPhoneNumber(9999999999L);
		communicationDto.setStatus("");
		communicationDto.setPassword("TEMP_PASS");
		registrationDto.setCommunication(communicationDto);
		UserDto userDto = new UserDto();
		userDto.setAadharNumber("ABCAADHAR1234");
		AddressDto addressDto = new AddressDto();
		addressDto.setBlock("BLOCK");
		addressDto.setCity("CITY");
		addressDto.setCountry("IN");
		addressDto.setDistrict("DISTRICT");
		addressDto.setAddressLine1("ADDR LINE 1");
		addressDto.setAddressLine2("ADDR LINE 2");
		addressDto.setAddressLine3("ADDR LINE 3");
		addressDto.setPostalCode(808080L);
		addressDto.setState("STATE");
		userDto.setAddress(addressDto);
		userDto.setBusinessName("BIZNAME");
		userDto.setFirstName("FNAME");
		userDto.setMiddleName("MNAME");
		userDto.setLastName("LNAME");
		userDto.seteMailId("abc@abc.com");
		userDto.setProfileWriteUp("SDADADSADsADADASD");
		userDto.setShopLicenseExpiryDate("31-07-1982");
		userDto.setShopLicenseNumber("LIC123456789");
		userDto.setTypeOfUser("INDIVIDUAL");
		registrationDto.setUser(userDto);
		Gson gson = new Gson();
		System.out.println(gson.toJson(registrationDto));
	}

	public static List<AdvertisementDto> generateAdvertisements(File imageDir) throws ParseException {
		List<AdvertisementDto> advertisements = new ArrayList<>();
		AdvertisementDto adv1 = new AdvertisementDto();
		adv1.setAltText("ALT_TEXT_1");
		adv1.setAdvertisementsAsBase64(getRandomImageAsBase64(imageDir, 1));
		adv1.setStartDate(new Date());
		adv1.setEndDate(new Date());
		advertisements.add(adv1);

		AdvertisementDto adv2 = new AdvertisementDto();
		adv2.setAltText("ALT_TEXT_3");
		adv2.setAdvertisementsAsBase64(getRandomImageAsBase64(imageDir, 2));
		adv2.setStartDate(new Date());
		adv2.setEndDate(new Date());
		advertisements.add(adv2);

		AdvertisementDto adv3 = new AdvertisementDto();
		adv3.setAltText("ALT_TEXT_3");
		adv3.setAdvertisementsAsBase64(getRandomImageAsBase64(imageDir, 3));
		adv3.setStartDate(new Date());
		adv3.setEndDate(new Date());
		advertisements.add(adv3);

		return advertisements;
	}

	private static String getRandomImageAsBase64(File imageDir, int i) {
		String encodedfile = null;
		FileInputStream fileInputStreamReader = null;
		try {
			File imageFile = new File(imageDir + (i == 1 ? "/pic1.png" : (i == 2 ? "/pic2.png" : "/pic3.png")));
			fileInputStreamReader = new FileInputStream(imageFile);
			byte[] bytes = new byte[(int) imageFile.length()];
			fileInputStreamReader.read(bytes);
			encodedfile = new String(Base64.getEncoder().encodeToString(bytes));
		} catch (Exception e) {
			e.printStackTrace();
			try {
				fileInputStreamReader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		return encodedfile;
	}

	public static List<BusinessTipsDto> generateBusinessTips(File imageDir) {
		List<BusinessTipsDto> businessTips = new ArrayList<>();
		BusinessTipsDto adv1 = new BusinessTipsDto();
		adv1.setAltText("ALT_TEXT_1");
		adv1.setBusinessTipsAsBase64(getRandomImageAsBase64(imageDir, 1));
		adv1.setStartDate(new Date());
		adv1.setEndDate(new Date());
		businessTips.add(adv1);

		BusinessTipsDto adv2 = new BusinessTipsDto();
		adv2.setAltText("ALT_TEXT_3");
		adv2.setBusinessTipsAsBase64(getRandomImageAsBase64(imageDir, 2));
		adv2.setStartDate(new Date());
		adv2.setEndDate(new Date());
		businessTips.add(adv2);

		BusinessTipsDto adv3 = new BusinessTipsDto();
		adv3.setAltText("ALT_TEXT_3");
		adv3.setBusinessTipsAsBase64(getRandomImageAsBase64(imageDir, 3));
		adv3.setStartDate(new Date());
		adv3.setEndDate(new Date());
		businessTips.add(adv3);

		return businessTips;
	}

	public static List<SalesAndOffersDto> getSalesAndOffers(File imageDir) {
		List<SalesAndOffersDto> salesAndOffers = new ArrayList<>();
		SalesAndOffersDto adv1 = new SalesAndOffersDto();
		adv1.setAltText("ALT_TEXT_1");
		adv1.setSalesAndOffersAsBase64(getRandomImageAsBase64(imageDir, 1));
		adv1.setStartDate(new Date());
		adv1.setEndDate(new Date());
		salesAndOffers.add(adv1);

		SalesAndOffersDto adv2 = new SalesAndOffersDto();
		adv2.setAltText("ALT_TEXT_3");
		adv2.setSalesAndOffersAsBase64(getRandomImageAsBase64(imageDir, 2));
		adv2.setStartDate(new Date());
		adv2.setEndDate(new Date());
		salesAndOffers.add(adv2);

		SalesAndOffersDto adv3 = new SalesAndOffersDto();
		adv3.setAltText("ALT_TEXT_3");
		adv3.setSalesAndOffersAsBase64(getRandomImageAsBase64(imageDir, 3));
		adv3.setStartDate(new Date());
		adv3.setEndDate(new Date());
		salesAndOffers.add(adv3);

		return salesAndOffers;
	}

}

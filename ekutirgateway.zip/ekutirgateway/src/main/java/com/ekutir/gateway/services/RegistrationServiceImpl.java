package com.ekutir.gateway.services;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.serial.SerialException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.ekutir.gateway.constants.GatewayConstants;
import com.ekutir.gateway.dao.GatewayDao;
import com.ekutir.gateway.dao.RestUtility;
import com.ekutir.gateway.dto.AddressDto;
import com.ekutir.gateway.dto.Communication;
import com.ekutir.gateway.dto.CustomerAndLandDetails;
import com.ekutir.gateway.dto.CustomerDto;
import com.ekutir.gateway.dto.LandDetailsDto;
import com.ekutir.gateway.dto.Otp2PlanResponse;
import com.ekutir.gateway.dto.RegistrationDto;
import com.ekutir.gateway.dto.RegistrationInProcessUserDto;
import com.ekutir.gateway.dto.RequestValidationDto;
import com.ekutir.gateway.dto.StatusDto;
import com.ekutir.gateway.dto.UserDtoForUpdate;
import com.ekutir.gateway.dto.ValidationDto;
import com.ekutir.gateway.model.Address;
import com.ekutir.gateway.model.AppMaster;
import com.ekutir.gateway.model.AppMasterKey;
import com.ekutir.gateway.model.Application;
import com.ekutir.gateway.model.Auth;
import com.ekutir.gateway.model.BusinessUser;
import com.ekutir.gateway.model.Customer;
import com.ekutir.gateway.model.CustomerType;
import com.ekutir.gateway.model.MeAndMyLand;
import com.ekutir.gateway.model.PhoneXOtp;
import com.ekutir.gateway.model.Registration;
import com.ekutir.gateway.model.SvadhaErpAddress;
import com.ekutir.gateway.model.SvadhaErpMeCustomer;
import com.ekutir.gateway.model.User;
import com.ekutir.gateway.model.UserLocation;
import com.ekutir.gateway.utilities.GatewayUtilties;

@Service("registrationService")
public class RegistrationServiceImpl implements RegistrationService {
	
	@Autowired
	RestUtility restUtil;

	@Autowired
	GatewayDao gatewayDao;

	private static final Logger LOGGER = Logger.getLogger(RegistrationServiceImpl.class);

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public RegistrationInProcessUserDto initiateUserRegistration(long phoneNumber, String tempAuthKey, String appCode) {
		RegistrationInProcessUserDto registrationInProcessUserDto = new RegistrationInProcessUserDto();
		registrationInProcessUserDto.setAuthKey(tempAuthKey);
		StatusDto status = new StatusDto();
		try {
			Map<String, Boolean> phoneNumberRegistrationDetails = gatewayDao.isPhoneNumberAlreadyRegistered(phoneNumber,
					appCode);
			if (null != phoneNumberRegistrationDetails && phoneNumberRegistrationDetails.size() > 0) {
				/*if(phoneNumberRegistrationDetails.containsKey("IS_BUSINESS_USER") && appCode=="RUHT"){*/
				if (phoneNumberRegistrationDetails.containsKey("IS_BUSINESS_USER")) {
					if(appCode.equalsIgnoreCase("RUHT")){
					registrationInProcessUserDto.setTypeOfUser(GatewayConstants.CUSTOMER_TYPE_BUSINESS_DELEGATE);
					status.setStatusCode(GatewayConstants.PHONE_NUMBER_ALREADY_REGISTERED_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.PHONE_NUMBER_ALREADY_REGISTERED_STATUS_MESSAGE);
					gatewayDao.saveTempAuthKey(phoneNumber, tempAuthKey);
					}else{
						if (generateAndSendOtp(phoneNumber, tempAuthKey)) {
							status.setStatusCode(GatewayConstants.PHONE_NUMBER_ACCEPTED_STATUS_CODE);
							status.setStatusMessage(GatewayConstants.PHONE_NUMBER_ACCEPTED_AND_OTP_SENT_STATUS_MESSAGE);
						} else {
							status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
							status.setStatusMessage(GatewayConstants.OTP_GENERATION_FAILED_STATUS_MESSAGE);
						}
					}
				} else {
					registrationInProcessUserDto.setTypeOfUser(GatewayConstants.CUSTOMER_TYPE_RETURNING_USER);
					status.setStatusCode(GatewayConstants.PHONE_NUMBER_ALREADY_REGISTERED_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.PHONE_NUMBER_ALREADY_REGISTERED_STATUS_MESSAGE);
					gatewayDao.saveTempAuthKey(phoneNumber, tempAuthKey);
				}
				/*status.setStatusCode(GatewayConstants.PHONE_NUMBER_ALREADY_REGISTERED_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.PHONE_NUMBER_ALREADY_REGISTERED_STATUS_MESSAGE);
				gatewayDao.saveTempAuthKey(phoneNumber, tempAuthKey);*/
			} else {
				if (generateAndSendOtp(phoneNumber, tempAuthKey)) {
					status.setStatusCode(GatewayConstants.PHONE_NUMBER_ACCEPTED_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.PHONE_NUMBER_ACCEPTED_AND_OTP_SENT_STATUS_MESSAGE);
				} else {
					status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.OTP_GENERATION_FAILED_STATUS_MESSAGE);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
		}
		registrationInProcessUserDto.setStatus(status);
		return registrationInProcessUserDto;
	}

	private boolean generateAndSendOtp(long phoneNumber, String tempAuthKey) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			// NEPAL
			//String url = "http://2factor.in/API/V1/{apiKey}/SMS/+977{phoneNumber}/{otp}";
			// INDIA
			 String url =
			 "http://2factor.in/API/V1/{apiKey}/SMS/{phoneNumber}/{otp}";
			String apiKey = GatewayConstants.TWO_PLAN_OTP_SERVICE_API_KEY;
			int otp = generateRandom4Digit();
			String otpdetails="Your buy code is"+otp;
			Otp2PlanResponse otp2PlanResponse = restTemplate.getForObject(url, Otp2PlanResponse.class, apiKey,
					phoneNumber, otp);
			savePhoneXOtp(phoneNumber, otp, tempAuthKey, otp2PlanResponse.getStatus(), otp2PlanResponse.getDetails());
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	private int generateRandom4Digit() {
		return (int) (Math.random() * 9000) + 1000;
	}

	private void savePhoneXOtp(long phoneNumber, int otp, String tempAuthKey, String status, String session) {
		PhoneXOtp phoneXOtp = new PhoneXOtp();
		phoneXOtp.setPhoneNumber(phoneNumber);
		phoneXOtp.setOtp(otp);
		phoneXOtp.setTempAuthKey(tempAuthKey);
		phoneXOtp.setStatus(status);
		phoneXOtp.setSession(session);
		gatewayDao.savePhoneNumberTempAuthKeyAndOtp(phoneXOtp);
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public RegistrationInProcessUserDto verifyPasscodeForExistingUser(String password, long phoneNumber,
			String tempAuthKey, String appCode) {
		RegistrationInProcessUserDto registrationInProcessUserDto = new RegistrationInProcessUserDto();
		registrationInProcessUserDto.setAuthKey(tempAuthKey);
		StatusDto status = new StatusDto();
		if (gatewayDao.checkTempAuth(phoneNumber, tempAuthKey)) {
			if (gatewayDao.verifyPassword(password, phoneNumber, tempAuthKey, appCode)) {
				if (generateAndSendOtp(phoneNumber, tempAuthKey)) {
					status.setStatusCode(GatewayConstants.PASSCODE_VERIFIED_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.PASSCODE_VERIFIED_STATUS_MESSAGE);
				} else {
					status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.OTP_GENERATION_FAILED_STATUS_MESSAGE);
				}

			} else {
				status.setStatusCode(GatewayConstants.PASSCODE_IS_NOT_VALID_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.PASSCODE_NOT_VALID_STATUS_MESSAGE);
			}
		} else {
			status.setStatusCode(GatewayConstants.AUTH_KEY_INVALID_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.INVALID_AUTH_KEY_STATUS_MESSAGE);
		}
		registrationInProcessUserDto.setStatus(status);
		return registrationInProcessUserDto;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public StatusDto verifyOtp(Communication communication, String tempAuthKey) {
		StatusDto status = new StatusDto();
		if (gatewayDao.verifyOtp(communication.getPhoneNumber(), communication.getOtp(), tempAuthKey)) {
			status.setStatusCode(GatewayConstants.OTP_VERIFICATION_COMPLETED_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.OTP_VERIFICATION_COMPLETED_STATUS_MESSAGE);
		} else {
			status.setStatusCode(GatewayConstants.OTP_VERIFICATION_FAILED_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.OTP_VERIFICATION_FAILED_STATUS_MESSAGE);
		}
		return status;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public RegistrationInProcessUserDto registerUser(RegistrationDto registrationUserDetails, String tempAuthKey) {
		RegistrationInProcessUserDto inProcessUserRegistrationDetails = new RegistrationInProcessUserDto();
		StatusDto status = new StatusDto();
		try {
			UserLocation userLoc=new UserLocation();
			if (isAuthKeyExists(tempAuthKey, registrationUserDetails.getCommunication().getPhoneNumber())) {
				String authKey = GatewayUtilties.generateAuthKey(registrationUserDetails.getCommunication().getImei(),
						registrationUserDetails.getCommunication().getPhoneNumber(), tempAuthKey);
				String masterKey = GatewayUtilties.getMasterKey(
						registrationUserDetails.getCommunication().getApplicationCode(),
						registrationUserDetails.getCommunication().getPhoneNumber());
				User user = getUserFromRegistrationDetails(registrationUserDetails, authKey, masterKey);
				user = gatewayDao.insertNewUserRegistrationDetails(user);
				String userLat=registrationUserDetails.getUserLat();
				String userLong=registrationUserDetails.getUserLong();
				int userId=user.getUserId();
				/*if(!userLat.equals(null) && !userLong.equals(null)){*/
					if(null!=userLat && null!=userLong){
					userLoc.setUser_id(userId);
					userLoc.setUser_lat(userLat);
					userLoc.setUser_long(userLong);
					userLoc=gatewayDao.insertUserLocation(userLoc);
				}
				// Upon successful registration process completion, remove
				// the
				// TEMP AUTH entry in PhoneXOtp table
				if (user.getUserId() != 0) {
					// Save Row in Svadha ERP Address & Customer table
					if (registrationUserDetails.getCommunication().getApplicationCode()
							.equalsIgnoreCase(GatewayConstants.SANIMARK_APP_CODE)) {
						SvadhaErpAddress erpAddress = populateSvadhaAddressDetails(user);
						int meAddrId = gatewayDao.saveSvadhaErpMeAddress(erpAddress);
						SvadhaErpMeCustomer erpMeCustomer = populateSvadhaMeDetails(user, meAddrId);
						int erpCustomerId = gatewayDao.saveSvadhaCustomerInfo(erpMeCustomer);
						AppMaster appMaster = new AppMaster();
						AppMasterKey appMasterKey = new AppMasterKey();
						appMasterKey.setAppId(erpCustomerId);
						appMasterKey.setUserId(user.getUserId());
						appMaster.setAppMasterKey(appMasterKey);
						appMaster.setApplicationCode(GatewayConstants.SANIMARK_APP_CODE);
						gatewayDao.saveAppMapping(appMaster);
						inProcessUserRegistrationDetails.setConnectedAppUserId(erpCustomerId);
					}
					gatewayDao.removeTempAuth(registrationUserDetails.getCommunication().getPhoneNumber());
					inProcessUserRegistrationDetails.setUser(transformUser(user));
					inProcessUserRegistrationDetails.setCommunication(getCommunicationFromDbUser(user));
					inProcessUserRegistrationDetails.setAuthKey(authKey);
					inProcessUserRegistrationDetails.setMasterKey(masterKey);
					status.setStatusCode(GatewayConstants.REGISTRATION_PROCESS_COMPLETED_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.REGISTRATION_PROCESS_COMPLETED_STATUS_MESSAGE);
				} else {
					status.setStatusCode(
							GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
					status.setStatusMessage(
							GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
				}
			} else {
				status.setStatusCode(GatewayConstants.AUTH_KEY_INVALID_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.INVALID_AUTH_KEY_STATUS_MESSAGE);
			}
			inProcessUserRegistrationDetails.setStatus(status);
		} catch (Exception e) {
			status.setStatusCode(GatewayConstants.AUTH_KEY_INVALID_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.INVALID_AUTH_KEY_STATUS_MESSAGE);
			inProcessUserRegistrationDetails.setStatus(status);
			e.printStackTrace();
		}
		return inProcessUserRegistrationDetails;
	}

	private SvadhaErpMeCustomer populateSvadhaMeDetails(User user, int meAddrId) throws ParseException {
		SvadhaErpMeCustomer erpMeCustomer = new SvadhaErpMeCustomer();
		Registration registration = user.getRegistration();
		erpMeCustomer.setAadhaarNumber(Long.parseLong(registration.getAadharNumber()));
		erpMeCustomer.setAddressId(meAddrId);
		erpMeCustomer.setBusinessCatId(0);
		erpMeCustomer.setBusinessName(user.getBusinessName());
		// TODO Get User From Svadha Survey
		erpMeCustomer.setCreatedBy(0);
		erpMeCustomer.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		erpMeCustomer.setCustomerFirstName(user.getFirstName());
		erpMeCustomer.setCustomerLastName(user.getLastName());
		erpMeCustomer.setCustomerMiddleName(user.getMiddleName());
		erpMeCustomer.setCustomerStatus(GatewayConstants.ACTIVE_STATUS_TAG);
		erpMeCustomer.setDescription(GatewayConstants.SVADHA_ERP_CUST_DESC);
		erpMeCustomer.setPrevLeadId(0);
		erpMeCustomer.setPrimaryPhoneNumber(registration.getPhoneNumber());
		// Duplicating primary phone number to secondary to prevent NPE in
		// SvadhaERP
		erpMeCustomer.setSecondaryPhoneNumber(registration.getPhoneNumber());
		return erpMeCustomer;
	}

	private SvadhaErpAddress populateSvadhaAddressDetails(User user) {
		SvadhaErpAddress erpAddress = new SvadhaErpAddress();
		Address address = user.getAddress();
		erpAddress.setAddressLine1(address.getAddressLine1());
		erpAddress.setAddressLine2(address.getAddressLine2());
		erpAddress.setAddressLine3(address.getAddressLine3());
		erpAddress.setBlock(address.getBlock());
		erpAddress.setCity(address.getCity());
		erpAddress.setCountry(address.getCountry());
		erpAddress.setDistrict(address.getDistrict());
		erpAddress.setPostalCode(String.valueOf(address.getPostalCode()));
		erpAddress.setState(address.getState());
		return erpAddress;
	}

	private Communication getCommunicationFromDbUser(User user) {
		Communication communication = new Communication();
		if (null != user) {
			communication.setImei(user.getRegistration().getImei());
			communication.setPhoneNumber(user.getRegistration().getPhoneNumber());
			communication.setTypeOfUser(user.getTypeOfUser());
		}
		return communication;
	}

	private UserDtoForUpdate transformUser(User dbUser) throws SQLException, ParseException {
		UserDtoForUpdate user = new UserDtoForUpdate();
		if (null != dbUser) {
			user = new UserDtoForUpdate();
			user.setAadharNumber(dbUser.getRegistration().getAadharNumber());
			user.setAddress(transformAddress(dbUser.getAddress()));
			user.setBusinessName(dbUser.getBusinessName());
			user.setFirstName(dbUser.getFirstName());
			user.setLastName(dbUser.getLastName());
			user.setMiddleName(dbUser.getMiddleName());
			user.setProfilePic(GatewayUtilties.convertBlobToBase64(dbUser.getProfilePic()));
			user.setProfileWriteUp(dbUser.getProfileWriteup());
			user.setRating(dbUser.getRating());
			user.setShopLicenseExpiryDate(dbUser.getShopLicExpiryDate());
			user.setShopLicenseNumber(dbUser.getShopLicNumber());
			user.setShopPicture(GatewayUtilties.convertBlobToBase64(dbUser.getShopPic()));
			user.setTinNumber(dbUser.getRegistration().getTinNumber());
			user.setTypeOfUser(dbUser.getTypeOfUser());
			user.setBankAccountName(dbUser.getRegistration().getBankAccountName());
			user.setBankAccountNumber(dbUser.getRegistration().getBankAccountNumber());
			user.setBankName(dbUser.getRegistration().getBankName());
			user.setBankIfscCode(dbUser.getRegistration().getBankAccountIfscCode());
			user.setUserId(dbUser.getUserId());
		}
		return user;
	}

	private AddressDto transformAddress(Address dbAddress) {
		AddressDto address = new AddressDto();
		if (null != dbAddress) {
			address.setAddressLine1(dbAddress.getAddressLine1());
			address.setAddressLine2(dbAddress.getAddressLine2());
			address.setAddressLine3(dbAddress.getAddressLine3());
			address.setBlock(dbAddress.getBlock());
			address.setCity(dbAddress.getCity());
			address.setCountry(dbAddress.getCountry());
			address.setDistrict(dbAddress.getDistrict());
			address.setPostalCode(dbAddress.getPostalCode());
			address.setState(dbAddress.getState());
		}
		return address;
	}

	/**
	 * Update registration for returning user. The method will update IMEI
	 * number and Auth token for the corresponding phone number.
	 *
	 * @param comunication
	 * @param masterKey
	 * @param authKey
	 * @param string
	 * @return
	 */
	private User updateRegistrationForReturningUser(Communication comunication, String authKey, String masterKey,
			String appCode) {
		String imei = comunication.getImei();
		User user = gatewayDao.fetchUser(comunication.getPhoneNumber(), appCode);
		Registration registration = user.getRegistration();
		String oldImei = registration.getImei();
		registration.setImei(imei);
		user.getAuth().setAuthToken(authKey);
		user = gatewayDao.updateRegistrationForReturningUser(user);
		gatewayDao.writeToAudit(GatewayConstants.AUDIT_CAPTION_BUSINESS_DELEGATE_CHANGE,
				"Returning user with phone number" + registration.getPhoneNumber() + " registered to IMEI : " + oldImei
						+ " is now registered to IMEI " + imei);
		return user;
	}

	private BusinessUser updateBusinessUserDelegate(Communication communication, String authKey, String masterKey) {
		BusinessUser businessUser = gatewayDao.fetchBusinessUser(communication.getPhoneNumber());
		String oldImei = businessUser.getRegisteredImei();
		businessUser.setRegisteredImei(communication.getImei());
		businessUser.getAuth().setAuthToken(authKey);
		businessUser = gatewayDao.updateBusinessUser(businessUser);
		gatewayDao.writeToAudit(GatewayConstants.AUDIT_CAPTION_BUSINESS_DELEGATE_CHANGE,
				"Business delegate with phone number" + communication.getPhoneNumber() + " registered to IMEI : "
						+ oldImei + " is now registered to IMEI " + communication.getImei());
		return businessUser;
	}

	private boolean isAuthKeyExists(String tempAuthKey, long phoneNumber) {
		return gatewayDao.checkTempAuth(phoneNumber, tempAuthKey);
	}

	private User getUserFromRegistrationDetails(RegistrationDto registrationUserDetails, String authKey,
			String masterKey) throws ParseException, SerialException, SQLException {
		User user = new User();
		Address address = new Address();
		address.setAddressLine1(registrationUserDetails.getUser().getAddress().getAddressLine1());
		address.setAddressLine2(null != registrationUserDetails.getUser().getAddress().getAddressLine2()
				? registrationUserDetails.getUser().getAddress().getAddressLine2() : "");
		address.setAddressLine3(null != registrationUserDetails.getUser().getAddress().getAddressLine3()
				? registrationUserDetails.getUser().getAddress().getAddressLine3() : "");
		address.setBlock(null != registrationUserDetails.getUser().getAddress().getBlock()
				? registrationUserDetails.getUser().getAddress().getBlock() : "");
		address.setCity(null != registrationUserDetails.getUser().getAddress().getCity()
				? registrationUserDetails.getUser().getAddress().getCity() : "");
		address.setCountry(null != registrationUserDetails.getUser().getAddress().getCountry()
				? registrationUserDetails.getUser().getAddress().getCountry() : "");
		address.setPostalCode(null != registrationUserDetails.getUser().getAddress().getPostalCode()
				? registrationUserDetails.getUser().getAddress().getPostalCode() : null);
		address.setDistrict(null != registrationUserDetails.getUser().getAddress().getDistrict()
				? registrationUserDetails.getUser().getAddress().getDistrict() : "");
		address.setState(null != registrationUserDetails.getUser().getAddress().getState()
				? registrationUserDetails.getUser().getAddress().getState() : "");
		address.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		address.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		user.setAddress(address);
		Auth auth = new Auth();
		auth.setAuthToken(authKey);
		auth.setAuthType(GatewayConstants.AUTH_KEY_TAG);
		auth.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		auth.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		user.setAuth(auth);

		user.setBusinessName(null != registrationUserDetails.getUser().getBusinessName()
				? registrationUserDetails.getUser().getBusinessName() : "");
		user.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		user.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		user.setFirstName(registrationUserDetails.getUser().getFirstName());
		user.setMiddleName(null != registrationUserDetails.getUser().getMiddleName()
				? registrationUserDetails.getUser().getMiddleName() : "");
		user.setLastName(registrationUserDetails.getUser().getLastName());
		user.setPassword(registrationUserDetails.getCommunication().getPassword());
		user.setProfilePic(GatewayUtilties.convertByteArrayToBlob(registrationUserDetails.getUser().getProfilePic()));
		user.setProfileWriteup(null != registrationUserDetails.getUser().getProfileWriteUp()
				? registrationUserDetails.getUser().getProfileWriteUp() : "");
		user.setRating(registrationUserDetails.getUser().getRating());
		Registration registration = new Registration();
		registration.setAadharNumber(registrationUserDetails.getUser().getAadharNumber());
		Application application = gatewayDao
				.fetchApplication(registrationUserDetails.getCommunication().getApplicationCode());
		registration.setApplication(application);
		registration.setDateTimeOfRegistration(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		registration.setImei(registrationUserDetails.getCommunication().getImei());
		registration.setPhoneNumber(registrationUserDetails.getCommunication().getPhoneNumber());
		registration.setRegistrationEndDateTime(null);
		registration.setStatus(1);
		registration.setTinNumber(registrationUserDetails.getUser().getTinNumber());
		registration.setOtp(registrationUserDetails.getCommunication().getOtp());
		registration.setBankAccountIfscCode(registrationUserDetails.getUser().getBankIfscCode());
		registration.setBankAccountName(registrationUserDetails.getUser().getBankAccountName());
		registration.setBankAccountNumber(registrationUserDetails.getUser().getBankAccountNumber());
		registration.setBankName(registrationUserDetails.getUser().getBankName());
		user.setRegistration(registration);
		user.setShopLicExpiryDate(
				null != registrationUserDetails.getUser().getShopLicenseExpiryDate() && null != GatewayUtilties
						.convertToLocalTimezone(registrationUserDetails.getUser().getShopLicenseExpiryDate())
								? registrationUserDetails.getUser().getShopLicenseExpiryDate() : null);
		user.setShopLicNumber(registrationUserDetails.getUser().getShopLicenseNumber());
		user.setShopPic(GatewayUtilties.convertByteArrayToBlob(registrationUserDetails.getUser().getShopPicture()));
		user.setStatus(1);
		user.setTypeOfUser(registrationUserDetails.getUser().getTypeOfUser());
		return user;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public StatusDto insertCustomerDetails(CustomerDto customerRegistrationDetails, String authKey) {
		StatusDto statusDto = new StatusDto();
		try {
			User user = gatewayDao.getMicroentrepreneur(customerRegistrationDetails.getUserId());
			CustomerType customerType = gatewayDao.fetchCustomerTypes(customerRegistrationDetails.getCustomerType());
			if (null != user) {
				Customer customer;
				customer = getCustomer(customerRegistrationDetails, user, customerType, authKey);
				int customerId = gatewayDao.insertCustomerDetails(customer);
				LOGGER.debug("Customer details inserted successfully for customer id : " + customerId);
			}
			statusDto.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_CODE);
			statusDto.setStatusMessage(
					GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_COMPLETE_STATUS_MESSAGE);
		} catch (ParseException e) {
			statusDto.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			statusDto.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
		}
		return statusDto;
	}

	private Customer getCustomer(CustomerDto customerRegistrationDetails, User user, CustomerType customerType,String authkey)
			throws ParseException {
		Customer customer = new Customer();
		if(authkey.equalsIgnoreCase("SANI")){
		customer.setAadharNumber(customerRegistrationDetails.getCustAadharNumber());
		customer.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		customer.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		customer.setFirstName(customerRegistrationDetails.getCustFirstName());
		customer.setLastName(customerRegistrationDetails.getCustLastName());
		customer.setUser(user);
		customer.setMiddleName(customerRegistrationDetails.getCustMiddleName());
		customer.setPhoneNumber(customerRegistrationDetails.getCustPhoneNumber());
		customer.setCustomerType(customerType);
		}else{
			customer.setAadharNumber(customerRegistrationDetails.getCustAadharNumber());
			customer.setCreatedBy(GatewayConstants.SYSTEM_TAG);
			customer.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			customer.setFirstName(customerRegistrationDetails.getCustFirstName());
			customer.setLastName(customerRegistrationDetails.getCustLastName());
			customer.setUser(user);
			customer.setMiddleName(customerRegistrationDetails.getCustMiddleName());
			customer.setPhoneNumber(customerRegistrationDetails.getCustPhoneNumber());
			customer.setCustomerType(customerType);
			//AddressDto address=customerRegistrationDetails.getAddress();
			//customer.setAddress(address);
			
			
			Address address = new Address();
			AddressDto addressDto = customerRegistrationDetails.getAddress();
			address.setAddressLine1(addressDto.getAddressLine1());
			address.setAddressLine2(addressDto.getAddressLine2());
			address.setAddressLine3(addressDto.getAddressLine3());
			address.setBlock(addressDto.getBlock());
			address.setCity(addressDto.getCity());
			address.setCountry(addressDto.getCountry());
			address.setCreatedBy(GatewayConstants.SYSTEM_TAG);
			address.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
			address.setDistrict(addressDto.getDistrict());
			address.setPostalCode(addressDto.getPostalCode());
			address.setState(addressDto.getState());
			customer.setAddress(address);
		}
		return customer;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public boolean isCustomerExists(CustomerDto customer, String authkey) {
		// Customer allowed to not enter aadhaar number
		// return
		// gatewayDao.isCustomerExistsForMicroentrepreneur(customer.getCustAadharNumber());
		return gatewayDao.isCustomerExistsForMicroentrepreneur(customer.getCustPhoneNumber());
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public RegistrationInProcessUserDto registerReturningOrBusinessUser(Communication communicationDto,
			String tempAuthKey) {
		RegistrationInProcessUserDto inProcessUserDto = new RegistrationInProcessUserDto();
		StatusDto status = new StatusDto();
		try {
			String typeOfUser = communicationDto.getTypeOfUser();
			String authKey = GatewayUtilties.generateAuthKey(communicationDto.getImei(),
					communicationDto.getPhoneNumber(), tempAuthKey);
			String masterKey = GatewayUtilties.getMasterKey(communicationDto.getApplicationCode(),
					communicationDto.getPhoneNumber());
			User user = null;
			BusinessUser businessUser = null;
			switch (typeOfUser) {
			case GatewayConstants.CUSTOMER_TYPE_BUSINESS_DELEGATE:
				businessUser = updateBusinessUserDelegate(communicationDto, authKey, masterKey);
				break;
			case GatewayConstants.CUSTOMER_TYPE_RETURNING_USER:
				user = updateRegistrationForReturningUser(communicationDto, authKey, masterKey,
						communicationDto.getApplicationCode());
				break;
			default:
				break;
			}
			// Upon successful registration process completion, remove the
			// TEMP AUTH entry in PhoneXOtp table
			if ((null != user && user.getUserId() != 0)
					|| (null != businessUser && businessUser.getBusinessUserId() != 0)) {
				// Get Customer ID for the connected App(e.g SANIMARK Customer
				// ID)
				if (communicationDto.getApplicationCode().equalsIgnoreCase(GatewayConstants.SANIMARK_APP_CODE)) {
					int connectedAppUserId = gatewayDao.getConnectedAppCustomerId(
							user.getRegistration().getPhoneNumber(), user.getRegistration().getAadharNumber());
					inProcessUserDto.setConnectedAppUserId(connectedAppUserId);
				}
				gatewayDao.removeTempAuth(communicationDto.getPhoneNumber());
				inProcessUserDto.setUser(transformUser(user));
				inProcessUserDto.setCommunication(getCommunicationFromDbUser(user));
				inProcessUserDto.setBusinessUser(businessUser);
				inProcessUserDto.setAuthKey(authKey);
				inProcessUserDto.setMasterKey(masterKey);
				status.setStatusCode(GatewayConstants.REGISTRATION_PROCESS_COMPLETED_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.REGISTRATION_PROCESS_COMPLETED_STATUS_MESSAGE);
			} else {
				status.setStatusCode(GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_CODE);
				status.setStatusMessage(
						GatewayConstants.REGISTERATION_RESPONSE_CUSTOMER_REGISTRATION_FAILED_STATUS_MESSAGE);
			}
			inProcessUserDto.setStatus(status);
		} catch (Exception e) {
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.SYSTEM_FAILURE_STATUS_MESSAGE);
			inProcessUserDto.setStatus(status);
			e.printStackTrace();
		}
		return inProcessUserDto;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public CustomerAndLandDetails insertCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey) {
		List<MeAndMyLand> listOfMeAndMyLands = new ArrayList<MeAndMyLand>();
		MeAndMyLand meAndMyLand = null;
		List<MeAndMyLand> myAndMyLandList = Collections.emptyList();
		StatusDto status = new StatusDto();
		try {
			Customer customer = getCustomer(customerLandDetails);
			// customer = gatewayDao.saveCustomer(customer);
			if (null != customerLandDetails.getLandDetails()) {
				for (LandDetailsDto l : customerLandDetails.getLandDetails()) {
					meAndMyLand = new MeAndMyLand();
					meAndMyLand.setCreatedBy(GatewayConstants.SYSTEM_TAG);
					meAndMyLand.setCreatedDateTime(
							GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
					meAndMyLand.setCustomer(customer);
					meAndMyLand.setLandArea(l.getLandArea());
					meAndMyLand.setLandLocation(l.getLandLocation());
					meAndMyLand.setLandOwnership(l.getLandOwnership());
					meAndMyLand.setLandUnit(l.getLandUnit());
					meAndMyLand.setLandlat(l.getLandlat());
					meAndMyLand.setLandlng(l.getLandlng());
					listOfMeAndMyLands.add(meAndMyLand);
					myAndMyLandList = gatewayDao.saveMeAndMyLandDetailsForCustomer(listOfMeAndMyLands);
				}
			} else {
				customer = gatewayDao.saveCustomer(customer);
				meAndMyLand = new MeAndMyLand();
				meAndMyLand.setCustomer(customer);
				myAndMyLandList.add(meAndMyLand);
			}

			status.setStatusCode(GatewayConstants.CUST_LAND_DETAILS_SAVED_SUCCESSFULLY_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.CUST_LAND_DETAILS_SAVED_SUCCESSFULLY_STATUS_MESSAGE);
			customerLandDetails = transformMeAndMyLand(myAndMyLandList);
			customerLandDetails.setStatus(status);
		} catch (Exception e) {
			status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.CUST_LAND_DETAILS_COULT_NOT_BE_SAVED_STATUS_MESSAGE);
			customerLandDetails.setStatus(status);
		}
		return customerLandDetails;
	}

	private Customer getCustomer(CustomerAndLandDetails customerLandDetails) throws ParseException {
		CustomerDto customerDto = customerLandDetails.getCustomer();
		Customer customer = new Customer();
		customer.setAadharNumber(customerDto.getCustAadharNumber());
		customer.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		customer.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		CustomerType customerType = gatewayDao.fetchCustomerTypes(customerDto.getCustomerType());
		customer.setCustomerType(customerType);
		customer.setFirstName(customerDto.getCustFirstName());
		customer.setMiddleName(customerDto.getCustMiddleName());
		customer.setLastName(customerDto.getCustLastName());
		customer.setPhoneNumber(customerDto.getCustPhoneNumber());
		Address address = new Address();
		AddressDto addressDto = customerLandDetails.getCustomer().getAddress();
		address.setAddressLine1(addressDto.getAddressLine1());
		address.setAddressLine2(addressDto.getAddressLine2());
		address.setAddressLine3(addressDto.getAddressLine3());
		address.setBlock(addressDto.getBlock());
		address.setCity(addressDto.getCity());
		address.setCountry(addressDto.getCountry());
		address.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		address.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		address.setDistrict(addressDto.getDistrict());
		address.setPostalCode(addressDto.getPostalCode());
		address.setState(addressDto.getState());
		customer.setAddress(address);
		User user = gatewayDao.fetchUserById(customerDto.getUserId());
		customer.setUser(user);
		return customer;
	}

	private CustomerAndLandDetails transformMeAndMyLand(List<MeAndMyLand> myAndMyLandList) {
		CustomerAndLandDetails customerAndLandDetails = new CustomerAndLandDetails();
		CustomerDto customerDto = new CustomerDto();
		AddressDto addressDto = new AddressDto();
		Customer customer = myAndMyLandList.get(0).getCustomer();

		Address address = customer.getAddress();
		addressDto.setAddressLine1(address.getAddressLine1());
		addressDto.setAddressLine2(address.getAddressLine2());
		addressDto.setAddressLine3(address.getAddressLine3());
		addressDto.setBlock(address.getBlock());
		addressDto.setCity(address.getCity());
		addressDto.setCountry(address.getCountry());
		addressDto.setDistrict(address.getDistrict());
		addressDto.setPostalCode(address.getPostalCode());
		addressDto.setState(address.getState());
		addressDto.setAddressId(address.getAddressId());
		customerDto.setAddress(addressDto);

		customerDto.setCustAadharNumber(customer.getAadharNumber());
		customerDto.setCustFirstName(customer.getFirstName());
		customerDto.setCustMiddleName(customer.getMiddleName());
		customerDto.setCustLastName(customer.getLastName());
		customerDto.setCustomerId(customer.getCustomerId());
		customerDto.setCustomerType(customer.getCustomerType().getTypeCode());
		customerDto.setCustPhoneNumber(customer.getPhoneNumber());
		customerAndLandDetails.setCustomer(customerDto);
		List<LandDetailsDto> landDetails = new ArrayList<>();
		LandDetailsDto landDetail = null;
		for (MeAndMyLand m : myAndMyLandList) {
			landDetail = new LandDetailsDto();
			landDetail.setLandId(m.getLandId());
			landDetail.setLandArea(m.getLandArea());
			landDetail.setLandLocation(m.getLandLocation());
			landDetail.setLandOwnership(m.getLandOwnership());
			landDetail.setLandUnit(m.getLandUnit());
			landDetail.setLandlat(m.getLandlat());
			landDetail.setLandlng(m.getLandlng());
			landDetails.add(landDetail);
		}
		customerAndLandDetails.setLandDetails(landDetails);
		return customerAndLandDetails;
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public RequestValidationDto verifyCustomerPhoneNumberAndAadhaarNumber(int userId, long custPhoneNumber,
			String aadhaarNumber, String typeOfRequest) {
		User user = gatewayDao.fetchUserById(userId);
		boolean isCustomerPhoneNumberPresent=false;
		if(custPhoneNumber>0){
		 isCustomerPhoneNumberPresent = gatewayDao.isCustomerPhoneNumberAndAadhaarNumberPresent(custPhoneNumber,
				userId, aadhaarNumber);
		}
		else
		{
			isCustomerPhoneNumberPresent=false;	
		}
		RequestValidationDto requestValidationDto = new RequestValidationDto();
		if (null != user) {
			if (user.getRegistration().getPhoneNumber() == custPhoneNumber
					|| ((typeOfRequest.equalsIgnoreCase("EDIT_CUSTOMER")
							|| typeOfRequest.equalsIgnoreCase("UPDATE_LAND_DETAILS")) ? false
									: isCustomerPhoneNumberPresent)) {
				requestValidationDto.setSuccesfullyValidated(false);
				List<ValidationDto> listOfValidationMessagesWithCodes = new ArrayList<>();
				ValidationDto validationMessage = new ValidationDto();
				validationMessage.setCode(GatewayConstants.DUPLICATE_PHONE_NUMBER_ERROR_STATUS_CODE);
				validationMessage.setMessage(GatewayConstants.DUPLICATE_PHONE_NUMBER_ERROR_STATUS_MSG);
				listOfValidationMessagesWithCodes.add(validationMessage);
				requestValidationDto.setListOfValidationMessagesWithCodes(listOfValidationMessagesWithCodes);
			} else {
				requestValidationDto.setSuccesfullyValidated(true);
			}
		}
		return requestValidationDto;
	}

	@Override
	public boolean getUserMappingStatus(int userId) {
		boolean isLicExists=gatewayDao.getUserMappingStatus(userId);
		return isLicExists;
	}

	@Override
	public boolean getWithinExpiryDate(int userId) {
		try{
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Date dt = new java.util.Date();
		String today=sdf.format(dt);
		Date expiryDate=gatewayDao.getWithinExpiryDate(userId);
		String exp=sdf.format(expiryDate);
		if(today.compareTo(exp)>0 ){
		return false;
		}else{
			return true;
		}
		}
		catch(Exception e){
			
		}
		return false;
	}

	@Override
	public boolean getMFApproval(int userId) {
		boolean isMFApproved=gatewayDao.getMFApprovedStatusForUser(userId);
		return isMFApproved;
	}
	
	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
	public RegistrationInProcessUserDto resetPasswordForExistingUser(String password, long phoneNumber,
			String tempAuthKey, String appCode) {
		RegistrationInProcessUserDto registrationInProcessUserDto = new RegistrationInProcessUserDto();
		registrationInProcessUserDto.setAuthKey(tempAuthKey);
		StatusDto status = new StatusDto();
		if (gatewayDao.checkTempAuth(phoneNumber, tempAuthKey)) {
			if (gatewayDao.resetPassword(password, phoneNumber, tempAuthKey, appCode)) {
				if (generateAndSendOtp(phoneNumber, tempAuthKey)) {
					status.setStatusCode(GatewayConstants.PASSCODE_VERIFIED_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.PASSCODE_VERIFIED_STATUS_MESSAGE);
				} else {
					status.setStatusCode(GatewayConstants.SYSTEM_FAILURE_STATUS_CODE);
					status.setStatusMessage(GatewayConstants.OTP_GENERATION_FAILED_STATUS_MESSAGE);
				}

			} else {
				status.setStatusCode(GatewayConstants.PASSCODE_IS_NOT_VALID_STATUS_CODE);
				status.setStatusMessage(GatewayConstants.PASSCODE_NOT_VALID_STATUS_MESSAGE);
			}
		} else {
			status.setStatusCode(GatewayConstants.AUTH_KEY_INVALID_STATUS_CODE);
			status.setStatusMessage(GatewayConstants.INVALID_AUTH_KEY_STATUS_MESSAGE);
		}
		registrationInProcessUserDto.setStatus(status);
		return registrationInProcessUserDto;
	}

	@Override
	public JSONObject resetpassword(long phoneNumber, String password, String appCode) {
		JSONObject obj = new JSONObject();
		try{
			int updStatus=restUtil.updatePass(phoneNumber,password,appCode);
			if(updStatus>0)
			obj.put("itemsUpdated", updStatus);
			else{
				obj.put("itemsUpdated", 0);
			}
		}catch(Exception e){
			obj.put("itemsUpdated", 0);
		}
		
		return obj;
	}
	
	@Override
	public JSONObject forgotpassword(long phoneNumber, String appCode) {
		JSONObject obj = new JSONObject();
		try{
			String password=restUtil.forgotpassword(phoneNumber,appCode);
			/*RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			MultiValueMap<String, String> parts = 
			          new LinkedMultiValueMap<String, String>();
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);
			int refetchedBuyCode=0;
			
			
		
				
				String From="EKBUYC";
				//INDIA
				String To=String.valueOf(phoneNumber);
				//NEPAL
				//String To="+977"+String.valueOf(registedMobile);
				String TemplateName="FORPAS";
				String VAR1="Your Password is: "+password;
				parts.add("From", From);
				parts.add("To", To);
				parts.add("TemplateName", TemplateName);
				parts.add("VAR1", VAR1);
				HttpEntity<MultiValueMap<String, String>> requestEntity =
				          new HttpEntity<MultiValueMap<String, String>>(parts, headers);
				// Send the buy code to the users phone number
				// NEPAL
				// String url =
				//String urlmod="http://2factor.in/API/V1/{apiKey}/ADDON_SERVICES/SEND/TSMS";
				// INDIA
				String urlmod="http://2factor.in/API/V1/{apiKey}/ADDON_SERVICES/SEND/TSMS";
				//String url = "http://2factor.in/API/V1/{apiKey}/SMS/{phoneNumber}/{otp}";
				String apiKey = AgriscoreConstantImpl.TWO_PLAN_OTP_SERVICE_API_KEY;
				Otp2PlanResponse otp2PlanResponse = restTemplate.getForObject(url, Otp2PlanResponse.class,
						apiKey, userPhone, otp);
				Otp2PlanResponse otp2PlanResponse = restTemplate.getForObject(url, Otp2PlanResponse.class,
						apiKey, userPhone, otp);
				
				ResponseEntity<Otp2PlanResponse> response = restTemplate.exchange(urlmod,HttpMethod.POST, requestEntity, Otp2PlanResponse.class,apiKey);*/
			
			if(null==password || ""==password)
			obj.put("password", password);
			else{
				obj.put("password", password);
			}
		}catch(Exception e){
			obj.put("exception", "ForgotPasswordException");
		}
		
		return obj;
	}
}
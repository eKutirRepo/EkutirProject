package com.ekutir.gateway.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gtwy_user_location")
public class UserLocation {
	
	@Id
	@GeneratedValue
	@Column(name = "user_location_id")
	private int user_location_id;
	@Column(name = "user_id")
	private int user_id;
	@Column(name = "user_lat")
	private String user_lat;
	@Column(name = "user_long")
	private String user_long;
	@Column(name = "created_by")
	private String created_by;
	@Column(name = "updated_by")
	private String updated_by;
	@Column(name = "created_at")
	private String created_at;
	@Column(name = "updated_at")
	private String updated_at;
	
	
	
	public int getUser_location_id() {
		return user_location_id;
	}
	public void setUser_location_id(int user_location_id) {
		this.user_location_id = user_location_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_lat() {
		return user_lat;
	}
	public void setUser_lat(String user_lat) {
		this.user_lat = user_lat;
	}
	public String getUser_long() {
		return user_long;
	}
	public void setUser_long(String user_long) {
		this.user_long = user_long;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getUpdated_by() {
		return updated_by;
	}
	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
}

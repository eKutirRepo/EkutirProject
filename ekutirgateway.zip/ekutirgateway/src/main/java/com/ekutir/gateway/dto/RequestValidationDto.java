package com.ekutir.gateway.dto;

import java.util.List;

public class RequestValidationDto {
	boolean isSuccesfullyValidated;
	List<ValidationDto> listOfValidationMessagesWithCodes;

	public boolean isSuccesfullyValidated() {
		return this.isSuccesfullyValidated;
	}

	public void setSuccesfullyValidated(boolean isSuccesfullyValidated) {
		this.isSuccesfullyValidated = isSuccesfullyValidated;
	}

	public List<ValidationDto> getListOfValidationMessagesWithCodes() {
		return listOfValidationMessagesWithCodes;
	}

	public void setListOfValidationMessagesWithCodes(List<ValidationDto> listOfValidationMessagesWithCodes) {
		this.listOfValidationMessagesWithCodes = listOfValidationMessagesWithCodes;
	}

}

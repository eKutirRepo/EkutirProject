
package com.ekutir.gateway.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "licenseDetailsList",
    "issuedLicenseTypeId",
    "appId"
})
public class LicIssuedList {

    @JsonProperty("licenseDetailsList")
    private List<LicenseDetailsList> licenseDetailsList = null;
    @JsonProperty("issuedLicenseTypeId")
    private long issuedLicenseTypeId;
    @JsonProperty("appId")
    private long appId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("licenseDetailsList")
    public List<LicenseDetailsList> getLicenseDetailsList() {
        return licenseDetailsList;
    }

    @JsonProperty("licenseDetailsList")
    public void setLicenseDetailsList(List<LicenseDetailsList> licenseDetailsList) {
        this.licenseDetailsList = licenseDetailsList;
    }

    @JsonProperty("issuedLicenseTypeId")
    public long getIssuedLicenseTypeId() {
        return issuedLicenseTypeId;
    }

    @JsonProperty("issuedLicenseTypeId")
    public void setIssuedLicenseTypeId(long issuedLicenseTypeId) {
        this.issuedLicenseTypeId = issuedLicenseTypeId;
    }

    @JsonProperty("appId")
    public long getAppId() {
        return appId;
    }

    @JsonProperty("appId")
    public void setAppId(long appId) {
        this.appId = appId;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

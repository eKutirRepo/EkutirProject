package com.ekutir.gateway.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "gtwy_land_details")
public class MeAndMyLand {

	@Id
	@GeneratedValue
	@Column(name = "land_id")
	private int landId;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer")
	private Customer customer;

	@Column(name = "area")
	private Double landArea;

	@Column(name = "location")
	private String landLocation;

	@Column(name = "unit")
	private String landUnit;

	@Column(name = "ownership")
	private String landOwnership;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date_time")
	private Date createdDateTime;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date_time")
	private Date updatedDateTime;
	
	@Column(name = "lat")
	private String landlat;
	
	@Column(name = "lng")
	private String landlng;
	
	

	public String getLandlat() {
		return landlat;
	}

	public void setLandlat(String landlat) {
		this.landlat = landlat;
	}

	public String getLandlng() {
		return landlng;
	}

	public void setLandlng(String landlng) {
		this.landlng = landlng;
	}

	public int getLandId() {
		return landId;
	}

	public void setLandId(int landId) {
		this.landId = landId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Double getLandArea() {
		return landArea;
	}

	public void setLandArea(Double landArea) {
		this.landArea = landArea;
	}

	public String getLandLocation() {
		return landLocation;
	}

	public void setLandLocation(String landLocation) {
		this.landLocation = landLocation;
	}

	public String getLandUnit() {
		return landUnit;
	}

	public void setLandUnit(String landUnit) {
		this.landUnit = landUnit;
	}

	public String getLandOwnership() {
		return landOwnership;
	}

	public void setLandOwnership(String landOwnership) {
		this.landOwnership = landOwnership;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

}

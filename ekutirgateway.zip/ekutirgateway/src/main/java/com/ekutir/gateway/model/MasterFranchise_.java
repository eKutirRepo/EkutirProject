
package com.ekutir.gateway.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "idsPerMasterFranchise",
    "mfName",
    "mfId",
    "eula"
})
public class MasterFranchise_ {

    @JsonProperty("idsPerMasterFranchise")
    private List<IdsPerMasterFranchise> idsPerMasterFranchise = null;
    @JsonProperty("mfName")
    private String mfName;
    @JsonProperty("mfId")
    private long mfId;
    @JsonProperty("eula")
    private String eula;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("idsPerMasterFranchise")
    public List<IdsPerMasterFranchise> getIdsPerMasterFranchise() {
        return idsPerMasterFranchise;
    }

    @JsonProperty("idsPerMasterFranchise")
    public void setIdsPerMasterFranchise(List<IdsPerMasterFranchise> idsPerMasterFranchise) {
        this.idsPerMasterFranchise = idsPerMasterFranchise;
    }

    @JsonProperty("mfName")
    public String getMfName() {
        return mfName;
    }

    @JsonProperty("mfName")
    public void setMfName(String mfName) {
        this.mfName = mfName;
    }

    @JsonProperty("mfId")
    public long getMfId() {
        return mfId;
    }

    @JsonProperty("mfId")
    public void setMfId(long mfId) {
        this.mfId = mfId;
    }

    @JsonProperty("eula")
    public String getEula() {
        return eula;
    }

    @JsonProperty("eula")
    public void setEula(String eula) {
        this.eula = eula;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

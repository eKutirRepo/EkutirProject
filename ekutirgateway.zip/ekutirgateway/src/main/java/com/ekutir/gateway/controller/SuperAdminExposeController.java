package com.ekutir.gateway.controller;

import javax.servlet.ServletContext;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.gateway.dao.RestUtility;
import com.ekutir.gateway.dto.ParamsDTO;
import com.ekutir.gateway.dto.UserDto;
import com.ekutir.gateway.model.LicenseMappingTO;
import com.ekutir.gateway.model.MasterFranchiseUserMappingTO;
import com.ekutir.gateway.services.SuperAdminService;

@RestController
public class SuperAdminExposeController {
	@Autowired
	ServletContext servletContext;
	
	@Autowired
	SuperAdminService supAdServ;
	
	
	@RequestMapping(value = "/fetchActiveUserswithoutFilter", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject fetchActiveUsers(@RequestBody ParamsDTO paramsDto) {
		JSONObject obj = new JSONObject();
		try {
			obj = supAdServ.fetchActiveUsers(paramsDto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	@RequestMapping(value = "/fetchActiveUserswithFilter", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject fetchActiveUserswithFilter(@RequestBody ParamsDTO paramsDto) {
		JSONObject obj = new JSONObject();
		try {
			obj = supAdServ.fetchActiveUserswithFilter(paramsDto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	@RequestMapping(value = "/fetchMasterFranchise", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject fetchMasterFranchise(@RequestBody ParamsDTO paramsDto) {
		JSONObject obj = new JSONObject();
		try {
			obj = supAdServ.fetchMasterFranchise(paramsDto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	@RequestMapping(value = "/saveMasterFranchiseMapping", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject saveMasterFranchiseMapping(@RequestBody MasterFranchiseUserMappingTO mfTO) {
		JSONObject obj = new JSONObject();
		try {
			obj = supAdServ.saveMasterFranchiseMapping(mfTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	@RequestMapping(value = "/fetchLicenseDetailsand", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody JSONObject fetchLicenseDetailsand() {
		JSONObject obj = new JSONObject();
		try {
			obj = supAdServ.fetchLicenseDetailsand();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	
	@RequestMapping(value = "/saveLicenseMappingData", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject saveLicenseMappingData(@RequestBody LicenseMappingTO licenseMappingTO) {
		JSONObject obj = new JSONObject();
		try {
			obj = supAdServ.saveLicenseMappingData(licenseMappingTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	@RequestMapping(value = "/getIsBasicProExists", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject getIsBasicProExists(@RequestBody UserDto userDto) {
		JSONObject obj = new JSONObject();
		try {
			int userId=userDto.getUserId();
			obj = supAdServ.getIsBasicProExists(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	/*
	@RequestMapping(value = "/updateLicensePurchaseStatus", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject updateLicensePurchaseStatus(@RequestBody LicenseMappingTO licenseMappingTO) {
		JSONObject obj = new JSONObject();
		try {
			int licenseDetailsId=licenseMappingTO.getLicDetailsId();
			
			obj = supAdServ.updateLicensePurchaseStatus(licenseDetailsId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}*/
	
	@RequestMapping(value = "/updateLicensePurchaseStatus", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONObject updateLicensePurchaseStatus(@RequestBody LicenseMappingTO licenseMappingTO) {
		JSONObject obj = new JSONObject();
		try {
			int licenseDetailsId=licenseMappingTO.getLicDetailsId();
			int appid=licenseMappingTO.getAppName();
			int mfid=licenseMappingTO.getMasterFranchiseId();
			obj = supAdServ.updateLicensePurchaseStatus(licenseDetailsId,appid,mfid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
}

package com.ekutir.gateway.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.NonUniqueResultException;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ekutir.gateway.constants.GatewayConstants;
import com.ekutir.gateway.controller.GatewayController;
import com.ekutir.gateway.model.AppMaster;
import com.ekutir.gateway.model.Application;
import com.ekutir.gateway.model.Audit;
import com.ekutir.gateway.model.BusinessUser;
import com.ekutir.gateway.model.Customer;
import com.ekutir.gateway.model.CustomerType;
import com.ekutir.gateway.model.LicenseMappingTO;
import com.ekutir.gateway.model.MasterFranchiseUserMappingTO;
import com.ekutir.gateway.model.MeAndMyLand;
import com.ekutir.gateway.model.PhoneXOtp;
import com.ekutir.gateway.model.Registration;
import com.ekutir.gateway.model.SvadhaErpAddress;
import com.ekutir.gateway.model.SvadhaErpMeCustomer;
import com.ekutir.gateway.model.User;
import com.ekutir.gateway.model.UserLocation;
import com.ekutir.gateway.utilities.GatewayUtilties;

@Repository("GatewayDao")
public class GatewayDaoImpl implements GatewayDao {

	private static final Logger LOGGER = Logger.getLogger(GatewayController.class);

	// private SessionFactory sessionFactory;

	@Autowired
	@Qualifier("manas")
	private SessionFactory sessionFactory;

	@Autowired
	@Qualifier("ananta")
	private SessionFactory svadhaDbSessionFactory;

	/*
	 * public void setSessionFactory(SessionFactory sf) { this.sessionFactory =
	 * sf; }
	 */

	Session session = null;
	Transaction tx = null;

	@Override
	public int insertCustomerDetails(Customer customer) {
		session = this.sessionFactory.getCurrentSession();
		session.persist(customer);
		return customer.getCustomerId();
	}

	@Override
	public Map<String, Boolean> isPhoneNumberAlreadyRegistered(long phoneNumber, String appCode) {
		Map<String, Boolean> typeOfUser = new HashMap<>();
		session = this.sessionFactory.getCurrentSession();
		List<Registration> me = null;
		List<BusinessUser> businessUser = null;
		Criteria criteria = null;
		try {
			criteria = session.createCriteria(Registration.class).createAlias("application", "a")
					.add(Restrictions.eq("a.applicationCode", appCode));
			criteria.add(Restrictions.eq("phoneNumber", phoneNumber));
			me = (List<Registration>) criteria.list();
			if (null != me ? (me.size() > 0 ? (null != me.get(0) ? me.get(0).getRegistrationId() != 0 : false) : false)
					: false) {
				typeOfUser.put("IS_ME_USER", true);
			}
		} catch (NonUniqueResultException e) {
			typeOfUser.put("IS_ME_USER", true);
		}

		try {
			// Check business user
			criteria = session.createCriteria(BusinessUser.class);
			criteria.add(Restrictions.eq("registeredPhoneNumber", phoneNumber));
			businessUser = (List<BusinessUser>) criteria.list();
			if (null != businessUser ? (businessUser.size() > 0
					? (null != businessUser.get(0) ? businessUser.get(0).getBusinessUserId() != 0 : false) : false)
					: false) {
				typeOfUser.put("IS_BUSINESS_USER", true);
			}
		} catch (NonUniqueResultException e) {
			typeOfUser.put("IS_BUSINESS_USER", true);
		}
		return typeOfUser;
	}

	@Override
	public void savePhoneNumberTempAuthKeyAndOtp(PhoneXOtp phoneXOtp) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(phoneXOtp);
		LOGGER.info("Phone and correspoding OTP saved successfully" + phoneXOtp.toString());
	}

	@Override
	public void saveTempAuthKey(long phoneNumber, String tempAuthKey) {
		session = this.sessionFactory.getCurrentSession();
		PhoneXOtp phoneXOtp = new PhoneXOtp();
		phoneXOtp.setPhoneNumber(phoneNumber);
		phoneXOtp.setTempAuthKey(tempAuthKey);
		session.saveOrUpdate(phoneXOtp);
	}

	@Override
	public boolean verifyPassword(String password, long phoneNumber, String tempAuthKey, String appCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).createAlias("registration", "r")
				.add(Restrictions.eq("r.phoneNumber", phoneNumber)).createAlias("r.application", "a")
				.add(Restrictions.eq("a.applicationCode", appCode)).add(Restrictions.eq("password", password));
		User user = (User) criteria.uniqueResult();

		// Check business user
		criteria = session.createCriteria(BusinessUser.class);
		criteria.add(Restrictions.eq("registeredPhoneNumber", phoneNumber)).add(Restrictions.eq("password", password));
		BusinessUser businessUser = (BusinessUser) criteria.uniqueResult();
		return ((null != user) || (null != businessUser));
	}

	@Override
	public boolean checkTempAuth(long phoneNumber, String tempAuthKey) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(PhoneXOtp.class).add(Restrictions.eq("phoneNumber", phoneNumber))
				.add(Restrictions.eq("tempAuthKey", tempAuthKey));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@Override
	public User insertNewUserRegistrationDetails(User user) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(user);
		return user;
	}

	@Override
	public BusinessUser updateBusinessUser(BusinessUser businessUser) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(businessUser);
		return businessUser;
	}

	@Override
	public BusinessUser fetchBusinessUser(long phoneNumber) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(BusinessUser.class)
				.add(Restrictions.eq("registeredPhoneNumber", phoneNumber));
		return (BusinessUser) criteria.uniqueResult();
	}

	@Override
	public void writeToAudit(String caption, String description) {
		session = this.sessionFactory.getCurrentSession();
		Audit audit = new Audit();
		audit.setCaption(caption);
		audit.setDescription(description);
		audit.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		try {
			audit.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		} catch (ParseException e) {
			LOGGER.error("Error writing in Audit Logs :::: Caption : " + caption + " :::: Description : " + description,
					e);
		}
		session.save(audit);
	}

	@Override
	public User getMicroentrepreneur(int microentrepreneurId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).add(Restrictions.idEq(microentrepreneurId));
		return (User) criteria.uniqueResult();
	}

	@Override
	public Registration fetchRegistrationDetails(long phoneNumber, String applicationCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Registration.class).createAlias("application", "a")
				.add(Restrictions.eq("a.applicationCode", applicationCode))
				.add(Restrictions.eq("phoneNumber", phoneNumber));
		return (Registration) criteria.uniqueResult();
	}

	@Override
	public User updateRegistrationForReturningUser(User user) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(user);
		return user;
	}

	@Override
	public void removeTempAuth(long phoneNumber) {
		session = this.sessionFactory.getCurrentSession();
		PhoneXOtp phoneXOtp = (PhoneXOtp) session.createCriteria(PhoneXOtp.class)
				.add(Restrictions.eq("phoneNumber", phoneNumber)).uniqueResult();
		session.delete(phoneXOtp);
	}

	@Override
	public Application fetchApplication(String applicationCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Application.class)
				.add(Restrictions.eq("applicationCode", applicationCode));
		return (Application) criteria.uniqueResult();
	}

	@Override
	public boolean isCustomerExistsForMicroentrepreneur(String custAadharNumber) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class)
				.add(Restrictions.eq("aadharNumber", custAadharNumber));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@Override
	public User fetchUser(long phoneNumber, String appCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).createAlias("registration", "r")
				.add(Restrictions.eq("r.phoneNumber", phoneNumber)).createAlias("r.application", "a")
				.add(Restrictions.eq("a.applicationCode", appCode));
		return (User) criteria.uniqueResult();
	}

	@Override
	public boolean verifyOtp(long phoneNumber, int otp, String tempAuthKey) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(PhoneXOtp.class).add(Restrictions.eq("phoneNumber", phoneNumber))
				.add(Restrictions.eq("tempAuthKey", tempAuthKey)).add(Restrictions.eq("otp", otp));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@Override
	public Customer fetchCustomer(int customerId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class).add(Restrictions.idEq(customerId));
		return (Customer) criteria.uniqueResult();
	}

	@Override
	public List<MeAndMyLand> saveMeAndMyLandDetailsForCustomer(List<MeAndMyLand> listOfMeAndMyLands) {
		List<MeAndMyLand> landDetails = new ArrayList<MeAndMyLand>();
		session = this.sessionFactory.getCurrentSession();
		for (MeAndMyLand m : listOfMeAndMyLands) {
			session.save(m);
			landDetails.add(m);
		}
		return landDetails;
	}

	@Override
	public CustomerType fetchCustomerTypes(String customerTypeDesc) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(CustomerType.class)
				.add(Restrictions.eq("typeCode", customerTypeDesc));
		return (CustomerType) criteria.uniqueResult();
	}

	@Override
	public User fetchUserById(int userId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).add(Restrictions.idEq(userId));
		return (User) criteria.uniqueResult();
	}

	@Override
	public int saveSvadhaCustomerInfo(SvadhaErpMeCustomer erpMeCustomer) {
		session = this.svadhaDbSessionFactory.getCurrentSession();
		session.save(erpMeCustomer);
		return erpMeCustomer.getCustomerId();
	}

	@Override
	public int saveSvadhaErpMeAddress(SvadhaErpAddress erpAddress) {
		session = this.svadhaDbSessionFactory.getCurrentSession();
		session.save(erpAddress);
		return erpAddress.getAddresId();
	}

	@Override
	public void saveAppMapping(AppMaster appMaster) {
		session = this.sessionFactory.getCurrentSession();
		session.save(appMaster);
	}

	@Override
	public int getConnectedAppCustomerId(long phoneNumber, String aadharNumber) {
		session = this.svadhaDbSessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(SvadhaErpMeCustomer.class)
				.add(Restrictions.eq("primaryPhoneNumber", phoneNumber))
				.add(Restrictions.eq("aadhaarNumber", Long.parseLong(aadharNumber)));
		return ((SvadhaErpMeCustomer) criteria.uniqueResult()).getCustomerId();
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		session = this.sessionFactory.getCurrentSession();
		session.save(customer);
		return customer;
	}

	@Override
	public boolean isCustomerPhoneNumberAndAadhaarNumberPresent(long custPhoneNumber, int userId,
			String aadhaarNumber) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class)
				.add(Restrictions.disjunction().add(Restrictions.eq("phoneNumber", custPhoneNumber)));
		// NOTE :: Aadhaar number deemed non mandatory
		// .add(Restrictions.eq("aadharNumber", aadhaarNumber)));
		List<Registration> customerList = criteria.list();

		criteria = session.createCriteria(User.class).add(Restrictions.idEq(userId)).createAlias("registration", "r")
				.add(Restrictions.disjunction().add(Restrictions.eq("r.phoneNumber", custPhoneNumber)));
		// .add(Restrictions.eq("r.aadharNumber", aadhaarNumber)));
		List<Registration> meList = criteria.list();

		return ((meList.size() > 0) || (customerList.size() > 0));
	}

	@Override
	@Transactional
	public boolean isCustomerExistsForMicroentrepreneur(long custPhoneNumber) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class).add(Restrictions.eq("phoneNumber", custPhoneNumber));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@Override
	@Transactional
	public boolean getUserMappingStatus(int userId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(MasterFranchiseUserMappingTO.class).add(Restrictions.eq("userId", userId));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
		
	}

	@Override
	@Transactional
	public Date getWithinExpiryDate(int userId) {
		Date expDate=null;
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(LicenseMappingTO.class).add(Restrictions.eq("gtwyUserId", userId));
		criteria.setProjection(Projections.property("expiryDate"));
		expDate=(Date)criteria.uniqueResult();
		return expDate;
	}

	@Override
	@Transactional
	public boolean getMFApprovedStatusForUser(int userId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(MasterFranchiseUserMappingTO.class).add(Restrictions.eq("userId", userId));
		criteria.setProjection(Projections.property("userMfAprovalStatus"));
		//long count = (Long) criteria.uniqueResult();
		int status=(int) criteria.uniqueResult();
		if(status==1){
			return true;
		}else{
			return false;
		}
	}

	@Override
	public UserLocation insertUserLocation(UserLocation userLoc) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(userLoc);
		return userLoc;
	}
	
	@Override
	public boolean resetPassword(String password, long phoneNumber, String tempAuthKey, String appCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).createAlias("registration", "r")
				.add(Restrictions.eq("r.phoneNumber", phoneNumber)).createAlias("r.application", "a")
				.add(Restrictions.eq("a.applicationCode", appCode));
		User user = (User) criteria.uniqueResult();
		String hqlUpdate = "update User c set c.password = :newPassword where c.userId = :UserId";
		int updatedEntities = session.createQuery( hqlUpdate )
		        .setString("newPassword", password )
		        .setInteger("UserId", user.getUserId())
		        .executeUpdate();
		return ((updatedEntities>=0));
	}
}
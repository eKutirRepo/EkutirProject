package com.ekutir.gateway.dao;

import java.util.Date;
import java.util.List;

import com.ekutir.gateway.model.Address;
import com.ekutir.gateway.model.Advertisement;
import com.ekutir.gateway.model.BusinessTip;
import com.ekutir.gateway.model.Customer;
import com.ekutir.gateway.model.CustomerType;
import com.ekutir.gateway.model.MeAndMyLand;
import com.ekutir.gateway.model.SaleAndOffer;
import com.ekutir.gateway.model.User;

public interface HomeDao {

	public List<Advertisement> getAdvertisements(String appId, String masterKey, Date currentDate);

	public List<BusinessTip> getBusinessTips(String appId, String masterKey, Date currentDate);

	public List<SaleAndOffer> getSalesAndOffers(String appId, String masterKey, Date currentDate);

	public boolean isMasterKeyExists(String masterKey);

	public boolean isAppCodeExists(String appCode);

	public List<Customer> fetchCustomers(int userId, int page);

	public boolean isAuthKeyExists(String authKey);

	public long getCustomerCount(int userId);

	public Customer getCustomer(int customerId);

	public Customer saveCustomer(Customer customer);

	public User fetchUser(int userId);

	public boolean checkAppRequestAndMasterKey(String masterKey, String appCode);

	public User saveUser(User user);

	public CustomerType fetchCustomerType(String customerType);

	public List<MeAndMyLand> fetchLandDetailsForCustomer(int customerId);

	public List<MeAndMyLand> updateLandDetails(List<MeAndMyLand> landDetails);

	public Address getCustomerAddress(int addressId);

	public User getUser(int userId);

	public List<CustomerType> fetchListOfCustomerType(String appCode);

}

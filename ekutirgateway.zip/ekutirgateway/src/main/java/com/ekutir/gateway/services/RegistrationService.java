package com.ekutir.gateway.services;

import org.json.simple.JSONObject;

import com.ekutir.gateway.dto.Communication;
import com.ekutir.gateway.dto.CustomerAndLandDetails;
import com.ekutir.gateway.dto.CustomerDto;
import com.ekutir.gateway.dto.RegistrationDto;
import com.ekutir.gateway.dto.RegistrationInProcessUserDto;
import com.ekutir.gateway.dto.RequestValidationDto;
import com.ekutir.gateway.dto.StatusDto;

public interface RegistrationService {

	public RegistrationInProcessUserDto initiateUserRegistration(long phoneNumber, String authKey, String appCode);

	public RegistrationInProcessUserDto registerUser(RegistrationDto registrationDto, String authKey);

	public StatusDto verifyOtp(Communication otp, String authKey);

	public StatusDto insertCustomerDetails(CustomerDto customer, String authKey);

	public RegistrationInProcessUserDto verifyPasscodeForExistingUser(String passCode, long phoneNumber,
			String tempAuthKey, String appCode);

	public boolean isCustomerExists(CustomerDto customer, String authkey);

	public RegistrationInProcessUserDto registerReturningOrBusinessUser(Communication registrationDto,
			String tempAuthKey);

	public CustomerAndLandDetails insertCustomerAndLandDetails(CustomerAndLandDetails customerLandDetails,
			String authkey);

	public RequestValidationDto verifyCustomerPhoneNumberAndAadhaarNumber(int userId, long custPhoneNumber,
			String aadhaarNumber, String typeOfRequest);

	public boolean getUserMappingStatus(int userId);

	public boolean getWithinExpiryDate(int userId);

	public boolean getMFApproval(int userId);

	public RegistrationInProcessUserDto resetPasswordForExistingUser(String password, long phoneNumber,
			String tempAuthKey, String applicationCode);

	public JSONObject resetpassword(long phonenumber, String password, String appcode);

	public JSONObject forgotpassword(long phoneNumber, String applicationCode);
}

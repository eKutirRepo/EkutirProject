package com.ekutir.gateway.dto;

import java.math.BigDecimal;

public class LandDetailsDto {
	private int landId;
	private Double landArea;
	private String landLocation;
	private String landUnit;
	private String landOwnership;
	private String landlat;
	private String landlng;

	public String getLandlat() {
		return landlat;
	}

	public void setLandlat(String landlat) {
		this.landlat = landlat;
	}

	public String getLandlng() {
		return landlng;
	}

	public void setLandlng(String landlng) {
		this.landlng = landlng;
	}

	public int getLandId() {
		return landId;
	}

	public void setLandId(int landId) {
		this.landId = landId;
	}

	public Double getLandArea() {
		return landArea;
	}

	public void setLandArea(Double landArea) {
		this.landArea = landArea;
	}

	public String getLandLocation() {
		return landLocation;
	}

	public void setLandLocation(String landLocation) {
		this.landLocation = landLocation;
	}

	public String getLandUnit() {
		return landUnit;
	}

	public void setLandUnit(String landUnit) {
		this.landUnit = landUnit;
	}

	public String getLandOwnership() {
		return landOwnership;
	}

	public void setLandOwnership(String landOwnership) {
		this.landOwnership = landOwnership;
	}

}

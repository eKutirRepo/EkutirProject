package ekutir.sanimark.android.dto;

public class DataManipulationBean {
private String message;
private int Id;

public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}

public int getId() {
	return Id;
}
public void setId(int id) {
	Id = id;
}
@Override
public String toString(){
	return getMessage() + ", "+getId();
}
}

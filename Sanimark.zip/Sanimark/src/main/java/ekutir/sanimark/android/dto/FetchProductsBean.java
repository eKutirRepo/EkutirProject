package ekutir.sanimark.android.dto;


public class FetchProductsBean {
	
	private int productId;
	private int supplierId;
	private String productName;
	private String companyName;
	private int prodCategoryId;
	private String prodCategoryName;
	private String warranty;
	private String dateOfManufacture;
	private String expiryDate;
	private String productFeatures;
	private Double mrp;
	private int discountInPercent;
	private Double sellingPrice;
	private String productImg;
	private String supplierName;
	
	public FetchProductsBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FetchProductsBean(int productId, int supplierId, String productName, String companyName, int prodCategoryId,
			String prodCategoryName, String warranty, String dateOfManufacture, String expiryDate,
			String productFeatures, Double mrp, int discountInPercent, Double sellingPrice, String productImg, String supplierName) {
		super();
		this.productId = productId;
		this.supplierId = supplierId;
		this.productName = productName;
		this.companyName = companyName;
		this.prodCategoryId = prodCategoryId;
		this.prodCategoryName = prodCategoryName;
		this.warranty = warranty;
		this.dateOfManufacture = dateOfManufacture;
		this.expiryDate = expiryDate;
		this.productFeatures = productFeatures;
		this.mrp = mrp;
		this.discountInPercent = discountInPercent;
		this.sellingPrice = sellingPrice;
		this.productImg = productImg;
		this.supplierName = supplierName;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getProdCategoryId() {
		return prodCategoryId;
	}

	public void setProdCategoryId(int prodCategoryId) {
		this.prodCategoryId = prodCategoryId;
	}

	public String getProdCategoryName() {
		return prodCategoryName;
	}

	public void setProdCategoryName(String prodCategoryName) {
		this.prodCategoryName = prodCategoryName;
	}

	public String getWarranty() {
		return warranty;
	}

	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}

	public String getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(String dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getProductFeatures() {
		return productFeatures;
	}

	public void setProductFeatures(String productFeatures) {
		this.productFeatures = productFeatures;
	}

	public Double getMrp() {
		return mrp;
	}

	public void setMrp(Double mrp) {
		this.mrp = mrp;
	}

	public int getDiscountInPercent() {
		return discountInPercent;
	}

	public void setDiscountInPercent(int discountInPercent) {
		this.discountInPercent = discountInPercent;
	}

	public Double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(Double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getProductImg() {
		return productImg;
	}

	public void setProductImg(String productImg) {
		this.productImg = productImg;
	}
	
}

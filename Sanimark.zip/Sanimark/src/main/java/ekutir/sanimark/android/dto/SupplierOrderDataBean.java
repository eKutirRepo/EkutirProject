package ekutir.sanimark.android.dto;

public class SupplierOrderDataBean {
	
	private int orderId;
	private int productId;
	private String productBrandName;
	private String companyName;
	private double orderQuantity;
	private String orderDate;
	private String deliveryDate;
	private int supplier_ack_status;
	private int customerId;
	private AddressBean address;
	
	public SupplierOrderDataBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SupplierOrderDataBean(int orderId, int productId, String productBrandName, String companyName,
			double orderQuantity, String orderDate, String deliveryDate, int supplier_ack_status, int customerId,
			AddressBean address) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.productBrandName = productBrandName;
		this.companyName = companyName;
		this.orderQuantity = orderQuantity;
		this.orderDate = orderDate;
		this.deliveryDate = deliveryDate;
		this.supplier_ack_status = supplier_ack_status;
		this.customerId = customerId;
		this.address = address;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductBrandName() {
		return productBrandName;
	}

	public void setProductBrandName(String productBrandName) {
		this.productBrandName = productBrandName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public double getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(double orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public int getSupplier_ack_status() {
		return supplier_ack_status;
	}

	public void setSupplier_ack_status(int supplier_ack_status) {
		this.supplier_ack_status = supplier_ack_status;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public AddressBean getAddress() {
		return address;
	}

	public void setAddress(AddressBean address) {
		this.address = address;
	}
	
}

package ekutir.sanimark.android.dto;

public class FetchBusinessCategoryBean {
	
	private int categoryId;
	private String categoryCode;
	private String categoryName;
	
	public FetchBusinessCategoryBean() {
		super();
	}
	
	public FetchBusinessCategoryBean(int categoryId, String categoryCode, String categoryName) {
		super();
		this.categoryId = categoryId;
		this.categoryCode = categoryCode;
		this.categoryName = categoryName;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
}

package ekutir.sanimark.android.model;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ekutir_gateway.gtwy_business_user")
public class BusinessUser {

	@Id
	@GeneratedValue
	@Column(name = "business_user_id")
	private int businessUserId;

	@ManyToOne
	@JoinColumn(name = "user_master_id")
	private User delegatedForUser;

	@Column(name = "phone_number")
	private long registeredPhoneNumber;

	@Column(name = "imei")
	private String registeredImei;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "auth")
	private Auth auth;

	@Column(name = "password")
	private String password;

	@Column(name = "status")
	private int status;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date_time")
	private Timestamp createdDateTime;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date_time")
	private Timestamp updatedDateTime;

	public int getBusinessUserId() {
		return businessUserId;
	}

	public void setBusinessUserId(int businessUserId) {
		this.businessUserId = businessUserId;
	}

	public User getDelegatedForUser() {
		return delegatedForUser;
	}

	public void setDelegatedForUser(User delegatedForUser) {
		this.delegatedForUser = delegatedForUser;
	}

	public long getRegisteredPhoneNumber() {
		return registeredPhoneNumber;
	}

	public void setRegisteredPhoneNumber(long registeredPhoneNumber) {
		this.registeredPhoneNumber = registeredPhoneNumber;
	}

	public String getRegisteredImei() {
		return registeredImei;
	}

	public void setRegisteredImei(String registeredImei) {
		this.registeredImei = registeredImei;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Timestamp updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public Auth getAuth() {
		return auth;
	}

	public void setAuth(Auth auth) {
		this.auth = auth;
	}

}

package ekutir.sanimark.android.dto;

public class ForgetPasswordBean {

	private String email;
	private String password;
	private String businessName;
	private String message;
	private String role;

	public ForgetPasswordBean() {
		super();
	}

	public ForgetPasswordBean(String email, String password, String businessName, String message, String role) {
		super();
		this.email = email;
		this.password = password;
		this.businessName = businessName;
		this.message = message;
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}

package ekutir.sanimark.erp.view.beans.crm;

public class FetchClusterDetailsBean {
	private int clusterId;
	private String clusterName;

	public int getClusterId() {
		return clusterId;
	}

	public void setClusterId(int clusterId) {
		this.clusterId = clusterId;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

}

package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.FetchDispositionsBean;

public class FetchDispositionsDto {
	private List<FetchDispositionsBean> dispositions;

	public List<FetchDispositionsBean> getDispositions() {
		return dispositions;
	}

	public void setDispositions(List<FetchDispositionsBean> dispositions) {
		this.dispositions = dispositions;
	}

}

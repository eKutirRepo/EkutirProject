package ekutir.sanimark.erp.view.beans.crm;

public class AdvertisementsBean {
	private int clickable;
	private String altText;
	private String advertisementsAsBase64;
	private String startDate;
	private String endDate;
	private int catalogId;
	public AdvertisementsBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AdvertisementsBean(int clickable, String altText, String advertisementsAsBase64, String startDate,
			String endDate,int catalogId) {
		super();
		this.clickable = clickable;
		this.altText = altText;
		this.advertisementsAsBase64 = advertisementsAsBase64;
		this.startDate = startDate;
		this.endDate = endDate;
		this.catalogId = catalogId;
	}
	
	public String getAltText() {
		return altText;
	}
	public void setAltText(String altText) {
		this.altText = altText;
	}
	public String getAdvertisementsAsBase64() {
		return advertisementsAsBase64;
	}
	public void setAdvertisementsAsBase64(String advertisementsAsBase64) {
		this.advertisementsAsBase64 = advertisementsAsBase64;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getClickable() {
		return clickable;
	}
	public void setClickable(int clickable) {
		this.clickable = clickable;
	}
	public int getCatalogId() {
		return catalogId;
	}
	public void setCatalogId(int catalogId) {
		this.catalogId = catalogId;
	}
	
	
	
}

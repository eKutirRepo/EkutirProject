package ekutir.sanimark.erp.view.beans.crm;

import java.util.List;

public class FetchPriceChangeDetailsBean {
	
	private boolean priceChange;
	 private List<PriceChangeItemBean> ChangedItemList;
	 
	public FetchPriceChangeDetailsBean() {
		super();
	}
	
	public FetchPriceChangeDetailsBean(boolean priceChange, List<PriceChangeItemBean> changedItemList) {
		super();
		this.priceChange = priceChange;
		ChangedItemList = changedItemList;
	}

	public boolean isPriceChange() {
		return priceChange;
	}
	public void setPriceChange(boolean priceChange) {
		this.priceChange = priceChange;
	}
	public List<PriceChangeItemBean> getChangedItemList() {
		return ChangedItemList;
	}
	public void setChangedItemList(List<PriceChangeItemBean> changedItemList) {
		ChangedItemList = changedItemList;
	}

}

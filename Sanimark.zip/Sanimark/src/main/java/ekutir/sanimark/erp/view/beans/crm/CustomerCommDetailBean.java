package ekutir.sanimark.erp.view.beans.crm;

public class CustomerCommDetailBean {
	private int customerId;
	private String communicationDate;
	private String communicationDetails;
	private String commMode;
	private int commCost;
	private int commDispositionId;

	public CustomerCommDetailBean() {
		super();
	}

	public CustomerCommDetailBean(int customerId, String communicationDate, String communicationDetails,
			String commMode, int commCost, int commDispositionId) {
		super();
		this.customerId = customerId;
		this.communicationDate = communicationDate;
		this.communicationDetails = communicationDetails;
		this.commMode = commMode;
		this.commCost = commCost;
		this.commDispositionId = commDispositionId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCommunicationDate() {
		return communicationDate;
	}

	public void setCommunicationDate(String communicationDate) {
		this.communicationDate = communicationDate;
	}

	public String getCommunicationDetails() {
		return communicationDetails;
	}

	public void setCommunicationDetails(String communicationDetails) {
		this.communicationDetails = communicationDetails;
	}

	public String getCommMode() {
		return commMode;
	}

	public void setCommMode(String commMode) {
		this.commMode = commMode;
	}

	public int getCommCost() {
		return commCost;
	}

	public void setCommCost(int commCost) {
		this.commCost = commCost;
	}

	public int getCommDispositionId() {
		return commDispositionId;
	}

	public void setCommDispositionId(int commDispositionId) {
		this.commDispositionId = commDispositionId;
	}

}

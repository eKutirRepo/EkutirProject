package ekutir.sanimark.erp.view.beans.crm;

public class LeadPlaceOrderItemBean {
	private int itemId;
	private double orderQunatity;

	public LeadPlaceOrderItemBean() {
		super();
	}

	public LeadPlaceOrderItemBean(int itemId, double orderQunatity) {
		super();
		this.itemId = itemId;
		this.orderQunatity = orderQunatity;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public double getOrderQunatity() {
		return orderQunatity;
	}

	public void setOrderQunatity(double orderQunatity) {
		this.orderQunatity = orderQunatity;
	}

}

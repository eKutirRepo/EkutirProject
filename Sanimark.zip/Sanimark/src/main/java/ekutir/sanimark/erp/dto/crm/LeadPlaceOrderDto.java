package ekutir.sanimark.erp.dto.crm;

import java.util.ArrayList;
import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.LeadPlaceOrderItemBean;



public class LeadPlaceOrderDto {

	List<LeadPlaceOrderItemBean> itemDetails = new ArrayList<>();

	public List<LeadPlaceOrderItemBean> getItemDetails() {
		return itemDetails;
	}

	public void setItemDetails(List<LeadPlaceOrderItemBean> itemDetails) {
		this.itemDetails = itemDetails;
	}

}

package ekutir.sanimark.erp.view.beans.crm;

public class FetchCustomerDataBean {

	private int customerId;

	private String customerFName;
	private String customerMName;
	private String customerLName;
	private int addressId;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String block;
	private String district;
	// private String city;
	private String state;
	private String country;
	private String postalCode;
	private long primaryPhone;
	private long secondaryPhone;
	private int businessCategory;
	private String businessName;
	private String description;
    private int prevLeadId;
    private String tinNo;
	public FetchCustomerDataBean() {
		super();
	}

	public FetchCustomerDataBean(int customerId, String customerFName, String customerMName, String customerLName,
			int addressId, String addressLine1, String addressLine2, String addressLine3, String block, String district,
			String state, String country, String postalCode, long primaryPhone, long secondaryPhone,
			int businessCategory, String businessName, String description,int prevLeadId,String tinNo) {
		super();
		this.customerId = customerId;

		this.customerFName = customerFName;
		this.customerMName = customerMName;
		this.customerLName = customerLName;
		this.addressId = addressId;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.block = block;
		this.district = district;
		// this.city = city;
		this.state = state;
		this.country = country;
		this.postalCode = postalCode;
		this.primaryPhone = primaryPhone;
		this.secondaryPhone = secondaryPhone;
		this.businessCategory = businessCategory;
		this.businessName = businessName;
		this.description = description;
		this.prevLeadId = prevLeadId;
		this.tinNo = tinNo;
	}

	public String getTinNo() {
		return tinNo;
	}

	public void setTinNo(String tinNo) {
		this.tinNo = tinNo;
	}

	public String getCustomerFName() {
		return customerFName;
	}

	public void setCustomerFName(String customerFName) {
		this.customerFName = customerFName;
	}

	public String getCustomerMName() {
		return customerMName;
	}

	public void setCustomerMName(String customerMName) {
		this.customerMName = customerMName;
	}

	public String getCustomerLName() {
		return customerLName;
	}

	public void setCustomerLName(String customerLName) {
		this.customerLName = customerLName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	/*
	 * public String getCity() { return city; }
	 * 
	 * public void setCity(String city) { this.city = city; }
	 */

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public long getPrimaryPhone() {
		return primaryPhone;
	}

	public void setPrimaryPhone(long primaryPhone) {
		this.primaryPhone = primaryPhone;
	}

	public long getSecondaryPhone() {
		return secondaryPhone;
	}

	public void setSecondaryPhone(long secondaryPhone) {
		this.secondaryPhone = secondaryPhone;
	}

	public int getBusinessCategory() {
		return businessCategory;
	}

	public void setBusinessCategory(int businessCategory) {
		this.businessCategory = businessCategory;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrevLeadId() {
		return prevLeadId;
	}

	public void setPrevLeadId(int prevLeadId) {
		this.prevLeadId = prevLeadId;
	}

}

package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.AdvertisementsBean;



public class AdvertisementsDto {
	private List<AdvertisementsBean> advertisement;

	public List<AdvertisementsBean> getAdvertisement() {
		return advertisement;
	}

	public void setAdvertisement(List<AdvertisementsBean> advertisement) {
		this.advertisement = advertisement;
	}

}

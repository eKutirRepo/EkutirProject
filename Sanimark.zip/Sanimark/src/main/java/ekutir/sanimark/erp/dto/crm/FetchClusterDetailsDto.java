package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.FetchClusterDetailsBean;

public class FetchClusterDetailsDto {
	private List<FetchClusterDetailsBean> clusters;

	public List<FetchClusterDetailsBean> getClusters() {
		return clusters;
	}

	public void setClusters(List<FetchClusterDetailsBean> clusters) {
		this.clusters = clusters;
	}

}

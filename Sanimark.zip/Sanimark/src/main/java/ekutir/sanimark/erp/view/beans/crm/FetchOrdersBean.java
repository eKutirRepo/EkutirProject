package ekutir.sanimark.erp.view.beans.crm;

import java.util.List;

public class FetchOrdersBean {
	private int orderId;
	private int customerId;
	private String customerFName;
	private String customerMName;
	private String customerLName;
	private String orderDate;
	private String orderAmount;
	private String status;
	private String payMode;
	private String customerStatus;
	private double outstanding;
	private int prevLeadId;
	private int disableCancel;
	private List<OrderDetailsBean> orderDetails;

	public int getPrevLeadId() {
		return prevLeadId;
	}

	public void setPrevLeadId(int prevLeadId) {
		this.prevLeadId = prevLeadId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerFName() {
		return customerFName;
	}

	public void setCustomerFName(String customerFName) {
		this.customerFName = customerFName;
	}

	public String getCustomerMName() {
		return customerMName;
	}

	public void setCustomerMName(String customerMName) {
		this.customerMName = customerMName;
	}

	public String getCustomerLName() {
		return customerLName;
	}

	public void setCustomerLName(String customerLName) {
		this.customerLName = customerLName;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(String orderAmount) {
		this.orderAmount = orderAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPayMode() {
		return payMode;
	}

	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}

	public void setOrderDetails(List<OrderDetailsBean> orderDetails) {
		this.orderDetails = orderDetails;
	}

	public List<OrderDetailsBean> getOrderDetails() {
		return orderDetails;
	}

	public String getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}

	public double getOutstanding() {
		return outstanding;
	}

	public void setOutstanding(double outstanding) {
		this.outstanding = outstanding;
	}

	public int getDisableCancel() {
		return disableCancel;
	}

	public void setDisableCancel(int disableCancel) {
		this.disableCancel = disableCancel;
	}

	public FetchOrdersBean() {
	}

	public FetchOrdersBean(int orderId, int customerId, String customerFName, String customerMName,
			String customerLName, String orderDate, String orderAmount, String status,
			List<OrderDetailsBean> orderDetails, String payMode, String customerStatus,int prevLeadId, double outstanding, int disableCancel) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.customerFName = customerFName;
		this.customerMName = customerMName;
		this.customerLName = customerLName;
		this.orderDate = orderDate;
		this.orderAmount = orderAmount;
		this.status = status;
		this.orderDetails = orderDetails;
		this.payMode = payMode;
		this.customerStatus = customerStatus;
		this.prevLeadId = prevLeadId;
		this.outstanding = outstanding;
		this.disableCancel = disableCancel;
	}

}

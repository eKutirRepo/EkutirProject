package ekutir.sanimark.erp.view.beans.crm;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FetchItemDetailsBean {

	private int itemId;
	private String itemName;
	private String itemDescription;
	private double unitPrice;
	private double actualPrice;
	private String itemImage;
	private String dimension;
	private String brandName;
	private int productId;


	public String getItemImage() {
		return itemImage;
	}

	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}

	@JsonCreator
	public FetchItemDetailsBean(@JsonProperty("itemId") int itemId, @JsonProperty("itemName") String itemName,
			@JsonProperty("itemDescription") String itemDescription, @JsonProperty("unitPrice") double unitPrice,@JsonProperty("MRP") double actualPrice,
			@JsonProperty("itemImage") String itemImage,@JsonProperty("dimension") String dimension,@JsonProperty("brandName")String brandName, @JsonProperty("productId")int productId) {
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemDescription = itemDescription;
		this.unitPrice = unitPrice;
		this.actualPrice = actualPrice;
		this.itemImage = itemImage;
        this.dimension = dimension;
        this.brandName = brandName;
        this.productId = productId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getActualPrice() {
		return actualPrice;
	}

	public void setActualPrice(double actualPrice) {
		this.actualPrice = actualPrice;
	}

	public String getDimension() {
		return dimension;
	}

	public void setDimension(String dimension) {
		this.dimension = dimension;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

}

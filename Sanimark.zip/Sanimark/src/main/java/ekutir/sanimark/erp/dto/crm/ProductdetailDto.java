package ekutir.sanimark.erp.dto.crm;

import java.util.List;

import ekutir.sanimark.erp.view.beans.crm.ProductdetailBean;



public class ProductdetailDto {
	private List<ProductdetailBean> productdetail;

	public List<ProductdetailBean> getProductdetail() {
		return productdetail;
	}

	public void setProductdetail(List<ProductdetailBean> productdetail) {
		this.productdetail = productdetail;
	}
}

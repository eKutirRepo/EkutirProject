package ekutir.sanimark.erp.view.beans.crm;

public class OrderFollowUpDetailsBean {

	private int customerId;
	private int orderId;
	private String communicationDate;
	private String commMode;
	private int commDisposition;
	private int CommCost;
	private String CommunicationDetails;
	 private int prevLeadId;
	public OrderFollowUpDetailsBean() {
		super();
	}

	public OrderFollowUpDetailsBean(int customerId, int orderId, String communicationDate, String commMode,
			int commDisposition, int commCost, String communicationDetails,int prevLeadId) {
		super();
		this.customerId = customerId;
		this.orderId = orderId;
		this.communicationDate = communicationDate;
		this.commMode = commMode;
		this.commDisposition = commDisposition;
		CommCost = commCost;
		CommunicationDetails = communicationDetails;
		this.prevLeadId = prevLeadId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getCommunicationDate() {
		return communicationDate;
	}

	public void setCommunicationDate(String communicationDate) {
		this.communicationDate = communicationDate;
	}

	public String getCommMode() {
		return commMode;
	}

	public void setCommMode(String commMode) {
		this.commMode = commMode;
	}

	public int getCommDisposition() {
		return commDisposition;
	}

	public void setCommDisposition(int commDisposition) {
		this.commDisposition = commDisposition;
	}

	public int getCommCost() {
		return CommCost;
	}

	public void setCommCost(int commCost) {
		CommCost = commCost;
	}

	public String getCommunicationDetails() {
		return CommunicationDetails;
	}

	public void setCommunicationDetails(String communicationDetails) {
		CommunicationDetails = communicationDetails;
	}

	public int getPrevLeadId() {
		return prevLeadId;
	}

	public void setPrevLeadId(int prevLeadId) {
		this.prevLeadId = prevLeadId;
	}

}

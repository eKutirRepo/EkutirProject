package ekutir.sanimark.dao;

import java.util.List;

import ekutir.sanimark.android.dto.FetchPCategoryBean;
import ekutir.sanimark.erp.view.beans.crm.AdvertisementsBean;
import ekutir.sanimark.erp.view.beans.crm.CatalogBean;
import ekutir.sanimark.erp.view.beans.crm.CustomerCommDetailBean;
import ekutir.sanimark.erp.view.beans.crm.CustomerPlaceOrderBean;
import ekutir.sanimark.erp.view.beans.crm.FetchBusinessCategoryBean;
import ekutir.sanimark.erp.view.beans.crm.FetchClusterDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchCustomerDataBean;
import ekutir.sanimark.erp.view.beans.crm.FetchDispositionsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchItemDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.FetchOrdersBean;
import ekutir.sanimark.erp.view.beans.crm.FetchPaymentModesBean;
import ekutir.sanimark.erp.view.beans.crm.FetchPriceChangeDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.LeadPlaceOrderItemBean;
import ekutir.sanimark.erp.view.beans.crm.OrderDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.OrderFollowUpDetailsBean;
import ekutir.sanimark.erp.view.beans.crm.ProductdetailBean;


public interface CrmDao {

	List<FetchCustomerDataBean> fetchCustomerData();

	List<FetchClusterDetailsBean> fetchClusterDetails();

	int deleteCustomer(int customerId);

	List<FetchCustomerDataBean> searchCustomer(String createdFromDate, String createdToDate);

	List<FetchBusinessCategoryBean> fetchBusinessCategory();

	//List<CommDetailsBean> fetchCustomerCommHistory(int customerId, int prevId);

	List<FetchDispositionsBean> fetchDispositions();

	List<FetchItemDetailsBean> fetchItemDetails();

	List<FetchPaymentModesBean> fetchPaymentModes();

	List<FetchOrdersBean> fetchOrders();

	List<OrderDetailsBean> orderDetails();

	//int addCustomer(FetchCustomerDataBean addCustomerData);

	int editCustomer(FetchCustomerDataBean editCustomer);

	int saveCustomerCommDetails(CustomerCommDetailBean saveCustomerComm);

	int placeOrder(CustomerPlaceOrderBean placeorderbean, List<LeadPlaceOrderItemBean> placeorderitemBean);

	List<FetchOrdersBean> searchOrders(String createdFromDate, String createdToDate, String myOrders);

	List<FetchOrdersBean> closeOrders();

	List<FetchOrdersBean> dropOrders();

	List<FetchOrdersBean> searchClosedOrders(String createdFromDate, String createdToDate, String myOrders);

	List<FetchOrdersBean> searchDropedOrders(String createdFromDate, String createdToDate, String myOrders);

	int saveOrderFollowUpDetail(OrderFollowUpDetailsBean saveOrderFollowUpData);

	List<OrderFollowUpDetailsBean> fetchOrderFollowUpHistory(int orderId);

	List<FetchOrdersBean> fetchCustomerOrderHistory(int customerId);

	List<CatalogBean> searchItemDetails(int itemid);

	List<FetchOrdersBean> ordersCustomerHistory(int customerId, int orderId);

	List<CatalogBean> fetchcatalog(int catalogid);

	List<AdvertisementsBean> getAdvertisements(int masterkey);

	List<FetchPCategoryBean> advClicable(int catalogid);

	List<AdvertisementsBean> getSaleOffer();

	List<AdvertisementsBean> getNewSaleOffer();

	//RoleActionBean getRoleAction();

	List<AdvertisementsBean> getbiztips(int masterkey);

	List<FetchOrdersBean> fetchPartialOrders();

	List<FetchOrdersBean> searchPartialOrders(String createdFromDate, String createdToDate, String myOrders);

	FetchPriceChangeDetailsBean checkForPriceChange(int customerId, List<OrderDetailsBean> orderDetails);

}

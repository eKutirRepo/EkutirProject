package ekutir.sanimark.dao.Impl;

public class CrmSqlUtility {

	//public static final String INSERT_ADDCUSTOMER_MASTER_QUERY ="INSERT INTO  `dbsvadha.survey`.`tbl_mecustomer_master`(CustomerFName,MName,CustomerLName,Address,BusinessName,BusinessCategory,Description,PrimaryPhone,SecondaryPhone,PrevLeadID,CreatedBy,CreatedDateTime,CustomerStatus,TinNo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	//public static final String INSERT_ADDRESSS_QUERY = "INSERT INTO  `dbsanimarkdlink`.`tbl_address`(AddressLine1,AddressLine2,AddressLine3,Block,District,State,Country,PostalCode) VALUES (?,?,?,?,?,?,?,?)";
	
	public static final String FETCH_CUSTOMER_QUERY = "SELECT customaster.CustomerID, customaster.CustomerFName,customaster.MName,customaster.CustomerLName,address.AddressID,address.AddressLine1,address.AddressLine2,address.AddressLine3,COALESCE(address.Block,'') as Block,"
			                     + "address.District,address.State,address.Country,address.PostalCode,customaster.PrimaryPhone,customaster.SecondaryPhone,customaster.BusinessCategory,"
                                 +" customaster.BusinessName,customaster.Description ,customaster.PrevLeadID,customaster.TinNo FROM `dbsvadha.survey`.`tbl_mecustomer_master` customaster inner join `dbsanimarkdlink`.`tbl_address` address on address.AddressId = customaster.Address where  customaster.CustomerStatus = 'active' order by customaster.CustomerID desc";
	
	public static final String UPDATE_ADDRESS_QUERY = "UPDATE `dbsanimarkdlink`.`tbl_address` SET `AddressLine1` = ?,"
		                 	+ "`AddressLine2` = ?,`AddressLine3` = ?,`Block` = ?,`District` = ?,`State` = ?,`Country` = ?,"
			                + "`PostalCode` = ? WHERE `AddressID` = ?";
	
	public static  final String EDIT_CUSTOMER_QUERY = "UPDATE `dbsvadha.survey`.`tbl_mecustomer_master` SET `CustomerFName` = ?,"
			                +"`MName` = ?,`CustomerLName` = ?,`PrimaryPhone` = ?,`SecondaryPhone` = ?,`BusinessCategory` = ?,"
			                +"`BusinessName` = ?,`Description` = ? ,CreatedBy = ? ,`UpdatedDateTime` = ? WHERE `CustomerID` = ?";
	
	public static final String INSERT_CUSTOMER_COMM = "INSERT INTO  `dbsanimarkdlink`.`tbl_communication_disposition`(CustomerID,CommunicationDate,CommMode,CommCost,CommDisposition,CommunicationDetails,UserID) VALUES (?,?,?,?,?,?,?)";
	
	public static final String SEARCH_CUSTOMER_QUERY = "SELECT customaster.CustomerID, customaster.CustomerFName,customaster.MName,customaster.CustomerLName,address.AddressID,address.AddressLine1,address.AddressLine2,address.AddressLine3,COALESCE(address.Block,''),"
			                 +"address.District,address.State,address.Country,address.PostalCode,customaster.PrimaryPhone,customaster.SecondaryPhone,customaster.BusinessCategory,"
                             +" customaster.BusinessName,customaster.Description,customaster.PrevLeadID,customaster.TinNo  FROM `dbsvadha.survey`.`tbl_mecustomer_master` customaster inner join `dbsanimarkdlink`.`tbl_address` address on address.AddressId = customaster.Address where   customaster.CustomerStatus = 'active' and customaster.CreatedDateTime >= ? AND customaster.CreatedDateTime   <= ? order by customaster.CustomerID desc ";
	
	public static final String INSERT_PLACEORDER_QUERY = "INSERT INTO `dbsanimarkdlink`.`tbl_order_header_master` (`CustomerID`,`OrderAmount`,`OrderDiscount`,`DeliveryRequestedDate`,`OrderPaymentMode`,Status,`UserID`,OrderDate) VALUES (?,?,?,?,?,?,?,?)";
	
	public static final String INSERT_ITEM_DETAILS_QUERY = "INSERT INTO `dbsanimarkdlink`.`tbl_order_details_master` "
			                 + "(`OrderID`,`ItemID`,`OrderQuantity`) VALUES (?,?,?)";
	
	public static final String CUSTOMER_DELETE = "DELETE FROM `dbsvadha.survey`.`tbl_mecustomer_master` WHERE CustomerID = ?";
	
	public static final String FETCH_BUZ_QUERY = "select BizCategoryID,BizCategoryCode,BizCategoryDisplayName from `dbsanimarkdlink`.`tbl_business_category_lookup`";
	
	public static final String CUSTOMER_HISTORY_QUERY = " SELECT distinct DATE_FORMAT(COMMDISP.CommunicationDate,'%d-%m-%Y') as CommunicationDate,COMMDISP.CommunicationDetails,COMMDISPLOOKUP.DispositionDisplayName,COMMDISP.CommMode,SURVEYUSER.UserName, COMMDISP.CommCost FROM  `dbsanimarkdlink`.`tbl_communication_disposition` COMMDISP "
                             +"  inner join `dbsanimarkdlink`.`tbl_commdisposition_lookup` COMMDISPLOOKUP  on COMMDISP.CommDisposition=COMMDISPLOOKUP.DispositionID "
                             +" inner join `dbsvadha.survey`.`tbl_survey_users` SURVEYUSER on COMMDISP.userId=SURVEYUSER.userId where COMMDISP.CustomerID= ? or COMMDISP.LeadID = ? ";
	
	public static final String FETCH_DISPO_QUERY = "select DispositionID,DispositionDisplayName from `dbsanimarkdlink`.`tbl_commdisposition_lookup` ";
	
	public static final String FETCH_ITEM_DETAILS = "select ItemID,ItemName,ItemDescription,UnitPrice,ItemImage from  `dbsvadha.erp`.`tbl_product_items`";
	
	public static final String FETCH_PAYMENT_QUERY = "select PaymentMode,PaymentModeDisplayName from `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup`";
	
	public static final String FETCH_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus,custmast.PrevLeadID from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast "
                              +"inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
			                  +"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where stalook.Status = 'InProcess' order by ordmast.OrderDate desc ";
	
	public static final String ORDER_DETAILS_QUERY = "select ITEM.ItemID,ItemName,ORDERDETMASTER.OrderQuantity,ITEM.UnitPrice,DATE_FORMAT(ORDERHEADMASTER.DeliveryRequestedDate,'%d-%m-%Y') as DeliveryRequestedDate,ORDERDETMASTER.ShipmentQuantity from  `dbsanimarkdlink`.`tbl_order_header_master` ORDERHEADMASTER "
    +"inner join  `dbsanimarkdlink`.`tbl_order_details_master` ORDERDETMASTER ON ORDERDETMASTER.ORDERID=ORDERHEADMASTER.ORDERID INNER join `dbsvadha.erp`.`tbl_product_items` ITEM on ITEM.ItemID = ORDERDETMASTER.ItemID "
   +" where ORDERHEADMASTER.ORDERID= ? ";
	
	
	public static final String CLOSE_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus,custmast.PrevLeadID  from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast "
                             +"inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
			                 +"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId where stalook.Status IN ('Delivery' ,'Shipped') order by ordmast.OrderDate desc ";
	
	
	public static final String DROP_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast "
                             +"inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId where stalook.Status = 'Cancelled' order by ordmast.OrderDate desc ";
	
	
	public static final String SEARCH_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus,custmast.PrevLeadID from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast"
            + " INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
            +"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where stalook.Status = 'InProcess' and ordmast.OrderDate >= ? AND ordmast.OrderDate <= ? order by ordmast.OrderDate desc";

	
	public static final String SEARCH_CLOSED_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus,custmast.PrevLeadID from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast"
		                  	+ " INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
	                     	+"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where stalook.Status IN ('Delivery' ,'Shipped') and ordmast.OrderDate >= ? AND ordmast.OrderDate <= ? order by ordmast.OrderDate desc ";
	
	
	public static final String SEARCH_DROPED_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast"
			              + " INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
	                      +"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where stalook.Status = 'Cancelled' and ordmast.OrderDate >= ? AND ordmast.OrderDate <= ? order by ordmast.OrderDate desc ";
	
	
	public static final String SEARCH_ORDER_DETAILS_QUERY = "select  ITEM.ItemID,ItemName,ORDERDETMASTER.OrderQuantity,ITEM.UnitPrice,DATE_FORMAT(ORDERHEADMASTER.DeliveryRequestedDate,'%d-%m-%Y') as DeliveryRequestedDate,ORDERDETMASTER.ShipmentQuantity from  `dbsanimarkdlink`.`tbl_order_header_master` ORDERHEADMASTER "
		  +"  inner join  `dbsanimarkdlink`.`tbl_order_details_master` ORDERDETMASTER ON ORDERDETMASTER.ORDERID=ORDERHEADMASTER.ORDERID INNER join `dbsvadha.erp`.`tbl_product_items` ITEM on ITEM.ItemID = ORDERDETMASTER.ItemID  "
          +" where orderhead.OrderDate >= ? and orderhead.OrderDate   <= ? and orderhead.OrderID = ?" ;
	
	public static final String SEARCH_MYDATE_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast"
            + " INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
            +"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where stalook.Status = 'InProcess' and ordmast.OrderDate >= ? AND ordmast.OrderDate <= ?  and custmast.CreatedBy = ? order by ordmast.OrderDate desc ";
	
	
	public static final String SEARCH_MYORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast"
            + " INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
            +"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where stalook.Status = 'InProcess' and  custmast.CreatedBy = ?";
	
	
	public static final String SEARCH_MYCLOSED_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast"
		                  	+ " INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
	                     	+"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where stalook.Status IN ('Delivery' ,'Shipped') and ordmast.OrderDate >= ? AND ordmast.OrderDate <= ? and  custmast.CreatedBy = ? order by ordmast.OrderDate desc ";
	
	
	public static final String SEARCH_MYDROPED_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast"
			              + " INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
	                      +"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where stalook.Status = 'Cancelled' and ordmast.OrderDate >= ? AND ordmast.OrderDate <= ? and   custmast.CreatedBy = ? order by ordmast.OrderDate desc ";
	
	public static final String INSERT_ORDER_FOLLOW_UP = "INSERT INTO `dbsanimarkdlink`.`tbl_communication_disposition` "
            + "(`CustomerID`,`RefOrderID`,`CommunicationDate`,`CommMode`,`CommDisposition`,`CommCost`,`CommunicationDetails`,`UserID`,`LeadID`) VALUES (?,?,?,?,?,?,?,?,?)";
	
	public static final String ORDER_FOLLOWUP_HISTORY_QUERY = " SELECT distinct DATE_FORMAT(COMMDISP.CommunicationDate,'%d-%m-%Y ') as CommunicationDate,COMMDISP.CommunicationDetails,COMMDISPLOOKUP.DispositionDisplayName,COMMDISP.CommMode,SURVEYUSER.UserName, COMMDISP.CommCost "
			+" FROM  `dbsanimarkdlink`.`tbl_communication_disposition` COMMDISP "
            +" inner join `dbsanimarkdlink`.`tbl_commdisposition_lookup` COMMDISPLOOKUP  on COMMDISP.CommDisposition=COMMDISPLOOKUP.DispositionID "
            +" inner join `dbsvadha.survey`.`tbl_survey_users` SURVEYUSER on COMMDISP.userId=SURVEYUSER.userId "
            +" where COMMDISP.RefOrderID=? ";
	
	public static final String FETCH_CUSTOMER_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast "
            +"inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
            +"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where ordmast.CustomerID=? order by ordmast.OrderDate desc ";
	
	public static final String ORDER_CUSTOMER_DETAILS_QUERY = "select ITEM.productid,product_brand_name,ORDERDETMASTER.OrderQuantity,ITEM.sellingprice,DATE_FORMAT(ORDERHEADMASTER.DeliveryRequestedDate,'%d-%m-%Y') as DeliveryRequestedDate,ORDERDETMASTER.ShipmentQuantity from  `dbsanimarkdlink`.`tbl_order_header_master` ORDERHEADMASTER "
		   +" inner join  `dbsanimarkdlink`.`tbl_order_details_master` ORDERDETMASTER ON ORDERDETMASTER.ORDERID=ORDERHEADMASTER.ORDERID INNER join `dbsanimarkdlink`.`sani_product` ITEM on ITEM.productid = ORDERDETMASTER.ItemID  "
		  +" where ORDERHEADMASTER.ORDERID= ?";
	public static final String FETCH_OUTSTANDING = " select distinct ( SELECT OrderAmount - ifnull((SELECT SUM(PaymentAmount) FROM `dbsanimarkdlink`.tbl_accounts_receivables  WHERE RefOrderID=ORDER_HEAD_MASTER.OrderID),0) "
			+" FROM `dbsanimarkdlink`.tbl_order_header_master ORDER_HEAD_MASTER WHERE ORDER_HEAD_MASTER.OrderID= HEADMASTER.OrderID)  as outstanding_amount FROM `dbsanimarkdlink`.tbl_order_header_master  HEADMASTER "
			+"LEFT JOIN `dbsanimarkdlink`.tbl_accounts_receivables ACCRECIVALES ON HEADMASTER.OrderID=ACCRECIVALES.REFORDERID where HEADMASTER.OrderID = ?";
	public static final String SEARCH_ITEM_DETAILS = "select proditem.ItemID,proditem.ItemName,proditem.ItemDescription,proditem.UnitPrice,proditem.MRP,proditem.ItemImage,proditem.Dimensions,proditem.ItemBrand, proditem.ProductID "
			+ "from  `dbsanimarkdlink`.`tbl_product_items` proditem where proditem.ProductID = ? ";
	public static final String SEARCH_ITEM_PRICECHANGE_DETAILS = " select supxitem.ProductItemSKU,supxitem.ItemName,supxitem.ItemDescription,supxitem.UnitPrice,supxitem.ItemImage,supxitem.MRP,supxitem.Dimensions,supxitem.ItemBrand "
             +"  from `dbsvadha.erp`.tbl_suppliersxproductitems supxitem  where supxitem.ProductItemSKU = ? ";
	public static final String HISTORY_CUSTOMER_ORDER_QUERY = " select ordmast.OrderID,ordmast.CustomerID,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status, "
			+"orpaymode.PaymentModeDisplayName from `dbsanimarkdlink`.`tbl_order_header_master` ordmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode "
			+"inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook on ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId  where ordmast.CustomerID= ? and ordmast.OrderID >= ?  LIMIT 10";
	public static final String CATALOG_DETAILS = "select product_cat_id,category_name FROM dbsanimarkdlink.sani_product_category";
	public static final String PRODUCT_DETAILS = "SELECT productid,product_brand_name,product_features FROM dbsanimarkdlink.sani_product where product_cat_id = ?";
	public static final String ADV_SANIMARK_QUERY = "select  clickable,alt_text,graphic,DATE_FORMAT(start_date_time ,'%d-%m-%Y' ) as start_date_time ,DATE_FORMAT(end_date_time,'%d-%m-%Y' ) as end_date_time,productID from  `dbsanimarkdlink`.tbl_advertisement";
	public static final String PRODUCT_DETAILS_ADV = " SELECT NPRODUCT.productid,NPRODUCT.product_brand_name,NPRODUCT.company_name,NPRODUCT.product_cat_id,NPRODUCT.warranty,NPRODUCT.date_of_manufacturing,"
			+"   NPRODUCT.expiry_date,NPRODUCT.product_features,NPRODUCT.productImg,NPRODUCT.mrp,NPRODUCT.discountInpercent,NPRODUCT.sellingprice "
			+" from sanimark.sani_product NPRODUCT,sanimark.sani_product_category NPRODUCTCAT ,sanimark.sani_supplier_x_product supxprod "
			+" where NPRODUCT.product_cat_id = NPRODUCTCAT.product_cat_id  and NPRODUCT.productid = supxprod.product_id and  NPRODUCT.product_cat_id = ?";
	public static final String ADV_SALESOFFER_QUERY = "select alt_text,graphic,DATE_FORMAT(start_date_time ,'%d-%m-%Y' ) as start_date_time ,DATE_FORMAT(end_date_time,'%d-%m-%Y' ) as end_date_time from  `ekutir_gateway`.gtwy_sale_offer where sale_offer_id in (1,2)";
	public static final String ROLE_ACTION_QUERY = "SELECT USER_ACTION.`Feature`, USER_ACTION.`Create`,USER_ACTION.`Update`,USER_ACTION.`Read`,USER_ACTION.`Delete`,USER_ACTION.`AcessLevel` ,USER_LOOKUP.OrderDiscount,SURVEY_USER.RoleID FROM `dbsvadha.survey`.tbl_survey_users SURVEY_USER,`dbsanimarkdlink`.tbl_role_action USER_ACTION,`dbsvadha.survey`.tbl_userrole_lookup USER_LOOKUP "
			+"	 where SURVEY_USER.`RoleID`=USER_ACTION.`RoleID` AND SURVEY_USER.`RoleID`=USER_LOOKUP.`RoleID` and SURVEY_USER.`UserID`= ? ";
	public static final String BIZ_TIPS_SANIMARK_QUERY = "select  alt_text,graphic,DATE_FORMAT(start_date_time ,'%d-%m-%Y' ) as start_date_time ,DATE_FORMAT(end_date_time,'%d-%m-%Y' ) as end_date_time from  `ekutir_gateway`.gtwy_business_tip";
	public static final String FETCH_CUSTOMER_ROLE_QUERY = "SELECT customaster.CustomerID, customaster.CustomerFName,customaster.MName,customaster.CustomerLName,address.AddressID,address.AddressLine1,address.AddressLine2,address.AddressLine3,COALESCE(address.Block,'') as Block,"
			                     + "address.District,address.State,address.Country,address.PostalCode,customaster.PrimaryPhone,customaster.SecondaryPhone,customaster.BusinessCategory,"
                                 +" customaster.BusinessName,customaster.Description,customaster.PrevLeadID  FROM `dbsvadha.survey`.`tbl_mecustomer_master` customaster inner join `dbsanimarkdlink`.`tbl_address` address on address.AddressId = customaster.Address where  customaster.CustomerStatus = 'active' and CreatedBy = ? order by customaster.CustomerID desc";
	
	public static final String FETCH_PARTIAL_ORDER_QUERY = "select * from (select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,"
			+"CASE WHEN pending_delivery >= 1 THEN 'Partial Delivery 'ELSE 'Shipped' END AS status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast "
			+"inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook  on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId "
			+"inner join (SELECT OrderID,sum(OrderQuantity) - sum(ShipmentQuantity) pending_delivery FROM `dbsanimarkdlink`.tbl_order_details_master group by  OrderID) pending_status on ordmast.OrderID= pending_status.OrderID and  stalook.Status = 'Partial Delivery' order by ordmast.OrderID desc ) X where X.status<> 'Shipped' ";
	
	public static final String PARTIAL_ORDER_DETAILS_QUERY = "select ITEM.ItemID,ItemName,ORDERDETMASTER.OrderQuantity,ITEM.UnitPrice,DATE_FORMAT(ORDERHEADMASTER.DeliveryRequestedDate,'%d-%m-%Y') as DeliveryRequestedDate,ORDERDETMASTER.ShipmentQuantity from  `dbsanimarkdlink`.`tbl_order_header_master` ORDERHEADMASTER "
		    +"inner join  `dbsanimarkdlink`.`tbl_order_details_master` ORDERDETMASTER ON ORDERDETMASTER.ORDERID=ORDERHEADMASTER.ORDERID INNER join `dbsvadha.erp`.`tbl_product_items` ITEM on ITEM.ItemID = ORDERDETMASTER.ItemID "
		    +" where ORDERHEADMASTER.ORDERID= ? ";
	
	public static final String SEARCH_PARTIAL_ORDER_QUERY = "select ordmast.OrderID,ordmast.CustomerID,custmast.CustomerFName,custmast.MName,custmast.CustomerLName,DATE_FORMAT(ordmast.OrderDate,'%d-%m-%Y') as OrderDate,ordmast.OrderAmount,stalook.Status,orpaymode.PaymentModeDisplayName,custmast.CustomerStatus from  `dbsanimarkdlink`.`tbl_order_header_master` ordmast"
		                  	+ " INNER JOIN `dbsvadha.survey`.`tbl_mecustomer_master` custmast inner join `dbsanimarkdlink`.`tbl_orderpaymentmode_lookup` orpaymode inner join `dbsanimarkdlink`.`tbl_status_lookup` stalook "
	                     	+"on ordmast.CustomerID=custmast.CustomerID and ordmast.OrderPaymentMode = orpaymode.PaymentMode and ordmast.Status = stalook.StatusId   where stalook.Status = 'Partial Delivery' and ordmast.OrderDate >= ? AND ordmast.OrderDate <= ? order by ordmast.OrderDate desc ";
	
	public static final String SEARCH_PARTIAL_DETAILS_QUERY = "select  ITEM.ItemID,ItemName,ORDERDETMASTER.OrderQuantity,ITEM.UnitPrice,DATE_FORMAT(ORDERHEADMASTER.DeliveryRequestedDate,'%d-%m-%Y') as DeliveryRequestedDate,ORDERDETMASTER.ShipmentQuantity from  `dbsanimarkdlink`.`tbl_order_header_master` ORDERHEADMASTER "
		  +"  inner join  `dbsanimarkdlink`.`tbl_order_details_master` ORDERDETMASTER ON ORDERDETMASTER.ORDERID=ORDERHEADMASTER.ORDERID INNER join `dbsvadha.erp`.`tbl_product_items` ITEM on ITEM.ItemID = ORDERDETMASTER.ItemID  "
          +" where orderhead.OrderDate >= ? and orderhead.OrderDate   <= ? and orderhead.OrderID = ?" ;
	public static final String FETCH_CANCELDISBLE = "SELECT   SUM(ShipmentQuantity) pending_delivery FROM `dbsanimarkdlink`.tbl_order_details_master WHERE OrderID = ?";

}

package ekutir.sanimark.dao.Impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceException;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ekutir.sanimark.android.model.AppMaster;
import ekutir.sanimark.android.model.Application;
import ekutir.sanimark.android.model.Audit;
import ekutir.sanimark.android.model.BusinessUser;
import ekutir.sanimark.android.model.Customer;
import ekutir.sanimark.android.model.CustomerType;
import ekutir.sanimark.android.model.MeAndMyLand;
import ekutir.sanimark.android.model.PhoneXOtp;
import ekutir.sanimark.android.model.Registration;
import ekutir.sanimark.android.model.SvadhaErpAddress;
import ekutir.sanimark.android.model.User;
import ekutir.sanimark.android.view.ResetPassword;
import ekutir.sanimark.constant.GatewayConstants;
import ekutir.sanimark.dao.GatewayDao;
import ekutir.sanimark.utilities.CommonUtilities;
import ekutir.sanimark.utilities.GatewayUtilties;

@Repository("GatewayDao")
public class GatewayDaoImpl implements GatewayDao {

	private static final Logger LOGGER = Logger.getLogger(GatewayDaoImpl.class);

	@Autowired
	@Qualifier(value = "hibernate4AnnotatedSessionFactoryForSanimark")
	private SessionFactory sessionFactory;
	List<Object[]> rows=null;
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	Session session = null;
	Transaction tx = null;

	@Override
	public int insertCustomerDetails(Customer customer) {
		session = this.sessionFactory.getCurrentSession();
		session.persist(customer);
		return customer.getCustomerId();
	}

	@Transactional
	@Override
	public Map<String, Boolean> isPhoneNumberAlreadyRegistered(long phoneNumber, String appCode) {
		Map<String, Boolean> typeOfUser = new HashMap<>();
		session = this.sessionFactory.getCurrentSession();
		List<Registration> me = null;
		List<BusinessUser> businessUser = null;
		Criteria criteria = null;
		try {
			criteria = session.createCriteria(Registration.class).createAlias("application", "a")
					.add(Restrictions.eq("a.applicationCode", appCode));
			criteria.add(Restrictions.eq("phoneNumber", phoneNumber));
			me = (List<Registration>) criteria.list();
			if (null != me ? (me.size() > 0 ? (null != me.get(0) ? me.get(0).getRegistrationId() != 0 : false) : false)
					: false) {
				typeOfUser.put("IS_ME_USER", true);
			}
		} catch (NonUniqueResultException e) {
			typeOfUser.put("IS_ME_USER", true);
		}

		try {
			// Check business user
			criteria = session.createCriteria(BusinessUser.class);
			criteria.add(Restrictions.eq("registeredPhoneNumber", phoneNumber));
			businessUser = (List<BusinessUser>) criteria.list();
			if (null != businessUser ? (businessUser.size() > 0
					? (null != businessUser.get(0) ? businessUser.get(0).getBusinessUserId() != 0 : false) : false)
					: false) {
				typeOfUser.put("IS_BUSINESS_USER", true);
			}
		} catch (NonUniqueResultException e) {
			typeOfUser.put("IS_BUSINESS_USER", true);
		}
		return typeOfUser;
	}

	@Override
	public void savePhoneNumberTempAuthKeyAndOtp(PhoneXOtp phoneXOtp) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(phoneXOtp);
		// LOGGER.info("Phone and correspoding OTP saved successfully" +
		// phoneXOtp.toString());
	}

	@Override
	public void saveTempAuthKey(long phoneNumber, String tempAuthKey) {
		session = this.sessionFactory.getCurrentSession();
		PhoneXOtp phoneXOtp = new PhoneXOtp();
		phoneXOtp.setPhoneNumber(phoneNumber);
		phoneXOtp.setTempAuthKey(tempAuthKey);
		session.saveOrUpdate(phoneXOtp);
	}

	@Override
	public boolean verifyPassword(String password, long phoneNumber, String tempAuthKey, String appCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).createAlias("registration", "r")
				.add(Restrictions.eq("r.phoneNumber", phoneNumber)).createAlias("r.application", "a")
				.add(Restrictions.eq("a.applicationCode", appCode)).add(Restrictions.eq("password", password));
		User user = (User) criteria.uniqueResult();

		// Check business user
		criteria = session.createCriteria(BusinessUser.class);
		criteria.add(Restrictions.eq("registeredPhoneNumber", phoneNumber)).add(Restrictions.eq("password", password));
		BusinessUser businessUser = (BusinessUser) criteria.uniqueResult();
		return ((null != user) || (null != businessUser));
	}

	@Override
	public boolean checkTempAuth(long phoneNumber, String tempAuthKey) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(PhoneXOtp.class).add(Restrictions.eq("phoneNumber", phoneNumber))
				.add(Restrictions.eq("tempAuthKey", tempAuthKey));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@Override
	public User insertNewUserRegistrationDetails(User user) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(user);
		return user;
	}

	@Override
	public BusinessUser updateBusinessUser(BusinessUser businessUser) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(businessUser);
		return businessUser;
	}

	@Override
	public BusinessUser fetchBusinessUser(long phoneNumber) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(BusinessUser.class)
				.add(Restrictions.eq("registeredPhoneNumber", phoneNumber));
		return (BusinessUser) criteria.uniqueResult();
	}

	@Override
	public void writeToAudit(String caption, String description) {
		session = this.sessionFactory.getCurrentSession();
		Audit audit = new Audit();
		audit.setCaption(caption);
		audit.setDescription(description);
		audit.setCreatedBy(GatewayConstants.SYSTEM_TAG);
		try {
			audit.setCreatedDateTime(GatewayUtilties.getCurrentDate(GatewayConstants.MYSQL_TIMESTAMP_FORMAT));
		} catch (ParseException e) {
			// LOGGER.error("Error writing in Audit Logs :::: Caption : " +
			// caption + " :::: Description : " + description,
			// e);
		}
		session.save(audit);
	}

	@Override
	public User getMicroentrepreneur(int microentrepreneurId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).add(Restrictions.idEq(microentrepreneurId));
		return (User) criteria.uniqueResult();
	}

	@Override
	public Registration fetchRegistrationDetails(long phoneNumber, String applicationCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Registration.class).createAlias("application", "a")
				.add(Restrictions.eq("a.applicationCode", applicationCode))
				.add(Restrictions.eq("phoneNumber", phoneNumber));
		return (Registration) criteria.uniqueResult();
	}

	@Override
	public User updateRegistrationForReturningUser(User user) {
		session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(user);
		return user;
	}

	@Override
	public void removeTempAuth(long phoneNumber) {
		session = this.sessionFactory.getCurrentSession();
		PhoneXOtp phoneXOtp = (PhoneXOtp) session.createCriteria(PhoneXOtp.class)
				.add(Restrictions.eq("phoneNumber", phoneNumber)).uniqueResult();
		session.delete(phoneXOtp);
	}

	@Override
	public Application fetchApplication(String applicationCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Application.class)
				.add(Restrictions.eq("applicationCode", applicationCode));
		return (Application) criteria.uniqueResult();
	}

	@Override
	public boolean isCustomerExistsForMicroentrepreneur(String custAadharNumber) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class)
				.add(Restrictions.eq("aadharNumber", custAadharNumber));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@Override
	public User fetchUser(long phoneNumber, String appCode) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).createAlias("registration", "r")
				.add(Restrictions.eq("r.phoneNumber", phoneNumber)).createAlias("r.application", "a")
				.add(Restrictions.eq("a.applicationCode", appCode));
		return (User) criteria.uniqueResult();
	}

	@Override
	public boolean verifyOtp(long phoneNumber, int otp, String tempAuthKey) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(PhoneXOtp.class).add(Restrictions.eq("phoneNumber", phoneNumber))
				.add(Restrictions.eq("tempAuthKey", tempAuthKey)).add(Restrictions.eq("otp", otp));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@Override
	public Customer fetchCustomer(int customerId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class).add(Restrictions.idEq(customerId));
		return (Customer) criteria.uniqueResult();
	}

	@Override
	public List<MeAndMyLand> saveMeAndMyLandDetailsForCustomer(List<MeAndMyLand> listOfMeAndMyLands) {
		List<MeAndMyLand> landDetails = new ArrayList<MeAndMyLand>();
		session = this.sessionFactory.getCurrentSession();
		for (MeAndMyLand m : listOfMeAndMyLands) {
			session.save(m);
			landDetails.add(m);
		}
		return landDetails;
	}

	@Override
	public CustomerType fetchCustomerTypes(String customerTypeDesc) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(CustomerType.class)
				.add(Restrictions.eq("typeCode", customerTypeDesc));
		return (CustomerType) criteria.uniqueResult();
	}

	@Override
	public User fetchUserById(int userId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class).add(Restrictions.idEq(userId));
		return (User) criteria.uniqueResult();
	}

	/*@Override
	public int saveSvadhaCustomerInfo(SvadhaErpMeCustomer erpMeCustomer) {
		session = this.sessionFactory.getCurrentSession();
		session.save(erpMeCustomer);
		return erpMeCustomer.getCustomerId();
	}*/

	@Override
	public int saveSvadhaErpMeAddress(SvadhaErpAddress erpAddress) {
		session = this.sessionFactory.getCurrentSession();
		session.save(erpAddress);
		return erpAddress.getAddresId();
	}

	@Override
	public void saveAppMapping(AppMaster appMaster) {
		session = this.sessionFactory.getCurrentSession();
		session.save(appMaster);
	}

	/*@Override
	public int getConnectedAppCustomerId(int registrationId) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class)
				.add(Restrictions.eq("registration", registrationId));
				//.add(Restrictions.eq("aadharNumber", aadharNumber));
		return ((User) criteria.uniqueResult()).getUserId();
	}*/
	
	@SuppressWarnings("rawtypes")
	@Override
	public int getConnectedAppCustomerId(long phoneNumber) {
		session = this.sessionFactory.getCurrentSession();
		int regId = 0;
		SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery("SELECT GUSER.user_id FROM ekutir_gateway.gtwy_user_master GUSER, ekutir_gateway.gtwy_registration REGD "
				+ "where GUSER.registration = REGD.registration_id and REGD.phone_number="+phoneNumber+" ");
		List list=query.list();
		regId=Integer.parseInt(list.get(0).toString());
		return regId;
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		session = this.sessionFactory.getCurrentSession();
		session.save(customer);
		return customer;
	}

	@Override
	public boolean isCustomerPhoneNumberAndAadhaarNumberPresent(long custPhoneNumber, int userId,
			String aadhaarNumber) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class)
				.add(Restrictions.disjunction().add(Restrictions.eq("phoneNumber", custPhoneNumber)));
		// NOTE :: Aadhaar number deemed non mandatory
		// .add(Restrictions.eq("aadharNumber", aadhaarNumber)));
		List<Registration> customerList = criteria.list();

		criteria = session.createCriteria(User.class).add(Restrictions.idEq(userId)).createAlias("registration", "r")
				.add(Restrictions.disjunction().add(Restrictions.eq("r.phoneNumber", custPhoneNumber)));
		// .add(Restrictions.eq("r.aadharNumber", aadhaarNumber)));
		List<Registration> meList = criteria.list();

		return ((meList.size() > 0) || (customerList.size() > 0));
	}

	@Override
	public boolean isCustomerExistsForMicroentrepreneur(long custPhoneNumber) {
		session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class).add(Restrictions.eq("phoneNumber", custPhoneNumber));
		criteria.setProjection(Projections.rowCount());
		long count = (Long) criteria.uniqueResult();
		return (count > 0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public int resetAppUserPassword(ResetPassword resetPassword) {
		int userID=0;
		int existsUserID=0;
		//Thread[] thread = new Thread[2];
		session = sessionFactory.openSession();
		session.getTransaction().begin();
		CommonUtilities cu=new CommonUtilities();
		String oldPassword = resetPassword.getCurrentPassword();
		//String oldHashedPassword = cu.generateHash(oldSaltedPassword);

		String newPassword = resetPassword.getNewPassword();
		//String hashedPassword = cu.generateHash(saltedPassword);

		SQLQuery varify_query = session.createSQLQuery("SELECT * FROM ekutir_gateway.gtwy_user_master where user_id=? and password=? ");
		varify_query.setParameter(0, resetPassword.getUserId());
		varify_query.setParameter(1, oldPassword);
		SQLQuery query = session.createSQLQuery("UPDATE ekutir_gateway.gtwy_user_master SET password = ?, updated_date_time = ? WHERE user_id = ? ");
		try {
			rows = varify_query.list();
			for (Object[] password_ok : rows) {
				existsUserID=Integer.parseInt(password_ok[0].toString());

			}
			if(existsUserID > 0)
			{
				query.setParameter(0, newPassword);
				try {
					query.setParameter(1, cu.currentDateTime());
				} catch (ParseException e) {

					e.printStackTrace();
				}
				query.setParameter(2, resetPassword.getUserId());

				userID=query.executeUpdate();
				
				session.getTransaction().commit();
				//userID=1;
				//ResetPasswordMail mail = new ResetPasswordMail();
				//mail.setParameters(httpSession.getAttribute("userId").toString(), httpSession.getAttribute("loggedInUser").toString(), resetPassword.getNewPassword());
				//thread[1] = new Thread(mail);
				//thread[1].start();
			}
			/*else
			{
				userID=2;	
			}*/
		} catch (HibernateException e) {
			if (session.getTransaction() != null)
				session.getTransaction().rollback();
			e.printStackTrace();
			userID=0;
		} catch (PersistenceException e) {
			e.printStackTrace();
			userID=0;;
		} finally {
			session.close();
		}
		return userID;
	}
}
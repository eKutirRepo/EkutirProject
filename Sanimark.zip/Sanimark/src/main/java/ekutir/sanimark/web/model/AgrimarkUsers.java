package ekutir.sanimark.web.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dbsanimarkdlink.sani_supplier")
public class AgrimarkUsers implements Serializable {

	private static final long serialVersionUID = -7988799579036225137L;
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int supplier_id;
	@Column
	private String login_id;
	@Column
	private String password;
	@Column
	private String business_name;
	@Column
	private String primary_contact_first_name;
	@Column
	private String primary_contact_middle_name;
	@Column
	private String primary_contact_last_name;
	@Column
	private String primary_Contact_Number;
	@Column
	private String secondary_contact_name;
	@Column
	private String secondary_contact_number;
	@Column
	private String service_description;
	@Column
	private int address;
	@Column
	private String last_login_date_time;
	@Column
	private int status;
	@Column
	private String created_date_time;
	@Column
	private String created_by;
	@Column
	private String updated_date_time;
	@Column
	private String updated_by;
	
	public AgrimarkUsers() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AgrimarkUsers(int supplier_id, String login_id, String password, String business_name,
			String primary_contact_first_name, String primary_contact_middle_name, String primary_contact_last_name,String primary_Contact_Number, String secondary_contact_name,
			String secondary_contact_number, String service_description, int address, String last_login_date_time,
			int status, String created_date_time, String created_by, String updated_date_time, String updated_by) {
		super();
		this.supplier_id = supplier_id;
		this.login_id = login_id;
		this.password = password;
		this.business_name = business_name;
		this.primary_contact_first_name = primary_contact_first_name;
		this.primary_contact_middle_name = primary_contact_middle_name;
		this.primary_contact_last_name = primary_contact_last_name;
		this.primary_Contact_Number = primary_Contact_Number;
		this.secondary_contact_name = secondary_contact_name;
		this.secondary_contact_number = secondary_contact_number;
		this.service_description = service_description;
		this.address = address;
		this.last_login_date_time = last_login_date_time;
		this.status = status;
		this.created_date_time = created_date_time;
		this.created_by = created_by;
		this.updated_date_time = updated_date_time;
		this.updated_by = updated_by;
	}

	public int getSupplier_id() {
		return supplier_id;
	}

	public void setSupplier_id(int supplier_id) {
		this.supplier_id = supplier_id;
	}

	public String getLogin_id() {
		return login_id;
	}

	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBusiness_name() {
		return business_name;
	}

	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}

	public String getPrimary_contact_first_name() {
		return primary_contact_first_name;
	}

	public void setPrimary_contact_first_name(String primary_contact_first_name) {
		this.primary_contact_first_name = primary_contact_first_name;
	}

	public String getPrimary_contact_middle_name() {
		return primary_contact_middle_name;
	}

	public void setPrimary_contact_middle_name(String primary_contact_middle_name) {
		this.primary_contact_middle_name = primary_contact_middle_name;
	}

	public String getPrimary_contact_last_name() {
		return primary_contact_last_name;
	}

	public void setPrimary_contact_last_name(String primary_contact_last_name) {
		this.primary_contact_last_name = primary_contact_last_name;
	}

	public String getPrimary_Contact_Number() {
		return primary_Contact_Number;
	}

	public void setPrimary_Contact_Number(String primary_Contact_Number) {
		this.primary_Contact_Number = primary_Contact_Number;
	}

	public String getSecondary_contact_name() {
		return secondary_contact_name;
	}

	public void setSecondary_contact_name(String secondary_contact_name) {
		this.secondary_contact_name = secondary_contact_name;
	}

	public String getSecondary_contact_number() {
		return secondary_contact_number;
	}

	public void setSecondary_contact_number(String secondary_contact_number) {
		this.secondary_contact_number = secondary_contact_number;
	}

	public String getService_description() {
		return service_description;
	}

	public void setService_description(String service_description) {
		this.service_description = service_description;
	}

	public int getAddress() {
		return address;
	}

	public void setAddress(int address) {
		this.address = address;
	}

	public String getLast_login_date_time() {
		return last_login_date_time;
	}

	public void setLast_login_date_time(String last_login_date_time) {
		this.last_login_date_time = last_login_date_time;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCreated_date_time() {
		return created_date_time;
	}

	public void setCreated_date_time(String created_date_time) {
		this.created_date_time = created_date_time;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_date_time() {
		return updated_date_time;
	}

	public void setUpdated_date_time(String updated_date_time) {
		this.updated_date_time = updated_date_time;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

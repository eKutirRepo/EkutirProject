package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.android.dto.CustomFeaturesBean;

public class CustomFeaturesDto {
	
	private List<CustomFeaturesBean> feature;

	public List<CustomFeaturesBean> getFeature() {
		return feature;
	}

	public void setitems(List<CustomFeaturesBean> feature) {
		this.feature = feature;

	}

}

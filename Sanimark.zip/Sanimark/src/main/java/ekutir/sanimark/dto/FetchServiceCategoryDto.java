package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.view.beans.ServiceCategoryBean;

public class FetchServiceCategoryDto {
	
	private List<ServiceCategoryBean> serviceCategories;

	public List<ServiceCategoryBean> getServiceCategories() {
		return serviceCategories;
	}

	public void setServiceCategories(List<ServiceCategoryBean> serviceCategories) {
		this.serviceCategories = serviceCategories;
	}
	
}

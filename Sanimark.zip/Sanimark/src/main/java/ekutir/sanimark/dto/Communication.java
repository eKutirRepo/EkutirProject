package ekutir.sanimark.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Communication implements Serializable {
	private static final long serialVersionUID = 1L;
	private int otp;
	private String imei;
	private Date otpGenerationDate;
	private long phoneNumber;
	private String applicationCode;
	private String status;
	private String password;
	private String typeOfUser;
	private int registrationId;

	public Date getOtpGenerationDate() {
		return this.otpGenerationDate;
	}

	public void setOtpGenerationDate(String otpGenerationDate) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
		dateFormat.setLenient(false);
		this.otpGenerationDate = dateFormat.parse(otpGenerationDate);
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getApplicationCode() {
		return applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/*public void setOtpGenerationDate(Date otpGenerationDate) {
		this.otpGenerationDate = otpGenerationDate;
	}*/

	public String getTypeOfUser() {
		return typeOfUser;
	}

	public void setTypeOfUser(String typeOfUser) {
		this.typeOfUser = typeOfUser;
	}

	public int getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	

}

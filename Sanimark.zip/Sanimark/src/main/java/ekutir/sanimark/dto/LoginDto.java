package ekutir.sanimark.dto;

import ekutir.sanimark.android.dto.UserViewBean;

public class LoginDto {
	private UserViewBean Sucess;

	public UserViewBean getSucess() {
		return Sucess;
	}

	public void setSucess(UserViewBean sucess) {
		Sucess = sucess;
	}

}

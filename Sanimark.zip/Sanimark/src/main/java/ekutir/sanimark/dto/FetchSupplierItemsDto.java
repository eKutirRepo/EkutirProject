package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.view.beans.FetchSupplierItemsBean;

public class FetchSupplierItemsDto {
	
	private List<FetchSupplierItemsBean> productItems;

	public List<FetchSupplierItemsBean> getProductItems() {
		return productItems;
	}

	public void setProductItems(List<FetchSupplierItemsBean> productItems) {
		this.productItems = productItems;
	}
}

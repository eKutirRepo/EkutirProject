package ekutir.sanimark.dto;

import java.util.List;

import ekutir.sanimark.view.beans.FetchSupplierServicesBean;

public class FetchSupplerServicesDataBeanDto {
	
	private List<FetchSupplierServicesBean> Services;

	public List<FetchSupplierServicesBean> getServices() {
		return Services;
	}

	public void setServices(List<FetchSupplierServicesBean> services) {
		Services = services;
	}
	
}

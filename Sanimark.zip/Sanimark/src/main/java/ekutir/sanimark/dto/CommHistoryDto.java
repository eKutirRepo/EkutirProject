package ekutir.sanimark.dto;

import java.util.ArrayList;
import java.util.List;

import ekutir.sanimark.android.dto.CommDetailsBean;

public class CommHistoryDto {
	
	List<CommDetailsBean> commDetails = new ArrayList<>();
	
	public List<CommDetailsBean> getCommDetails() {
		return commDetails;
	}
	public void setCommDetails(List<CommDetailsBean> commDetails) {
		this.commDetails = commDetails;
	}
	
}

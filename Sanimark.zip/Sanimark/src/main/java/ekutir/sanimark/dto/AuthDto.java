package ekutir.sanimark.dto;

public class AuthDto {

}

package ekutir.sanimark.dto;

import java.math.BigDecimal;

public class LandDetailsDto {
	private int landId;
	private BigDecimal landArea;
	private String landLocation;
	private String landUnit;
	private String landOwnership;

	public int getLandId() {
		return landId;
	}

	public void setLandId(int landId) {
		this.landId = landId;
	}

	public BigDecimal getLandArea() {
		return landArea;
	}

	public void setLandArea(BigDecimal bigDecimal) {
		this.landArea = bigDecimal;
	}

	public String getLandLocation() {
		return landLocation;
	}

	public void setLandLocation(String landLocation) {
		this.landLocation = landLocation;
	}

	public String getLandUnit() {
		return landUnit;
	}

	public void setLandUnit(String landUnit) {
		this.landUnit = landUnit;
	}

	public String getLandOwnership() {
		return landOwnership;
	}

	public void setLandOwnership(String landOwnership) {
		this.landOwnership = landOwnership;
	}

}

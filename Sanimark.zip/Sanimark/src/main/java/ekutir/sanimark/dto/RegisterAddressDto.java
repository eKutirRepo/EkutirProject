package ekutir.sanimark.dto;

import java.util.ArrayList;
import java.util.List;

import ekutir.sanimark.android.dto.AddressBean;

public class RegisterAddressDto {
	
	List<AddressBean> address = new ArrayList<>();

	public List<AddressBean> getAddress() {
		return address;
	}

	public void setAddress(List<AddressBean> address) {
		this.address = address;
	}

}

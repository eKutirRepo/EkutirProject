package ekutir.sanimark.constant;

public class MailConstant {
	/*public static final String emailServiceProvider = "smtp.zoho.com";
	public static final String emailServiceUser = "info@ekisticssolutions.com";
	public static final String emailServicePassword = "Ek1st1csCorpWeb@7102";
	public static final String emailServicePort = "465";*/
	
	public static final String emailServiceProvider = "smtp.gmail.com";
	public static final String emailServiceUser = "farmchalo@ekutirsb.com";
	public static final String emailServicePassword = "ekutir1234";
	public static final String emailServicePort = "465";
}

package ekutir.sanimark.controller;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ekutir.sanimark.android.dto.AddressBean;
import ekutir.sanimark.android.dto.AdminUserBean;
import ekutir.sanimark.android.dto.DataManipulationBean;
import ekutir.sanimark.android.dto.ErrorResponseBean;
import ekutir.sanimark.android.dto.ForgetPasswordBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ResetPasswordBean;
import ekutir.sanimark.android.dto.TokenBean;
import ekutir.sanimark.android.dto.UserViewBean;
import ekutir.sanimark.dto.ErrorDto;
import ekutir.sanimark.dto.LoginDto;
import ekutir.sanimark.service.UserService;
import ekutir.sanimark.utilities.CommonException;
import ekutir.sanimark.utilities.EncryptionDecryption;
import ekutir.sanimark.utilities.PasswordHasher;
import ekutir.sanimark.view.beans.UserResetPassword;

@Controller
@RequestMapping("/")
/*@RestController*/
@CrossOrigin(origins = "*", maxAge = 3600)
public class AppController {

	@Autowired
	UserService userService;

	@Autowired
	MessageSource messageSource;
	
	@Autowired
	PasswordHasher passwordHasher;
	
	private DataManipulationBean datamanipulation = null;
	private ObjectMapper mapper = null;
	private Locale locale;
	private RegisterDataBean registerBean = null;
	private AdminUserBean adminBean = null;
	private AdminUserBean changeadminpass = null;
	private AddressBean addressBean = null;
	private ResetPasswordBean resetPwd = null;
	
	@SuppressWarnings("unused")
	private static final Logger logger = Logger.getLogger(AppController.class);

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String showLogin(ModelMap model) {
		return "login";
	}
	public EncryptionDecryption encryptionDecryption = new EncryptionDecryption();
	@Autowired
	HttpSession httpSession;

	
	@RequestMapping(value = "/login", method = RequestMethod.POST , produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LoginDto> getLogin(@RequestBody final String json,@ModelAttribute("userviewBean") UserViewBean userviewBean,Locale locale) throws CommonException, JsonProcessingException, IOException, Exception{
		try{
			ObjectMapper mapper = new ObjectMapper();
			userviewBean = mapper.readValue(json,UserViewBean.class);
			LoginDto logindatalistdto=new LoginDto();
			String password=userviewBean.getPassword();
			String loginuser=userviewBean.getLoginId();
			
			userService.isValidUser(userviewBean);
			String password_from_database = userviewBean.getPassword();
			//System.out.println("=========db=========="+password_from_database);
			//String hashedPassword = PasswordHasher.generateHash(userviewBean.getPassword());
			//System.out.println("==============hsdb==============="+hashedPassword);
			/*if (authentication == false) {
				throw new CommonException(messageSource.getMessage("valid.invalidcredential", null, locale));
			}
			if (isValidUser == true && userviewBean.getStatus() == 0 ) {
				throw new CommonException(messageSource.getMessage("error.approval", null, locale));
			}*/
			
			Boolean authentication=passwordHasher.login(loginuser, password, password_from_database);
			if (authentication == false) {
				throw new CommonException(messageSource.getMessage("valid.invalidcredential", null, locale));
			}
			if (authentication == true && userviewBean.getStatus() == 0 ) {
				throw new CommonException(messageSource.getMessage("error.approval", null, locale));
			}
			//userviewBean.setMessage(messageSource.getMessage("valid.login", null, locale));
			logindatalistdto.setSucess(userviewBean);
			//System.out.println(" userviewBean.getUserId() : "+userviewBean.getUserId());
			httpSession.setAttribute("userId", userviewBean.getUserId());
			httpSession.setAttribute("userName", userviewBean.getLoginId());
			httpSession.setAttribute("loggedInUser", userviewBean.getUserName());
			
			userviewBean.setUserId(0);
			userviewBean.setLoginId(null);
			userviewBean.setPassword(null);
			
			
//			Map<String,String> ret = new LinkedHashMap<String,String>();
//			ret.add("userName","tapas");
//			ret.add("Success");
			return new ResponseEntity<LoginDto>(logindatalistdto, HttpStatus.OK);
		}
		catch(JsonProcessingException jpe)
		{
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
		catch(IOException io)
		{
			throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
		}
	}
	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String sucessLogin() {
		return "home";
	}

	@ExceptionHandler(CommonException.class)
	public ResponseEntity<ErrorDto> exceptionHandler(Exception ex) {
		ErrorResponseBean error = new ErrorResponseBean();
		error.setErrorCode(HttpStatus.PRECONDITION_FAILED.value());
		error.setMessage(ex.getMessage());
		ErrorDto errorDto=new ErrorDto();
		errorDto.setError(error);
		return new ResponseEntity<ErrorDto>(errorDto, HttpStatus.OK);
	}
	/**
	 * This method handles logout requests.
	 */

	@RequestMapping(value = "/logOut", method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request, HttpServletResponse
			response) throws CommonException{
		try {	
			
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setDateHeader("Expires", 0); // Proxies.
			httpSession.invalidate();
			return "login";

		} catch (Exception e) {
			throw new CommonException("Logout Error!");		
		}

	}
	
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		@RequestMapping(value = "/forgetPassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity forgetPassword(@RequestBody final String json,
				@ModelAttribute("forgetPasswordBean") ForgetPasswordBean forgetPasswordBean, Locale locale)
				throws CommonException, JsonParseException, JsonMappingException, IOException {
			try {
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				String roleBean = mapper.readValue(json, ForgetPasswordBean.class).getRole();
				//System.out.println("========Role=========="+roleBean);

				String email = mapper.readValue(json, ForgetPasswordBean.class).getEmail();
				boolean mailSend = userService.forgetPassword(roleBean,email);
				//System.out.println("========Role=========="+forgetPasswordBean.getRole());
				//System.out.println("==================mailSend======================="+mailSend);
				if (mailSend == false) {
					throw new CommonException(messageSource.getMessage("valid.invalidmailid", null, locale));
				}
				forgetPasswordBean.setMessage(messageSource.getMessage("Password has been sent to your register Email.", null, locale));
				return new ResponseEntity(forgetPasswordBean, HttpStatus.OK);
			} catch (JsonProcessingException jpe) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (IOException io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}

		}
		
		// Register Agrimark Supplier
		
		@SuppressWarnings("unused")
		@RequestMapping(value = "/registration", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })
		public ResponseEntity<DataManipulationBean> registration(@RequestBody final String json)
				throws CommonException, JsonParseException, JsonMappingException, IOException {
			datamanipulation = new DataManipulationBean();
			try {

				mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				registerBean = mapper.readValue(json, RegisterDataBean.class);
				boolean duplicateCheck = userService.duplicateRegistration(registerBean);
				if(duplicateCheck == false)
				{
					int registrationData = userService.registration(registerBean);
					List<String> fetchAdminDetails = userService.fetchAdminDetails();
					if (registrationData > 0) {
						for(String adminMail: fetchAdminDetails){
							boolean adminmailSend = userService.sendRegisterMailtoAdmin(adminMail);
							}
						
						datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
						datamanipulation.setId(registrationData);
					} else {
						throw new CommonException(messageSource.getMessage("error.msg", null, locale));
					}
				}else{
					throw new CommonException(messageSource.getMessage("invalid.email", null, locale));
					
				}

			} catch (JsonParseException jpe) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (JsonMappingException jme) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (IOException io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}

			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
		}
		
		/*For Admin temporary use*/
		
		@RequestMapping(value = "/adminuser", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })
		public ResponseEntity<DataManipulationBean> adminuser(@RequestBody final String json)
				throws CommonException, JsonParseException, JsonMappingException, IOException {
			datamanipulation = new DataManipulationBean();
			try {

				mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				adminBean = mapper.readValue(json, AdminUserBean.class);
				int adminData = userService.adminUser(adminBean);
				if (adminData > 0) {
					
					//datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));
					datamanipulation.setId(adminData);
				} else {
					throw new CommonException(messageSource.getMessage("error.msg", null, locale));
				}

			} catch (JsonParseException jpe) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (JsonMappingException jme) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (IOException io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}

			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
		}
		
		/*Change all password for Admin*/
		
		@RequestMapping(value = "/changeAllPasswordAdmin", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
		public ResponseEntity<DataManipulationBean> changeAllPassword()
				throws CommonException, JsonParseException, JsonMappingException, IOException {
			datamanipulation = new DataManipulationBean();
			try {

				List<AdminUserBean> fetchAdminData = userService.fetchAdminData();
					for(AdminUserBean adminMail: fetchAdminData){
						String login = adminMail.getLoginId();
						String pass = adminMail.getPassword();
						String hashPassword = passwordHasher.signup(login, pass);
						userService.updatedminpass(login, hashPassword);
						}
					//datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));

			
			} catch (Exception io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}

			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
		}
		
		/* Change all password for Supplier */
		
		@RequestMapping(value = "/changeAllPasswordSupplier", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
		public ResponseEntity<DataManipulationBean> changeAllPasswordSupplier()
				throws CommonException, JsonParseException, JsonMappingException, IOException {
			datamanipulation = new DataManipulationBean();
			try {
				List<RegisterDataBean> fetchSupplierData = userService.fetchSupplierData();
				
					for(RegisterDataBean supplierData: fetchSupplierData){
						String login = supplierData.getLoginId();
						String pass = supplierData.getPassword();
						String hashPassword = passwordHasher.signup(login, pass);
						userService.updatesupplierpass(login, hashPassword);
						}
					//datamanipulation.setMessage(messageSource.getMessage("valid.save", null, locale));

			
			} catch (Exception io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}

			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
		}
		
		/* Reset password */
		
		@RequestMapping(value = "/resetPassword", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE })
		public ResponseEntity<DataManipulationBean> resetPassword(@RequestBody final String json,HttpServletRequest request)
			throws CommonException, JsonParseException, JsonMappingException, IOException {
			datamanipulation = new DataManipulationBean();
			try {
				mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				String roleBean = mapper.readValue(json, ResetPasswordBean.class).getRole();
				String tokn = mapper.readValue(json, ResetPasswordBean.class).getToken();
				resetPwd = mapper.readValue(json, ResetPasswordBean.class);
				boolean resetPasswordData = userService.resetPassword(resetPwd, roleBean);
				//System.out.println(" ============= Token for Delete : "+tkn);
				String rtnckhExistToken = userService.returnToken(request.getParameter("token")); 
				System.out.println("==================returnToken==============="+rtnckhExistToken);
				if(resetPasswordData){
					userService.clearToken(tokn);
				}
				//datamanipulation.setMessage(messageSource.getMessage("valid.update", null, locale));
//				datamanipulation.setId(resetPasswordData);
			} catch (JsonParseException jpe) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (JsonMappingException jme) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (IOException io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}
	
			return new ResponseEntity<DataManipulationBean>(datamanipulation, HttpStatus.OK);
		}
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		@RequestMapping(value = "/resetSupplierPassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity userResetPassword(@RequestBody final String json)
				throws CommonException, JsonParseException, JsonMappingException, IOException {
			datamanipulation = new DataManipulationBean();
			try {
				mapper = new ObjectMapper();
				UserResetPassword userResetPassword = mapper.readValue(json, UserResetPassword.class);
				int userId = userService.resetUserPassword(userResetPassword);
				//System.out.println("=============userId============="+userId);
				if (userId == 1) {
					datamanipulation.setMessage(messageSource.getMessage("valid.resetpwd", null, locale));
					datamanipulation.setId(userId);
				} else if (userId == 2) {
					throw new CommonException(messageSource.getMessage("invalid.password", null, locale));
				} else {
					datamanipulation.setMessage(messageSource.getMessage("valid.error", null, locale));
					datamanipulation.setId(0);
				}
				return new ResponseEntity(datamanipulation, HttpStatus.OK);
			} catch (JsonProcessingException jpe) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (IOException io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}
		}
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		@RequestMapping(value = "/resetAdminPassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity resetAdminPassword(@RequestBody final String json)
				throws CommonException, JsonParseException, JsonMappingException, IOException {
			datamanipulation = new DataManipulationBean();
			try {
				mapper = new ObjectMapper();
				UserResetPassword adminResetPassword = mapper.readValue(json, UserResetPassword.class);
				int userId = userService.resetAdminPassword(adminResetPassword);
				//System.out.println("=============userId============="+userId);
				if (userId == 1) {
					datamanipulation.setMessage(messageSource.getMessage("valid.resetpwd", null, locale));
					datamanipulation.setId(userId);
				} else if (userId == 2) {
					throw new CommonException(messageSource.getMessage("invalid.password", null, locale));
				} else {
					datamanipulation.setMessage(messageSource.getMessage("valid.error", null, locale));
					datamanipulation.setId(0);
				}
				return new ResponseEntity(datamanipulation, HttpStatus.OK);
			} catch (JsonProcessingException jpe) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			} catch (IOException io) {
				throw new CommonException(messageSource.getMessage("valid.jsonformat", null, locale));
			}
		}
		
		@RequestMapping(value = "/openRegistration", method = RequestMethod.GET)
		public String mr_addLead() {
			return "register";
		}
		
		@RequestMapping(value = "/adminHome", method = RequestMethod.GET)
		public String openAdminViewSupplier() {
			return "admin_home";
		}
		
		@RequestMapping(value = "/supplierHome", method = RequestMethod.GET)
		public String openSupplierHome() {
			return "supplier_home";
		}
		
		@RequestMapping(value = "/manageOrders", method = RequestMethod.GET)
		public String manageOrders() {
			return "manage_orders";
		}
		
		@RequestMapping(value = "/productRegistration", method = RequestMethod.GET)
		public String openProductRegistration() {
			return "product_reg";
		}
		
		@RequestMapping(value = "/itemRegistration", method = RequestMethod.GET)
		public String itemRegistration() {
			return "item_reg";
		}
		
		@RequestMapping(value = "/editProduct", method = RequestMethod.GET)
		public String editProduct() {
			return "edit_product";
		}
		
		@RequestMapping(value = "/editItem", method = RequestMethod.GET)
		public String editItem() {
			return "edit_item";
		}
		
		@RequestMapping(value = "/services", method = RequestMethod.GET)
		public String services() {
			return "services";
		}
		
		@RequestMapping(value = "/createService", method = RequestMethod.GET)
		public String createService() {
			return "create_service";
		}
		
		@RequestMapping(value = "/viewSupplierProducts", method = RequestMethod.GET)
		public String viewSupplierProducts() {
			return "view_supplier_products";
		}
		
		@RequestMapping(value = "/openLogin", method = RequestMethod.GET)
		public String openLogin() {
			return "login";
		}
		
		@RequestMapping(value = "/approveProducts", method = RequestMethod.GET)
		public String approveProducts() {
			return "approve_products";
		}
		
		@RequestMapping(value = "/reset_password_supplier", method = RequestMethod.GET)
		public String reset_password_supplier() {
			return "reset_password_supplier";
		}
		
		@RequestMapping(value = "/reset_password_admin", method = RequestMethod.GET)
		public String reset_password_admin() {
			return "reset_password_admin";
		}
		
		@RequestMapping(value = "/resetPassword", method = RequestMethod.GET)
		public String openResetPassword(HttpServletRequest request){ 

			boolean ckhExistToken = userService.checkForExistToken(request.getParameter("emailLoginToken")); 
			System.out.println(" ckhExistToken ==== "+ckhExistToken);
			if(ckhExistToken)return "resetPassword";
			else return "resetPasswordExpired";
			
			
		}
}
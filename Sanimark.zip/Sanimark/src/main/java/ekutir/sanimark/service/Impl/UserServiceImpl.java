package ekutir.sanimark.service.Impl;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ekutir.sanimark.android.dto.AddressBean;
import ekutir.sanimark.android.dto.AdminUserBean;
import ekutir.sanimark.android.dto.ForgetPasswordBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ResetPasswordBean;
import ekutir.sanimark.android.dto.UserViewBean;
import ekutir.sanimark.dao.UserDao;
import ekutir.sanimark.service.UserService;
import ekutir.sanimark.utilities.MailForgetPassword;
import ekutir.sanimark.utilities.MailProductAddedMsgtoAdmin;
import ekutir.sanimark.utilities.MailRegisterMsgtoAdmin;
import ekutir.sanimark.utilities.SessionIdentifierGenerator;
import ekutir.sanimark.view.beans.UserResetPassword;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	@Autowired
	private HttpServletResponse response;
	@Autowired
	HttpSession httpSession;
	private String loginUserId = null;
	private List<Object[]> rows = null;

	public boolean isValidUser(UserViewBean userviewBean) {
		/*if(userviewBean.getRemPwd().equals("1"))
		{
			Cookie cUserName = new Cookie("cookuser", userviewBean.getLoginId().trim());
			Cookie cPassword = new Cookie("cookpass", userviewBean.getPassword().trim());
			Cookie cRemember = new Cookie("cookrem", userviewBean.getRemPwd().trim());
			cUserName.setMaxAge(60 * 60 * 24 * 15);//15 days
			cPassword.setMaxAge(60 * 60 * 24 * 15);
			cRemember.setMaxAge(60 * 60 * 24 * 15);
			response.addCookie(cUserName);
			response.addCookie(cPassword);
			response.addCookie(cRemember);
		}*/
		userDao.findByNameAndPassword(userviewBean);
		if(userDao.findByNameAndPassword(userviewBean) !=null)
		{
			return true;	
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean forgetPassword(String roleBean, String email) {
		boolean sucess = false;
		Thread[] thread = new Thread[2];
		if(userDao.forgetPassword(roleBean,email) !=null)
		{
			SessionIdentifierGenerator token = new SessionIdentifierGenerator();
			String nextToken = token.nextSessionId();
			System.out.println("=========token========="+nextToken);
			
			boolean tokenInsert= userDao.insertToken(nextToken);
			String getToken = userDao.fetchToken(nextToken);
			
			System.out.println("======getToken======="+getToken);
			if(tokenInsert){
			System.out.println("======22===tokenInsert======="+tokenInsert);
			rows=userDao.forgetPassword(roleBean,email);
			}
			for (Object[] row : rows) {
				
				
				MailForgetPassword mail = new MailForgetPassword();
				mail.setParameters(email,row[1].toString(), row[2].toString(), getToken,roleBean);
				thread[1] = new Thread(mail);
				thread[1].start();
				sucess = true;
			}
		}
		return sucess;
	}

	@Override
	public int registration(RegisterDataBean registerBean) {
		boolean duplicateCheck= userDao.duplicateRegistration(registerBean);
		System.out.println("==========duplicateCheck============="+duplicateCheck);
		int sucess=0;
		if(duplicateCheck == false)
		{
			 sucess=userDao.registration(registerBean);
		}
		return sucess;
	}

	@Override
	public List<String> fetchAdminDetails() {
		return userDao.fetchAdminDetails();
	}

	@Override
	public boolean sendRegisterMailtoAdmin(String fetchAdminDetails) {
		Thread thread = new Thread();
		MailRegisterMsgtoAdmin maillist = new MailRegisterMsgtoAdmin();
		maillist.setParameters(fetchAdminDetails);
		thread = new Thread(maillist);
		thread.start();
		System.out.println("in service Impl");
		return true;
	}

	@Override
	public int adminUser(AdminUserBean adminBean) {
		return userDao.adminBean(adminBean);
	}

	@Override
	public int changeadminpass(AdminUserBean changeadminpass) {
		return userDao.changeadminpass(changeadminpass);
	}

	@Override
	public List<AdminUserBean> fetchAdminData() {
		return userDao.fetchAdminData();
	}

	@Override
	public void updatedminpass(String loginId,String hashPassword) {
		userDao.updatedminpass(loginId,hashPassword);
		
	}

	@Override
	public List<RegisterDataBean> fetchSupplierData() {
		return userDao.fetchSupplierData();
	}

	@Override
	public void updatesupplierpass(String login, String hashPassword) {
		userDao.updatesupplierpass(login,hashPassword);
		
	}

	@Override
	public boolean resetPassword(ResetPasswordBean resetPwd, String roleBean) {
		return userDao.resetPassword(resetPwd, roleBean);
	}

	@Override
	public boolean checkForExistToken(String chkToken) {
		return userDao.checkForExistToken(chkToken);
		
	}

	@Override
	public void clearToken(String clrtoken) {
		userDao.clearToken(clrtoken);
	}

	@Override
	public String returnToken(String rtnToken) {
		return userDao.returnToken(rtnToken);
	}

	@Override
	public int resetUserPassword(UserResetPassword userResetPassword) {
		if (httpSession.getAttribute("userName") == null) {
			//loginUserId = 1;
		} else {
			loginUserId = (String) httpSession.getAttribute("userName");
		}
		return userDao.resetUserPassword(userResetPassword, loginUserId);
	}

	@Override
	public int resetAdminPassword(UserResetPassword adminResetPassword) {
		if (httpSession.getAttribute("userName") == null) {
			//loginUserId = 1;
		} else {
			loginUserId = (String) httpSession.getAttribute("userName");
		}
		return userDao.resetAdminPassword(adminResetPassword, loginUserId);
	}

	@Override
	public boolean duplicateRegistration(RegisterDataBean registerBean) {
		return userDao.duplicateRegistration(registerBean);
	}
}

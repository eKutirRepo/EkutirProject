package ekutir.sanimark.service.Impl;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ekutir.sanimark.android.dto.EditProductDataBean;
import ekutir.sanimark.android.dto.FetchBusinessCategoryBean;
import ekutir.sanimark.android.dto.FetchPCategoryBean;
import ekutir.sanimark.android.dto.FetchProductsBean;
import ekutir.sanimark.android.dto.FetchServiceForApprovalBean;
import ekutir.sanimark.android.dto.FetchServicesDataBean;
import ekutir.sanimark.android.dto.FetchSupplierOrderDataBean;
import ekutir.sanimark.android.dto.ProductDataBean;
import ekutir.sanimark.android.dto.RegisterDataBean;
import ekutir.sanimark.android.dto.ServicesDataBean;
import ekutir.sanimark.android.dto.ServicesEditDataBean;
import ekutir.sanimark.dao.SanimarkDao;
import ekutir.sanimark.dto.FetchProductServiceCategoryDto;
import ekutir.sanimark.service.SanimarkService;
import ekutir.sanimark.utilities.MailProductAddedMsg;
import ekutir.sanimark.utilities.MailProductAddedMsgtoAdmin;
import ekutir.sanimark.utilities.MailProductApproveMsgByAdmin;
import ekutir.sanimark.utilities.MailServiceAddedMsg;
import ekutir.sanimark.utilities.MailServiceAddedMsgtoAdmin;
import ekutir.sanimark.utilities.MailServiceApproveMsgByAdmin;
import ekutir.sanimark.utilities.MailSupplerApprovedMsgByAdmin;
import ekutir.sanimark.utilities.MailSupplerRejectMsgByAdmin;
import ekutir.sanimark.view.beans.CreateProductBean;
import ekutir.sanimark.view.beans.EditItemBean;
import ekutir.sanimark.view.beans.FetchItemsApprovalBean;
import ekutir.sanimark.view.beans.FetchItemsForProductBean;
import ekutir.sanimark.view.beans.FetchProductsForSani;
import ekutir.sanimark.view.beans.FetchServiceCategoryBean;
import ekutir.sanimark.view.beans.FetchSupplierItemsBean;
import ekutir.sanimark.view.beans.FetchSupplierServicesBean;
import ekutir.sanimark.view.beans.ItemBean;
import ekutir.sanimark.view.beans.ItemIdDetailsBean;
import ekutir.sanimark.view.beans.MicroEntrepreneurMsgBean;
import ekutir.sanimark.view.beans.ServiceCategoryBean;

@Service("SanimarkService")
@Transactional
public class SanimarkServiceImpl implements SanimarkService{
	
	@Autowired
	private SanimarkDao dao;
	
	@Autowired
	private HttpServletResponse response;

	@Override
	public List<RegisterDataBean> fetchSuppliersDetails() {
		return dao.fetchSuppliersDetails();
	}

	@Override
	public int rejectSupplier(int supplierId) {
		return dao.rejectSupplier(supplierId);
	}

	@Override
	public int approveSupplier(int supplierId) {
		return dao.approveSupplier(supplierId);
	}

	@Override
	public List<FetchBusinessCategoryBean> fetchBusinessCategory() {
		return dao.fetchBusinessCategory();
	}

	@Override
	public List<FetchProductsBean> fetchProductsDetails() {
		return dao.fetchProductsDetails();
	}

	@Override
	public int addProduct(ProductDataBean productBean) {
		return dao.addProduct(productBean);
	}

	@Override
	public List<FetchSupplierOrderDataBean> fetchSuppliersOrderDetails() {
		return dao.fetchSuppliersOrderDetails();
	}

	@Override
	public int acknowledgeOrder(int orderId, int productId) {
		return dao.acknowledgeOrder(orderId,productId);
	}

	@Override
	public List<FetchProductServiceCategoryDto> fetchProductCategory() {
		return dao.fetchProductCategory();
	}

	@Override
	public List<FetchProductServiceCategoryDto> fetchServiceCategory() {
		return dao.fetchServiceCategory();
	}

	@Override
	public int deleteProduct(int productId) {
		return dao.deleteProduct(productId);
	}

	@Override
	public int editProducts(EditProductDataBean editProducts) {
		return dao.editProducts(editProducts);
	}

	@Override
	public int createServices(ServicesDataBean createServicesData) {
		return dao.createServices(createServicesData);
	}

	@Override
	public int approveProduct(int productId) {
		return dao.approveProduct(productId);
	}

	@Override
	public List<FetchServicesDataBean> fetchServicesDetails() {
		return dao.fetchServicesDetails();
	}

	/*@Override
	public List<FetchProductsBean> fetchProducts() {
		return dao.fetchProducts();
	}*/

	@Override
	public List<FetchServiceForApprovalBean> fetchServicesApprovalDetails() {
		return dao.fetchServicesApprovalDetails();
	}

	@Override
	public int approveService(int serviceId) {
		return dao.approveService(serviceId);
	}

	@Override
	public boolean sendProductAddedMail(String email) {
		Thread[] thread = new Thread[2];
		MailProductAddedMsg mail = new MailProductAddedMsg();
		mail.setParameters(email);
		thread[1] = new Thread(mail);
		thread[1].start();
		System.out.println("in service Impl");
		return true;
	}

	@Override
	public int deleteService(int serviceId) {
		return dao.deleteService(serviceId);
	}

	@Override
	public int editService(ServicesEditDataBean editService) {
		return dao.editService(editService);
	}

	@Override
	public int rejectProduct(int productId) {
		return dao.rejectProduct(productId);
	}

	@Override
	public int rejectService(int serviceId) {
		return dao.rejectService(serviceId);
	}
	
	@Override
	public List<String> fetchAdminDetails() {
		return dao.fetchAdminDetails();
	}
	
	@Override
	public boolean sendProductAddedMailtoAdmin(String fetchAdminDetails)  {
		Thread thread = new Thread();
		MailProductAddedMsgtoAdmin maillist = new MailProductAddedMsgtoAdmin();
		maillist.setParameters(fetchAdminDetails);
		thread = new Thread(maillist);
		thread.start();
		System.out.println("in service Impl");
		return true;
	}

	@Override
	public boolean sendProductApproveddMail(String fetchApprovalLogin) {
		Thread thread = new Thread();
		MailProductApproveMsgByAdmin maillist = new MailProductApproveMsgByAdmin();
		maillist.setParameters(fetchApprovalLogin);
		thread = new Thread(maillist);
		thread.start();
		System.out.println("in service Impl");
		return true;
	}

	@Override
	public List<String> fetchApprovalLogin(int itemId) {
		return dao.fetchApprovalLogin(itemId);
	}

	@Override
	public List<String> fetchSupplierApproval(int supplierId) {
		return dao.fetchSupplierApproval(supplierId);
	}

	@Override
	public boolean sendSupplierApproveddMail(String approveSupplierMail) {
		Thread thread = new Thread();
		MailSupplerApprovedMsgByAdmin maillist = new MailSupplerApprovedMsgByAdmin();
		maillist.setParameters(approveSupplierMail);
		thread = new Thread(maillist);
		thread.start();
		System.out.println("in service Impl");
		return true;
	}

	@Override
	public boolean sendSupplierRejectdMail(String rejectSupplierMail) {
		Thread thread = new Thread();
		MailSupplerRejectMsgByAdmin maillist = new MailSupplerRejectMsgByAdmin();
		maillist.setParameters(rejectSupplierMail);
		thread = new Thread(maillist);
		thread.start();
		System.out.println("in service Impl");
		return true;
	}

	@Override
	public List<ProductDataBean> fetchSupplierProducts(int suplierid) {
		// TODO Auto-generated method stub
		return dao.fetchSupplierProducts(suplierid);
	}

	@Override
	public List<FetchPCategoryBean> fetchProdCategory() {
		return dao.fetchProdCategory();
	}

	@Override
	public int closeOrder(int orderId, int productId) {
		// TODO Auto-generated method stub
		return dao.closeOrder(orderId,productId);
	}

	@Override
	public List<FetchProductsForSani> fetchSaniProducts() {
		return dao.fetchSaniProducts();
	}

	@Override
	public List<FetchItemsForProductBean> fetchSaniProductItems(int productId) {
		return dao.fetchSaniProductItems(productId);
	}

	@Override
	public List<FetchItemsForProductBean> fetchAllItems() {
		return dao.fetchAllItems();
	}

	@Override
	public int createItem(ItemBean createItemData) {
		return dao.createItem(createItemData);
	}

	@Override
	public int createProduct(CreateProductBean createProduct, List<ItemIdDetailsBean> itemLists) {
		return dao.createProduct(createProduct, itemLists);
	}

	@Override
	public int approveItems(int itemId) {
		return dao.approveItems(itemId);
	}

	@Override
	public boolean sendServiceAddedMail(String email) {
		Thread[] thread = new Thread[2];
		MailServiceAddedMsg mail = new MailServiceAddedMsg();
		mail.setParameters(email);
		thread[1] = new Thread(mail);
		thread[1].start();
		System.out.println("in service Impl");
		return true;
	}
	
	@Override
	public boolean sendServiceAddedMailtoAdmin(String fetchAdminDetails) {
		Thread thread = new Thread();
		MailServiceAddedMsgtoAdmin maillist = new MailServiceAddedMsgtoAdmin();
		maillist.setParameters(fetchAdminDetails);
		thread = new Thread(maillist);
		thread.start();
		System.out.println("in service Impl");
		return true;
	}
	
	@Override
	public List<String> fetchServicesApprovalLogin(int serviceId) {
		return dao.fetchServicesApprovalLogin(serviceId);
	}
	
	@Override
	public boolean sendServiceApproveddMail(String fetchApprovalLogin) {
		Thread thread = new Thread();
		MailServiceApproveMsgByAdmin maillist = new MailServiceApproveMsgByAdmin();
		maillist.setParameters(fetchApprovalLogin);
		thread = new Thread(maillist);
		thread.start();
		System.out.println("in service Impl");
		return true;
	}

	@Override
	public int editItem(EditItemBean editItem) {
		return dao.editItem(editItem);
	}

	@Override
	public List<FetchItemsApprovalBean> fetchItemsforApproval() {
		return dao.fetchItemsforApproval();
	}

	@Override
	public List<FetchSupplierItemsBean> fetchSupplierItems(int supplierId) {
		return dao.fetchSupplierItems(supplierId);
	}

	@Override
	public int deleteItem(int itemId) {
		return dao.deleteItem(itemId);
	}

	@Override
	public List<FetchSupplierServicesBean> fetchSupplierServices(int supplierId) {
		return dao.fetchSupplierServices(supplierId);
	}

	@Override
	public boolean updateAckStatus(int orderId, int productId) {
		return dao.updateAckStatus(orderId, productId);
	}

	@Override
	public boolean fetchBuycode(int orderId, int buyCode) {
		return dao.fetchBuycode(orderId,buyCode);
	}

	@Override
	public int sendMicroEntrepreneurMsg(MicroEntrepreneurMsgBean microEntrepreneurMsgData) {
		return dao.sendMicroEntrepreneurMsg(microEntrepreneurMsgData);
	}

	@Override
	public List<ServiceCategoryBean> fetchServiceCategories() {
		return dao.fetchServiceCategories();
	}

}

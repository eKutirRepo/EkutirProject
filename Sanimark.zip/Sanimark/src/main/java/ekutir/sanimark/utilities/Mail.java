
package ekutir.sanimark.utilities;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class Mail implements Runnable{
	String url="";
	String mailId="";
	String mallerName="";
	public Mail() {
		// TODO Auto-generated constructor stub
	}
	@Override
    public void run() {
        try {
            System.out.println("inside thread");
            this.publishSendingToUser();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	 public void setParameters(String url,String mailId,String mallerName) {
	        this.url=url;
	        this.mailId=mailId;
	        this.mallerName=mallerName;
	       
	    }

	private static String emailServiceProvider = "smtp.office365.com";  
	private static String emailServiceUser = "noreply@goodfoodtracker.com";
	private static String emailServicePassword = "gft2016!";
	private static String emailServicePort = "587";
	public static  String status;
	private static String subject = "View Response Details";
	private static String note = "Note : Please, Do not share this account details outside of the Svdha Survey domain";
	private static String text="";
	public Properties properties = System.getProperties();
	public Session session = Session.getDefaultInstance(properties);
	Transport transport=null;
	public MimeMessage message = new MimeMessage(session);
	
	public String publishSendingToUser() {
		
        text="Hello "+mallerName+",\n\nView Survey Response Details Click below link "+"\n\nURL  : "+url+"\n\n"+note+"\n\nWith Regards\nSvdha Survey Team \n";
		properties.put("mail.smtp.host",emailServiceProvider);
		properties.put("mail.smtp.user",emailServiceUser); 
		properties.put("mail.smtp.password",emailServicePassword);
		properties.put("mail.smtp.port",emailServicePort);
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true"); 
		try{
			message.setFrom(new InternetAddress(emailServiceUser));
			message.addRecipient(Message.RecipientType.TO,new InternetAddress(mailId));
			message.setSubject(subject);
			message.setText(text);
			transport = session.getTransport("smtp");
			transport.connect(emailServiceProvider, emailServiceUser, emailServicePassword);
			transport.sendMessage(message, message.getAllRecipients());
			status="success";

		}
		catch (AddressException ae) {
			status="failure";
			ae.printStackTrace();
		}
		catch (MessagingException me) {
			status="failure";
			me.printStackTrace();
		}
		catch (Exception e) {  
			status="failure";
			e.printStackTrace();
		} finally {
			try {
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return status;
	}

	
}

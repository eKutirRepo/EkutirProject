package ekutir.sanimark.model.erp;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "`dbsvadha.erp`.`tbl_mecustomer_master`")
public class MeCustomerMaster implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column
	private int customerID;
	@Column
	private int prevLeadID;
	@Column
	private String customerFName;
	@Column
	private String mName;
	@Column
	private String customerLName;
	@Column
	private long primaryPhone;
	@Column
	private long secondaryPhone;
	@Column
	private int address;
	@Column
	private int businessCategory;
	@Column
	private String businessName;
	@Column
	private long aadhaarNumber;
	@Column
	private String description;
	@Column
	private int createdBy;
	@Column
	private Date createdDateTime;
	@Column
	private int updatedBy;
	@Column
	private Date updatedDateTime;

	public MeCustomerMaster() {
		super();
	}

	public MeCustomerMaster(int customerID, int prevLeadID, String customerFName, String mName, String customerLName,
			long primaryPhone, long secondaryPhone, int address, int businessCategory, String businessName,
			long aadhaarNumber, String description, int createdBy, Date createdDateTime, int updatedBy,
			Date updatedDateTime) {
		super();
		this.customerID = customerID;
		this.prevLeadID = prevLeadID;
		this.customerFName = customerFName;
		this.mName = mName;
		this.customerLName = customerLName;
		this.primaryPhone = primaryPhone;
		this.secondaryPhone = secondaryPhone;
		this.address = address;
		this.businessCategory = businessCategory;
		this.businessName = businessName;
		this.aadhaarNumber = aadhaarNumber;
		this.description = description;
		this.createdBy = createdBy;
		this.createdDateTime = createdDateTime;
		this.updatedBy = updatedBy;
		this.updatedDateTime = updatedDateTime;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public int getPrevLeadID() {
		return prevLeadID;
	}

	public void setPrevLeadID(int prevLeadID) {
		this.prevLeadID = prevLeadID;
	}

	public String getCustomerFName() {
		return customerFName;
	}

	public void setCustomerFName(String customerFName) {
		this.customerFName = customerFName;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getCustomerLName() {
		return customerLName;
	}

	public void setCustomerLName(String customerLName) {
		this.customerLName = customerLName;
	}

	public long getPrimaryPhone() {
		return primaryPhone;
	}

	public void setPrimaryPhone(long primaryPhone) {
		this.primaryPhone = primaryPhone;
	}

	public long getSecondaryPhone() {
		return secondaryPhone;
	}

	public void setSecondaryPhone(long secondaryPhone) {
		this.secondaryPhone = secondaryPhone;
	}

	public int getAddress() {
		return address;
	}

	public void setAddress(int address) {
		this.address = address;
	}

	public int getBusinessCategory() {
		return businessCategory;
	}

	public void setBusinessCategory(int businessCategory) {
		this.businessCategory = businessCategory;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public long getAadhaarNumber() {
		return aadhaarNumber;
	}

	public void setAadhaarNumber(long aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	@Override
	public String toString() {
		return "MeCustomerMaster [customerID=" + customerID + ", prevLeadID=" + prevLeadID + ", customerFName="
				+ customerFName + ", mName=" + mName + ", customerLName=" + customerLName + ", primaryPhone="
				+ primaryPhone + ", secondaryPhone=" + secondaryPhone + ", address=" + address + ", businessCategory="
				+ businessCategory + ", businessName=" + businessName + ", aadhaarNumber=" + aadhaarNumber
				+ ", description=" + description + ", createdBy=" + createdBy + ", createdDateTime=" + createdDateTime
				+ ", updatedBy=" + updatedBy + ", updatedDateTime=" + updatedDateTime + "]";
	}

}

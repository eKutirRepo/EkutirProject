package ekutir.sanimark.model.erp;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "`dbsvadha.erp`.`tbl_communication_disposition`")
public class CommunicationDisposition implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column
	private int CommID;
	@Column
	private String CommMode;
	@Column
	private String CommDisposition;
	@Column
	private int LeadID;
	@Column
	private int CustomerID;
	@Column
	private int UserID;
	@Column
	private int CommCost;
	@Column
	private String FollowUpFor;
	@Column
	private String Disposition;
	@Column
	private int RefOrderID;
	@Column
	private int SupplierID;
	@Column
	private String CommunicationDetails;
	@Column
	private Date CommunicationDate;

	public CommunicationDisposition(int commID, String commMode, String commDisposition, int leadID, int customerID,
			int userID, int commCost, String followUpFor, String disposition, int refOrderID, int supplierID,
			String communicationDetails, Date communicationDate) {
		super();
		CommID = commID;
		CommMode = commMode;
		CommDisposition = commDisposition;
		LeadID = leadID;
		CustomerID = customerID;
		UserID = userID;
		CommCost = commCost;
		FollowUpFor = followUpFor;
		Disposition = disposition;
		RefOrderID = refOrderID;
		SupplierID = supplierID;
		CommunicationDetails = communicationDetails;
		CommunicationDate = communicationDate;
	}

	public int getCommID() {
		return CommID;
	}

	public void setCommID(int commID) {
		CommID = commID;
	}

	public String getCommMode() {
		return CommMode;
	}

	public void setCommMode(String commMode) {
		CommMode = commMode;
	}

	public String getCommDisposition() {
		return CommDisposition;
	}

	public void setCommDisposition(String commDisposition) {
		CommDisposition = commDisposition;
	}

	public int getLeadID() {
		return LeadID;
	}

	public void setLeadID(int leadID) {
		LeadID = leadID;
	}

	public int getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(int customerID) {
		CustomerID = customerID;
	}

	public int getUserID() {
		return UserID;
	}

	public void setUserID(int userID) {
		UserID = userID;
	}

	public int getSupplierID() {
		return SupplierID;
	}

	public void setSupplierID(int supplierID) {
		SupplierID = supplierID;
	}

	public String getCommunicationDetails() {
		return CommunicationDetails;
	}

	public void setCommunicationDetails(String communicationDetails) {
		CommunicationDetails = communicationDetails;
	}

	public Date getCommunicationDate() {
		return CommunicationDate;
	}

	public void setCommunicationDate(Date communicationDate) {
		CommunicationDate = communicationDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getCommCost() {
		return CommCost;
	}

	public void setCommCost(int commCost) {
		CommCost = commCost;
	}

	public String getFollowUpFor() {
		return FollowUpFor;
	}

	public void setFollowUpFor(String followUpFor) {
		FollowUpFor = followUpFor;
	}

	public String getDisposition() {
		return Disposition;
	}

	public void setDisposition(String disposition) {
		Disposition = disposition;
	}

	public int getRefOrderID() {
		return RefOrderID;
	}

	public void setRefOrderID(int refOrderID) {
		RefOrderID = refOrderID;
	}

	@Override
	public String toString() {
		return "CommunicationDisposition [CommID=" + CommID + ", CommMode=" + CommMode + ", CommDisposition="
				+ CommDisposition + ", LeadID=" + LeadID + ", CustomerID=" + CustomerID + ", UserID=" + UserID
				+ ", CommCost=" + CommCost + ", FollowUpFor=" + FollowUpFor + ", Disposition=" + Disposition
				+ ", RefOrderID=" + RefOrderID + ", SupplierID=" + SupplierID + ", CommunicationDetails="
				+ CommunicationDetails + ", CommunicationDate=" + CommunicationDate + "]";
	}

}

package ekutir.sanimark.model.erp;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "`dbsvadha.survey`.tbl_survey_users")
public class SurveyUsers implements Serializable {

	private static final long serialVersionUID = -7988799579036225137L;
	@Id
	@Column
	private int userId;
	@Column
	private String userName;
	@Column
	private int roleId;
	@Column
	private int departmentId;
	@Column
	private String userEmail;
	@Column
	private String hashPassword;
	@Column
	private String password;
	@Column
	private BigInteger userPhone;
	@Column
	private int createdBy;
	@Column
	private Date createdDateTime;

	public SurveyUsers() {

	}

	public SurveyUsers(int userId, String userName, int roleId, int departmentId, String userEmail, String hashPassword,
			String password, BigInteger userPhone, int createdBy, Date createdDateTime) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.roleId = roleId;
		this.departmentId = departmentId;
		this.userEmail = userEmail;
		this.hashPassword = hashPassword;
		this.password = password;
		this.userPhone = userPhone;
		this.createdBy = createdBy;
		this.createdDateTime = createdDateTime;

	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getHashPassword() {
		return hashPassword;
	}

	public void setHashPassword(String hashPassword) {
		this.hashPassword = hashPassword;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public BigInteger getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(BigInteger userPhone) {
		this.userPhone = userPhone;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", roleId=" + roleId + ", departmentId="
				+ departmentId + ", userEmail=" + userEmail + ", hashPassword=" + hashPassword + ", password="
				+ password + ", userPhone=" + userPhone + ", createdBy=" + createdBy + ", createdDateTime="
				+ createdDateTime + "]";
	}

}

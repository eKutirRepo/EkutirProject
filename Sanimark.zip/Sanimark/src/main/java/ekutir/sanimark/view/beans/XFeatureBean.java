package ekutir.sanimark.view.beans;

public class XFeatureBean {
	
	private int featureId;
	private int productId;
	
	public XFeatureBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public XFeatureBean(int featureId, int productId) {
		super();
		this.featureId = featureId;
		this.productId = productId;
	}

	public int getFeatureId() {
		return featureId;
	}

	public void setFeatureId(int featureId) {
		this.featureId = featureId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}
	
}

package ekutir.sanimark.view.beans;

import java.util.Date;

public class ItemBean {
	
	private String itemName;
	private String brandName;
	private int categoryId;
	private double mrp;
	private double sellingPrice;
	private String itemDescription;
	private byte[] productImg;
	private String warranty;
	private String dimension;
	private Date manufactureDate;
	private Date expiryDate;
	private String color;
	
	public ItemBean() {
		super();
	}

	public ItemBean(String itemName, String brandName, int categoryId, double mrp, double sellingPrice,
			String itemDescription, byte[] productImg, String warranty, String dimension, Date manufactureDate,
			Date expiryDate, String color) {
		super();
		this.itemName = itemName;
		this.brandName = brandName;
		this.categoryId = categoryId;
		this.mrp = mrp;
		this.sellingPrice = sellingPrice;
		this.itemDescription = itemDescription;
		this.productImg = productImg;
		this.warranty = warranty;
		this.dimension = dimension;
		this.manufactureDate = manufactureDate;
		this.expiryDate = expiryDate;
		this.color = color;
	}

	
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public double getMrp() {
		return mrp;
	}

	public void setMrp(double mrp) {
		this.mrp = mrp;
	}

	public double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public byte[] getProductImg() {
		return productImg;
	}

	public void setProductImg(byte[] productImg) {
		this.productImg = productImg;
	}

	public String getWarranty() {
		return warranty;
	}

	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}

	public String getDimension() {
		return dimension;
	}

	public void setDimension(String dimension) {
		this.dimension = dimension;
	}

	public Date getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}

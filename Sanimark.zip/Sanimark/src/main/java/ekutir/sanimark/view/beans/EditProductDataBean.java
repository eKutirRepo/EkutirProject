package ekutir.sanimark.view.beans;

import java.util.List;

public class EditProductDataBean {
	
	private int productId;
	private String productBrandName;
	private String companyName;
	private String prodCategoryId;
	private String productFeatures;
	private String warranty;
	private double mrp;
	private int discountInPercent;
	private double sellingPrice;
	private String dateOfManufacture;
	private String expiryDate;
	private byte[] productImg;
	//private String productImg;
	
	public EditProductDataBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EditProductDataBean(int productId, String productBrandName, String companyName, String prodCategoryId,
			String productFeatures, String warranty, double mrp, int discountInPercent, double sellingPrice,
			String dateOfManufacture, String expiryDate, byte[] productImg) {
		super();
		this.productId = productId;
		this.productBrandName = productBrandName;
		this.companyName = companyName;
		this.prodCategoryId = prodCategoryId;
		this.productFeatures = productFeatures;
		this.warranty = warranty;
		this.mrp = mrp;
		this.discountInPercent = discountInPercent;
		this.sellingPrice = sellingPrice;
		this.dateOfManufacture = dateOfManufacture;
		this.expiryDate = expiryDate;
		this.productImg = productImg;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductBrandName() {
		return productBrandName;
	}

	public void setProductBrandName(String productBrandName) {
		this.productBrandName = productBrandName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getProdCategoryId() {
		return prodCategoryId;
	}

	public void setProdCategoryId(String prodCategoryId) {
		this.prodCategoryId = prodCategoryId;
	}

	public String getProductFeatures() {
		return productFeatures;
	}

	public void setProductFeatures(String productFeatures) {
		this.productFeatures = productFeatures;
	}

	public String getWarranty() {
		return warranty;
	}

	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}

	public double getMrp() {
		return mrp;
	}

	public void setMrp(double mrp) {
		this.mrp = mrp;
	}

	public int getDiscountInPercent() {
		return discountInPercent;
	}

	public void setDiscountInPercent(int discountInPercent) {
		this.discountInPercent = discountInPercent;
	}

	public double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(String dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public byte[] getProductImg() {
		return productImg;
	}

	public void setProductImg(byte[] productImg) {
		this.productImg = productImg;
	}

	
}

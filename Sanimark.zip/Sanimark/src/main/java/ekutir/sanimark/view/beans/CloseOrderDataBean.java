package ekutir.sanimark.view.beans;

public class CloseOrderDataBean {
	
	private int buycodeId;
	private int buycode;
	private int orderId;
	private int itemId;
	private int supplierackStatus;
	
	public CloseOrderDataBean() {
		super();
	}

	public CloseOrderDataBean(int buycodeId, int buycode, int orderId, int itemId, int supplierackStatus) {
		super();
		this.buycodeId = buycodeId;
		this.buycode = buycode;
		this.orderId = orderId;
		this.itemId = itemId;
		this.supplierackStatus = supplierackStatus;
	}

	public int getBuycodeId() {
		return buycodeId;
	}

	public void setBuycodeId(int buycodeId) {
		this.buycodeId = buycodeId;
	}

	public int getBuycode() {
		return buycode;
	}

	public void setBuycode(int buycode) {
		this.buycode = buycode;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getSupplierackStatus() {
		return supplierackStatus;
	}

	public void setSupplierackStatus(int supplierackStatus) {
		this.supplierackStatus = supplierackStatus;
	}
	
}

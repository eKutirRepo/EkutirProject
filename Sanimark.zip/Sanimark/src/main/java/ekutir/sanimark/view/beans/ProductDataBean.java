package ekutir.sanimark.view.beans;

import java.util.List;

public class ProductDataBean {
	
	private int productId;
	private String productBrandName;
	private String companyName;
	private int prodCategoryId;
	private String warranty;
	private String dateOfManufacture;
	private String expiryDate;
	private String whenToUse;
	private String howToUse;
	private String productFeatures;
	private byte[] productImg;
	//private String productImg;
	private double mrp;
	private int discountInPercent;
	private double sellingPrice;
	/*private String seedType;
	private String crop;
	private String season;
	private String sowingMonthFrom;
	private String sowingMonthTo;
	private String productivity;
	private String preferredDuration;
	private String diseasesResistance;
	private String pestResistance;
	private String seedRequirement;
	private String landUnit;
	private String germination;
	private String howToApply;
	private String genericFertilizer;
	private String nitrogen;
	private String phosphorus;
	private String potassium;
	private String sulfur;
	private String pestandDiseases;
	private String chemicalName;
	private String dose;*/
	public ProductDataBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductDataBean(int productId, String productBrandName, String companyName, int prodCategoryId,
			String warranty, String dateOfManufacture, String expiryDate, String whenToUse, String howToUse,
			String productFeatures, byte[] productImg, double mrp, int discountInPercent, double sellingPrice) {
		super();
		this.productId = productId;
		this.productBrandName = productBrandName;
		this.companyName = companyName;
		this.prodCategoryId = prodCategoryId;
		this.warranty = warranty;
		this.dateOfManufacture = dateOfManufacture;
		this.expiryDate = expiryDate;
		this.whenToUse = whenToUse;
		this.howToUse = howToUse;
		this.productFeatures = productFeatures;
		this.productImg = productImg;
		this.mrp = mrp;
		this.discountInPercent = discountInPercent;
		this.sellingPrice = sellingPrice;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductBrandName() {
		return productBrandName;
	}
	public void setProductBrandName(String productBrandName) {
		this.productBrandName = productBrandName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public int getProdCategoryId() {
		return prodCategoryId;
	}
	public void setProdCategoryId(int prodCategoryId) {
		this.prodCategoryId = prodCategoryId;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	public String getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(String dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getWhenToUse() {
		return whenToUse;
	}
	public void setWhenToUse(String whenToUse) {
		this.whenToUse = whenToUse;
	}
	public String getHowToUse() {
		return howToUse;
	}
	public void setHowToUse(String howToUse) {
		this.howToUse = howToUse;
	}
	public String getProductFeatures() {
		return productFeatures;
	}
	public void setProductFeatures(String productFeatures) {
		this.productFeatures = productFeatures;
	}
	
	public double getMrp() {
		return mrp;
	}
	public void setMrp(double mrp) {
		this.mrp = mrp;
	}
	public int getDiscountInPercent() {
		return discountInPercent;
	}
	public void setDiscountInPercent(int discountInPercent) {
		this.discountInPercent = discountInPercent;
	}
	public double getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public byte[] getProductImg() {
		return productImg;
	}
	public void setProductImg(byte[] productImg) {
		this.productImg = productImg;
	}
	
	
	
}

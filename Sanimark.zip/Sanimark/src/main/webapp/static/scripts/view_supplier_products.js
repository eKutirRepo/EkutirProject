var serviceData;
 
$(document).ready(function() {
    if(window.sessionStorage.userName)
        $("#username").text(window.sessionStorage.userName);
    if(window.sessionStorage.currSupplier)
        $("#supplierName").text(window.sessionStorage.currSupplier);
    
    $(".loader").show();
    var supplier = {"supplierId": window.sessionStorage.currSupplierId};
    $.ajax({
                url: "fetchSupplierItems",
				data: JSON.stringify(supplier),
                error: function(e){
					showErrorAlert("Data fetch failed. Please try again.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Data fetch failed. Please try again.");
                   else{
                       $.each(data.productItems, function(index){
                           this.serialNo = index+1;
                       });
                      setTableData(data.productItems);
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
    });
    
    
    
    $("#tabService").click(function(e){
        if(typeof serviceData == 'undefined'){
            $(".loader").show();
            var supplier = {"supplierId": window.sessionStorage.currSupplierId};
            $.ajax({
                url: "fetchSupplierServices",
                data: JSON.stringify(supplier),
                error: function(e){
					showErrorAlert("Services data fetch failed. Please try again.");
                    $(".loader").hide();
                },
                success: function(data){
                    $(".loader").hide();
                   if(data.error)
						showErrorAlert("Services data fetch failed. Please try again.");
                   else{
                       $.each(data.services, function(index){
                           this.serialNo = index+1;
                       });
                       serviceData = data.services;
                       setServiceTableData();
                   }   
                },
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                type: "POST",
                cache: false,
                crossDomain: true
            });
        }
    });
} );

function setServiceTableData(){
    
    if ( ! $.fn.DataTable.isDataTable( '#tblServices' ) ) {
        var table = $('#tblServices').DataTable( {
            data: serviceData,
            columns: [
                { "data": "serialNo" },
                { "data": "serviceBrandName" },
                { "data": "contactDetails" }
            ]
        } );

        $('#tblServices tbody tr').css("cursor", "pointer");
        
        $('#tblServices tbody').on( 'click', 'tr', function () {
            var data = table.row(this).data();
            $("#serviceName").text(data.serviceBrandName);
            $("#servContact").text(data.contactDetails);
            $("#servDesc").text(data.serviceDescription);
            $("#servWhenToUse").text(data.whenToUse);
            $("#servHowToUse").text(data.howToUse);
            $("#consumerBen").text(data.consumerBenifit);
            
            $("#serviceModal").modal();
        });
    }
}

function setTableData(dataSet){
    if ( ! $.fn.DataTable.isDataTable( '#tblServices' ) ) {
        var table = $('#tblProducts').DataTable( {
            data: dataSet,
            columns: [
                { "data": "serialNo" },
                { "data": "itemName" },
                { "data": "itemBrand" },
                { "data": "categoryName" },
                { "data": "mrp" },
                { "data": "sellingPrice" }
            ],
            columnDefs: [ 
                {"className": "dt-center", "targets": -5}
            ]
        } );
    }
    
    $('#tblProducts tbody tr').css("cursor", "pointer");
    
    $('#tblProducts tbody').on( 'click', 'tr', function () {
        var data = table.row(this).data();
        $("#itemName").text(data.itemName);
        $("#brandName").text(data.itemBrand);
        $("#category").text(data.categoryName);
        $("#warranty").text(data.warranty);
        $("#mrp").text(data.mrp);
        $("#sellingPrice").text(data.sellingPrice);
        $("#dimension").text(data.dimension);
        $("#doman").text(data.manufactureDate);
        $("#exp").text(data.expiryDate);
        $("#prodFeatures").text(data.itemDescription);
        $("#prodImg").attr('src', 'data:image/jpeg;base64,'+data.itemImage);
        
        $("#myModal").modal();
    } );
}

function reorderProducts(){
    if($("#tblProducts tbody tr").length > 1){
       $("#tblProducts tbody tr").each(function(index){
            $("td", this).first().text(index+1);
       }); 
    }
}

function reorderServices(){
    if($("#tblServices tbody tr").length > 1){
       $("#tblServices tbody tr").each(function(index){
            $("td", this).first().text(index+1);
       }); 
    }
}

function showSuccessAlert(msg, redirect)
{
        if(msg){
            $('#success-alert').html("<strong>Success:&nbsp;</strong>"+msg)  
        }
        $('#success-alert').css("opacity", 1); 
        $('#success-alert').css("visibility", "visible");
        $('#success-alert').fadeTo(2000, 0, function()
        {
            if(redirect == true)
                window.location.reload();
        });
}
function showErrorAlert(msg)
{
        if(msg){
            $('#error-alert').html("<strong>Error:&nbsp;</strong>"+msg);  
        }
        $('#error-alert').css("opacity", 1); 
        $('#error-alert').css("visibility", "visible");
        $('#error-alert').fadeTo(4000, 0, function()
        {
           	
        }); 
}
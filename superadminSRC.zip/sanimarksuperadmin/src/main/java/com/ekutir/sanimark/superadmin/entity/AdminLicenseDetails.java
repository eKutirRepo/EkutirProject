package com.ekutir.sanimark.superadmin.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class AdminLicenseDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	private long id;
	
	private String licenseType;
	
	private String licenseNo;
	
	private String licenceFor;
	
	private Date licenseDate;
	
	private Double licenceprice;
	
    private String createdBy;
    
    private String updatedBy;
    
    private int accessId;


	
	public AdminLicenseDetails(long id, String licenseType, String licenseNo, String licenceFor, Date licenseDate,
			Double licenceprice, String createdBy, String updatedBy, int accessId) {
		super();
		this.id = id;
		this.licenseType = licenseType;
		this.licenseNo = licenseNo;
		this.licenceFor = licenceFor;
		this.licenseDate = licenseDate;
		this.licenceprice = licenceprice;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.accessId = accessId;
	}
	public Double getLicenceprice() {
		return licenceprice;
	}
	public void setLicenceprice(Double licenceprice) {
		this.licenceprice = licenceprice;
	}





	public int getAccessId() {
		return accessId;
	}





	public void setAccessId(int accessId) {
		this.accessId = accessId;
	}





	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getLicenseType() {
		return licenseType;
	}


	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}


	public String getLicenseNo() {
		return licenseNo;
	}


	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}


	public String getLicenceFor() {
		return licenceFor;
	}


	public void setLicenceFor(String licenceFor) {
		this.licenceFor = licenceFor;
	}


	public Date getLicenseDate() {
		return licenseDate;
	}


	public void setLicenseDate(Date licenseDate) {
		this.licenseDate = licenseDate;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
    
    
    

}

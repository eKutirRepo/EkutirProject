/*
 * Copyright (C) 2013 , Inc. All rights reserved 
 */
package com.ekutir.sanimark.superadmin.service;

import com.ekutir.sanimark.superadmin.util.ResponseUtil;

public interface SuperAdminService {

	public ResponseUtil approveUser(String email);

}

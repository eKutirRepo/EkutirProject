package com.ekutir.sanimark.superadmin.service;

import com.ekutir.sanimark.superadmin.dto.User;
import com.ekutir.sanimark.superadmin.dto.UserProfileDTO;
import com.ekutir.sanimark.superadmin.entity.UserProfile;
import com.ekutir.sanimark.superadmin.exception.LoginException;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

public interface RegistrationService {
	public ResponseUtil registerUser(User user) throws LoginException;
	
	public ResponseUtil registerAdmin(UserProfileDTO userProfileDTO, String loginUser)  throws Exception;
}

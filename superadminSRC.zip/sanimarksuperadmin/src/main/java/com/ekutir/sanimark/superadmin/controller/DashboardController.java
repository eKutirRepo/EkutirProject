package com.ekutir.sanimark.superadmin.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.ekutir.sanimark.superadmin.dto.OrderProduct;
import com.ekutir.sanimark.superadmin.entity.SaniProduct;
import com.ekutir.sanimark.superadmin.entity.SupplierDetails;
import com.ekutir.sanimark.superadmin.service.DashboardService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@RestController
public class DashboardController {
	@Autowired
	private DashboardService dashboardService;
	
	@RequestMapping(value = "/totalnofordashboard", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil registerUser(){
		ResponseUtil response = new ResponseUtil();
		Long totalSupplier=0L;
		Long totalProduct=0L;
		Long totalItem=0L;
		Long totalOrder=0L;
		Double totalTransaction=0.0;
		Map<String, Object> objMap = null;
		List<OrderProduct> productList;
	
		
		try {	
			objMap = new HashMap<String, Object>();
			totalSupplier=dashboardService.getToatlSupplier();
			//totalMicroEntrePrenure=dashboardService.getTotalMictoEnreprenure();
			totalProduct=dashboardService.getTotalProduct();
			totalItem=dashboardService.getTotalTotalItem();
			totalOrder=dashboardService.getTotalOrder();
			totalTransaction=dashboardService.getTotalTransaction();
			
			objMap.put("totalSupplier",totalSupplier);
			objMap.put("totalProduct",totalProduct);
			objMap.put("totaliTEM",totalItem);
			objMap.put("totalOrder",totalOrder);
			objMap.put("totalTransaction",totalTransaction.longValue());
			
			productList=new ArrayList<>();
			
			
			//dashboardCountList.add(totalProduct);
			//dashboardCountList.add(count);
			response.setObject(objMap);
			
		}catch (Exception ex) {
			ex.printStackTrace();
			return response;
		}
		return response;
	}
	

	
	
/*	
	@RequestMapping(value = "/hello", method = RequestMethod.GET, produces = "application/json")
	public String Hello() {
		
		
		return "JHHH";
		
		
	}*/
	
	
	
	
	@RequestMapping(value = "/totalsupplier", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil totalsupplier(){
		
		ResponseUtil responseUtil=new ResponseUtil();
		List<SupplierDetails> supplierDetails=null;
		try {	
			supplierDetails=dashboardService.totalSupplier();
			if(supplierDetails.size()>0){
				responseUtil.setStatus(200);
				responseUtil.setObject(supplierDetails);
			}else{
				responseUtil.setStatus(400);
				responseUtil.setObject(null);
			}

		}catch (Exception ex) {
			ex.printStackTrace();
		
		}
		return responseUtil;
	}
	
	
	
	@RequestMapping(value = "/totalproduct", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil totalproduct(){
		
		ResponseUtil responseUtil=new ResponseUtil();
		List<SaniProduct> totalproductList=null;
		try {	
			totalproductList=dashboardService.totalproduct();
			if(totalproductList.size()>0){
				responseUtil.setStatus(200);
				responseUtil.setObject(totalproductList);
			}else{
				responseUtil.setStatus(400);
				responseUtil.setObject(null);
			}

		}catch (Exception ex) {
			ex.printStackTrace();
		
		}
		return responseUtil;
	}
	
	
	
	
	@RequestMapping(value = "/topproductorder", method = RequestMethod.GET, produces = "application/json")
	public ResponseUtil topproductorder(){
		
		ResponseUtil responseUtil=new ResponseUtil();
		List<Object[]> topfiveproductList=null;
		Map<String, Object> objMap = null;
		List<Object> totaltoporder=new ArrayList<>();
		
		HashMap<String, String> hmap = new HashMap<String, String>();
		 
		try {	
			topfiveproductList=dashboardService.topfiveproduct();
			
			
			for (int i = 0; i < topfiveproductList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("productName", (topfiveproductList.get(i))[0]);
				objMap.put("totalorder", (topfiveproductList.get(i))[1]);
				totaltoporder.add(objMap);
				
			}
			
			
			
			
			responseUtil.setObject(totaltoporder);
			

		}catch (Exception ex) {
			ex.printStackTrace();
		
		}
		return responseUtil;
	}
	

}

package com.ekutir.sanimark.superadmin.serviceImpl;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekutir.sanimark.superadmin.dto.User;
import com.ekutir.sanimark.superadmin.dto.UserProfileDTO;
import com.ekutir.sanimark.superadmin.entity.License;
import com.ekutir.sanimark.superadmin.entity.Role;
import com.ekutir.sanimark.superadmin.entity.UserProfile;
import com.ekutir.sanimark.superadmin.entity.UserRole;
import com.ekutir.sanimark.superadmin.exception.LoginException;
import com.ekutir.sanimark.superadmin.repository.RoleRepo;
import com.ekutir.sanimark.superadmin.repository.UserRepo;
import com.ekutir.sanimark.superadmin.security.Authorities;
import com.ekutir.sanimark.superadmin.service.RegistrationService;
import com.ekutir.sanimark.superadmin.util.QuickPasswordEncodingGenerator;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@Service("registerService")
public class RegistrationServiceImpl implements RegistrationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RegistrationServiceImpl.class);
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private RoleRepo roleRepo;
	
	@Override
	public ResponseUtil registerUser(User user) throws LoginException {
		LOGGER.info("Inside RegistrationServiceImpl .. registerUser");
		ResponseUtil response = new ResponseUtil();
		
		if(StringUtils.isNotEmpty(user.getEmail())){
			com.ekutir.sanimark.superadmin.entity.User dbUser=new com.ekutir.sanimark.superadmin.entity.User();
			BeanUtils.copyProperties(user, dbUser);
			dbUser.setPassword(QuickPasswordEncodingGenerator.encodePassword("ekutir123"));
			dbUser.setStatus(0);
			dbUser.setEnabled(0);
			dbUser = userRepo.save(dbUser);
			if(dbUser.getId()!=null){
				BeanUtils.copyProperties(dbUser, user);
				if(dbUser.getVersion() == 0){
					response.setStatus(200);
					response.setObject(user);
				}
			}
		}
		LOGGER.info("Exit RegistrationServiceImpl .. registerUser");
		return response;
	}

	@Override
	public ResponseUtil registerAdmin(UserProfileDTO userProfileDTO, String loginUser) throws Exception {
		LOGGER.info("Inside RegistrationServiceImpl .. registerAdmin");
		ResponseUtil response = new ResponseUtil();
		if(StringUtils.isNotEmpty(userProfileDTO.getEmail())){
			List<Role> roleList = roleRepo.findAll();
			com.ekutir.sanimark.superadmin.entity.User user = userRepo.findByEmail(userProfileDTO.getEmail());
			if(user!=null){
				UserProfile userProfile = new UserProfile();
				userProfile.setFirstName(userProfileDTO.getFirstName());
				userProfile.setMiddleName(userProfileDTO.getMiddleName());
				userProfile.setLastName(userProfileDTO.getLastName());
				userProfile.setEmail(userProfileDTO.getEmail());
				userProfile.setCountry(userProfileDTO.getCountry());
				userProfile.setState(userProfileDTO.getState());
				userProfile.setCity(userProfileDTO.getCity());
				userProfile.setMobile(userProfileDTO.getMobile());
				userProfile.setOrganisationName(userProfileDTO.getOrganisationName());
				userProfile.setOrgAddress(userProfileDTO.getOrgAddress());
				userProfile.setOrgPhone(userProfileDTO.getOrgPhone());
				userProfile.setPin(userProfile.getPin());
				userProfile.setCreatedBy(userProfileDTO.getEmail());
				userProfile.setProfileStatus(1);
				userProfile.setUser(user);
				user.setUserProfile(userProfile);
				
				License license = new License();
				license.setLicenseNo("LIC-NO:"+RandomStringUtils.randomAlphanumeric(8));
				license.setLicenseType(userProfileDTO.getLicense().getLicenseType());
				license.setLicensePeriod(userProfileDTO.getLicense().getLicensePeriod());
				user.getLicenseList().add(license);
				license.setUser(user);
				user.setPassword(QuickPasswordEncodingGenerator.encodePassword(userProfileDTO.getPassword()));
				user.setStatus(1);
				user = userRepo.save(user);
				if(user.getUserProfile().getId()!=null){
					LOGGER.info("User Profile updated successfully..");
					response.setStatus(200);
				}
			}
			
		}
		LOGGER.info("Exit RegistrationServiceImpl .. registerAdmin");
		return response;
	}

	@Override
	public List<com.ekutir.sanimark.superadmin.entity.User> pendingApprovalList() {
		List<com.ekutir.sanimark.superadmin.entity.User> pendingApprovalList=null;
		try{
			
			pendingApprovalList=userRepo.findAll();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return pendingApprovalList;
	}

	@Override
	public com.ekutir.sanimark.superadmin.entity.User getAdminDetails(String email) {
		com.ekutir.sanimark.superadmin.entity.User adminDetails=null;
		try{
			
			adminDetails=userRepo.findByEmail(email);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return adminDetails;
	}


}

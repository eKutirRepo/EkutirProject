package com.ekutir.sanimark.superadmin.util;

import java.util.List;
import java.util.Map;

public class ResponseUtil {
	
	private int status;
	private Object object;
	private String message;
	private List<Map<String, Object>> dashboardObject;
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Object getObject() {
		return object;
	}
	public void setObject(Object object) {
		this.object = object;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<Map<String, Object>> getDashboardObject() {
		return dashboardObject;
	}
	public void setDashboardObject(List<Map<String, Object>> dashboardObject) {
		this.dashboardObject = dashboardObject;
	}
	
	
	
	

}

package com.ekutir.sanimark.superadmin.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekutir.sanimark.superadmin.entity.EkutirGatewayRegd;




public interface DashboardTotalMe extends JpaRepository<EkutirGatewayRegd, Long> {
	
	
	String TOTALME="select count(*) from EkutirGatewayRegd where status=1 and application=5";

	
	
	@Query(TOTALME)
	Long countTotalME();
	

	
}

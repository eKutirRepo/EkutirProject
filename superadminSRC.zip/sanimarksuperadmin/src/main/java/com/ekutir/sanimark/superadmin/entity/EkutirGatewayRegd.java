package com.ekutir.sanimark.superadmin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gtwy_registration")
public class EkutirGatewayRegd implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4411336192955968819L;

	@Id
	@Column(name="registration_id")
	private Long registrationId;
	
	@Column(name="phone_number")
	private Long phoneNumber;
	
	@Column(name="aadhar_number")
	private String aadharNumber;
	
	@Column(name="imei")
	private String imeiNumber;
	
	@Column(name="otp")
	private int otp;
	
	@Column(name="date_time_of_registration")
	private Date registartionDate;
	
	@Column(name="registration_end_date_time")
	private Date registrationEndDateTime;
	
	@Column(name="status")
	private int status;
	
	@Column(name="tin_number")
	private String tinNumber;
	
	@Column(name="application")
	private int application;
	
	@Column(name="bank_account_name")
	private String bankAccountName;
	
	@Column(name="bank_account_number")
	private String bankAccountNumber;
	
	@Column(name="bank_name")
    private String bankName;
	
	@Column(name="ban_ifsc_code")
	private String bankIfscCode;

	public Long getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(Long registrationId) {
		this.registrationId = registrationId;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getImeiNumber() {
		return imeiNumber;
	}

	public void setImeiNumber(String imeiNumber) {
		this.imeiNumber = imeiNumber;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public Date getRegistartionDate() {
		return registartionDate;
	}

	public void setRegistartionDate(Date registartionDate) {
		this.registartionDate = registartionDate;
	}

	public Date getRegistrationEndDateTime() {
		return registrationEndDateTime;
	}

	public void setRegistrationEndDateTime(Date registrationEndDateTime) {
		this.registrationEndDateTime = registrationEndDateTime;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getTinNumber() {
		return tinNumber;
	}

	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}

	public int getApplication() {
		return application;
	}

	public void setApplication(int application) {
		this.application = application;
	}

	public String getBankAccountName() {
		return bankAccountName;
	}

	public void setBankAccountName(String bankAccountName) {
		this.bankAccountName = bankAccountName;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankIfscCode() {
		return bankIfscCode;
	}

	public void setBankIfscCode(String bankIfscCode) {
		this.bankIfscCode = bankIfscCode;
	}

	public EkutirGatewayRegd() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EkutirGatewayRegd(Long registrationId, Long phoneNumber, String aadharNumber, String imeiNumber, int otp,
			Date registartionDate, Date registrationEndDateTime, int status, String tinNumber, int application,
			String bankAccountName, String bankAccountNumber, String bankName, String bankIfscCode) {
		super();
		this.registrationId = registrationId;
		this.phoneNumber = phoneNumber;
		this.aadharNumber = aadharNumber;
		this.imeiNumber = imeiNumber;
		this.otp = otp;
		this.registartionDate = registartionDate;
		this.registrationEndDateTime = registrationEndDateTime;
		this.status = status;
		this.tinNumber = tinNumber;
		this.application = application;
		this.bankAccountName = bankAccountName;
		this.bankAccountNumber = bankAccountNumber;
		this.bankName = bankName;
		this.bankIfscCode = bankIfscCode;
	}
	
	
	
	
	
	

}

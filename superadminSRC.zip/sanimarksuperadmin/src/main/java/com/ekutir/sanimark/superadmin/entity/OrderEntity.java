package com.ekutir.sanimark.superadmin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_order_header_master")
public class OrderEntity implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2331561209909664333L;

	@Id
	@Column(name="OrderID")
	private Long orderId;
	
	@Column(name="UserID")
	private int userId;
	
	@Column(name="OrderDate")
	private String orderDate;
	
	@Column(name="PaymentId")
	private String paymentId;
	
	@Column(name="DeliveryRequestedFromDate")
	private Date deliveryRequestFromDate;
	
	@Column(name="OrderDiscount")
	private double orderDiscount;
	
	@Column(name="Adjustments")
	private double adjustments;
	
	@Column(name="OrderAmount")
	private double orderAmount;
	
	@Column(name="OrderPaymentMode")
	private String  orderpaymentMode;
	
	@Column(name="Status")
	private int status;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="created_at")
	private String createdAt;
	
	@Column(name="updated_by")
	private String updatedBy;
	
	@Column(name="updated_at")
	private String updatedAt;
	
	@Column(name="DeliveryRequestedToDate")
	private Date deliveryRequestToDate;

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public Date getDeliveryRequestFromDate() {
		return deliveryRequestFromDate;
	}

	public void setDeliveryRequestFromDate(Date deliveryRequestFromDate) {
		this.deliveryRequestFromDate = deliveryRequestFromDate;
	}

	public double getOrderDiscount() {
		return orderDiscount;
	}

	public void setOrderDiscount(double orderDiscount) {
		this.orderDiscount = orderDiscount;
	}

	public double getAdjustments() {
		return adjustments;
	}

	public void setAdjustments(double adjustments) {
		this.adjustments = adjustments;
	}

	public double getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(double orderAmount) {
		this.orderAmount = orderAmount;
	}

	public String getOrderpaymentMode() {
		return orderpaymentMode;
	}

	public void setOrderpaymentMode(String orderpaymentMode) {
		this.orderpaymentMode = orderpaymentMode;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeliveryRequestToDate() {
		return deliveryRequestToDate;
	}

	public void setDeliveryRequestToDate(Date deliveryRequestToDate) {
		this.deliveryRequestToDate = deliveryRequestToDate;
	}
	
	
	
	
	
	
	
	
	

}

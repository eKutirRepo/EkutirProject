package com.ekutir.sanimark.superadmin.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.sanimark.superadmin.dto.AccessTokenDTO;
import com.ekutir.sanimark.superadmin.dto.User;
import com.ekutir.sanimark.superadmin.security.AuthorizedUserDetails;
import com.ekutir.sanimark.superadmin.service.UserService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@PropertySource(ignoreResourceNotFound = true, value = "classpath:application.properties")
@RestController
public class BaseController {

	@Value("${authentication.oauth.clientid}")
	private  String clientId;
	
	@Value("${authentication.oauth.secret}")
	private  String clientSecret;
	
	@Autowired
	private UserService userService;
	
	private final static String OAUTH_TOKEN_URL = "http://localhost:8082/api/oauth/token?grant_type=password"; 
	
	@RequestMapping(value="/auth/header", produces="application/json", method=RequestMethod.GET)
	public ResponseEntity<ResponseUtil> getBasicAuthHeader(){
		String authStringEnc="";
		ResponseUtil response = new ResponseUtil();
		if(StringUtils.isNotEmpty(clientId) && StringUtils.isNotBlank(clientSecret)){
		String authString=clientId+":"+clientSecret;
		byte[] authEncBytes = Base64.encodeBase64(authString.getBytes());
		 authStringEnc = new String(authEncBytes);
		 response.setObject(authStringEnc);
		}else{
			response.setObject(authStringEnc);
		}
		return new ResponseEntity<ResponseUtil>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value="/basic/token", produces="application/json", method=RequestMethod.GET)
	public ResponseEntity<ResponseUtil> getBasicAuthToken(@RequestParam(value="username") String username, 
			@RequestParam(value="password") String password, @RequestParam(value="authheader") String authheader ){
		ResponseUtil responseObj = new ResponseUtil();
		ResponseEntity<ResponseUtil> responseEntity = new ResponseEntity<ResponseUtil>(HttpStatus.NO_CONTENT);
		User user = userService.findByEmail(username);
		HttpResponse response=null;
		if(user.getId()!=null){
		HttpClient httpClient =  HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(OAUTH_TOKEN_URL+"&username="+username+"&password="+password);

		// add request header
		request.addHeader("Authorization", "Basic "+ authheader);
		request.addHeader("Accept", "application/json");
		
		try {
			response = httpClient.execute(request);
			System.out.println("Response Code : "
	                + response.getStatusLine().getStatusCode());

			BufferedReader rd = new BufferedReader(
				new InputStreamReader(response.getEntity().getContent()));
		
			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			
			ObjectMapper mapper = new ObjectMapper();
			AccessTokenDTO accessTokenDto = mapper.readValue(result.toString(), AccessTokenDTO.class);
			user.setLoginToken(accessTokenDto);
			responseObj.setStatus(200);
			responseObj.setObject(user);
			responseEntity = new ResponseEntity<ResponseUtil>(responseObj,HttpStatus.OK);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			responseObj.setStatus(response.getStatusLine().getStatusCode());
			responseEntity = new ResponseEntity<ResponseUtil>(responseObj,HttpStatus.EXPECTATION_FAILED);
		} catch (IOException e) {
			e.printStackTrace();
			responseObj.setStatus(response.getStatusLine().getStatusCode());
			responseEntity = new ResponseEntity<ResponseUtil>(responseObj,HttpStatus.EXPECTATION_FAILED);
		}
		}
	
		return responseEntity;
		
	}
}

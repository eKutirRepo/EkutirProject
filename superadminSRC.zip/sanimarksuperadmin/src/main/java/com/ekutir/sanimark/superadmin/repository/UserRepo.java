package com.ekutir.sanimark.superadmin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekutir.sanimark.superadmin.entity.User;

public interface UserRepo extends JpaRepository<User, Long> {
	


	public User findByEmail(String email);

	
	
}

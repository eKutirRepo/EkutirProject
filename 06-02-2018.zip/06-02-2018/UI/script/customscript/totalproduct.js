
var reuseArrayHeader;
var responseDataReuse;

$(document).ready(function () {

	responseDataReuse=[
		  {
		    "productid": 1,
		    "product_name": "Organica Biotech",
		    "category_name": "Bathroom Accessories",
		    "active_status": "Active"
		  },
		  {
		    "productid": 2,
		    "product_name": "Lixil Sato Connecter",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		  },
		  {
		    "productid": 3,
		    "product_name": "Sato Foot Rest",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		  },
		  {
		    "productid": 4,
		    "product_name": "Johnson Wash Basins",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		   
		  },
		  {
		    "productid": 5,
		    "product_name": "Svadha Padestals",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		   
		  },
		  {
		    "productid": 6,
		    "product_name": "Svadha Basins",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		   
		  },
		  {
		    "productid": 7,
		    "product_name": "Svadha Commodes",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		   
		  },
		  {
		    "productid": 8,
		    "product_name": "Johnson Anglo Seat Cover",
		    "category_name": "Bathroom Accessories",
		    "active_status":  "Active"
		   
		  },
		  {
		    "productid": 9,
		    "product_name": "Johnson CP Fittings",
		    "category_name": "Bathroom Accessories",
		    "active_status":  "Active"
		   
		  },
		  {
		    "productid": 10,
		    "product_name": "Lixil Sato Pan",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		  },
		  {
		    "productid": 11,
		    "product_name": "Svadha Orissa Pan",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		  },
		  {
		    "productid": 12,
		    "product_name": "Johnson Commodes",
		    "category_name": "Sanitaryware",
		    "active_status":  "Active"
		  }
		]
	
	
	reuseArrayHeader = [
		{ "sTitle": "S.No", "mData": "productid" },
		{ "sTitle": "Supplier Name", "mData": "product_name" },
		{ "sTitle": "Category Name", "mData": "category_name" },
		{ "sTitle": "Status", "mData": "active_status" }
		]
	
	showReuseTableData(responseDataReuse);
});

function showReuseTableData(responseDataReuse){

	
	
	$('#totalproductid').addClass( 'nowrap' ).dataTable({
		"aaData": responseDataReuse,
		dom: 'lBfrtip',
		"bFilter" : true, 
		"bPaginate": true,
		"lengthMenu": [5,10,15,20],
		buttons: ['excel' , 'print','copyHtml5'],
		// "scrollY": 200,
		fixedHeader: true,

		"scrollX": true,
		"aoColumns":reuseArrayHeader

	}); 
} 






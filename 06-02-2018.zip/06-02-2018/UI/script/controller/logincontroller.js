'use strict';

MyApp.controller('LoginController', ['$scope','AuthService', function($scope, AuthService) {
	
		$scope.login=function(){
		console.log($scope.user);
		$('#progress').show();
		AuthService.login($scope.user)
		.then(function(data){
			console.log(data);
				if(data.object==""){
					console.log(data);
				}else{
					//alert("Success");
					console.log(data);
					
					
					
					$.jStorage.set("user", data.object);
					$.jStorage.set("token", data.object.randomNumer);
					/*if(data.object.loginToken.access_token==null){
						console.log(data.object.loginToken.error_description);
					}else{*/
						$('#progress').hide();
						if(data.object.role.toUpperCase()=="ROLE_ADMIN" && data.object.profilecompletedstatus==0){
					
						 /* window.location.href="http://localhost:8080/sanimarkWeb/admin-home.html";*/
							
							 window.location.href="http://13.126.219.190:8080/sanimarkweb/admin-home.html";
							
						  
						}else if(data.object.role.toUpperCase()=="ROLE_ADMIN" && data.object.profilecompletedstatus==1){
							
							/* window.location.href="http://localhost:8080/sanimarkWeb/admindashboard.html";*/
							
							window.location.href="http://13.126.219.190:8080/sanimarkweb/admindashboard.html";
						}
						
						else if(data.object.role.toUpperCase()=="ROLE_SUPER_ADMIN" && data.object.profilecompletedstatus==3){
							console.log("success coming");
						/*  window.location.href="http://localhost:8080/sanimarkWeb/home.html";*/
						/*}*/
							
							window.location.href="http://13.126.219.190:8080/sanimarkweb/home.html";
					}
				
			}
		},function(data){
			$('#progress').hide();
			console.log(data)
		});
		
		}
		
	
          
}]);
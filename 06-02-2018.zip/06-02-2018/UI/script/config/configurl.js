/*'use strict';

MyApp.value("baseUrl","http://")*/
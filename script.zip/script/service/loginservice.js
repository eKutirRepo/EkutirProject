'use strict';
MyApp.factory('AuthService', ['$http', '$q', function($http, $q){

	var AuthService={
			getAuthToken:getAuthToken,
			generateBasicAuth:generateBasicAuth
	}
	return AuthService;
	
	function generateBasicAuth(){
		var defer = $q.defer();
		
		$http.get("http://localhost:8082/api/auth/header")
			.success(function(response) {
				console.log(response);
				defer.resolve(response);
			})
			.error(function(err) {
				console.log(err);
				defer.reject(err);
			});
			
		return defer.promise;
	}
	function getAuthToken(user, basicAuth){
		var defer = $q.defer();
		var url='http://localhost:8082/api/basic/token?username='+user.userName+'&password='+user.password+"&authheader="+basicAuth;
		$http.get(url)
			.success(function(response) {
				console.log(response);
				defer.resolve(response);
			})
			.error(function(err) {
				console.log(err);
				defer.reject(err);
			});
			
		return defer.promise;
	}
	
		

}]);

MyApp.factory('LoginService', ['$http', '$q', function($http, $q){

	var LoginService={
			login:login	
	}
	return LoginService;
	
	function login(user){
		var defer = $q.defer(user);
		
		$http.post("http://localhost:8082/login",JSON.stringify(user))
			.success(function(response) {
				defer.resolve(response);
			})
			.error(function(err) {
				defer.reject(err);
			});
			
		return defer.promise;
	}
	
		

}]);

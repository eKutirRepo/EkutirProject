package com.ekutir.sanimark.superadmin.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ekutir.sanimark.superadmin.dto.User;
import com.ekutir.sanimark.superadmin.repository.UserRepo;

@Service("userService")
@Transactional
public class UserServiceImpl implements com.ekutir.sanimark.superadmin.service.UserService {


	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private UserRepo userRepo;
	

	@Override
	public User findByEmail(final String email) {
		com.ekutir.sanimark.superadmin.entity.User user = userRepo.findByEmail(email);
		User savedUser = new User();
		if(user!=null){
			BeanUtils.copyProperties(user, savedUser);
			savedUser.setRole(user.getUserRole().getRole().getRoleName());
		}
		return savedUser;
	}

	
}

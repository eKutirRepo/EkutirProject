package com.ekutir.sanimark.superadmin.security;

public enum Authorities {

    ROLE_ANONYMOUS,
    ROLE_ADMIN,
    ROLE_SUPER_ADMIN,
    ROLE_SUPPLIER,
    ROLE_ME,
}

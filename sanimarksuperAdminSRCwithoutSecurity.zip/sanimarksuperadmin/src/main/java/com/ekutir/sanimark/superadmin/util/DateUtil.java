package com.ekutir.sanimark.superadmin.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

public class DateUtil {

	public static final String DATE_FORMAT_DDMMYYYY = SanimarkConstants.DATE_FORMAT_DDMMYYYY;
	public static final String DATE_FORMAT_DDMMYYYYHHMM = SanimarkConstants.DATE_FORMAT_DDMMYYYYHHMMA;
	public static final String DATE_FORMAT_DDMMMYYYY = SanimarkConstants.DATE_FORMAT_DDMMMYYYY;
	public static final String SQL_DATE_FORMAT = SanimarkConstants.DATE_FORMAT_YYYYMMDD;

	public static Date StringToDate(String strDate) {
		Date date = null;
		try {
			if(strDate!=null){
				SimpleDateFormat formatter = new SimpleDateFormat(
					DATE_FORMAT_DDMMYYYY);
				date = (Date) formatter.parse(strDate);
			}

		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return date;
	}

	public static Date StringToDate(String strDate, String format) {
		Date date = null;
		try {
			if(strDate!=null){
				SimpleDateFormat formatter = new SimpleDateFormat(format);
				date = (Date) formatter.parse(strDate);
			}
		} catch (Exception e) {
			e.printStackTrace();
		
		}
		return date;
	}

	public static String DateToString(Date date) {
		String strDate = null;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(
					DATE_FORMAT_DDMMYYYY);
			if(date!=null){
				strDate = formatter.format(date);	
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return strDate;
	}

	public static String DateToString(Date date, String format) {
		String strDate = null;
		try {
			if(date!=null){
				SimpleDateFormat formatter = new SimpleDateFormat(format);
				strDate = formatter.format(date);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		
		}
		return strDate;
	}

	public static java.sql.Date DateToSqlDate(Date date) {
		java.sql.Date sqlDate = null;
		try {
			if(date!=null){
				sqlDate = new java.sql.Date(date.getTime());
			}
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return sqlDate;
	}

	public static java.sql.Date StringToSqlDate(String strDate) {
		Date date = null;
		java.sql.Date sqlDate = null;
		try {
			if(strDate!=null){
			SimpleDateFormat formatter = new SimpleDateFormat(
					DATE_FORMAT_DDMMYYYY);
			date = (Date) formatter.parse(strDate);
			sqlDate = new java.sql.Date(date.getTime());
			}
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return sqlDate;
	}

	public static boolean isDateGraterThenCurrentDate(Date date) {
		boolean result=false;
		try{
			if(date!=null){
				Calendar givenDate = Calendar.getInstance();
				givenDate.setTime(date);
				Calendar currentDate = Calendar.getInstance();
				result = givenDate.after(currentDate);
			}
			
		}catch(Exception e){
			e.printStackTrace();			
		}
		return result;

	}

	public static boolean isDateEqualsToCurrentDate(Date date) {
		boolean result=false;
		try{
			if(date!=null){
				Calendar givenDate = Calendar.getInstance();
				givenDate.setTime(date);
				Calendar currentDate = Calendar.getInstance();
				result = givenDate.equals(currentDate);
			}
			
		}catch(Exception e){
			e.printStackTrace();			
		}
		return result;
	}

	public static boolean isDateLessThenCurrentDate(Date date) {
		boolean result=false;
		try{
			if(date!=null){
				Calendar givenDate = Calendar.getInstance();
				givenDate.setTime(date);
				Calendar currentDate = Calendar.getInstance();
				result = givenDate.before(currentDate);
			}
			
		}catch(Exception e){
			e.printStackTrace();			
		}
		return result;
	}
	
	public static int getAge(Date dob) {
		int age = 0;
		try{
			if(dob!=null){
				Calendar calDob = Calendar.getInstance();
				calDob.setTime(dob);
				Calendar now = Calendar.getInstance();
				
				int bday = calDob.get(Calendar.DATE);
				int bmonth = calDob.get(Calendar.MONTH)+1;
				int byear = calDob.get(Calendar.YEAR);
				 
				int tday = now.get(Calendar.DATE);
				int tmonth = now.get(Calendar.MONTH)+1;
				int tyear = now.get(Calendar.YEAR);
				
				if(!((tmonth > bmonth)||(tmonth==bmonth & tday>=bday))){
					 byear++;
				 }
				 age = tyear-byear;
			}
			
		}catch(Exception e){
			e.printStackTrace();			
		}
		return age;
	}


	public static boolean getNoOfHours(Date optgeneratedDate) {
		Calendar calendar = Calendar.getInstance();
		long otpDate = optgeneratedDate.getTime();
		long currentDate = calendar.getTimeInMillis();
		long diff = currentDate - otpDate;
		long diffhours = diff / (60 * 60 * 1000);
		if (diffhours > 48)
		{
			return true;
		}
		else
		{
			return false;
	}
	}

	public static int getOtpGenerator() {
		int n = 1;
		int otp = 0;
		while (n != 0) {
			otp = (int) (Math.random() * (999999 - 000001) + 000001);
			String otpgenerator = Integer.toString(otp);
			if ((otpgenerator.length() == 6)) {
				n = 0;
				break;
			}
			n = 1;
		}
		return otp;
	}
	
	public static String reportDateConversion(long inputValue){
		inputValue=inputValue/1000;
		String format=String.format("%%0%dd", 2);
		String sec=String.format(format, inputValue%60);
		String min=String.format(format, (inputValue%3600)/60);
		String hrs=String.format(format, inputValue/3600);
		return hrs+":"+min+":"+sec;
	}
	
	public static Date getFirstDateOfCurrentMonth(){
		 Calendar calendar = Calendar.getInstance();
		 calendar.set(Calendar.DAY_OF_MONTH,Calendar.getInstance().getActualMinimum(Calendar.DAY_OF_MONTH));
		 return calendar.getTime();
		
	}
	
	
	public static String lastTwodigitofYear() {
		
		DateFormat df = new SimpleDateFormat("yy"); // Just the year, with 2 digits
		String formattedDate = df.format(Calendar.getInstance().getTime());
		
		return formattedDate;

	}
	
	public static String lastTwodigitMonth() {
		int month;
		GregorianCalendar date = new GregorianCalendar();      
		month = date.get(Calendar.MONTH);
		month = month+1;
		//month = 10;
		String cocat;

		if(month<=9) {
			cocat="0"+month;
		}
		else
		{
			cocat="";
			cocat=Integer.toString(month);
		}
		return cocat;
		
	}
	
	public static String lastTwodigitOfCurrentDate() {
	
		String currentDate="";
		
		String twodigitMonth="";
		
		try {
			Date date = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_DDMMYYYY);
			if(date!=null){
				currentDate = formatter.format(date);	
				twodigitMonth=currentDate.substring(0, 2);
			
			}
			
		}catch(Exception e) {
			
			
			
		}
		
		
		return twodigitMonth;
		
		
		
		
	}
	
/*	public static void main(String[] args) {
		
		String date=lastTwodigitOfCurrentDate();
		
		System.out.println(date);
	}
	*/
	
	/*public static void main(String args[])
    {		int month;
    		GregorianCalendar date = new GregorianCalendar();      
    		month = date.get(Calendar.MONTH);
    		//month = month+1;
    		month = 10;
    		String cocat;
    
    		if(month<=9) {
    			cocat="0"+month;
    
    		}else {
    			cocat="";
    			cocat=Integer.toString(month);
    		}
    		
    		System.out.println(cocat);

    }*/
		
	
}

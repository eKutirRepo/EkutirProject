package com.ekutir.sanimark.superadmin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_order_details_master",schema="dbsanimarkdlink")
public class OrderDetailMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8465605996352284406L;
	
	@Id
	@Column(name="OrderID")
	private Long orderId;
	
	@Column(name="ProductId")
	private int productId;
	
	@Column(name="OrderQuantity")
	private double orderQuantity;
	
	@Column(name="supplier_ack_status")
	private int supplierAckStatus;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="created_at")
	private String createdAt;
	
	@Column(name="updated_by")
	private String updatedBy;
	
	@Column(name="updated_at")
	private String updatedAt;
	
	@Column(name="order_details_id")
	private int orderDetailsId;
	
	@Column(name="actual_delivery_date")
	private Date  actualyDeliveryDate;
	
	@Column(name="rating")
	private double rating;
	
	@Column(name="comments")
	private String comment;

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public double getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(double orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public int getSupplierAckStatus() {
		return supplierAckStatus;
	}

	public void setSupplierAckStatus(int supplierAckStatus) {
		this.supplierAckStatus = supplierAckStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public int getOrderDetailsId() {
		return orderDetailsId;
	}

	public void setOrderDetailsId(int orderDetailsId) {
		this.orderDetailsId = orderDetailsId;
	}

	public Date getActualyDeliveryDate() {
		return actualyDeliveryDate;
	}

	public void setActualyDeliveryDate(Date actualyDeliveryDate) {
		this.actualyDeliveryDate = actualyDeliveryDate;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	
	
	
	
	

}

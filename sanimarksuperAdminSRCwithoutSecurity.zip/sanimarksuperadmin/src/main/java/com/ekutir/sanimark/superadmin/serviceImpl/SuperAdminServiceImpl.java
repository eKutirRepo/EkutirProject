package com.ekutir.sanimark.superadmin.serviceImpl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekutir.sanimark.superadmin.entity.Role;
import com.ekutir.sanimark.superadmin.entity.User;
import com.ekutir.sanimark.superadmin.entity.UserRole;
import com.ekutir.sanimark.superadmin.repository.RoleRepo;
import com.ekutir.sanimark.superadmin.repository.UserRepo;
import com.ekutir.sanimark.superadmin.security.Authorities;
import com.ekutir.sanimark.superadmin.service.SuperAdminService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

@Service("superAdminService")
public class SuperAdminServiceImpl implements SuperAdminService {

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private RoleRepo roleRepo;
	
	@Override
	public ResponseUtil approveUser(String email) {
		ResponseUtil response = new ResponseUtil();
		if(StringUtils.isNotBlank(email)){
			try{
			User user = userRepo.findByEmail(email);
			if(user!=null){
				List<Role> roleList = roleRepo.findAll();
				if(!roleList.isEmpty()){
					for(Role role:roleList){
						if(role.getRoleName().equals(Authorities.ROLE_ADMIN.name())){
							UserRole userRole = new UserRole();
							userRole.setRole(role);
							user.setUserRole(userRole);
							userRole.setUser(user);
							user.setEnabled(1);
							user.setStatus(1);
							/*user.setPassword(QuickPasswordEncodingGenerator.encodePassword("welcome2sanimark"));*/
							user = userRepo.save(user);
							if(user.getUserRole().getId()!=null){
								response.setStatus(200);
							}else{
								response.setStatus(500);
							}
							break;
						}
					}
				}
				
			}
			}catch(Exception e){
				e.printStackTrace();
				response.setStatus(500);
			}
		}
		return response;
	}

}

package com.ekutir.sanimark.superadmin.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="user",schema="dbsanimarkdlink")
public class User implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5510104336704968373L;
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(name="email")
	private String email;
	
	@Column(name="mobile")
	private String phone;
	
	@Column(name="description")
	private String description;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="enabled")
	private int enabled;
	
	@Column(name="version")
	private int version;
	
	@Column(name="password")
	private String password;
	
	@Column(name="status")
	private int status;
	
	@Column(name="profilecmpltstatus")
	private int profilecompletedstatus;

	@OneToOne(fetch = FetchType.EAGER, mappedBy = "user", cascade= CascadeType.ALL)
	private UserRole userRole;
	
	
	@OneToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL, mappedBy="user")
	private UserProfile userProfile;
	
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL, mappedBy="user")
	private Set<License> licenseList = new HashSet<License>(0);
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	public int getProfilecompletedstatus() {
		return profilecompletedstatus;
	}




	public void setProfilecompletedstatus(int profilecompletedstatus) {
		this.profilecompletedstatus = profilecompletedstatus;
	}




	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public Set<License> getLicenseList() {
		return licenseList;
	}

	public void setLicenseList(Set<License> licenseList) {
		this.licenseList = licenseList;
	}


	@Override
	public String toString() {
		return "User [id=" + id + ", email=" + email + ", phone=" + phone + ", description=" + description
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", enabled=" + enabled + ", version="
				+ version + ", password=" + password + ", status=" + status + ", profilecompletedstatus="
				+ profilecompletedstatus + ", userRole=" + userRole + ", userProfile=" + userProfile + ", licenseList="
				+ licenseList + "]";
	}




	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	
	
	
	
	

}

package com.ekutir.sanimark.superadmin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekutir.sanimark.superadmin.entity.User;

public interface UserRepo extends JpaRepository<User, Long> {
	
	String TOTALADMIN="from User where profilecompletedstatus!=3";


	public User findByEmail(String email);

	
	@Query(TOTALADMIN)
	public List<User> totalAdmin();

	
	
}

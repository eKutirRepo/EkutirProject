package com.ekutir.sanimark.superadmin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ekutir.sanimark.superadmin.entity.Role;

public interface RoleRepo extends JpaRepository<Role, Long> {

}

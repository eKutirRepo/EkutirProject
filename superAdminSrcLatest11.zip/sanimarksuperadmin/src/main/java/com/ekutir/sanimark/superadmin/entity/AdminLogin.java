package com.ekutir.sanimark.superadmin.entity;

import java.io.Serializable;

public class AdminLogin implements Serializable {
	
	private int id;
	
	private String adminName;
	
	private String countryName;
	
	private String stateName;
	
	private String licenseNo;
	
	private int licensePeriod;
	
	private String adminEmail;
	
	private String accessId;
	
	private String password;
	
    private String createdBy;
    
    private String updatedBy;
	
	
	
	
	
	

}

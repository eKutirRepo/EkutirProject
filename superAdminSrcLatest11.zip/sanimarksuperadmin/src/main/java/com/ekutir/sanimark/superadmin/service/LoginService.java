package com.ekutir.sanimark.superadmin.service;

import com.ekutir.sanimark.superadmin.dto.LoginDto;
import com.ekutir.sanimark.superadmin.exception.LoginException;

public interface LoginService {
	

	 LoginDto login(LoginDto user) throws LoginException;
	
	
	

}

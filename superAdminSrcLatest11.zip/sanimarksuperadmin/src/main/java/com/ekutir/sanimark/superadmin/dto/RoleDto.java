package com.ekutir.sanimark.superadmin.dto;

public class RoleDto {

}

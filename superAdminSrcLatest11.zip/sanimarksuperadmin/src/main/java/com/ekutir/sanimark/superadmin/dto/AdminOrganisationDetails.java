package com.ekutir.sanimark.superadmin.dto;

import java.io.Serializable;
import java.util.Date;

public class AdminOrganisationDetails implements Serializable{
	

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String organisationName;
	
	private String organisationRegdNo;
	
	private String address;
	
	private String phone;
	
	private String createdBy;
	
	private String updatedBy;
	
	private Date createdDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getOrganisationRegdNo() {
		return organisationRegdNo;
	}

	public void setOrganisationRegdNo(String organisationRegdNo) {
		this.organisationRegdNo = organisationRegdNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
	
	
	

}

package com.ekutir.sanimark.superadmin.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ekutir.sanimark.superadmin.dto.LoginDto;
import com.ekutir.sanimark.superadmin.service.LoginService;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;


@RestController
public class LoginController {
	
	@Autowired
	private LoginService loginService;
	
	@RequestMapping(value = "/hello", method = RequestMethod.GET, produces = "application/json")
	public String hello() {
		
		return "hello welcome to ekutir";
	}
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	public ResponseUtil sayHello(@RequestBody @Valid final LoginDto user){
		ResponseUtil response = new ResponseUtil();
		try {
			LoginDto checkSuperAdmin = loginService.login(user);
			
			if(null!=checkSuperAdmin){
				if ((checkSuperAdmin.getUserName().equalsIgnoreCase(user.getUserName()))
						&& (checkSuperAdmin.getPassword().equalsIgnoreCase(user.getPassword()))) {
					response.setObject(checkSuperAdmin);
					response.setStatus(200);
					response.setMessage("Success");
				} else {
					response.setMessage("Failure");
					response.setStatus(201);
				}
			}else{
				response.setMessage("NotExist");
				response.setStatus(201);
				
			}
		}catch (Exception ex) {
		
			
			return response;

		}
		
		return response;
	
		
		
	}
	

}

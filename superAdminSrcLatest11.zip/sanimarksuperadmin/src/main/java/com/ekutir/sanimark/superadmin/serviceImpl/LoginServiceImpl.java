package com.ekutir.sanimark.superadmin.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ekutir.sanimark.superadmin.dto.LoginDto;
import com.ekutir.sanimark.superadmin.exception.LoginException;
import com.ekutir.sanimark.superadmin.repository.LoginRepository;
import com.ekutir.sanimark.superadmin.service.LoginService;

@Component
public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginRepository loginRepo;
	
	@Override
	public LoginDto login(LoginDto user)throws LoginException {
		
		LoginDto isexistUser;
		
		try {
			isexistUser = loginRepo.login(user.getUserName());
		} catch (Exception e) {
			throw new LoginException("Error while login to  superAdmin", e);
		}
		return isexistUser;
	}

}

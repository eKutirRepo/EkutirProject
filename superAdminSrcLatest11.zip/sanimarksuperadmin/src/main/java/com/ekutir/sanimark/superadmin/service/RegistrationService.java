package com.ekutir.sanimark.superadmin.service;

import java.util.List;

import com.ekutir.sanimark.superadmin.dto.User;
import com.ekutir.sanimark.superadmin.exception.LoginException;
import com.ekutir.sanimark.superadmin.util.ResponseUtil;

public interface RegistrationService {
	

	public ResponseUtil registerUser(User user) throws LoginException;
	public List<User> pendingApproval();
	
	
	

}

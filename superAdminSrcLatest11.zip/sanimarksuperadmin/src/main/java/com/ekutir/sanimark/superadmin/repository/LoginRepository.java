package com.ekutir.sanimark.superadmin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ekutir.sanimark.superadmin.dto.LoginDto;


public interface LoginRepository extends JpaRepository<LoginDto, Long> {
	
String CHECK_SUPER_ADMIN = "from LoginDto user where user.userName=?1";
	
	@Query(CHECK_SUPER_ADMIN)
	LoginDto login(String userName);

}
